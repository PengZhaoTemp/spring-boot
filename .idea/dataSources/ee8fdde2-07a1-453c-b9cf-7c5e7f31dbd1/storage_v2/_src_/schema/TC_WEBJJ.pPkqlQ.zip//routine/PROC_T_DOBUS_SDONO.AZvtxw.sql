create Procedure          proc_t_dobus_sdono
(
     lvoldsdono VARCHAR2,  --旧办理编号
     lvReturn IN OUT VARCHAR2, --新办理编号
     lvsno IN OUT varchar2--材料编号
)
as
 lvstate varchar2(20);
 cursor c is
     select *  from tc_webjj.t_dobus
     where 1=1
     and sdono=lvoldsdono;   --办理编号
  d c%rowtype;

 cursor b is
     select *  from tc_webjj.t_applymasterdata
     where 1=1
     and sdono=lvoldsdono;   --关系编号
    e b%rowtype;
begin

    for d in c loop
   INSERT into tc_webjj.t_dobus
    (
      sdono,   --办理编号
      sbusno,   --业务编码
      sdounit,   --办理单位
      sdounitno,   --办理单位编码
      suserno,   --用户编码
      state,   --状　　态
      sbooking,   --sbooking
      dbookingdate,   --预约时间
      snotealert,   --是否短信提醒
      ncharge,   --支付金额
      nsercharge,   --服务资费
      nexpcharge,   --快递资费
      nrecharge,   --回寄资费
      sexpno,   --快递单号
      sexpaddress,   --快递地址
      sexppostcode,   --快递地址邮政编码
      sconsignee,   --收  件 人
      scontel,   --收件人联系电话
      snetbus,   --是否网上下单
      sreno,   --回寄快递单号
      sreaddress,   --回寄地址
      srepostcode,   --回寄地址邮政编码
      srecon,   --回寄收件人
      srecontel,   --回寄收件人联系电话
      ddecdate,   --申报时间
      schecker,   --审  核 人
      dcheckdate,   --审核时间
      sacceptman,   --受  理 人
      sacceptdate,   --受理时间
      sunreason,   --退回原因
      sopinion,   --评价内容
      sserattitude,   --服务态度得分
      sefficiency,   --办事效率得分
      ssatisfaction,   --满  意 度
      sopdate,   --评价时间
      sdodata,   --业务数据概要
      sprocity,   --回寄省市
      address,   --回寄详细地址
      sreems,   --sreems
      semssend,   --semssend
      sbotime    --预约时间段
    )values(
      lvReturn,   --办理编号
      d.sbusno,   --业务编码
      d.sdounit,   --办理单位
      d.sdounitno,   --办理单位编码
      d.suserno,   --用户编码
      '10',   --状　　态
      d.sbooking,   --sbooking
      d.dbookingdate,   --预约时间
      d.snotealert,   --是否短信提醒
      d.ncharge,   --支付金额
      d.nsercharge,   --服务资费
      d.nexpcharge,   --快递资费
      d.nrecharge,   --回寄资费
      '',   --快递单号
      d.sexpaddress,   --快递地址
      d.sexppostcode,   --快递地址邮政编码
      d.sconsignee,   --收  件 人
      d.scontel,   --收件人联系电话
      d.snetbus,   --是否网上下单
      '',   --回寄快递单号
      d.sreaddress,   --回寄地址
      d.srepostcode,   --回寄地址邮政编码
      d.srecon,   --回寄收件人
      d.srecontel,   --回寄收件人联系电话
      sysdate,   --申报时间
      d.schecker,   --审  核 人
      d.dcheckdate,   --审核时间
      d.sacceptman,   --受  理 人
      d.sacceptdate,   --受理时间
      d.sunreason,   --退回原因
      d.sopinion,   --评价内容
      d.sserattitude,   --服务态度得分
      d.sefficiency,   --办事效率得分
      d.ssatisfaction,   --满  意 度
      d.sopdate,   --评价时间
      d.sdodata,   --业务数据概要
      d.sprocity,   --回寄省市
      d.address,   --回寄详细地址
      d.sreems,   --sreems
      d.semssend,   --semssend
      d.sbotime    --预约时间段
    );
    lvstate:=d.state;
    end loop;
    for e in b loop
       select  fun_get16code(tc_webjj.seq_applymasterdata_nid.Nextval) into  lvsno from dual where 1=1;
        INSERT into tc_webjj.t_applymasterdata
    (
      sno,   --关系编号
      sdono,   --办理编号
      smasterialsno,   --材料编号
      smasterialsname,   --材料名称
      smasterialspath,   --材料路径
      dupload    --上传时间
    )values(
      lvsno,   --关系编号
      lvReturn,   --办理编号
      e.smasterialsno,   --材料编号
      e.smasterialsname,   --材料名称
      e.smasterialspath,   --材料路径
      sysdate   --上传时间
    );
    end loop  ;

    IF lvstate='32' THEN
    UPDATE tc_webjj.t_dobus
    Set
    state='36'
    where sdono=lvoldsdono;
    ELSE
      UPDATE tc_webjj.t_dobus
    Set
    state='35'
    where sdono=lvoldsdono;
    END IF;


commit;
end;

/

