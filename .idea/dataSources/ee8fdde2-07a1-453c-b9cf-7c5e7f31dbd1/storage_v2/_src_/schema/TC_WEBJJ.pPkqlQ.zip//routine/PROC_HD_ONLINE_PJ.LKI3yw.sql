create procedure          proc_hd_online_pj(lv_NID          in out number,
                                              lv_STYPE        varchar2,
                                              lv_DWMC         varchar2,
                                              lv_DWDM         varchar2,
                                              lv_MJXM         varchar2,
                                              lv_MJJH         varchar2,
                                              lv_MJYHBH       varchar2,
                                              lv_SPJ          varchar2,
                                              lv_SPJ_MEMO     varchar2,
                                              lv_SIP          varchar2,
                                              lv_SPJ_PERSONID varchar2,
                                              lv_ProcMode     varchar2,
                                              lv_msg_return   in out varchar2) as
  lv_count number;

begin
  if lv_ProcMode = 'PMINSERT' then
    if lv_STYPE = '单位' then
      select count(0)
        into lv_count
        from tc_webjj.T_HD_Online_PJ
       where SPJ_PERSONID = lv_SPJ_PERSONID
         and STYPE = lv_STYPE
         and DWDM = lv_DWDM
         and DPJDATE > trunc(sysdate)
         and DPJDATE < trunc(sysdate + 1);
    else
      select count(0)
        into lv_count
        from tc_webjj.T_HD_Online_PJ
       where SPJ_PERSONID = lv_SPJ_PERSONID
         and STYPE = lv_STYPE
         and DWDM = lv_DWDM
         and MJYHBH = lv_MJYHBH
         and DPJDATE > trunc(sysdate)
         and DPJDATE < trunc(sysdate + 1);
    end if;
    if lv_count > 0 then
      lv_msg_return := '每人每天对单个单位及个人只能投1票，多投无效';
    else
      select tc_webjj.SEQ_HD_ONLINE_PJ_NID.nextval into lv_NID from dual; --
      insert into tc_webjj.T_HD_Online_PJ
        (NID,
         STYPE,
         DWMC,
         DWDM,
         MJXM,
         MJJH,
         MJYHBH,
         SPJ,
         SPJ_MEMO,
         SIP,
         SPJ_PERSONID)
      values
        (lv_NID,
         lv_STYPE,
         lv_DWMC,
         lv_DWDM,
         lv_MJXM,
         lv_MJJH,
         lv_MJYHBH,
         lv_SPJ,
         lv_SPJ_MEMO,
         lv_SIP,
         lv_SPJ_PERSONID);
      lv_msg_return := '操作成功';
    end if;
  end if;
  commit;
end proc_hd_online_pj;

/

