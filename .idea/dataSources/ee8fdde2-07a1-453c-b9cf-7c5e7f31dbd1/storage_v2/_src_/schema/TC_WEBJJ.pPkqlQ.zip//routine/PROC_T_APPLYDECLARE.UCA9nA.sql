create PROCEDURE          PROC_t_applydeclare   /*T_APPLYDECLARE*/
(
 lvsrelationno IN OUT VARCHAR2,  --关系编号
 lvsdodeclareno VARCHAR2,  --申报表办理编号
 lvsno VARCHAR2,  --材料编号
 lvsitem VARCHAR2,  --材料名称
 lvspath VARCHAR2,  --材料路径
 lvdupdate DATE,  --上传时间
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS

BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/

    Select TC_WEBJJ.SEQ_T_APPLYDECLARE_SRELATIONNO.Nextval  into lvsrelationno From dual;    /*关系编号序列*/


   INSERT into tc_webjj.t_applydeclare
    (
      srelationno,   --关系编号
      sdodeclareno,   --申报表办理编号
      sno,   --材料编号
      sitem,   --材料名称
      spath,   --材料路径
      dupdate    --上传时间
    )values(
      lvsrelationno,   --关系编号
      lvsdodeclareno,   --申报表办理编号
      lvsno,   --材料编号
      lvsitem,   --材料名称
      lvspath,   --材料路径

      sysdate    --上传时间


    );
   -- 返回值

END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_applydeclare
    Set
      srelationno=lvsrelationno,   --关系编号
      sdodeclareno=lvsdodeclareno,   --申报表办理编号
      sno=lvsno,   --材料编号
      sitem=lvsitem,   --材料名称
      spath=lvspath,   --材料路径
      dupdate=sysdate    --上传时间
    Where 1=1
    and srelationno=lvsrelationno   --关系编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_applydeclare
    Where 1=1
    and srelationno=lvsrelationno   --关系编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

