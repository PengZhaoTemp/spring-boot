create PROCEDURE          PROC_t_bir_declare_new /*出生申报表*/

(

 lvhu_master_name  VARCHAR2, --户主姓名

 lvhu_master_pid VARCHAR2, --户主公民身份号码

 lvmaster_relation VARCHAR2, --与户主关系

 lvwhen_logged DATE, --与与户主关系创建时间

 lvpid VARCHAR2, --公民身份号码

 lvname VARCHAR2, --姓　　名

 lvgender VARCHAR2, --性　　别

 lvused_name VARCHAR2, --曾  用 名

 lvnation VARCHAR2, --民　　族

 lvnative_country VARCHAR2, --籍贯（国家地区）

 lvnative_place VARCHAR2, --籍贯（省市县区）

 lvdob DATE, --出生日期

 lvdob_time VARCHAR2, --出生时间

 lvnatal_country VARCHAR2, --出生地（国家地区）

 lvnatal_place VARCHAR2, --出生地（省市县区）

 lvnatal_xiang VARCHAR2, --出生地详址

 lvgurardian_1_id NUMBER, --监护人1编号

 lvgurardian_1_pid VARCHAR2, --监护人1公民身份号码

 lvgurardian_1 VARCHAR2, --监护人1姓名

 lvwardship_1 VARCHAR2, --与监护人1关系

 lvgurardian_2_id NUMBER, --监护人2编号

 lvgurardian_2_pid VARCHAR2, --监护人2公民身份号码

 lvgurardian_2 VARCHAR2, --监护人2姓名

 lvwardship_2 VARCHAR2, --与监护人2关系

 lvfa_person_id NUMBER, --父亲人员编号

 lvfa_pid VARCHAR2, --父亲公民身份号码

 lvfa_name VARCHAR2, --父亲姓名

 lvma_person_id NUMBER, --母亲人员编号

 lvma_pid VARCHAR2, --母亲公民身份号码

 lvma_name VARCHAR2, --母亲姓名

 lvbloodtype VARCHAR2, --血　　型

 lvscontact VARCHAR2, --联系方式

 lvin_category VARCHAR2, --出生原因

 lvborn_card_no VARCHAR2, --出生证号码

 lvnatal_card_date DATE, --出生证签发日期

 lvwhen_in DATE, --出生申报时间

 lvsend_hu NUMBER, --是否要打印户口本

 lvin_hu_kind VARCHAR2, --落户类型

 lvin_app_name varchar2,--申请人姓名

 lvin_app_pid varchar2,--申请人身份证号
 lvmemo varchar2,--备注
 lvsdono IN OUT VARCHAR2, --办理编号


 lv_ProcMode Varchar2, /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
 lv_ProcFlag varchar2 --区别是保存还是提交
 )

 AS
 lvdbbj varchar2(1);
 lvdbsj date;
BEGIN

   IF lv_ProcFlag='PMSUBMIT' THEN
    lvdbbj:='0';
    lvdbsj:=sysdate;
   END IF;
  --begin TRAN

  IF lv_procMode = 'PMINSERT' THEN
    /*登记*/

    INSERT into tc_webjj.t_bir_declare

      (
       sdono,--业务编号
       hu_master_name, --户主姓名

       hu_master_pid, --户主公民身份号码

       master_relation, --与户主关系

       when_logged, --与与户主关系创建时间

       pid, --公民身份号码

       name, --姓　　名

       gender, --性　　别

       used_name, --曾  用 名

       nation, --民　　族

       native_country, --籍贯（国家地区）

       native_place, --籍贯（省市县区）

       dob, --出生日期

       dob_time, --出生时间

       natal_country, --出生地（国家地区）

       natal_place, --出生地（省市县区）

       natal_xiang, --出生地详址

       gurardian_1_id, --监护人1编号

       gurardian_1_pid, --监护人1公民身份号码

       gurardian_1, --监护人1姓名

       wardship_1, --与监护人1关系

       gurardian_2_id, --监护人2编号

       gurardian_2_pid, --监护人2公民身份号码

       gurardian_2, --监护人2姓名

       wardship_2, --与监护人2关系

       fa_person_id, --父亲人员编号

       fa_pid, --父亲公民身份号码

       fa_name, --父亲姓名

       ma_person_id, --母亲人员编号

       ma_pid, --母亲公民身份号码

       ma_name, --母亲姓名

       bloodtype, --血　　型

       scontact, --联系方式

       in_category, --出生原因

       born_card_no, --出生证号码

       natal_card_date, --出生证签发日期

       when_in, --出生申报时间

       send_hu, --是否要打印户口本

       in_hu_kind,--落户类型
       in_app_name,
       in_app_pid ,
       memo,
       dbbj,
       dbsj
      )
    values
      (
       lvsdono,
       lvhu_master_name, --户主姓名

       lvhu_master_pid, --户主公民身份号码

       lvmaster_relation, --与户主关系

       sysdate, --与与户主关系创建时间

       lvpid, --公民身份号码

       lvname, --姓　　名

       lvgender, --性　　别

       lvused_name, --曾  用 名

       lvnation, --民　　族

       lvnative_country, --籍贯（国家地区）

       lvnative_place, --籍贯（省市县区）

       lvdob, --出生日期

       lvdob_time, --出生时间

       lvnatal_country, --出生地（国家地区）

       lvnatal_place, --出生地（省市县区）

       lvnatal_xiang, --出生地详址

       lvgurardian_1_id, --监护人1编号

       lvgurardian_1_pid, --监护人1公民身份号码

       lvgurardian_1, --监护人1姓名

       lvwardship_1, --与监护人1关系

       lvgurardian_2_id, --监护人2编号

       lvgurardian_2_pid, --监护人2公民身份号码

       lvgurardian_2, --监护人2姓名

       lvwardship_2, --与监护人2关系

       lvfa_person_id, --父亲人员编号

       lvfa_pid, --父亲公民身份号码

       lvfa_name, --父亲姓名

       lvma_person_id, --母亲人员编号

       lvma_pid, --母亲公民身份号码

       lvma_name, --母亲姓名

       lvbloodtype, --血　　型

       lvscontact, --联系方式

       '出生', --出生原因

       lvborn_card_no, --出生证号码

       lvnatal_card_date, --出生证签发日期

       sysdate, --出生申报时间

       lvsend_hu, --是否要打印户口本

       '入户', --落户类型
       lvin_app_name,
       lvin_app_pid,
       lvmemo,
       lvdbbj,
       lvdbsj
       );

    -- 返回值

  END IF;

  IF lv_procMode = 'PMUPDATE' THEN
    /*更新*/

    UPDATE tc_webjj.t_bir_declare

       Set hu_master_name = lvhu_master_name, --户主姓名

           hu_master_pid = lvhu_master_pid, --户主公民身份号码

           master_relation = lvmaster_relation, --与户主关系

           when_logged = lvwhen_logged, --与与户主关系创建时间

           pid = lvpid, --公民身份号码

           name = lvname, --姓　　名

           gender = lvgender, --性　　别

           used_name = lvused_name, --曾  用 名

           nation = lvnation, --民　　族

           native_country = lvnative_country, --籍贯（国家地区）

           native_place = lvnative_place, --籍贯（省市县区）

           dob = lvdob, --出生日期

           dob_time = lvdob_time, --出生时间

           natal_country = lvnatal_country, --出生地（国家地区）

           natal_place = lvnatal_place, --出生地（省市县区）

           natal_xiang = lvnatal_xiang, --出生地详址

           gurardian_1_id = lvgurardian_1_id, --监护人1编号

           gurardian_1_pid = lvgurardian_1_pid, --监护人1公民身份号码

           gurardian_1 = lvgurardian_1, --监护人1姓名

           wardship_1 = lvwardship_1, --与监护人1关系

           gurardian_2_id = lvgurardian_2_id, --监护人2编号

           gurardian_2_pid = lvgurardian_2_pid, --监护人2公民身份号码

           gurardian_2 = lvgurardian_2, --监护人2姓名

           wardship_2 = lvwardship_2, --与监护人2关系

           fa_person_id = lvfa_person_id, --父亲人员编号

           fa_pid = lvfa_pid, --父亲公民身份号码

           fa_name = lvfa_name, --父亲姓名

           ma_person_id = lvma_person_id, --母亲人员编号

           ma_pid = lvma_pid, --母亲公民身份号码

           ma_name = lvma_name, --母亲姓名

           bloodtype = lvbloodtype, --血　　型

           scontact = lvscontact, --联系方式

            in_category = '出生', --出生原因

           born_card_no = lvborn_card_no, --出生证号码

           natal_card_date = lvnatal_card_date, --出生证签发日期

           when_in = lvwhen_in, --出生申报时间

           send_hu = lvsend_hu, --是否要打印户口本

           in_hu_kind = '入户', --落户类型
           in_app_name=lvin_app_name,
           in_app_pid=lvin_app_pid,
           memo=lvmemo,
           dbbj=lvdbbj,
           dbsj=lvdbsj
       Where 1 = 1

       and sdono = lvsdono --办理编号

    ;

  END IF;

  IF lv_procMode = 'PMDELETE' THEN
    /*删除*/

    DElETE FROM tc_webjj.t_bir_declare

     Where 1 = 1

       and sdono = lvsdono --办理编号

    ;
   END IF;

  Commit;

END; /*存储过程结束*/

