create procedure          proc_t_masterialsType --添加材料类型
(lv_sno       varchar2, --材料编号
 lv_sbusno    varchar2, --业务编码
 lv_sitem     varchar2, --材料名称
 lv_smust     varchar2, --是否必须
 lv_sitemsize varchar2, --材料大小限制(k)
 lv_norder    varchar2, --排序
 lv_sgroup    varchar2, --所属分组
 lv_imgurl    varchar2, --图片URL
 lv_isused    varchar2, --是否使用
 lv_procmode  varchar2 --模式
 ) as
begin
  if lv_procmode = 'PMINSERT' then
    insert into tc_webjj.t_applymasterials
      (sno, sbusno, sitem, smust, sitemsize, norder, sgroup, imgurl, isused)
    values
      (fun_get16code_pz(tc_webjj.seq_applymasterials_nid.nextval),
       lv_sbusno,
       lv_sitem,
       lv_smust,
       lv_sitemsize,
       lv_norder,
       lv_sgroup,
       lv_imgurl,
       lv_isused);
  elsif lv_procmode = 'PMUPDATE' then
    update tc_webjj.t_applymasterials
       set sbusno    = lv_sbusno,
           sitem     = lv_sitem,
           smust     = lv_smust,
           sitemsize = lv_sitemsize,
           norder    = lv_norder,
           sgroup    = lv_sgroup,
           imgurl    = lv_imgurl,
           isused    = lv_isused
     where sno = lv_sno;
  elsif lv_procmode = 'PMDELETE' then
    delete tc_webjj.t_applymasterials where sno = lv_sno;
  end if;
end;

/

