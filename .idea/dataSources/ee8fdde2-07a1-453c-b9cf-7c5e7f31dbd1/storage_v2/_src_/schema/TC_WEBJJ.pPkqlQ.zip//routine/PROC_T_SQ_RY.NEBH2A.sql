create PROCEDURE          PROC_t_sq_ry   /*PROC_t_sq_ry*/
(
 lvsno in out varchar2,--随迁序号
 lvsdono VARCHAR2,  --业务编号
 lvs_relation VARCHAR2,  --与户主关系
 lvsname VARCHAR2,  --随迁人员姓名
 lvspid VARCHAR2,  --随迁人员身份证
 lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
   select SEQ_T_SQ_RY.Nextval into lvsno from dual;
   INSERT into tc_webjj.T_SQ_RY
    (
      sno,
      sdono,
      s_relation,
      sname,
      spid,
      dbbj,
      dbsj
    )values(
      lvsno ,--随迁序号
      lvsdono ,  --业务编号
      lvs_relation ,  --与户主关系
      lvsname ,  --随迁人员姓名
      lvspid,   --随迁人员身份证
      '0',
      sysdate
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.T_SQ_RY
    Set
      sno=lvsno,
      sdono=lvsdono,
      s_relation=lvs_relation,
      sname=lvsname,
      spid=lvspid,
      dbbj='0',
      dbsj=sysdate
    Where 1=1
    and sno=lvsno
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.T_SQ_RY
    Set
      sno=lvsno,
      sdono=lvsdono,
      s_relation=lvs_relation,
      sname=lvsname,
      spid=lvspid,
      dbbj='0',
      dbsj=sysdate
    Where 1=1
    and sno=lvsno
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    update tc_webjj.T_SQ_RY  set zxbj='1',dbbj='0',
      dbsj=sysdate
    Where 1=1
    and sno=lvsno
    ;
END IF;
 Commit;
END; /*存储过程结束*/

