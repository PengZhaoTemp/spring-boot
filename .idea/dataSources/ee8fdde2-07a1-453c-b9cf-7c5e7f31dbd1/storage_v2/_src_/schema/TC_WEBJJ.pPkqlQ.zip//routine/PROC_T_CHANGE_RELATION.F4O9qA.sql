create PROCEDURE          PROC_t_change_relation   /*t_change_reLATION*/
(
 lvsdono IN OUT VARCHAR2,  --办理编号
 lvpid VARCHAR2,  --身份证号码(申报人)
 lvname VARCHAR2,  --姓名(申报人)
 lvpid_1 VARCHAR2,  --对象身份证1
 lvname_1 VARCHAR2,  --对象姓名1
 lvpid_2 VARCHAR2,  --对象身份证2
 lvname_2 VARCHAR2,  --对象姓名2
 lvpid_3 VARCHAR2,  --对象身份证3
 lvname_3 VARCHAR2,  --对象姓名3
 lvrelation_1 VARCHAR2,  --调整后关系1
 lvrelation_2 VARCHAR2,  --调整后关系2
 lvrelation_3 VARCHAR2,  --调整后关系3
 lvold_relation varchar2,--原来与户主的关系
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
   INSERT into tc_webjj.t_change_relation
    (
      sdono,   --办理编号
      pid,   --身份证号码(申报人)
      name,   --姓名(申报人)
      pid_1,   --对象身份证1
      name_1,   --对象姓名1
      pid_2,   --对象身份证2
      name_2,   --对象姓名2
      pid_3,   --对象身份证3
      name_3,   --对象姓名3
      relation_1,   --调整后关系1
      relation_2,   --调整后关系2
      relation_3,    --调整后关系3
      old_relation
    )values(
      lvsdono,   --办理编号
      lvpid,   --身份证号码(申报人)
      lvname,   --姓名(申报人)
      lvpid_1,   --对象身份证1
      lvname_1,   --对象姓名1
      lvpid_2,   --对象身份证2
      lvname_2,   --对象姓名2
      lvpid_3,   --对象身份证3
      lvname_3,   --对象姓名3
      lvrelation_1,   --调整后关系1
      lvrelation_2,   --调整后关系2
      lvrelation_3,    --调整后关系3
      lvold_relation
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_change_relation
    Set
      sdono=lvsdono,   --办理编号
      pid=lvpid,   --身份证号码(申报人)
      name=lvname,   --姓名(申报人)
      pid_1=lvpid_1,   --对象身份证1
      name_1=lvname_1,   --对象姓名1
      pid_2=lvpid_2,   --对象身份证2
      name_2=lvname_2,   --对象姓名2
      pid_3=lvpid_3,   --对象身份证3
      name_3=lvname_3,   --对象姓名3
      relation_1=lvrelation_1,   --调整后关系1
      relation_2=lvrelation_2,   --调整后关系2
      relation_3=lvrelation_3,    --调整后关系3
      old_relation=lvold_relation
    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_change_relation
    Set
      sdono=lvsdono,   --办理编号
      pid=lvpid,   --身份证号码(申报人)
      name=lvname,   --姓名(申报人)
      pid_1=lvpid_1,   --对象身份证1
      name_1=lvname_1,   --对象姓名1
      pid_2=lvpid_2,   --对象身份证2
      name_2=lvname_2,   --对象姓名2
      pid_3=lvpid_3,   --对象身份证3
      name_3=lvname_3,   --对象姓名3
      relation_1=lvrelation_1,   --调整后关系1
      relation_2=lvrelation_2,   --调整后关系2
      relation_3=lvrelation_3,    --调整后关系3
      old_relation=lvold_relation
    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_change_relation
    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

