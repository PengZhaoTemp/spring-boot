create function          fun_geturl_relation(lvsdono varchar2)
  return varchar2 is
  lvsurl   varchar2(500);
  lv_PID   varchar2(18);
  lv_NAME  varchar2(50);
  lv_PID1  varchar2(18);
  lv_NAME1 varchar2(50);
  /* lv_PID2         varchar2(18);
  lv_NAME2        varchar2(50);
  lv_PID3         varchar2(18);
  lv_NAME3        varchar2(50);*/
  lv_old_relation varchar2(75);
  lv_count        number;
  lv_person_id    number;
  lv_hu_id        number;
  lv_send_flag    varchar2(50);
  lvsbooking      varchar2(2);
  lv_sbusno       VARCHAR2(6);
  /*lvNUM_PID       number;*/
begin
  /*    调整家庭关系
    /rkxt/hjgl/changerelatewithmaster.jsp?
    changerelatewithmaster.jsp?opr_type=户成员关系调整
    &bd_type=户成员关系调整&person_id=14158&hu_id=4875&stuff=
  */
  lvsurl   := '';
  lv_count := 0;
  select PID, NAME, pid_1, name_1, old_relation /*, pid_2, name_2, pid_3, name_3, NUM_PID*/
    into lv_PID, lv_NAME, lv_PID1, lv_NAME1, lv_old_relation /*,
               lv_PID2,
               lv_NAME2,
               lv_PID3,
               lv_NAME3,
               lvNUM_PID*/
    from tc_webjj.T_CHANGE_RELATION
   where sdono = lvsdono;
  select count(*)
    into lv_count
    from ccic_data.tbn_data c
   where c.sidentityid in (lv_PID, lv_PID1 /*, lv_PID2, lv_PID3*/);
  if lv_count > 0 then
    return 'ccic_false'; --'ccic人员';
  end if;

  select count(*)
    into lv_count
    from TC_RKXT.v_tp_huji_ck m
   where 1 = 1
     and pid = lv_PID
     and name = lv_NAME;
  if lv_count = 0 then
    return 'app_false'; --'申请人不存在出错';
  end if;

  select count(*)
    into lv_count
    from TC_RKXT.v_tp_huji_ck c
   where c.pid in (lv_PID1);
  if lv_count <> 1 then
    return 'duixian_false'; --'对象存在不是常口';
  end if;

  select count(distinct hu_id)
    into lv_count
    from TC_RKXT.v_tp_huji_ck c
   where c.pid in (lv_PID1, lv_PID);
  if lv_count <> 1 then
    return 'hu_false'; --'对象和申请人不同户';
  end if;

  select count(*)
    into lv_count
    from TC_RKXT.v_tp_huji_ck c
   where c.pid in (lv_PID1)
     and master_relation = lv_old_relation;
  if lv_count <> 1 then
    return 'relation_false'; --'家庭关系错误';
  end if;
  /*if lvNUM_PID = 1 then
    select count(*)
      into lv_count
      from TC_RKXT.v_tp_huji_ck c
     where c.pid in (lv_PID1);
    if lv_count <> 1 then
      return 'duixian_false'; --'对象存在不是常口';
    end if;

  elsif lvNUM_PID = 2 then
    select count(*)
      into lv_count
      from TC_RKXT.v_tp_huji_ck c
     where c.pid in (lv_PID1, lv_PID2);
    if lv_count <> 2 then
      return 'duixian_false'; --'对象存在不是常口';
    end if;
    select count(distinct hu_id)
      into lv_count
      from TC_RKXT.v_tp_huji_ck c
     where c.pid in (lv_PID1, lv_PID2);
    if lv_count <> 1 then
      return 'hu_false'; --'申请人不存在出错';
    end if;
  elsif lvNUM_PID = 3 then
    select count(*)
      into lv_count
      from TC_RKXT.v_tp_huji_ck c
     where c.pid in (lv_PID1, lv_PID2, lv_PID3);
    if lv_count <> 3 then
      return 'duixian_false'; --'对象存在不是常口';
    end if;
    select count(distinct hu_id)
      into lv_count
      from TC_RKXT.v_tp_huji_ck c
     where c.pid in (lv_PID1, lv_PID2, lv_PID3);
    if lv_count <> 1 then
      return 'hu_false'; --'申请人不存在出错';
    end if;
  end if;*/

  select hu_id, person_id
    into lv_hu_id, lv_person_id
    from tc_rkxt.v_tp_huji_ck
   where pid = lv_PID1
     and name = lv_NAME1;
  select need_back, sbooking, sbusno
    into lv_send_flag, lvsbooking, lv_sbusno
    from tc_webjj.v_dobus
   where sdono = lvsdono;

  lvsurl := '?opr_type=户成员关系调整=户成员关系调整';
  lvsurl := lvsurl || '=' || lv_person_id;
  lvsurl := lvsurl || '=' || lv_hu_id;
  lvsurl := lvsurl || '=' || lvsdono;
  lvsurl := lvsurl || '=008';

  if lv_send_flag = '需回寄' then
    lvsurl := lvsurl || '=1';
  else
    lvsurl := lvsurl || '=0';
  end if;
  /*if lvsbooking = '1' then
    lvsurl := lvsurl || '&sdr=888';
  end if;*/
  return(lvsurl);
end fun_geturl_relation;

/

