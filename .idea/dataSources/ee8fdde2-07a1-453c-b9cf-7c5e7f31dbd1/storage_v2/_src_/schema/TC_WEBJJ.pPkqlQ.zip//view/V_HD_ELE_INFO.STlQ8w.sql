create view V_HD_ELE_INFO as
  select nid,sname,
       stype,
       decode(a.sexa_status,
              '',
              '未审核',
              '0',
              '审核不通过',
              '1',
              '审核通过') sexa_status,
       (select t.qgroup_number
          from tc_webjj.t_hd_ele_item t
         where t.eleid = a.nid
           and t.seletype = 'qgroup') qgroup_number,
       (select t.blog_url
          from tc_webjj.t_hd_ele_item t
         where t.eleid = a.nid
           and t.seletype = 'microblog'
           and t.company = 'sina') blog_url_sina,
       (select t.blog_url
          from tc_webjj.t_hd_ele_item t
         where t.eleid = a.nid
           and t.seletype = 'microblog'
           and t.company = 'tencent') blog_url_tencent,
           a.ssort,a.headpic,
           a.sregunit,
           a.sregunitcode

  from tc_webjj.t_hd_ele_info a
/

