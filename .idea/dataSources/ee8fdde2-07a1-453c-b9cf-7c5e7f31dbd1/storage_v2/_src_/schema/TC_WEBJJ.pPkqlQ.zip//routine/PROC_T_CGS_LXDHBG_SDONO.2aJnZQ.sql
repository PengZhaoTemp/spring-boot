create procedure          PROC_t_cgs_lxdhbg_SDONO
(
     lvoldsdono VARCHAR2,  --办理编号
     lvReturn in out varchar2 --新办理编号
)
as
  cursor c is
     select * from tc_webjj.t_cgs_lxdhbg
     where 1=1
     and sdono=lvoldsdono;   --公民身份号码
  r c%rowtype;

BEGIN
   select TC_WEBJJ.fun_get16code(TC_WEBJJ.SEQ_T_DOBUS_SDONO.Nextval)  into  lvReturn from dual  where 1=1;
   for r in c loop
   INSERT into tc_webjj.t_cgs_lxdhbg
    (
      sdono,   --办理编号
      scarid,   --车牌号码
      scar_type,   --车辆类型
      sloginid,   --登记证书编号
      scar_sbid,   --车辆识别代号/车架号
      scar_fdjid,   --发动机号
      scar_name,   -- 机动车所有人
      scar_pid,   --身份证明号/代码
      stel,   --原联系电话
      snewtel,   --新联系电话
      saddress    --通信地址
    )values(
      lvReturn,   --办理编号
      r.scarid,   --车牌号码
      r.scar_type,   --车辆类型
      r.sloginid,   --登记证书编号
      r.scar_sbid,   --车辆识别代号/车架号
      r.scar_fdjid,   --发动机号
      r.scar_name,   -- 机动车所有人
      r.scar_pid,   --身份证明号/代码
      r.stel,   --原联系电话
      r.snewtel,   --新联系电话
      r.saddress    --通信地址

    );
    commit;
    end loop;
END;

/

