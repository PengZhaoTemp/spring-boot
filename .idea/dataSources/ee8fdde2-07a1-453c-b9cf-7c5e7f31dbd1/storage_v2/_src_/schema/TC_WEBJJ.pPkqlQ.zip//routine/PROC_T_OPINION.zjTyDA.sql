create PROCEDURE          PROC_t_opinion   /*t_chaRGECENTER*/
(

 lvsdono IN OUT VARCHAR2,  --办理编号
 lvsopinion VARCHAR2,  --评价内容
 lvsserattitude VARCHAR2,  --服务态度得分
 lvsefficiency VARCHAR2,  --办事效率得分
 lvssatisfaction VARCHAR2,--满意度
 lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS

BEGIN
  --begin TRAN

IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_dobus
    Set
      state='43',
      dbbj='0',
      dbsj=sysdate,
      sopinion=lvsopinion,   --评价内容
      sserattitude=lvsserattitude,   --服务态度得分
      sefficiency=lvsefficiency,   --办事效率得分
      ssatisfaction=lvssatisfaction,   --满意度
      DDECDATE=sysdate
    Where 1=1
    and sdono=lvsdono   --支付编号
    ;
END IF;

IF lv_ProcMode='PMEMS' THEN
  UPDATE tc_webjj.t_dobus
  Set
      state='41',
      dbbj='0'
      where 1=1
      and sdono=lvsdono;
END IF;
 Commit;
END; /*存储过程结束*/

