create procedure           proc_manage_time
as
begin

update tc_webjj.t_file_manage  set dbbj='0' where sfiletime < TRUNC(sysdate,'mi') - 3/ (24*60) and dbbj = '3';

Commit;
end proc_manage_time;
/

