create PROCEDURE          PROC_t_yhbz_ys   /*T_YHBZ_YS*/
(
 lvsdono IN OUT VARCHAR2,  --业务编号
 lvyh_type VARCHAR2,  --烟花种类
 lvyh_gg VARCHAR2,  --烟花规格
 lvyh_shuliang VARCHAR2,  --烟花数量
 lvys_cph VARCHAR2,  --运输车牌号
 lvys_time DATE,  --运输时间
 lvys_qsdd VARCHAR2,  --运输行驶路线
 lvys_xslx VARCHAR2,  --行驶路线
 lvsq_name VARCHAR2,  --申  请 人
 lvsq_pid VARCHAR2,  --申请人身份证
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
   INSERT into tc_webjj.t_yhbz_ys
    (
      sdono,   --业务编号
      yh_type,   --烟花种类
      yh_gg,   --烟花规格
      yh_shuliang,   --烟花数量
      ys_cph,   --运输车牌号
      ys_time,   --运输时间
      ys_qsdd,   --运输行驶路线
      ys_xslx,   --行驶路线
      sq_name,   --申  请 人
      sq_pid    --申请人身份证
    )values(
      lvsdono,   --业务编号
      lvyh_type,   --烟花种类
      lvyh_gg,   --烟花规格
      lvyh_shuliang,   --烟花数量
      lvys_cph,   --运输车牌号
      lvys_time,   --运输时间
      lvys_qsdd,   --运输行驶路线
      lvys_xslx,   --行驶路线
      lvsq_name,   --申  请 人
      lvsq_pid    --申请人身份证
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_yhbz_ys
    Set
      sdono=lvsdono,   --业务编号
      yh_type=lvyh_type,   --烟花种类
      yh_gg=lvyh_gg,   --烟花规格
      yh_shuliang=lvyh_shuliang,   --烟花数量
      ys_cph=lvys_cph,   --运输车牌号
      ys_time=lvys_time,   --运输时间
      ys_qsdd=lvys_qsdd,   --运输行驶路线
      ys_xslx=lvys_xslx,   --行驶路线
      sq_name=lvsq_name,   --申  请 人
      sq_pid=lvsq_pid    --申请人身份证
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_yhbz_ys
    Set
      sdono=lvsdono,   --业务编号
      yh_type=lvyh_type,   --烟花种类
      yh_gg=lvyh_gg,   --烟花规格
      yh_shuliang=lvyh_shuliang,   --烟花数量
      ys_cph=lvys_cph,   --运输车牌号
      ys_time=lvys_time,   --运输时间
      ys_qsdd=lvys_qsdd,   --运输行驶路线
      ys_xslx=lvys_xslx,   --行驶路线
      sq_name=lvsq_name,   --申  请 人
      sq_pid=lvsq_pid    --申请人身份证
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_yhbz_ys
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

