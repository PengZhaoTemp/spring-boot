create procedure proc_weixin_express(
lv_sdono varchar2
) is
lv_dobus tc_webjj.t_dobus%rowtype;
lv_org   tc_jcyw.t_org%rowtype;
lv_msg   varchar2(500);
begin
 -- begin
    select * into lv_dobus from tc_webjj.t_dobus  where sdono=lv_sdono;
    select * into lv_org from tc_jcyw.t_org  where sunit_code=lv_dobus.sdounitno and rownum<2;
  --快递送
  if lv_dobus.NEXPCHARGE>0 then
     insert into tc_webjj.t_weixin_express(
            SNO                 ,--业务表主键
            SDONO                ,-- 互联网+受理编号
            SSTATE              ,--寄送状态 1寄送/2回寄
            SEXPADDRESS         ,--寄送地址（详细地址）/回寄地址
            SEXPPRO             ,--寄送省份/回寄省份
            SEXPCITY            ,--寄送市/回寄市
            SEXPAREA            ,--寄送区县/回寄区县
            SEXPPOSTCODE        ,--寄送邮政编码/回寄邮政编码
            SNAME               ,--寄件人姓名/回寄人姓名
            SPID                ,--寄件人身份证（根据需求可能不需要提供）/回寄人身份证
            STEL                ,--寄件人联系方式/回寄人联系方式
            SDWNAME             ,--寄件收件单位/回寄收件单位
            SDWADDRESS          ,--寄件收件单位地址/回寄收件单位地址
            STATUS              ,--业务单状态
            BILLNO              ,--业务流水号
            DBBJ                --打包标记
            )values(
            tc_webjj.seq_weixin_express_sno.nextval,
            lv_sdono,
            '1',
            lv_org.sdetail_addr          ,--寄送地址（详细地址）
            ''                           ,--寄送省份
            ''                           ,--寄送市
            ''                           ,--寄送区县
            lv_dobus.SEXPPOSTCODE        ,--寄送邮政编码
            lv_dobus.SCONSIGNEE          ,--寄件人姓名
            ''                           ,--寄件人身份证（根据需求可能不需要提供）
            lv_dobus.SCONTEL             ,--寄件人联系方式
            ''               ,--寄件收件单位
            lv_dobus.SEXPADDRESS       ,--寄件收件单位地址
             '0'              ,--业务单状态
            tc_webjj.seq_weixin_express_sno.nextval,
            '0'              --打包标记
     );
  end if;
  --快递取
  if lv_dobus.NRECHARGE>0 then
     insert into tc_webjj.t_weixin_express(
            SNO                 ,--业务表主键
            SDONO                ,-- 互联网+受理编号
            SSTATE              ,--寄送状态 1寄送/2回寄
            SEXPADDRESS         ,--寄送地址（详细地址）/回寄地址
            SEXPPRO             ,--寄送省份/回寄省份
            SEXPCITY            ,--寄送市/回寄市
            SEXPAREA            ,--寄送区县/回寄区县
            SEXPPOSTCODE        ,--寄送邮政编码/回寄邮政编码
            SNAME               ,--寄件人姓名/回寄人姓名
            SPID                ,--寄件人身份证（根据需求可能不需要提供）/回寄人身份证
            STEL                ,--寄件人联系方式/回寄人联系方式
            SDWNAME             ,--寄件收件单位/回寄收件单位
            SDWADDRESS          ,--寄件收件单位地址/回寄收件单位地址
            STATUS              ,--业务单状态
            BILLNO              ,--业务流水号
            DBBJ                --打包标记
     )values(
            tc_webjj.seq_weixin_express_sno.nextval,
            lv_sdono,
            '2',
             lv_dobus.SREADDRESS        ,--回寄地址
            ''                          ,--回寄省份
            ''                          ,--回寄市
            ''                          ,--回寄区县
            lv_dobus.SREPOSTCODE        ,--回寄邮政编码
            ''                          ,--回寄人姓名
            ''                          ,--回寄人身份证
            lv_org.stel_no              ,--回寄人联系方式
            lv_org.orgname              ,--回寄收件单位
            lv_org.sdetail_addr         ,--回寄收件单位地址
            
            ''              ,--业务单状态
            tc_webjj.seq_weixin_express_sno.nextval,
            '0'              --打包标记
     );

  end if;

      commit;

  --exception when others then
   -- lv_msg:=substr(SQLCODE||'---'||SQLERRM,0,100);
   -- null;
   --DBMS_OUTPUT.put_line(lv_msg);
  --end;
end;

/

