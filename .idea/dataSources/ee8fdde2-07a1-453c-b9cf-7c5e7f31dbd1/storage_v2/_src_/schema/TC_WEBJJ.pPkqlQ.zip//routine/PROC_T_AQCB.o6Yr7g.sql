create PROCEDURE          PROC_t_aqcb   /*T_AQCB*/
(
 lvsdono IN OUT VARCHAR2,  --业务编号
 lvscb_unit VARCHAR2,  --呈报单位名称
 lvscb_address VARCHAR2,  --单位地址
 lvsfd_dbr VARCHAR2,  --法定代表人
 lvsdy_name VARCHAR2,  --打  印 人
 lvsdy_unit VARCHAR2,  --打印人单位
 lvsdy_date DATE,  --打印时间
 lvsstart_time1 DATE,  --开始时间
 lvsend_time1 DATE,  --结束时间
 lvsgc_name1 VARCHAR2,  --爆破工程名称
 lvsgc_address1 VARCHAR2,  --爆破作业地址
 lvsgc_jb1 VARCHAR2,  --工程级别
 lvssjr1 VARCHAR2,  --设  计 人
 lvsshr1 VARCHAR2,  --工程审核人
 lvspzr1 VARCHAR2,  --工程批准人
 lvsaqqk1 VARCHAR2,  --安全情况
 lvsstart_time2 DATE,  --开始时间
 lvsend_time2 DATE,  --结束时间
 lvsgc_name2 VARCHAR2,  --爆破工程名称
 lvsgc_address2 VARCHAR2,  --爆破作业地址
 lvsgc_jb2 VARCHAR2,  --工程级别
 lvssjr2 VARCHAR2,  --设  计 人
 lvsshr2 VARCHAR2,  --工程审核人
 lvspzr2 VARCHAR2,  --工程批准人
 lvsaqqk2 VARCHAR2,  --安全情况
 lvsstart_time3 DATE,  --开始时间
 lvsend_time3 DATE,  --结束时间
 lvsgc_name3 VARCHAR2,  --爆破工程名称
 lvsgc_address3 VARCHAR2,  --爆破作业地址
 lvsgc_jb3 VARCHAR2,  --工程级别
 lvssjr3 VARCHAR2,  --设  计 人
 lvsshr3 VARCHAR2,  --工程审核人
 lvspzr3 VARCHAR2,  --工程批准人
 lvsaqqk3 VARCHAR2,  --安全情况
 lvsstart_time4 DATE,  --开始时间
 lvsend_time4 DATE,  --结束时间
 lvsgc_name4 VARCHAR2,  --爆破工程名称
 lvsgc_address4 VARCHAR2,  --爆破作业地址
 lvsgc_jb4 VARCHAR2,  --工程级别
 lvssjr4 VARCHAR2,  --设  计 人
 lvsshr4 VARCHAR2,  --工程审核人
 lvspzr4 VARCHAR2,  --工程批准人
 lvsaqqk4 VARCHAR2,  --安全情况
 lvsstart_time5 DATE,  --开始时间
 lvsend_time5 DATE,  --结束时间
 lvsgc_name5 VARCHAR2,  --爆破工程名称
 lvsgc_address5 VARCHAR2,  --爆破作业地址
 lvsgc_jb5 VARCHAR2,  --工程级别
 lvssjr5 VARCHAR2,  --设  计 人
 lvsshr5 VARCHAR2,  --工程审核人
 lvspzr5 VARCHAR2,  --工程批准人
 lvsaqqk5 VARCHAR2,  --安全情况
 lvsstart_time6 DATE,  --开始时间
 lvsend_time6 DATE,  --结束时间
 lvsgc_name6 VARCHAR2,  --爆破工程名称
 lvsgc_address6 VARCHAR2,  --爆破作业地址
 lvsgc_jb6 VARCHAR2,  --工程级别
 lvssjr6 VARCHAR2,  --设  计 人
 lvsshr6 VARCHAR2,  --工程审核人
 lvspzr6 VARCHAR2,  --工程批准人
 lvsaqqk6 VARCHAR2,  --安全情况
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS

BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/



   INSERT into tc_webjj.t_aqcb
    (
      sdono,   --业务编号
      scb_unit,   --呈报单位名称
      scb_address,   --单位地址
      sfd_dbr,   --法定代表人
      sdy_name,   --打  印 人
      sdy_unit,   --打印人单位
      sdy_date,   --打印时间
      sstart_time1,   --开始时间
      send_time1,   --结束时间
      sgc_name1,   --爆破工程名称
      sgc_address1,   --爆破作业地址
      sgc_jb1,   --工程级别
      ssjr1,   --设  计 人
      sshr1,   --工程审核人
      spzr1,   --工程批准人
      saqqk1,   --安全情况
      sstart_time2,   --开始时间
      send_time2,   --结束时间
      sgc_name2,   --爆破工程名称
      sgc_address2,   --爆破作业地址
      sgc_jb2,   --工程级别
      ssjr2,   --设  计 人
      sshr2,   --工程审核人
      spzr2,   --工程批准人
      saqqk2,   --安全情况
      sstart_time3,   --开始时间
      send_time3,   --结束时间
      sgc_name3,   --爆破工程名称
      sgc_address3,   --爆破作业地址
      sgc_jb3,   --工程级别
      ssjr3,   --设  计 人
      sshr3,   --工程审核人
      spzr3,   --工程批准人
      saqqk3,   --安全情况
      sstart_time4,   --开始时间
      send_time4,   --结束时间
      sgc_name4,   --爆破工程名称
      sgc_address4,   --爆破作业地址
      sgc_jb4,   --工程级别
      ssjr4,   --设  计 人
      sshr4,   --工程审核人
      spzr4,   --工程批准人
      saqqk4,   --安全情况
      sstart_time5,   --开始时间
      send_time5,   --结束时间
      sgc_name5,   --爆破工程名称
      sgc_address5,   --爆破作业地址
      sgc_jb5,   --工程级别
      ssjr5,   --设  计 人
      sshr5,   --工程审核人
      spzr5,   --工程批准人
      saqqk5,   --安全情况
      sstart_time6,   --开始时间
      send_time6,   --结束时间
      sgc_name6,   --爆破工程名称
      sgc_address6,   --爆破作业地址
      sgc_jb6,   --工程级别
      ssjr6,   --设  计 人
      sshr6,   --工程审核人
      spzr6,   --工程批准人
      saqqk6    --安全情况
    )values(
      lvsdono,   --业务编号
      lvscb_unit,   --呈报单位名称
      lvscb_address,   --单位地址
      lvsfd_dbr,   --法定代表人
      lvsdy_name,   --打  印 人
      lvsdy_unit,   --打印人单位
      lvsdy_date,   --打印时间
      lvsstart_time1,   --开始时间
      lvsend_time1,   --结束时间
      lvsgc_name1,   --爆破工程名称
      lvsgc_address1,   --爆破作业地址
      lvsgc_jb1,   --工程级别
      lvssjr1,   --设  计 人
      lvsshr1,   --工程审核人
      lvspzr1,   --工程批准人
      lvsaqqk1,   --安全情况
      lvsstart_time2,   --开始时间
      lvsend_time2,   --结束时间
      lvsgc_name2,   --爆破工程名称
      lvsgc_address2,   --爆破作业地址
      lvsgc_jb2,   --工程级别
      lvssjr2,   --设  计 人
      lvsshr2,   --工程审核人
      lvspzr2,   --工程批准人
      lvsaqqk2,   --安全情况
      lvsstart_time3,   --开始时间
      lvsend_time3,   --结束时间
      lvsgc_name3,   --爆破工程名称
      lvsgc_address3,   --爆破作业地址
      lvsgc_jb3,   --工程级别
      lvssjr3,   --设  计 人
      lvsshr3,   --工程审核人
      lvspzr3,   --工程批准人
      lvsaqqk3,   --安全情况
      lvsstart_time4,   --开始时间
      lvsend_time4,   --结束时间
      lvsgc_name4,   --爆破工程名称
      lvsgc_address4,   --爆破作业地址
      lvsgc_jb4,   --工程级别
      lvssjr4,   --设  计 人
      lvsshr4,   --工程审核人
      lvspzr4,   --工程批准人
      lvsaqqk4,   --安全情况
      lvsstart_time5,   --开始时间
      lvsend_time5,   --结束时间
      lvsgc_name5,   --爆破工程名称
      lvsgc_address5,   --爆破作业地址
      lvsgc_jb5,   --工程级别
      lvssjr5,   --设  计 人
      lvsshr5,   --工程审核人
      lvspzr5,   --工程批准人
      lvsaqqk5,   --安全情况
      lvsstart_time6,   --开始时间
      lvsend_time6,   --结束时间
      lvsgc_name6,   --爆破工程名称
      lvsgc_address6,   --爆破作业地址
      lvsgc_jb6,   --工程级别
      lvssjr6,   --设  计 人
      lvsshr6,   --工程审核人
      lvspzr6,   --工程批准人

      lvsaqqk6    --安全情况


    );
   -- 返回值

END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_aqcb
    Set
      sdono=lvsdono,   --业务编号
      scb_unit=lvscb_unit,   --呈报单位名称
      scb_address=lvscb_address,   --单位地址
      sfd_dbr=lvsfd_dbr,   --法定代表人
      sdy_name=lvsdy_name,   --打  印 人
      sdy_unit=lvsdy_unit,   --打印人单位
      sdy_date=lvsdy_date,   --打印时间
      sstart_time1=lvsstart_time1,   --开始时间
      send_time1=lvsend_time1,   --结束时间
      sgc_name1=lvsgc_name1,   --爆破工程名称
      sgc_address1=lvsgc_address1,   --爆破作业地址
      sgc_jb1=lvsgc_jb1,   --工程级别
      ssjr1=lvssjr1,   --设  计 人
      sshr1=lvsshr1,   --工程审核人
      spzr1=lvspzr1,   --工程批准人
      saqqk1=lvsaqqk1,   --安全情况
      sstart_time2=lvsstart_time2,   --开始时间
      send_time2=lvsend_time2,   --结束时间
      sgc_name2=lvsgc_name2,   --爆破工程名称
      sgc_address2=lvsgc_address2,   --爆破作业地址
      sgc_jb2=lvsgc_jb2,   --工程级别
      ssjr2=lvssjr2,   --设  计 人
      sshr2=lvsshr2,   --工程审核人
      spzr2=lvspzr2,   --工程批准人
      saqqk2=lvsaqqk2,   --安全情况
      sstart_time3=lvsstart_time3,   --开始时间
      send_time3=lvsend_time3,   --结束时间
      sgc_name3=lvsgc_name3,   --爆破工程名称
      sgc_address3=lvsgc_address3,   --爆破作业地址
      sgc_jb3=lvsgc_jb3,   --工程级别
      ssjr3=lvssjr3,   --设  计 人
      sshr3=lvsshr3,   --工程审核人
      spzr3=lvspzr3,   --工程批准人
      saqqk3=lvsaqqk3,   --安全情况
      sstart_time4=lvsstart_time4,   --开始时间
      send_time4=lvsend_time4,   --结束时间
      sgc_name4=lvsgc_name4,   --爆破工程名称
      sgc_address4=lvsgc_address4,   --爆破作业地址
      sgc_jb4=lvsgc_jb4,   --工程级别
      ssjr4=lvssjr4,   --设  计 人
      sshr4=lvsshr4,   --工程审核人
      spzr4=lvspzr4,   --工程批准人
      saqqk4=lvsaqqk4,   --安全情况
      sstart_time5=lvsstart_time5,   --开始时间
      send_time5=lvsend_time5,   --结束时间
      sgc_name5=lvsgc_name5,   --爆破工程名称
      sgc_address5=lvsgc_address5,   --爆破作业地址
      sgc_jb5=lvsgc_jb5,   --工程级别
      ssjr5=lvssjr5,   --设  计 人
      sshr5=lvsshr5,   --工程审核人
      spzr5=lvspzr5,   --工程批准人
      saqqk5=lvsaqqk5,   --安全情况
      sstart_time6=lvsstart_time6,   --开始时间
      send_time6=lvsend_time6,   --结束时间
      sgc_name6=lvsgc_name6,   --爆破工程名称
      sgc_address6=lvsgc_address6,   --爆破作业地址
      sgc_jb6=lvsgc_jb6,   --工程级别
      ssjr6=lvssjr6,   --设  计 人
      sshr6=lvsshr6,   --工程审核人
      spzr6=lvspzr6,   --工程批准人
      saqqk6=lvsaqqk6    --安全情况
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_aqcb
    Set
      sdono=lvsdono,   --业务编号
      scb_unit=lvscb_unit,   --呈报单位名称
      scb_address=lvscb_address,   --单位地址
      sfd_dbr=lvsfd_dbr,   --法定代表人
      sdy_name=lvsdy_name,   --打  印 人
      sdy_unit=lvsdy_unit,   --打印人单位
      sdy_date=lvsdy_date,   --打印时间
      sstart_time1=lvsstart_time1,   --开始时间
      send_time1=lvsend_time1,   --结束时间
      sgc_name1=lvsgc_name1,   --爆破工程名称
      sgc_address1=lvsgc_address1,   --爆破作业地址
      sgc_jb1=lvsgc_jb1,   --工程级别
      ssjr1=lvssjr1,   --设  计 人
      sshr1=lvsshr1,   --工程审核人
      spzr1=lvspzr1,   --工程批准人
      saqqk1=lvsaqqk1,   --安全情况
      sstart_time2=lvsstart_time2,   --开始时间
      send_time2=lvsend_time2,   --结束时间
      sgc_name2=lvsgc_name2,   --爆破工程名称
      sgc_address2=lvsgc_address2,   --爆破作业地址
      sgc_jb2=lvsgc_jb2,   --工程级别
      ssjr2=lvssjr2,   --设  计 人
      sshr2=lvsshr2,   --工程审核人
      spzr2=lvspzr2,   --工程批准人
      saqqk2=lvsaqqk2,   --安全情况
      sstart_time3=lvsstart_time3,   --开始时间
      send_time3=lvsend_time3,   --结束时间
      sgc_name3=lvsgc_name3,   --爆破工程名称
      sgc_address3=lvsgc_address3,   --爆破作业地址
      sgc_jb3=lvsgc_jb3,   --工程级别
      ssjr3=lvssjr3,   --设  计 人
      sshr3=lvsshr3,   --工程审核人
      spzr3=lvspzr3,   --工程批准人
      saqqk3=lvsaqqk3,   --安全情况
      sstart_time4=lvsstart_time4,   --开始时间
      send_time4=lvsend_time4,   --结束时间
      sgc_name4=lvsgc_name4,   --爆破工程名称
      sgc_address4=lvsgc_address4,   --爆破作业地址
      sgc_jb4=lvsgc_jb4,   --工程级别
      ssjr4=lvssjr4,   --设  计 人
      sshr4=lvsshr4,   --工程审核人
      spzr4=lvspzr4,   --工程批准人
      saqqk4=lvsaqqk4,   --安全情况
      sstart_time5=lvsstart_time5,   --开始时间
      send_time5=lvsend_time5,   --结束时间
      sgc_name5=lvsgc_name5,   --爆破工程名称
      sgc_address5=lvsgc_address5,   --爆破作业地址
      sgc_jb5=lvsgc_jb5,   --工程级别
      ssjr5=lvssjr5,   --设  计 人
      sshr5=lvsshr5,   --工程审核人
      spzr5=lvspzr5,   --工程批准人
      saqqk5=lvsaqqk5,   --安全情况
      sstart_time6=lvsstart_time6,   --开始时间
      send_time6=lvsend_time6,   --结束时间
      sgc_name6=lvsgc_name6,   --爆破工程名称
      sgc_address6=lvsgc_address6,   --爆破作业地址
      sgc_jb6=lvsgc_jb6,   --工程级别
      ssjr6=lvssjr6,   --设  计 人
      sshr6=lvsshr6,   --工程审核人
      spzr6=lvspzr6,   --工程批准人
      saqqk6=lvsaqqk6    --安全情况
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_aqcb
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

