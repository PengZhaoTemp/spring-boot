create PROCEDURE          PROC_t_commoner   /*T_COMMONER*/
(
 lvslogin_id IN OUT VARCHAR2,  --账　　号
 lvspwd  IN OUT VARCHAR2,  --密　　码
 lvpersonid VARCHAR2,  --人员编号2
 lvname VARCHAR2,  --姓　　名
 lvpid VARCHAR2,  --身份号码
 lvdob DATE,  --出生日期
 lvgender VARCHAR2,  --性　　别
 lvnation VARCHAR2,  --民　　族
 lvmarriage VARCHAR2,  --婚姻状况
 lvnative_place VARCHAR2,  --籍　　贯
 lvnatal VARCHAR2,  --2
 lvsnow_full_addr VARCHAR2,  --现  住 址
 lvsswitch_visage VARCHAR2,  --政治面貌
 lvedu_degree VARCHAR2,  --学　　历
 lvsother_info VARCHAR2,  --2
 lvshuji_region VARCHAR2,  --户籍所在地2
 lvshuji_full_addr VARCHAR2,  --户籍所在地详址2
 lvsspeciality VARCHAR2,  --专　　长
 lvstaste VARCHAR2,  --爱　　好
 lvsuser_kind CHAR,  --用户类型2
 lvslogin_type CHAR,  --登录方式2
 lvwho_logged NUMBER,  --登记人编号2
 lvwho_unit VARCHAR2,  --登记单位编号2
 lvwhen_logged DATE,  --登记时间2
 lvsstate VARCHAR2,  --状  态 2
 lvswork_story VARCHAR2,  --工作经历
 lvshome_phone VARCHAR2,  --住宅电话
 lvsinternet_mail VARCHAR2,  --邮箱地址
 lvnareaid VARCHAR2,  --2
 lvsunitname VARCHAR2,  --常关注的单位
 lvdbbj VARCHAR2,  --2
 lvdbsj DATE,  --2
 lvquestion VARCHAR2,  --密码保护问题
 lvanswer VARCHAR2,  --答　　案
 lvqq VARCHAR2,  --qq号码
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN



IF lv_procMode='PMINSERT' THEN    /*登记*/
    Select TC_WEBJJ.SEQ_T_COMMONER_SLOGIN_ID.Nextval  into lvslogin_id From dual;    /*账　　号序列*/

   INSERT into tc_webjj.t_commoner
    (
      slogin_id,   --账　　号
      spwd,   --密　　码
      personid,   --人员编号2
      name,   --姓　　名
      pid,   --身份号码
      dob,   --出生日期
      gender,   --性　　别
      nation,   --民　　族
      marriage,   --婚姻状况
      native_place,   --籍　　贯
      natal,   --2
      snow_full_addr,   --现  住 址
      sswitch_visage,   --政治面貌
      edu_degree,   --学　　历
      sother_info,   --2
      shuji_region,   --户籍所在地2
      shuji_full_addr,   --户籍所在地详址2
      sspeciality,   --专　　长
      staste,   --爱　　好
      suser_kind,   --用户类型2
      slogin_type,   --登录方式2
      who_logged,   --登记人编号2
      who_unit,   --登记单位编号2
      when_logged,   --登记时间2
      sstate,   --状  态 2
      swork_story,   --工作经历
      shome_phone,   --住宅电话
      sinternet_mail,   --邮箱地址
      nareaid,   --2
      sunitcode,   --常关注的单位
      dbbj,   --2
      dbsj,   --2
      question,   --密码保护问题
      answer,   --答　　案
      qq    --qq号码
    )values(
      lvslogin_id,   --账　　号
      lvspwd,   --密　　码
      lvpersonid,   --人员编号2
      lvname,   --姓　　名
      lvpid,   --身份号码
      lvdob,   --出生日期
      lvgender,   --性　　别
      lvnation,   --民　　族
      lvmarriage,   --婚姻状况
      lvnative_place,   --籍　　贯
      lvnatal,   --2
      lvsnow_full_addr,   --现  住 址
      lvsswitch_visage,   --政治面貌
      lvedu_degree,   --学　　历
      lvsother_info,   --2
      lvshuji_region,   --户籍所在地2
      lvshuji_full_addr,   --户籍所在地详址2
      lvsspeciality,   --专　　长
      lvstaste,   --爱　　好
      lvsuser_kind,   --用户类型2
      lvslogin_type,   --登录方式2
      lvwho_logged,   --登记人编号2
      lvwho_unit,   --登记单位编号2
      lvwhen_logged,   --登记时间2
      lvsstate,   --状  态 2
      lvswork_story,   --工作经历
      lvshome_phone,   --住宅电话
      lvsinternet_mail,   --邮箱地址
      lvnareaid,   --2
      lvsunitname,   --常关注的单位
      lvdbbj,   --2
      lvdbsj,   --2
      lvquestion,   --密码保护问题
      lvanswer,   --答　　案
      lvqq    --qq号码
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_commoner
    Set
      slogin_id=lvslogin_id,   --账　　号
      spwd=lvspwd,   --密　　码
      personid=lvpersonid,   --人员编号2
      name=lvname,   --姓　　名
      pid=lvpid,   --身份号码
      dob=lvdob,   --出生日期
      gender=lvgender,   --性　　别
      nation=lvnation,   --民　　族
      marriage=lvmarriage,   --婚姻状况
      native_place=lvnative_place,   --籍　　贯
      natal=lvnatal,   --2
      snow_full_addr=lvsnow_full_addr,   --现  住 址
      sswitch_visage=lvsswitch_visage,   --政治面貌
      edu_degree=lvedu_degree,   --学　　历
      sother_info=lvsother_info,   --2
      shuji_region=lvshuji_region,   --户籍所在地2
      shuji_full_addr=lvshuji_full_addr,   --户籍所在地详址2
      sspeciality=lvsspeciality,   --专　　长
      staste=lvstaste,   --爱　　好
      suser_kind=lvsuser_kind,   --用户类型2
      slogin_type=lvslogin_type,   --登录方式2
      who_logged=lvwho_logged,   --登记人编号2
      who_unit=lvwho_unit,   --登记单位编号2
      when_logged=lvwhen_logged,   --登记时间2
      sstate=lvsstate,   --状  态 2
      swork_story=lvswork_story,   --工作经历
      shome_phone=lvshome_phone,   --住宅电话
      sinternet_mail=lvsinternet_mail,   --邮箱地址
      nareaid=lvnareaid,   --2
      sunitname=lvsunitname,   --常关注的单位
      dbbj=lvdbbj,   --2
      dbsj=lvdbsj,   --2
      question=lvquestion,   --密码保护问题
      answer=lvanswer,   --答　　案
      qq=lvqq    --qq号码
    Where 1=1
    and personid=lvpersonid   --账　　号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_commoner
    Set
      slogin_id=lvslogin_id,   --账　　号
      spwd=lvspwd,   --密　　码
      personid=lvpersonid,   --人员编号2
      name=lvname,   --姓　　名
      pid=lvpid,   --身份号码
      dob=lvdob,   --出生日期
      gender=lvgender,   --性　　别
      nation=lvnation,   --民　　族
      marriage=lvmarriage,   --婚姻状况
      native_place=lvnative_place,   --籍　　贯
      natal=lvnatal,   --2
      snow_full_addr=lvsnow_full_addr,   --现  住 址
      sswitch_visage=lvsswitch_visage,   --政治面貌
      edu_degree=lvedu_degree,   --学　　历
      sother_info=lvsother_info,   --2
      shuji_region=lvshuji_region,   --户籍所在地2
      shuji_full_addr=lvshuji_full_addr,   --户籍所在地详址2
      sspeciality=lvsspeciality,   --专　　长
      staste=lvstaste,   --爱　　好
      suser_kind=lvsuser_kind,   --用户类型2
      slogin_type=lvslogin_type,   --登录方式2
      who_logged=lvwho_logged,   --登记人编号2
      who_unit=lvwho_unit,   --登记单位编号2
      when_logged=lvwhen_logged,   --登记时间2
      sstate=lvsstate,   --状  态 2
      swork_story=lvswork_story,   --工作经历
      shome_phone=lvshome_phone,   --住宅电话
      sinternet_mail=lvsinternet_mail,   --邮箱地址
      nareaid=lvnareaid,   --2
      sunitname=lvsunitname,   --常关注的单位
      dbbj=lvdbbj,   --2
      dbsj=lvdbsj,   --2
      question=lvquestion,   --密码保护问题
      answer=lvanswer,   --答　　案
      qq=lvqq    --qq号码
    Where 1=1
    and personid=lvpersonid  --账　　号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_commoner
    Where 1=1
    and personid=lvpersonid   --账　　号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

