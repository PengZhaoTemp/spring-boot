create procedure proc_up_flag as
begin
  update tc_webjj.update_flag set state='1', flag='Y' where state='0' and flag='N';
  commit;
end;
/

