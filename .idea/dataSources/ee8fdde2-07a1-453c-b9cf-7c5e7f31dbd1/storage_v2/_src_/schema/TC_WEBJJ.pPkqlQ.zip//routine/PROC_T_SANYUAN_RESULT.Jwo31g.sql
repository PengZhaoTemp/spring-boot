create PROCEDURE          PROC_t_sanyuan_result   /*T_SANYUAN_RESULT*/
(
 lvsdono IN OUT VARCHAR2,  --业务编号
 lvspid VARCHAR2,  --身份证号
 lvsname VARCHAR2,  --姓　　名
 lvstmno VARCHAR2,  --题目编号
 lvschoose VARCHAR2,  --考生的答案
 lvsanswer VARCHAR2,  --标准答案
 lvsks_time DATE,  --考试时间
 lvsks_fenshu VARCHAR2,  --考试分数
 lvspsnno VARCHAR2,  --人员编号
 lvsks_zf VARCHAR2,  --总　　分
 lvsjdl_no VARCHAR,--试卷类型
 lvsjbk_type VARCHAR2,--报考类型
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS

BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/



   INSERT into tc_webjj.t_sanyuan_result
    (
      sdono,   --业务编号
      spid,   --身份证号
      sname,   --姓　　名
      stmno,   --题目编号
      schoose,   --考生的答案
      sanswer,   --标准答案
      sks_time,   --考试时间
      sks_fenshu,   --考试分数
      spsnno,   --人员编号
      sks_zf ,   --总　　分
      sjdl_no,
      sjbk_type
    )values(
      lvsdono,   --业务编号
      lvspid,   --身份证号
      lvsname,   --姓　　名
      lvstmno,   --题目编号
      lvschoose,   --考生的答案
      lvsanswer,   --标准答案
      sysdate,   --考试时间
      lvsks_fenshu,   --考试分数
      lvspsnno,   --人员编号

      lvsks_zf ,   --总　　分
      lvsjdl_no,
      lvsjbk_type
    );
   -- 返回值

END IF;

IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_sanyuan_result
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

