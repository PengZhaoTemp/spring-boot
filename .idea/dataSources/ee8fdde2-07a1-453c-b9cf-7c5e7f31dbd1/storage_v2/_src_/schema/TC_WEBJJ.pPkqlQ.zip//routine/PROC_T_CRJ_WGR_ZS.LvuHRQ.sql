create PROCEDURE          PROC_t_crj_wgr_zs   /*T_CRJ_WGR_ZS*/
(
 lvsdono IN OUT VARCHAR2,  --业务编号
 lvstb_type VARCHAR2,  --填表类型0港澳台同胞临时住宿1外国人临时住宿 2散居
 lvszs_name VARCHAR2,  --英文姓名
 lvszs_sex VARCHAR2,  --性　　别
 lvszs_gj VARCHAR2,  --国　　籍
 lvszs_zy VARCHAR2,  --身份职业
 lvsrj_adr VARCHAR2,  --入境口岸
 lvszj_name VARCHAR2,  --证件名称
 lvszj_num VARCHAR2,  --证件号码
 lvszj_yxq DATE,  --证件有效期
 lvsqz_type VARCHAR2,  --签证种类
 lvsqz_num VARCHAR2,  --签证号码
 lvstl_yxq DATE,  --停留有效期
 lvstl_reason VARCHAR2,  --停留事由
 lvswhere_com VARCHAR2,  --何  处 来
 lvswhere_go VARCHAR2,  --去  何 处
 lvsjw_address VARCHAR2,  --境外住址
 lvsjd_unit VARCHAR2,  --接待单位
 lvsaddress VARCHAR2,  --现在住址
 lvsnz_date DATE,  --拟住日期
 lvsol1 VARCHAR2,  --备　　注
 lvsls_name VARCHAR2,  --留宿人
 lvstb_date DATE,  --填表日期
 lvsfd_name VARCHAR2,  --房东姓名
 lvsfd_gx VARCHAR2,  --与房东关系
 lvszs_xm VARCHAR2,  --中文姓名
 lvsrj_time DATE,  --入境日期
 lvszs_birth DATE,  --出生日期
 lvszs_ywx VARCHAR2,  --英  文 姓
 lvszs_ywm VARCHAR2,  --英  文 名
 lvsjb_name VARCHAR2,  --经  办 人
 lvsfd_phone VARCHAR2,  --房东电话
 lvsjj_lxr VARCHAR2,  --紧急情况下的联系人
 lvsjj_phone VARCHAR2,  --联系人电话
 lvsgz_jg VARCHAR2,  --工作机构
 lvsqz_jg VARCHAR2,  --签证机构
 lvszs_type VARCHAR2,  --住房类型
 lvsls_unit varchar2,--留宿单位
 lvssf_qz   varchar2,--是否签注 0有1无
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS

BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/



   INSERT into tc_webjj.t_crj_wgr_zs
    (
      sdono,   --业务编号
      stb_type,   --填表类型0港澳台同胞临时住宿1外国人临时住宿 2散居
      szs_name,   --英文姓名
      szs_sex,   --性　　别
      szs_gj,   --国　　籍
      szs_zy,   --身份职业
      srj_adr,   --入境口岸
      szj_name,   --证件名称
      szj_num,   --证件号码
      szj_yxq,   --证件有效期
      sqz_type,   --签证种类
      sqz_num,   --签证号码
      stl_yxq,   --停留有效期
      stl_reason,   --停留事由
      swhere_com,   --何  处 来
      swhere_go,   --去  何 处
      sjw_address,   --境外住址
      sjd_unit,   --接待单位
      saddress,   --现在住址
      snz_date,   --拟住日期
      sol1,   --备　　注
      sls_name,   --留宿人
      stb_date,   --填表日期
      sfd_name,   --房东姓名
      sfd_gx,   --与房东关系
      szs_xm,   --中文姓名
      srj_time,   --入境日期
      szs_birth,   --出生日期
      szs_ywx,   --英  文 姓
      szs_ywm,   --英  文 名
      sjb_name,   --经  办 人
      sfd_phone,   --房东电话
      sjj_lxr,   --紧急情况下的联系人
      sjj_phone,   --联系人电话
      sgz_jg,   --工作机构
      sqz_jg,   --签证机构
      szs_type,    --住房类型
      sls_unit,
      ssf_qz
    )values(
      lvsdono,   --业务编号
      lvstb_type,   --填表类型0港澳台同胞临时住宿1外国人临时住宿 2散居
      lvszs_name,   --英文姓名
      lvszs_sex,   --性　　别
      lvszs_gj,   --国　　籍
      lvszs_zy,   --身份职业
      lvsrj_adr,   --入境口岸
      lvszj_name,   --证件名称
      lvszj_num,   --证件号码
      lvszj_yxq,   --证件有效期
      lvsqz_type,   --签证种类
      lvsqz_num,   --签证号码
      lvstl_yxq,   --停留有效期
      lvstl_reason,   --停留事由
      lvswhere_com,   --何  处 来
      lvswhere_go,   --去  何 处
      lvsjw_address,   --境外住址
      lvsjd_unit,   --接待单位
      lvsaddress,   --现在住址
      lvsnz_date,   --拟住日期
      lvsol1,   --备　　注
      lvsls_name,   --留宿单位或留宿人
      sysdate,   --填表日期
      lvsfd_name,   --房东姓名
      lvsfd_gx,   --与房东关系
      lvszs_xm,   --中文姓名
      lvsrj_time,   --入境日期
      lvszs_birth,   --出生日期
      lvszs_ywx,   --英  文 姓
      lvszs_ywm,   --英  文 名
      lvsjb_name,   --经  办 人
      lvsfd_phone,   --房东电话
      lvsjj_lxr,   --紧急情况下的联系人
      lvsjj_phone,   --联系人电话
      lvsgz_jg,   --工作机构
      lvsqz_jg,   --签证机构

      lvszs_type,    --住房类型
      lvsls_unit,
      lvssf_qz

    );
   -- 返回值

END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_crj_wgr_zs
    Set
      sdono=lvsdono,   --业务编号
      stb_type=lvstb_type,   --填表类型0港澳台同胞临时住宿1外国人临时住宿 2散居
      szs_name=lvszs_name,   --英文姓名
      szs_sex=lvszs_sex,   --性　　别
      szs_gj=lvszs_gj,   --国　　籍
      szs_zy=lvszs_zy,   --身份职业
      srj_adr=lvsrj_adr,   --入境口岸
      szj_name=lvszj_name,   --证件名称
      szj_num=lvszj_num,   --证件号码
      szj_yxq=lvszj_yxq,   --证件有效期
      sqz_type=lvsqz_type,   --签证种类
      sqz_num=lvsqz_num,   --签证号码
      stl_yxq=lvstl_yxq,   --停留有效期
      stl_reason=lvstl_reason,   --停留事由
      swhere_com=lvswhere_com,   --何  处 来
      swhere_go=lvswhere_go,   --去  何 处
      sjw_address=lvsjw_address,   --境外住址
      sjd_unit=lvsjd_unit,   --接待单位
      saddress=lvsaddress,   --现在住址
      snz_date=lvsnz_date,   --拟住日期
      sol1=lvsol1,   --备　　注
      sls_name=lvsls_name,   --留宿单位或留宿人
      stb_date=sysdate,   --填表日期
      sfd_name=lvsfd_name,   --房东姓名
      sfd_gx=lvsfd_gx,   --与房东关系
      szs_xm=lvszs_xm,   --中文姓名
      srj_time=lvsrj_time,   --入境日期
      szs_birth=lvszs_birth,   --出生日期
      szs_ywx=lvszs_ywx,   --英  文 姓
      szs_ywm=lvszs_ywm,   --英  文 名
      sjb_name=lvsjb_name,   --经  办 人
      sfd_phone=lvsfd_phone,   --房东电话
      sjj_lxr=lvsjj_lxr,   --紧急情况下的联系人
      sjj_phone=lvsjj_phone,   --联系人电话
      sgz_jg=lvsgz_jg,   --工作机构
      sqz_jg=lvsqz_jg,   --签证机构
      szs_type=lvszs_type,    --住房类型
      sls_unit=lvsls_unit,
      ssf_qz=lvssf_qz
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_crj_wgr_zs
    Set
      sdono=lvsdono,   --业务编号
      stb_type=lvstb_type,   --填表类型0港澳台同胞临时住宿1外国人临时住宿 2散居
      szs_name=lvszs_name,   --英文姓名
      szs_sex=lvszs_sex,   --性　　别
      szs_gj=lvszs_gj,   --国　　籍
      szs_zy=lvszs_zy,   --身份职业
      srj_adr=lvsrj_adr,   --入境口岸
      szj_name=lvszj_name,   --证件名称
      szj_num=lvszj_num,   --证件号码
      szj_yxq=lvszj_yxq,   --证件有效期
      sqz_type=lvsqz_type,   --签证种类
      sqz_num=lvsqz_num,   --签证号码
      stl_yxq=lvstl_yxq,   --停留有效期
      stl_reason=lvstl_reason,   --停留事由
      swhere_com=lvswhere_com,   --何  处 来
      swhere_go=lvswhere_go,   --去  何 处
      sjw_address=lvsjw_address,   --境外住址
      sjd_unit=lvsjd_unit,   --接待单位
      saddress=lvsaddress,   --现在住址
      snz_date=lvsnz_date,   --拟住日期
      sol1=lvsol1,   --备　　注
      sls_name=lvsls_name,   --留宿单位或留宿人
      stb_date=sysdate,   --填表日期
      sfd_name=lvsfd_name,   --房东姓名
      sfd_gx=lvsfd_gx,   --与房东关系
      szs_xm=lvszs_xm,   --中文姓名
      srj_time=lvsrj_time,   --入境日期
      szs_birth=lvszs_birth,   --出生日期
      szs_ywx=lvszs_ywx,   --英  文 姓
      szs_ywm=lvszs_ywm,   --英  文 名
      sjb_name=lvsjb_name,   --经  办 人
      sfd_phone=lvsfd_phone,   --房东电话
      sjj_lxr=lvsjj_lxr,   --紧急情况下的联系人
      sjj_phone=lvsjj_phone,   --联系人电话
      sgz_jg=lvsgz_jg,   --工作机构
      sqz_jg=lvsqz_jg,   --签证机构
      szs_type=lvszs_type,    --住房类型
       sls_unit=lvsls_unit,
      ssf_qz=lvssf_qz
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_crj_wgr_zs
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

