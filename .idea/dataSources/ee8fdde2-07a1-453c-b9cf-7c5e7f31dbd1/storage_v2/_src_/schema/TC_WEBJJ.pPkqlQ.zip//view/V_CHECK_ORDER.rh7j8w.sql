create view V_CHECK_ORDER as
  select o.sdono,
       o.scarno,
       o.scartype,
       o.sphone,
       o.out_app_pid,
       o.out_app_name,
       d.sbusno,
       d.sbusname,
       d.SDOUNIT,
       to_char(d.DBOOKINGDATE, 'yyyy-mm-dd') bookingdate,
       d.DBOOKINGDATE,
       d.STATE,
       d.stateCn,
       d.SDOUNITNO,
       (select fieldvaluecn
          from tc_webjj.t_fieldvalue_deploy
         where fieldno = 736
           and fieldvalue = o.scartype) scartypecn
  from tc_webjj.t_check_order o, tc_webjj.v_dobus d
 where d.sbusno = '0417'
   and o.sdono = d.sdono
   and d.state = '43'
/

