create PROCEDURE          PROC_t_gasw_nbxx   /*T_GASW_NBXX*/
(
 lvnbbh IN OUT VARCHAR2,  --nbbh
 lvsdono VARCHAR2,  --sdono
 lvsname VARCHAR2,  --姓　　名
 lvsex VARCHAR2,  --s  e x
 lvspid VARCHAR2,  --身份证号码
 lvshj VARCHAR2,  --s  h j
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
   select  tc_webjj.seq_gasw_nbxx.nextval into lvnbbh from dual;
   INSERT into tc_webjj.t_gasw_nbxx
    (
      nbbh,   --nbbh
      sdono,   --sdono
      sname,   --姓　　名
      sex,   --s  e x
      spid,   --身份证号码
      shj ,   --s  h j
      dbbj,
      dbsj
    )values(
      lvnbbh,   --nbbh
      lvsdono,   --sdono
      lvsname,   --姓　　名
      lvsex,   --s  e x
      lvspid,   --身份证号码
      lvshj,    --s  h j
      '0',
      sysdate
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_gasw_nbxx
    Set
      nbbh=lvnbbh,   --nbbh
      sdono=lvsdono,   --sdono
      sname=lvsname,   --姓　　名
      sex=lvsex,   --s  e x
      spid=lvspid,   --身份证号码
      shj=lvshj ,   --s  h j
      dbbj='0',
      dbsj=sysdate
    Where 1=1
    and nbbh=lvnbbh   --nbbh
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_gasw_nbxx
    Set
      nbbh=lvnbbh,   --nbbh
      sdono=lvsdono,   --sdono
      sname=lvsname,   --姓　　名
      sex=lvsex,   --s  e x
      spid=lvspid,   --身份证号码
      shj=lvshj ,   --s  h j
       dbbj='0',
      dbsj=sysdate
    Where 1=1
    and nbbh=lvnbbh   --nbbh
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_gasw_nbxx
    Where 1=1
    and nbbh=lvnbbh   --nbbh
    ;
END IF;
 Commit;
END; /*存储过程结束*/

