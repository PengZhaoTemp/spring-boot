create procedure          PROC_t_xzfy_sq_SDONO
(
     lvoldsdono VARCHAR2,  --办理编号
     lvReturn in out varchar2 --新办理编号
)
as
  cursor c is
     select * from tc_webjj.t_xzfy_sq
     where 1=1
     and sdono=lvoldsdono ;  --办理编号
      r c%rowtype;

BEGIN
   select TC_WEBJJ.fun_get16code(TC_WEBJJ.SEQ_T_DOBUS_SDONO.Nextval)  into  lvReturn from dual  where 1=1;
   for r in c loop
    INSERT into tc_webjj.t_xzfy_sq
    (
      sdono,   --办理编号
      s_cf_unit,   --处罚单位/被申请人
      s_cf_sdtime,   --处罚决定书送达时间
      s_cf_bh,   --处罚决定书编号
      s_cf_jl,
      s_cf_fk,
      s_cf_content,   --处罚内容
      s_sq_name,   --委托人姓名
      s_sq_pid,   --委托人身份证
      s_relation,   --与被处罚人关系
      stel,   --联系电话/委托人联系电话
      s_yjdz,   --邮寄地址
      s_cxsq,   --撤销申请标记
      s_cx_reason,   --撤销原因
      s_result,   --决议结果
      s_name,   --申  请 人
      s_sex,   --性　　别
      s_birth,   --出生日期
      s_pid,   --身份证号码
      s_unit,   --工作单位
      s_address,   --住　　所
      s_postcode,   --邮政编码
      s_tel,   --电　　话
      s_unit_name,   --组织名称
      s_unit_address,   --住　　所
      s_unit_code,   --邮政编码
      s_unit_tel,   --电　　话
      s_unit_dbr,   --法定代表/主要负责人
      s_unit_zw,   --职　　务
      s_xzfy_qq,   --行政复议请求
      s_reason,   --事实和理由
      s_xzfy_unit,    --s_xzfy_unit
      s_result_date,--决议时间
      s_result_user --决议人
    )values(
       lvReturn,   --办理编号
      r.s_cf_unit,   --处罚单位/被申请人
      r.s_cf_sdtime,   --处罚决定书送达时间
      r.s_cf_bh,   --处罚决定书编号
      r.s_cf_jl,
      r.s_cf_fk,
      r.s_cf_content,   --处罚内容
      r.s_sq_name,   --委托人姓名
      r.s_sq_pid,   --委托人身份证
      r.s_relation,   --与被处罚人关系
      r.stel,   --联系电话/委托人联系电话
      r.s_yjdz,   --邮寄地址
      '0',   --撤销申请标记
      '',   --撤销原因
      r.s_result,   --决议结果
      r.s_name,   --申  请 人
      r.s_sex,   --性　　别
      r.s_birth,   --出生日期
      r.s_pid,   --身份证号码
      r.s_unit,   --工作单位
      r.s_address,   --住　　所
      r.s_postcode,   --邮政编码
      r.s_tel,   --电　　话
      r.s_unit_name,   --组织名称
      r.s_unit_address,   --住　　所
      r.s_unit_code,   --邮政编码
      r.s_unit_tel,   --电　　话
      r.s_unit_dbr,   --法定代表/主要负责人
      r.s_unit_zw,   --职　　务
      r.s_xzfy_qq,   --行政复议请求
      r.s_reason,   --事实和理由
      r.s_xzfy_unit,    --s_xzfy_unit
      r.s_result_date,--决议时间
      r.s_result_user --决议人

    );
   -- 返回值

    commit;
    end loop;
END;

/

