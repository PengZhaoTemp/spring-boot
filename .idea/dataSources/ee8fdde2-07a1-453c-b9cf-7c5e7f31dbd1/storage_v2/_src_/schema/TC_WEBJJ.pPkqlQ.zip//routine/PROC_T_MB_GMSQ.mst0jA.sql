create PROCEDURE          PROC_t_mb_gmsq   /*T_MB_GMSQ*/
(
 lvsdono IN OUT VARCHAR2,  --业务编号（与购买物品表关联）
 lvsgm_name VARCHAR2,  --购买单位名称
 lvsgm_dz VARCHAR2,  --购买单位地址
 lvsgm_yyzz VARCHAR2,  --购买单位营业执照
 lvsgm_frzs VARCHAR2,  --事业单位法人证书编号
 lvsgm_bpdw_bh VARCHAR2,  --爆破单位许可证编号
 lvsgm_yhzh VARCHAR2,  --银行账号
 lvsgm_fzr VARCHAR2,  --购买负责人
 lvsgm_lxfs VARCHAR2,  --购买负责人联系方式
 lvsgm_jbr VARCHAR2,  --购买经办人
 lvsgm_jbr_pid VARCHAR2,  --购买经办人姓名
 lvsgm_jbr_lxfs VARCHAR2,  --购买经办人联系方式
 lvsxs_name VARCHAR2,  --销售单位名称
 lvsxs_dz VARCHAR2,  --销售单位地址
 lvsxs_xvk_bh VARCHAR2,  --销售单位许可证编号
 lvsxs_yhzh VARCHAR2,  --银行账号
 lvsxs_fzr VARCHAR2,  --销售负责人
 lvsxs_lxfs VARCHAR2,  --销售负责人联系方式
 lvsxs_bz VARCHAR2,  --备　　注
 lvsxs_shr VARCHAR2,  --审  核 人
 lvsxs_shsj DATE,  --审核时间
 lvsxs_qfr VARCHAR2,  --签  发 人
 lvsxs_qfsj DATE,  --签发时间
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS

BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/



   INSERT into tc_webjj.t_mb_gmsq
    (
      sdono,   --业务编号（与购买物品表关联）
      sgm_name,   --购买单位名称
      sgm_dz,   --购买单位地址
      sgm_yyzz,   --购买单位营业执照
      sgm_frzs,   --事业单位法人证书编号
      sgm_bpdw_bh,   --爆破单位许可证编号
      sgm_yhzh,   --银行账号
      sgm_fzr,   --购买负责人
      sgm_lxfs,   --购买负责人联系方式
      sgm_jbr,   --购买经办人
      sgm_jbr_pid,   --购买经办人姓名
      sgm_jbr_lxfs,   --购买经办人联系方式
      sxs_name,   --销售单位名称
      sxs_dz,   --销售单位地址
      sxs_xvk_bh,   --销售单位许可证编号
      sxs_yhzh,   --银行账号
      sxs_fzr,   --销售负责人
      sxs_lxfs,   --销售负责人联系方式
      sxs_bz,   --备　　注
      sxs_shr,   --审  核 人
      sxs_shsj,   --审核时间
      sxs_qfr,   --签  发 人
      sxs_qfsj  ,  --签发时间
      dbbj,
      dbsj
    )values(
      lvsdono,   --业务编号（与购买物品表关联）
      lvsgm_name,   --购买单位名称
      lvsgm_dz,   --购买单位地址
      lvsgm_yyzz,   --购买单位营业执照
      lvsgm_frzs,   --事业单位法人证书编号
      lvsgm_bpdw_bh,   --爆破单位许可证编号
      lvsgm_yhzh,   --银行账号
      lvsgm_fzr,   --购买负责人
      lvsgm_lxfs,   --购买负责人联系方式
      lvsgm_jbr,   --购买经办人
      lvsgm_jbr_pid,   --购买经办人姓名
      lvsgm_jbr_lxfs,   --购买经办人联系方式
      lvsxs_name,   --销售单位名称
      lvsxs_dz,   --销售单位地址
      lvsxs_xvk_bh,   --销售单位许可证编号
      lvsxs_yhzh,   --银行账号
      lvsxs_fzr,   --销售负责人
      lvsxs_lxfs,   --销售负责人联系方式
      lvsxs_bz,   --备　　注
      lvsxs_shr,   --审  核 人
      lvsxs_shsj,   --审核时间
      lvsxs_qfr,   --签  发 人

      lvsxs_qfsj ,   --签发时间
      '0',
      sysdate
    );
   -- 返回值

END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_mb_gmsq
    Set
      sdono=lvsdono,   --业务编号（与购买物品表关联）
      sgm_name=lvsgm_name,   --购买单位名称
      sgm_dz=lvsgm_dz,   --购买单位地址
      sgm_yyzz=lvsgm_yyzz,   --购买单位营业执照
      sgm_frzs=lvsgm_frzs,   --事业单位法人证书编号
      sgm_bpdw_bh=lvsgm_bpdw_bh,   --爆破单位许可证编号
      sgm_yhzh=lvsgm_yhzh,   --银行账号
      sgm_fzr=lvsgm_fzr,   --购买负责人
      sgm_lxfs=lvsgm_lxfs,   --购买负责人联系方式
      sgm_jbr=lvsgm_jbr,   --购买经办人
      sgm_jbr_pid=lvsgm_jbr_pid,   --购买经办人姓名
      sgm_jbr_lxfs=lvsgm_jbr_lxfs,   --购买经办人联系方式
      sxs_name=lvsxs_name,   --销售单位名称
      sxs_dz=lvsxs_dz,   --销售单位地址
      sxs_xvk_bh=lvsxs_xvk_bh,   --销售单位许可证编号
      sxs_yhzh=lvsxs_yhzh,   --银行账号
      sxs_fzr=lvsxs_fzr,   --销售负责人
      sxs_lxfs=lvsxs_lxfs,   --销售负责人联系方式
      sxs_bz=lvsxs_bz,   --备　　注
      sxs_shr=lvsxs_shr,   --审  核 人
      sxs_shsj=lvsxs_shsj,   --审核时间
      sxs_qfr=lvsxs_qfr,   --签  发 人
      sxs_qfsj=lvsxs_qfsj ,   --签发时间
      dbbj='0',
      dbsj=sysdate
    Where 1=1
    and sdono=lvsdono   --业务编号（与购买物品表关联）
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_mb_gmsq
    Set
      sdono=lvsdono,   --业务编号（与购买物品表关联）
      sgm_name=lvsgm_name,   --购买单位名称
      sgm_dz=lvsgm_dz,   --购买单位地址
      sgm_yyzz=lvsgm_yyzz,   --购买单位营业执照
      sgm_frzs=lvsgm_frzs,   --事业单位法人证书编号
      sgm_bpdw_bh=lvsgm_bpdw_bh,   --爆破单位许可证编号
      sgm_yhzh=lvsgm_yhzh,   --银行账号
      sgm_fzr=lvsgm_fzr,   --购买负责人
      sgm_lxfs=lvsgm_lxfs,   --购买负责人联系方式
      sgm_jbr=lvsgm_jbr,   --购买经办人
      sgm_jbr_pid=lvsgm_jbr_pid,   --购买经办人姓名
      sgm_jbr_lxfs=lvsgm_jbr_lxfs,   --购买经办人联系方式
      sxs_name=lvsxs_name,   --销售单位名称
      sxs_dz=lvsxs_dz,   --销售单位地址
      sxs_xvk_bh=lvsxs_xvk_bh,   --销售单位许可证编号
      sxs_yhzh=lvsxs_yhzh,   --银行账号
      sxs_fzr=lvsxs_fzr,   --销售负责人
      sxs_lxfs=lvsxs_lxfs,   --销售负责人联系方式
      sxs_bz=lvsxs_bz,   --备　　注
      sxs_shr=lvsxs_shr,   --审  核 人
      sxs_shsj=lvsxs_shsj,   --审核时间
      sxs_qfr=lvsxs_qfr,   --签  发 人
      sxs_qfsj=lvsxs_qfsj ,   --签发时间
      dbbj='0',
      dbsj=sysdate
    Where 1=1
    and sdono=lvsdono   --业务编号（与购买物品表关联）
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_mb_gmsq
    Where 1=1
    and sdono=lvsdono   --业务编号（与购买物品表关联）
    ;
END IF;
 Commit;
END; /*存储过程结束*/

