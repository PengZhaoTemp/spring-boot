create PROCEDURE          PROC_t_sanyuan_change_info   /*T_SANYUAN_CHANGE_INFO*/
(
 lvsdono IN OUT VARCHAR2,  --业务编号
 lvspsnno VARCHAR2,  --人员编号
 lvsxg_time DATE,  --修改时间
 lvsxg_xm VARCHAR2,  --修改项目
 lvsxgq_content VARCHAR2,  --修改前内容
 lvsxgh_content VARCHAR2,  --修改后内容
 lvssh_person VARCHAR2,  --审  核 人
 lvssh_time DATE,  --审核时间
 lvsbg_content VARCHAR2,  --变更描述
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS

BEGIN
  --begin TRAN

IF lv_procMode='PMINSERT' THEN    /*登记*/



   INSERT into tc_webjj.t_sanyuan_change_info
    (
      sdono,   --业务编号
      spsnno,   --人员编号
      sxg_time,   --修改时间
      sxg_xm,   --修改项目
      sxgq_content,   --修改前内容
      sxgh_content,   --修改后内容
      ssh_person,   --审  核 人
      ssh_time,   --审核时间
      sbg_content    --变更描述
    )values(
      lvsdono,   --业务编号
      lvspsnno,   --人员编号
      sysdate,   --申请修改时间
      lvsxg_xm,   --修改项目
      lvsxgq_content,   --修改前内容
      lvsxgh_content,   --修改后内容
      lvssh_person,   --审  核 人
      lvssh_time,   --审核时间

      lvsbg_content    --变更描述


    );
   -- 返回值

END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_sanyuan_change_info
    Set
      sdono=lvsdono,   --业务编号
      spsnno=lvspsnno,   --人员编号
      sxg_time=sysdate,   --修改时间
      sxg_xm=lvsxg_xm,   --修改项目
      sxgq_content=lvsxgq_content,   --修改前内容
      sxgh_content=lvsxgh_content,   --修改后内容
      ssh_person=lvssh_person,   --审  核 人
      ssh_time=lvssh_time,   --审核时间
      sbg_content=lvsbg_content    --变更描述
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_sanyuan_change_info
    Set
      sdono=lvsdono,   --业务编号
      spsnno=lvspsnno,   --人员编号
      sxg_time=sysdate,   --修改时间
      sxg_xm=lvsxg_xm,   --修改项目
      sxgq_content=lvsxgq_content,   --修改前内容
      sxgh_content=lvsxgh_content,   --修改后内容
      ssh_person=lvssh_person,   --审  核 人
      ssh_time=lvssh_time,   --审核时间
      sbg_content=lvsbg_content    --变更描述
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_sanyuan_change_info
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

