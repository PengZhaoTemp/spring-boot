create procedure proc_mailbox_save(
      lvsid         in out      varchar2,
      lvsregion_name      varchar2, --区县名称
      lvsregion_id        varchar2, --区县id
      lvstype       varchar2,       --咨询类型
      lvstitle      varchar2,       --咨询标题
      lvscontent    varchar2,       --咨询类型
      lvsuserid     varchar2,       --登记人id
      lvsname       varchar2,       --登记人名称
      lvsphone      varchar2,       --登记人联系方式
      lvsphoneaddr  varchar2,       --
      lvsemail      varchar2,       --
      lvsaddress    varchar2,       --
      lvsmailip     varchar2,       --登记人IP
      lvsgzdw       varchar2,       --
      lvsispublic    varchar2,      --是否公开
      lvjc_type   varchar2          --提交类型

) is
  lvid varchar2(16);
begin
         if  lvsid='' or lvsid is null then
             --select tc_webjj.fun_get16code(tc_webjj.seq_portal_mailbox_sid.nextval) into lvsid from dual;
            SELECT LPAD(tc_webjj.seq_portal_mailbox_sid.nextval,10,'0') into lvsid from dual;
            --lvsid:=lvid;
         end if;

  insert into tc_webjj.t_portal_mailbox(
     sid,
     sregion_name,
     sregion_id,
     stype,
     stitle,
     scontent,
     dcreatedate,
     suserid,
     sispublic,
     sname,
     sphone,
     sphoneaddr,
     semail,
     saddress,
     smailip,
     dmaildeadline,
     sisdone,
     sgzdw,
     ssource,
     jc_type,
     xg_stype
  )values(
     lvsid,
     lvsregion_name,
     lvsregion_id,
     lvstype,
     lvstitle,
     lvscontent,
     sysdate,
     lvsuserid,
     lvsispublic,
     lvsname,
     lvsphone,
     lvsphoneaddr,
     lvsemail,
     lvsaddress,
     lvsmailip,
     sysdate+10,
     '0',
     lvsgzdw,
     '1',
     lvjc_type,
     lvstype
  );
  commit;
end proc_mailbox_save;

/

