create Procedure          proc_add_glunit
(
    lvstype VARCHAR2
)
as
   lvglunit_id VARCHAR2(16);
   CURSOR a IS SELECT bus_orgno,sbusname FROM tc_webjj.t_bus_deploy WHERE sstatus='开通' AND sbustypeno =lvstype GROUP BY bus_orgno,sbusname;
   CURSOR b IS select '01' stype,'1' unit_level, sunit_code,orgname,sshort_name from tc_jcyw.t_org where sunit_code like '61__00000000'  and substr(sunit_code,3,2)!=0 and dcancel_app_date is NULL;
   CURSOR c IS select '01' stype,'2' unit_level,sunit_code,orgname,sshort_name from tc_jcyw.t_hzorg_dzb where sunit_code like '61____000000'  and substr(sunit_code,5,2)!=0 and dcancel_app_date is NULL;
   CURSOR d IS select '01' stype,'3' unit_level,sunit_code,orgname,sshort_name from tc_jcyw.t_hzorg_dzb where sunit_code like '61______1200'  and dcancel_app_date is NULL;
   CURSOR e IS select '02' stype,'1' unit_level, sunit_code,orgname,sshort_name from tc_jcyw.t_zaorg_dzb where sunit_code like '61__00000000'  and substr(sunit_code,3,2)!=0 and dcancel_app_date is NULL;
   CURSOR f IS select '02' stype,'2' unit_level,sunit_code,orgname,sshort_name from tc_jcyw.t_zaorg_dzb where sunit_code like '61____000000'  and substr(sunit_code,5,2)!=0  and dcancel_app_date is null;
   CURSOR g IS select '02' stype,'3' unit_level,sunit_code,orgname,sshort_name from tc_jcyw.t_zaorg_dzb where sunit_code like '61______1200'  and dcancel_app_date is null;
   CURSOR h IS SELECT '03' stype,'1' unit_level , sunit_code,orgname,sshort_name from tc_jcyw.t_org where sunit_code like '61__00000000' and substr(sunit_code,3,2)!=0 and dcancel_app_date is NULL;
   CURSOR i IS select '03' stype,'2' unit_level,sunit_code,orgname,sshort_name from tc_jcyw.t_org where sunit_code like '61__00__0301' and substr(sunit_code,3,2)!=0  and dcancel_app_date is NULL;
   CURSOR j IS SELECT '10' stype,'1' unit_level , sunit_code,orgname,sshort_name from tc_jcyw.t_org where sunit_code like '61__00000000' and substr(sunit_code,3,2)!=0 and dcancel_app_date is NULL;
   CURSOR k IS select '10' stype,'2' unit_level ,sunit_code,orgname,sshort_name from tc_jcyw.t_crjorg_dzb where sunit_code like '61____000000'  and substr(sunit_code,5,2)!=0 or sunit_code like '61__00000400' and dcancel_app_date is NULL;
   CURSOR l IS SELECT '10' stype,'3' unit_level , sunit_code,orgname,sshort_name from tc_jcyw.t_crjorg_dzb where sunit_code like '61____000400' and dcancel_app_date is NULL;
   CURSOR m IS SELECT '08' stype,'1' unit_level , sunit_code,orgname,sshort_name from tc_jcyw.t_org where sunit_code like '61__00000000'  and dcancel_app_date is NULL;
   CURSOR n IS select '08' stype,'2' unit_level ,sunit_code,orgname,sshort_name from tc_jcyw.t_org where  sunit_code like '61____000700' or sunit_code like '61____000702'   and dcancel_app_date is NULL;
   CURSOR o IS SELECT '06' stype,'1' unit_level , sunit_code,orgname,sshort_name from tc_jcyw.t_org where sunit_code like '61__00000000' and substr(sunit_code,3,2)!=0 and dcancel_app_date is NULL;
   CURSOR p IS select '06' stype,'2' unit_level ,sunit_code,orgname,sshort_name from tc_jcyw.t_xforg_dzb where sunit_code like '61____000000'  and substr(sunit_code,5,2)!=0 or sunit_code like '61__00001000' and dcancel_app_date is NULL;
   CURSOR q IS SELECT '06' stype,'3' unit_level , sunit_code,orgname,sshort_name from tc_jcyw.t_xforg_dzb where sunit_code like '61____001000' and dcancel_app_date is NULL;

   CURSOR aa IS select '14' stype,'1' unit_level ,sunit_code,orgname,sshort_name from tc_jcyw.t_org where sunit_code='610100001100' and dcancel_app_date is NULL;
   CURSOR bb IS SELECT '05' stype,'1' unit_level , sunit_code,orgname,sshort_name from tc_jcyw.t_org where sunit_code like '61__00000000' and substr(sunit_code,3,2)!=0 and sunit_code!='616100000000' and dcancel_app_date  is NULL;
   CURSOR cc IS select '05' stype,'2' unit_level ,sunit_code,orgname,sshort_name from tc_jcyw.t_waorg_dzb where sunit_code like '61____000000'  and substr(sunit_code,5,2)!=0 or sunit_code like '61__00000800' and dcancel_app_date is NULL;
   CURSOR dd IS SELECT '05' stype,'3' unit_level , sunit_code,orgname,sshort_name from tc_jcyw.t_waorg_dzb where sunit_code like '61____000800' and dcancel_app_date is NULL;
   CURSOR ee IS SELECT '09' stype,'1' unit_level , sunit_code,orgname,sshort_name from tc_jcyw.t_org where sunit_code like '61__00000000' and substr(sunit_code,3,2)!=0 and dcancel_app_date is NULL;
   CURSOR ff IS select '09' stype,'2' unit_level ,sunit_code,orgname,sshort_name from tc_jcyw.t_org where sunit_code like '61____000000'  and substr(sunit_code,5,2)!=0 or sunit_code like '61__00000900' and dcancel_app_date is NULL;
   CURSOR hh IS SELECT '09' stype,'3' unit_level , sunit_code,orgname,sshort_name from tc_jcyw.t_org where sunit_code like '61____000900' and dcancel_app_date is null;

BEGIN
  IF lvstype='01' THEN--户籍
     FOR r IN a LOOP
         FOR r1 IN b LOOP
             SELECT tc_webjj.seq_glunit_manage.nextval INTO lvglunit_id FROM dual;
             INSERT INTO tc_webjj.t_glunit_manage(bus_orgno, sbusname, slevel ,sunit_code,orgname ,sshort_name, sid,stype )
             VALUES( r.bus_orgno ,r.sbusname,r1.unit_level,r1.sunit_code,r1.orgname, r1.sshort_name,lvglunit_id,lvstype);

         END LOOP;
         FOR r1 IN c LOOP
             SELECT tc_webjj.seq_glunit_manage.nextval INTO lvglunit_id FROM dual;
             INSERT INTO tc_webjj.t_glunit_manage(bus_orgno, sbusname, slevel ,sunit_code,orgname ,sshort_name, sid,stype )
             VALUES( r.bus_orgno ,r.sbusname,r1.unit_level,r1.sunit_code,r1.orgname, r1.sshort_name,lvglunit_id,lvstype);

         END LOOP;
         FOR r1 IN d LOOP
             SELECT tc_webjj.seq_glunit_manage.nextval INTO lvglunit_id FROM dual;
             INSERT INTO tc_webjj.t_glunit_manage(bus_orgno, sbusname, slevel ,sunit_code,orgname ,sshort_name, sid,stype )
             VALUES( r.bus_orgno ,r.sbusname,r1.unit_level,r1.sunit_code,r1.orgname, r1.sshort_name,lvglunit_id,lvstype);

         END LOOP;
     END LOOP;
  END IF;
  IF lvstype='02' THEN--治安
     FOR r IN a LOOP
         FOR r1 IN e LOOP
             SELECT tc_webjj.seq_glunit_manage.nextval INTO lvglunit_id FROM dual;
             INSERT INTO tc_webjj.t_glunit_manage(bus_orgno, sbusname, slevel ,sunit_code,orgname ,sshort_name, sid,stype )
             VALUES( r.bus_orgno ,r.sbusname,r1.unit_level,r1.sunit_code,r1.orgname, r1.sshort_name,lvglunit_id,lvstype);

         END LOOP;
         FOR r1 IN f LOOP
             SELECT tc_webjj.seq_glunit_manage.nextval INTO lvglunit_id FROM dual;
             INSERT INTO tc_webjj.t_glunit_manage(bus_orgno, sbusname, slevel ,sunit_code,orgname ,sshort_name, sid,stype )
             VALUES( r.bus_orgno ,r.sbusname,r1.unit_level,r1.sunit_code,r1.orgname, r1.sshort_name,lvglunit_id,lvstype);

         END LOOP;
         FOR r1 IN g LOOP
             SELECT tc_webjj.seq_glunit_manage.nextval INTO lvglunit_id FROM dual;
             INSERT INTO tc_webjj.t_glunit_manage(bus_orgno, sbusname, slevel ,sunit_code,orgname ,sshort_name, sid,stype )
             VALUES( r.bus_orgno ,r.sbusname,r1.unit_level,r1.sunit_code,r1.orgname, r1.sshort_name,lvglunit_id,lvstype);

         END LOOP;
     END LOOP;
  END IF;
  IF lvstype='03' THEN--交警
     FOR r IN a LOOP
         FOR r1 IN h LOOP
             SELECT tc_webjj.seq_glunit_manage.nextval INTO lvglunit_id FROM dual;
             INSERT INTO tc_webjj.t_glunit_manage(bus_orgno, sbusname, slevel ,sunit_code,orgname ,sshort_name, sid,stype )
             VALUES( r.bus_orgno ,r.sbusname,r1.unit_level,r1.sunit_code,r1.orgname, r1.sshort_name,lvglunit_id,lvstype);

         END LOOP;
         FOR r1 IN i LOOP
             SELECT tc_webjj.seq_glunit_manage.nextval INTO lvglunit_id FROM dual;
             INSERT INTO tc_webjj.t_glunit_manage(bus_orgno, sbusname, slevel ,sunit_code,orgname ,sshort_name, sid,stype )
             VALUES( r.bus_orgno ,r.sbusname,r1.unit_level,r1.sunit_code,r1.orgname, r1.sshort_name,lvglunit_id,lvstype);

         END LOOP;

     END LOOP;
  END IF;
  IF lvstype='10' THEN--出入境
     FOR r IN a LOOP
         FOR r1 IN j LOOP
             SELECT tc_webjj.seq_glunit_manage.nextval INTO lvglunit_id FROM dual;
             INSERT INTO tc_webjj.t_glunit_manage(bus_orgno, sbusname, slevel ,sunit_code,orgname ,sshort_name, sid,stype )
             VALUES( r.bus_orgno ,r.sbusname,r1.unit_level,r1.sunit_code,r1.orgname, r1.sshort_name,lvglunit_id,lvstype);

         END LOOP;
         FOR r1 IN k LOOP
             SELECT tc_webjj.seq_glunit_manage.nextval INTO lvglunit_id FROM dual;
             INSERT INTO tc_webjj.t_glunit_manage(bus_orgno, sbusname, slevel ,sunit_code,orgname ,sshort_name, sid,stype )
             VALUES( r.bus_orgno ,r.sbusname,r1.unit_level,r1.sunit_code,r1.orgname, r1.sshort_name,lvglunit_id,lvstype);

         END LOOP;
         FOR r1 IN l LOOP
             SELECT tc_webjj.seq_glunit_manage.nextval INTO lvglunit_id FROM dual;
             INSERT INTO tc_webjj.t_glunit_manage(bus_orgno, sbusname, slevel ,sunit_code,orgname ,sshort_name, sid,stype )
             VALUES( r.bus_orgno ,r.sbusname,r1.unit_level,r1.sunit_code,r1.orgname, r1.sshort_name,lvglunit_id,lvstype);

         END LOOP;
     END LOOP;
  END IF;
  IF lvstype='08' THEN--监所业务
     FOR r IN a LOOP
         FOR r1 IN m LOOP
             SELECT tc_webjj.seq_glunit_manage.nextval INTO lvglunit_id FROM dual;
             INSERT INTO tc_webjj.t_glunit_manage(bus_orgno, sbusname, slevel ,sunit_code,orgname ,sshort_name, sid,stype )
             VALUES( r.bus_orgno ,r.sbusname,r1.unit_level,r1.sunit_code,r1.orgname, r1.sshort_name,lvglunit_id,lvstype);

         END LOOP;
         FOR r1 IN n LOOP
             SELECT tc_webjj.seq_glunit_manage.nextval INTO lvglunit_id FROM dual;
             INSERT INTO tc_webjj.t_glunit_manage(bus_orgno, sbusname, slevel ,sunit_code,orgname ,sshort_name, sid,stype )
             VALUES( r.bus_orgno ,r.sbusname,r1.unit_level,r1.sunit_code,r1.orgname, r1.sshort_name,lvglunit_id,lvstype);

         END LOOP;

     END LOOP;
  END IF;
  IF lvstype='06' THEN--消防业务
     FOR r IN a LOOP
         FOR r1 IN o LOOP
             SELECT tc_webjj.seq_glunit_manage.nextval INTO lvglunit_id FROM dual;
             INSERT INTO tc_webjj.t_glunit_manage(bus_orgno, sbusname, slevel ,sunit_code,orgname ,sshort_name, sid,stype )
             VALUES( r.bus_orgno ,r.sbusname,r1.unit_level,r1.sunit_code,r1.orgname, r1.sshort_name,lvglunit_id,lvstype);

         END LOOP;
         FOR r1 IN p LOOP
             SELECT tc_webjj.seq_glunit_manage.nextval INTO lvglunit_id FROM dual;
             INSERT INTO tc_webjj.t_glunit_manage(bus_orgno, sbusname, slevel ,sunit_code,orgname ,sshort_name, sid,stype )
             VALUES( r.bus_orgno ,r.sbusname,r1.unit_level,r1.sunit_code,r1.orgname, r1.sshort_name,lvglunit_id,lvstype);

         END LOOP;
         FOR r1 IN q LOOP
             SELECT tc_webjj.seq_glunit_manage.nextval INTO lvglunit_id FROM dual;
             INSERT INTO tc_webjj.t_glunit_manage(bus_orgno, sbusname, slevel ,sunit_code,orgname ,sshort_name, sid,stype )
             VALUES( r.bus_orgno ,r.sbusname,r1.unit_level,r1.sunit_code,r1.orgname, r1.sshort_name,lvglunit_id,lvstype);

         END LOOP;
     END LOOP;
  END IF;
  IF lvstype='14' THEN--边防业务
     FOR r IN a LOOP
         FOR r1 IN aa LOOP
             SELECT tc_webjj.seq_glunit_manage.nextval INTO lvglunit_id FROM dual;
             INSERT INTO tc_webjj.t_glunit_manage(bus_orgno, sbusname, slevel ,sunit_code,orgname ,sshort_name, sid,stype )
             VALUES( r.bus_orgno ,r.sbusname,r1.unit_level,r1.sunit_code,r1.orgname, r1.sshort_name,lvglunit_id,lvstype);

         END LOOP;

     END LOOP;
  END IF;
  IF lvstype='05' THEN--网安业务
     FOR r IN a LOOP
         FOR r1 IN bb LOOP
             SELECT tc_webjj.seq_glunit_manage.nextval INTO lvglunit_id FROM dual;
             INSERT INTO tc_webjj.t_glunit_manage(bus_orgno, sbusname, slevel ,sunit_code,orgname ,sshort_name, sid,stype )
             VALUES( r.bus_orgno ,r.sbusname,r1.unit_level,r1.sunit_code,r1.orgname, r1.sshort_name,lvglunit_id,lvstype);

         END LOOP;
         FOR r1 IN cc LOOP
             SELECT tc_webjj.seq_glunit_manage.nextval INTO lvglunit_id FROM dual;
             INSERT INTO tc_webjj.t_glunit_manage(bus_orgno, sbusname, slevel ,sunit_code,orgname ,sshort_name, sid,stype )
             VALUES( r.bus_orgno ,r.sbusname,r1.unit_level,r1.sunit_code,r1.orgname, r1.sshort_name,lvglunit_id,lvstype);

         END LOOP;
         FOR r1 IN dd LOOP
             SELECT tc_webjj.seq_glunit_manage.nextval INTO lvglunit_id FROM dual;
             INSERT INTO tc_webjj.t_glunit_manage(bus_orgno, sbusname, slevel ,sunit_code,orgname ,sshort_name, sid,stype )
             VALUES( r.bus_orgno ,r.sbusname,r1.unit_level,r1.sunit_code,r1.orgname, r1.sshort_name,lvglunit_id,lvstype);

         END LOOP;
     END LOOP;
  END IF;
  IF lvstype='09' THEN--禁毒业务
     FOR r IN a LOOP
         FOR r1 IN ee LOOP
             SELECT tc_webjj.seq_glunit_manage.nextval INTO lvglunit_id FROM dual;
             INSERT INTO tc_webjj.t_glunit_manage(bus_orgno, sbusname, slevel ,sunit_code,orgname ,sshort_name, sid,stype )
             VALUES( r.bus_orgno ,r.sbusname,r1.unit_level,r1.sunit_code,r1.orgname, r1.sshort_name,lvglunit_id,lvstype);

         END LOOP;
         FOR r1 IN ff LOOP
             SELECT tc_webjj.seq_glunit_manage.nextval INTO lvglunit_id FROM dual;
             INSERT INTO tc_webjj.t_glunit_manage(bus_orgno, sbusname, slevel ,sunit_code,orgname ,sshort_name, sid,stype )
             VALUES( r.bus_orgno ,r.sbusname,r1.unit_level,r1.sunit_code,r1.orgname, r1.sshort_name,lvglunit_id,lvstype);

         END LOOP;
         FOR r1 IN hh LOOP
             SELECT tc_webjj.seq_glunit_manage.nextval INTO lvglunit_id FROM dual;
             INSERT INTO tc_webjj.t_glunit_manage(bus_orgno, sbusname, slevel ,sunit_code,orgname ,sshort_name, sid,stype )
             VALUES( r.bus_orgno ,r.sbusname,r1.unit_level,r1.sunit_code,r1.orgname, r1.sshort_name,lvglunit_id,lvstype);

         END LOOP;
     END LOOP;
  END IF;
  COMMIT;
end;

/

