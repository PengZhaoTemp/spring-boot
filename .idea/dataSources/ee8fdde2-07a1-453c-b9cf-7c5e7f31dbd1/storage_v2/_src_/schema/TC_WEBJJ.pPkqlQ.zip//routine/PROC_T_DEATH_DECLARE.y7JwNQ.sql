create PROCEDURE          PROC_t_death_declare   /*T_DEATH_DECLARE*/
(
 lvsdono IN OUT VARCHAR2,  --办理编号
 lvpid VARCHAR2,  --公民身份号码
 lvname VARCHAR2,  --姓　　名
 lvdate_of_death DATE,  --死亡日期
 lvout_category VARCHAR2,  --死亡原因(字典'变动原因'的代码以2开头)
 lvdeath_no VARCHAR2,  --死亡医学编号
 lvout_app_pid VARCHAR2,  --申请人身份证号码
 lvout_app_name VARCHAR2,  --申请人姓名
 lvscol3 VARCHAR2,  --备　　注
 lvsunit varchar2,--出具证明单位
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
   INSERT into tc_webjj.t_death_declare
    (
      sdono,   --办理编号
      pid,   --公民身份号码
      name,   --姓　　名
      date_of_death,   --死亡日期
      out_category,   --死亡原因(字典'变动原因'的代码以2开头)
      death_no,   --死亡医学编号
      out_app_pid,   --申请人身份证号码
      out_app_name,   --申请人姓名
      scol3,    --备　　注
      sunit
    )values(
      lvsdono,   --办理编号
      lvpid,   --公民身份号码
      lvname,   --姓　　名
      lvdate_of_death,   --死亡日期
      lvout_category,   --死亡原因(字典'变动原因'的代码以2开头)
      lvdeath_no,   --死亡医学编号
      lvout_app_pid,   --申请人身份证号码
      lvout_app_name,   --申请人姓名
      lvscol3,    --备　　注
      lvsunit
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_death_declare
    Set
      sdono=lvsdono,   --办理编号
      pid=lvpid,   --公民身份号码
      name=lvname,   --姓　　名
      date_of_death=lvdate_of_death,   --死亡日期
      out_category=lvout_category,   --死亡原因(字典'变动原因'的代码以2开头)
      death_no=lvdeath_no,   --死亡医学编号
      out_app_pid=lvout_app_pid,   --申请人身份证号码
      out_app_name=lvout_app_name,   --申请人姓名
      scol3=lvscol3,    --备　　注
      sunit=lvsunit
    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_death_declare
    Set
      sdono=lvsdono,   --办理编号
      pid=lvpid,   --公民身份号码
      name=lvname,   --姓　　名
      date_of_death=lvdate_of_death,   --死亡日期
      out_category=lvout_category,   --死亡原因(字典'变动原因'的代码以2开头)
      death_no=lvdeath_no,   --死亡医学编号
      out_app_pid=lvout_app_pid,   --申请人身份证号码
      out_app_name=lvout_app_name,   --申请人姓名
      scol3=lvscol3,    --备　　注
      sunit=lvsunit
    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_death_declare
    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

