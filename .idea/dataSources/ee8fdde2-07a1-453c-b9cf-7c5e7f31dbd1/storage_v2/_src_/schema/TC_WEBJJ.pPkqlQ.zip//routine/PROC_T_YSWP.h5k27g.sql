create PROCEDURE          PROC_t_yswp   /*T_YSWP*/
(
 lvsys_wpbh IN OUT VARCHAR2,  --运输物品编号
 lvsdono VARCHAR2,  --业务编号
 lvsys_wppz VARCHAR2,  --物品品种
 lvsys_wpsl VARCHAR2,  --物品数量
 lvsys_bzcl VARCHAR2,  --包装材料
 lvsys_bzfs VARCHAR2,  --包装方式
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS

BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/

 select  tc_webjj.seq_yswp_wpbh.nextval into lvsys_wpbh from dual;

   INSERT into tc_webjj.t_yswp
    (
      sys_wpbh,   --运输物品编号
      sdono,   --业务编号
      sys_wppz,   --物品品种
      sys_wpsl,   --物品数量
      sys_bzcl,   --包装材料
      sys_bzfs ,   --包装方式
      dbbj,
      dbsj
    )values(
      lvsys_wpbh,   --运输物品编号
      lvsdono,   --业务编号
      lvsys_wppz,   --物品品种
      lvsys_wpsl,   --物品数量
      lvsys_bzcl,   --包装材料

      lvsys_bzfs,    --包装方式
      '0',
      sysdate
    );
   -- 返回值

END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_yswp
    Set
      sys_wpbh=lvsys_wpbh,   --运输物品编号
      sdono=lvsdono,   --业务编号
      sys_wppz=lvsys_wppz,   --物品品种
      sys_wpsl=lvsys_wpsl,   --物品数量
      sys_bzcl=lvsys_bzcl,   --包装材料
      sys_bzfs=lvsys_bzfs,    --包装方式
      dbbj='0',
      dbsj=sysdate
    Where 1=1
    and sys_wpbh=lvsys_wpbh   --运输物品编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_yswp
    Set
      sys_wpbh=lvsys_wpbh,   --运输物品编号
      sdono=lvsdono,   --业务编号
      sys_wppz=lvsys_wppz,   --物品品种
      sys_wpsl=lvsys_wpsl,   --物品数量
      sys_bzcl=lvsys_bzcl,   --包装材料
      sys_bzfs=lvsys_bzfs ,   --包装方式
      dbbj='0',
      dbsj=sysdate
    Where 1=1
    and sys_wpbh=lvsys_wpbh   --运输物品编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_yswp
    Where 1=1
    and sys_wpbh=lvsys_wpbh   --运输物品编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

