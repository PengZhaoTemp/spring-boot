create view V_BUSFLOW_PLAN as
  select a.splanno,
       a.sflowno,
       a.sdono,
       a.scomplete,
       a.sresult,
       a.dendtime,
       a.nstepnum,
       b.sflowtaxis,
       b.sflowname,
       b.sbusno,
       b.sflowtype,
       b.sremark,
       b.sbusstatuscode,
       b.soperationno,
       b.snoteno,
       b.snexttaxis,
       b.sjudgetable,
       b.sjudgefield,
       b.sflowstatus,
       a.dstarttime,
       b.limitdays
  from tc_webjj.t_busflow_plan a,tc_webjj.t_busflow_deploy b
  where a.sflowno = b.sflowno
/

