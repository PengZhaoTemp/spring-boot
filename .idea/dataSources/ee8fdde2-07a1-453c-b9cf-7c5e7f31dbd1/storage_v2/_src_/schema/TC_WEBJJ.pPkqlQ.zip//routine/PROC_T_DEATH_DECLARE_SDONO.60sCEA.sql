create procedure          Proc_t_death_declare_SDONO
(
     lvoldsdono VARCHAR2,  --办理编号
     lvReturn in out varchar2 --新办理编号
)
as
  cursor c is
     select * from tc_webjj.t_death_declare
     where 1=1
     and sdono=lvoldsdono;   --公民身份号码
  r c%rowtype;

BEGIN
   select TC_WEBJJ.fun_get16code(TC_WEBJJ.SEQ_T_DOBUS_SDONO.Nextval)  into  lvReturn from dual  where 1=1;
   for r in c loop
   INSERT into tc_webjj.t_death_declare
    (
      pid,   --公民身份号码
      name,   --姓　　名
      date_of_death,   --死亡日期
      out_category,   --死亡原因(字典'变动原因'的代码以2开头)
      death_no,   --死亡医学编号
      out_app_pid,   --申请人身份证号码
      out_app_name,   --申请人姓名
      scol3,   --备　　注
      sunit,   --出具证明单位
      sdono   --办理编号
    )values(
      r.pid,   --公民身份号码
      r.name,   --姓　　名
      r.date_of_death,   --死亡日期
      r.out_category,   --死亡原因(字典'变动原因'的代码以2开头)
      r.death_no,   --死亡医学编号
      r.out_app_pid,   --申请人身份证号码
      r.out_app_name,   --申请人姓名
      r.scol3,   --备　　注
      r.sunit,
      lvReturn   --办理编号
    );
    commit;
    end loop;
END;

/

