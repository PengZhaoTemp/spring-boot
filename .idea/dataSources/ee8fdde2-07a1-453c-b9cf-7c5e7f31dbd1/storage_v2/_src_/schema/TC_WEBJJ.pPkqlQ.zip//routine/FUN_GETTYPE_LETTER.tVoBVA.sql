create function          fun_gettype_letter(lvsbusno varchar2,
                                              lvsdono  varchar2)
  return varchar2 is
  lvsurl varchar2(50);
begin
/*    有更小操作类型时，返回该业务的最小操作类型*/
  lvsurl := '';
  if lvsbusno = '003' then
    select app_type
      into lvsurl
      from tc_webjj.t_remove_declare
     where sdono = lvsdono;
  else
    lvsurl := 'sbusno is null';
  end if;
  return(lvsurl);
end fun_gettype_letter;

/

