create procedure          PROC_t_xzcf_SDONO
(
     lvoldsdono VARCHAR2,  --办理编号
     lvReturn in out varchar2 --新办理编号
)
as
  cursor c is
     select * from tc_webjj.t_xzcf
     where 1=1
     and sdono=lvoldsdono ;  --办理编号
      r c%rowtype;

BEGIN
   select TC_WEBJJ.fun_get16code(TC_WEBJJ.SEQ_T_DOBUS_SDONO.Nextval)  into  lvReturn from dual  where 1=1;
   for r in c loop
    INSERT into tc_webjj.t_xzcf
    (
      sdono,   --业务编号
      s_xzfc_no,   --行政处罚编号
      s_name,   --被处罚人
      s_pid,   --被处罚人身份证
      s_money,   --处罚金额
      s_cf_date,   --开罚单的日期
      s_jf_date,    --缴费的日期
      s_cf_aj
    )values(
      lvReturn,   --办理编号
      r.s_xzfc_no,   --行政处罚编号
      r.s_name,   --被处罚人
      r.s_pid,   --被处罚人身份证
      r.s_money,   --处罚金额
      r.s_cf_date,   --开罚单的日期
      r.s_jf_date,    --缴费的日期
      r.s_cf_aj
    );
   -- 返回值

    commit;
    end loop;
END;

/

