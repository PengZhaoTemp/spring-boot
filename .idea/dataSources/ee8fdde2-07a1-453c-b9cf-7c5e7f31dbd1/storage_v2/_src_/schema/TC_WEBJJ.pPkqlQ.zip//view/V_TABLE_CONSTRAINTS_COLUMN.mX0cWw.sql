create view V_TABLE_CONSTRAINTS_COLUMN as
  select /*+rule*/a.owner||'.'||a.table_name owner_table,
a.owner, a.table_name, a.comments, b.column_name, b.DATA_TYPE
  from v_owner_table a, v_constraints_column b
 where a.owner = b.OWNER(+)
   and a.table_name = b.table_name(+)
/

