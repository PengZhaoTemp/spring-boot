create function          fun_get16code_pz
(
  lvsdono number
)
 return varchar2 is
  sdono varchar2(500);
begin
     IF length(lvsdono)<2 then
      sdono:='350400'||'1'||'0'||'0000000'||lvsdono;
      elsIF length(lvsdono)<3 then
      sdono:='350400'||'1'||'0'||'000000'||lvsdono;
      elsIF length(lvsdono)<4 then
      sdono:='350400'||'1'||'0'||'00000'||lvsdono;
      elsIF length(lvsdono)<5 then
      sdono:='350400'||'1'||'0'||'0000'||lvsdono;
      elsIF length(lvsdono)<6 then
      sdono:='350400'||'1'||'0'||'000'||lvsdono;
      elsIF length(lvsdono)<7 then
      sdono:='350400'||'1'||'0'||'00'||lvsdono;
      elsIF length(lvsdono)<8 then
      sdono:='350400'||'1'||'0'||'0'||lvsdono;
     end if;
  return(sdono);
end fun_get16code_pz;

/

