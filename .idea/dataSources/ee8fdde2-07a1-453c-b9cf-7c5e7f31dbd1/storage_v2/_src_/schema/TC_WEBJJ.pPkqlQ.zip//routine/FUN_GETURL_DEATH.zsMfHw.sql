create function          fun_geturl_death(lv_sdono varchar2)
  return varchar2 is
  lv_surl      varchar2(500);
  lv_hu_id     number;
  lv_person_id number;
  --lv_sitem     VARCHAR2(300);
  lv_send_flag varchar2(50);
  lv_state     varchar2(2);
begin
  /*死亡注销获取传值url*/
  lv_surl := '';
  select hu_id, person_id
    into lv_hu_id, lv_person_id
    from tc_rkxt.v_tp_huji_ck
   where pid =
         (select pid from tc_webjj.t_death_declare where sdono = lv_sdono)
     and rownum < 2;
  lv_surl := lv_surl || '=' || lv_hu_id;
  lv_surl := lv_surl || '=' || lv_person_id;
 /* select sitem
    into lv_sitem
    from tc_webjj.t_applymasterdata a, tc_webjj.t_applymasterials s
   where a.smasterialsno = s.sno
     and sdono = lv_sdono
     and rownum < 2;
  if lv_sitem = '《死亡医学证明书》' then
    lv_surl := lv_surl || '&stuff=@(LVNCL_ID:902)(LVNCL_NAME:《死亡医学证明书》)@';
  elsif lv_sitem = '人民法院民事裁定书' then
    lv_surl := lv_surl || '&stuff=@(LVNCL_ID:1185)(LVNCL_NAME:人民法院民事裁定书)@';
  else
    lv_surl := lv_surl ||
               '&stuff=@(LVNCL_ID:903)(LVNCL_NAME:村(居)委会出具的死亡证明)@';
  end if;*/ --在页面添加

  select need_back, state
    into lv_send_flag, lv_state
    from tc_webjj.v_dobus
   where sdono = lv_sdono;
  if lv_send_flag = '需回寄' then
    lv_surl := lv_surl || '=1';
  else
    lv_surl := lv_surl || '=0';
  end if;
  if lv_state = '42' then
    -- 预约业务
    lv_surl := lv_surl || '=' || '888';
  end if;
    lv_surl := lv_surl || '=' || lv_sdono;


  return(lv_surl);
end fun_geturl_death;

/

