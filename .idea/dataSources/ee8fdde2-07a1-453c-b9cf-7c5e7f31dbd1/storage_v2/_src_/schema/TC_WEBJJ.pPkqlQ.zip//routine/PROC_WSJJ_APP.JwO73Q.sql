create PROCEDURE          PROC_wsjj_app /*????????????*/
(lvapplyno    varchar2, --????????
 lvuserno     varchar2, --????????
 lvmessage    varchar2, --????????
 lvcheckflag  varchar2, --???????? 20/??????  21/ ??????  22/??????????   23/????????   24/??????????   25??????
 lvapplyno_pz varchar2) AS
  lvSUNIT_CODE VARCHAR2(16); -- Y     ??????????????
  lvSUSERNO    VARCHAR2(21); --Y      ????????
  lvnote       varchar2(1000);
  lvSUNREASON  varchar2(500);
  lvspr        varchar2(45);
  lvspdw       varchar2(120);
  lvspdwno     varchar2(12);
BEGIN
  /*5+N ???????????? yzh 2011-09-26*/
  lvnote := '';
  --????????
  if lvcheckflag='22' then
    select bus.name || ',????' || to_char(bus.ddecdate, 'yyyy-mm-dd') ||
     '????????'  ||bus.sdodata || '????????????????????????'||lvSUNREASON into lvnote
     from tc_webjj.v_dobus bus where sdono = lvapplyno;
      update tc_webjj.t_dobus
         set STATE      = '28',
             SCHECKER   = lvuserno,
             DCHECKDATE = sysdate,
             DBBJ       = '0',
             DBSJ       = sysdate,
             SUNREASON  = lvmessage
       where sdono = lvapplyno;
  else
    select bus.name || ',????' || to_char(bus.ddecdate, 'yyyy-mm-dd') ||
     '????????'  ||bus.sdodata || '????????????????' into lvnote
     from tc_webjj.v_dobus bus where sdono = lvapplyno;
      update tc_webjj.t_dobus
         set STATE      = '51',
             SCHECKER   = lvuserno,
             DCHECKDATE = sysdate,
             DBBJ       = '0',
             DBSJ       = sysdate,
             SUNREASON  = lvmessage
       where sdono = lvapplyno;
  end if;
  select sdounitno
    into lvSUNIT_CODE
    from tc_webjj.t_dobus
   where sdono = lvapplyno;
  select SUSERNO
    into lvSUSERNO
    from tc_webjj.t_dobus
   where sdono = lvapplyno;
  begin
    select name,tc_jcyw.fun_get_orgname(sunit_code),sunit_code into lvspr,lvspdw,lvspdwno from tc_jcyw.t_user where npolice_id=lvuserno;
  exception when others then
    null;
  end;
  --??????????
  insert into t_bssp_info
    (sno, sdono, spyj, spr, sprno, spdw, spdwno, spdate)
  values
    (substr(lvSUNIT_CODE, 0, 6) || '12' ||
     lpad(SEQ_t_bssp_info.nextval, 8, '0'),
     lvapplyno,
     lvmessage,
     lvspr,
     lvuserno,
     lvspdw,
     lvspdwno,
     sysdate);
  insert into tc_tools.t_sjps_sendtel
    (nid, stel, scon, dbbj, dbsj)
  values
    (substr(lvSUNIT_CODE, 0, 6) || '12' ||
     lpad(tc_tools.SEQU_t_sjps_sendtel.nextval, 8, '0'),
     /* (select SHOME_PHONE from tc_webjj.t_commoner where PERSONID = lvSUSERNO),*/
     (select SHOME_PHONE  from tc_webjj.v_dobus where sdono = lvapplyno),
     lvnote||'????????????',
     '0',
     sysdate);
   commit;
END; /*????????????*/

