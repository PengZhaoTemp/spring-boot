create PROCEDURE          PROC_t_cancel_hukou   /*t_caNCEL_HUKOU*/
(
 lvsdono IN OUT VARCHAR2,  --办理编号
 lvmaster_relation VARCHAR2,  --与户主关系
 lvname VARCHAR2,  --姓　　名
 lvpid VARCHAR2,  --公民身份号码
 lvgender VARCHAR2,  --性　　别
 lvnation VARCHAR2,  --民　　族
 lvnative_country VARCHAR2,  --籍贯（国家地区）
 lvnative_place VARCHAR2,  --籍贯（省市县区）
 lvdob DATE,  --出生日期
 lvmaster_name VARCHAR2,  --户主姓名
 lvmaster_pid VARCHAR2,  --户主身份证号
 lvapp_pid VARCHAR2,  --申请人公民身份号码
 lvapp_name VARCHAR2,  --申请人姓名
 lvcancel_reason VARCHAR2,  --注销原因
 lvmemo VARCHAR2,  --备　　注
 lvgoto_address_decode VARCHAR2,  --前往地区编码(参军省市县,前往国家)
 lvgoto_address VARCHAR2,  --前往地区(参军省市县,前往国家)
 lvaddress VARCHAR2,  --前往地详址
 lvnew_master_pid varchar2,--新户主身份证号
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
   INSERT into tc_webjj.t_cancel_hukou
    (
      sdono,   --办理编号
      master_relation,   --与户主关系
      name,   --姓　　名
      pid,   --公民身份号码
      gender,   --性　　别
      nation,   --民　　族
      native_country,   --籍贯（国家地区）
      native_place,   --籍贯（省市县区）
      dob,   --出生日期
      master_name,   --户主姓名
      master_pid,   --户主身份证号
      app_pid,   --申请人公民身份号码
      app_name,   --申请人姓名
      cancel_reason,   --注销原因
      memo,   --备　　注
      goto_address_decode,   --前往地区编码(参军省市县,前往国家)
      goto_address,   --前往地区(参军省市县,前往国家)
      can_address,    --前往地详址
      new_master_pid
    )values(
      lvsdono,   --办理编号
      lvmaster_relation,   --与户主关系
      lvname,   --姓　　名
      lvpid,   --公民身份号码
      lvgender,   --性　　别
      lvnation,   --民　　族
      lvnative_country,   --籍贯（国家地区）
      lvnative_place,   --籍贯（省市县区）
      lvdob,   --出生日期
      lvmaster_name,   --户主姓名
      lvmaster_pid,   --户主身份证号
      lvapp_pid,   --申请人公民身份号码
      lvapp_name,   --申请人姓名
      lvcancel_reason,   --注销原因
      lvmemo,   --备　　注
      lvgoto_address_decode,   --前往地区编码(参军省市县,前往国家)
      lvgoto_address,   --前往地区(参军省市县,前往国家)
      lvaddress,    --前往地详址
      lvnew_master_pid
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_cancel_hukou
    Set
      sdono=lvsdono,   --办理编号
      master_relation=lvmaster_relation,   --与户主关系
      name=lvname,   --姓　　名
      pid=lvpid,   --公民身份号码
      gender=lvgender,   --性　　别
      nation=lvnation,   --民　　族
      native_country=lvnative_country,   --籍贯（国家地区）
      native_place=lvnative_place,   --籍贯（省市县区）
      dob=lvdob,   --出生日期
      master_name=lvmaster_name,   --户主姓名
      master_pid=lvmaster_pid,   --户主身份证号
      app_pid=lvapp_pid,   --申请人公民身份号码
      app_name=lvapp_name,   --申请人姓名
      cancel_reason=lvcancel_reason,   --注销原因
      memo=lvmemo,   --备　　注
      goto_address_decode=lvgoto_address_decode,   --前往地区编码(参军省市县,前往国家)
      goto_address=lvgoto_address,   --前往地区(参军省市县,前往国家)
      can_address=lvaddress ,   --前往地详址
      new_master_pid=lvnew_master_pid
    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
END IF;

IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_cancel_hukou
    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

