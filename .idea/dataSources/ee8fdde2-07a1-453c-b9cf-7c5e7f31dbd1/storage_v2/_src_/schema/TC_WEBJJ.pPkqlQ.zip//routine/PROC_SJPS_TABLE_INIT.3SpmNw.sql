create procedure          proc_sjps_table_init as
  lv_sql varchar2(500);

begin
  lv_sql := 'truncate table tc_tools.t_sjps_sendobject';
  begin
    execute immediate lv_sql;
  exception
    when others then
      null;
  end;
  commit;
  /*i := 0;
  for r in (select * from tc_webjj.v_table_constraints_column) loop
      insert into tc_webjj.t_sjps_sendobject
      i:=i+1;
      if i=100 then
      commit;
      i:=0;
      end if;
  end loop;*/
  insert into tc_tools.t_sjps_sendobject
    select * from tc_webjj.v_table_constraints_column;
  /* select count(0) into lv_count from tc_webjj.v_table_constraints_column;*/
  commit;
end proc_sjps_table_init;

/

