create function          fun_geturl_born(lv_sdono varchar2)
  return varchar2 is
  lv_surl      varchar2(500);
  lv_hu_id     number;
  lv_hu_id1    number;
  lv_person_id number;
  --lv_sitem     VARCHAR2(300);
  lv_send_flag      varchar2(50);
  lv_state          varchar2(2);
  lv_hu_master_pid  varchar2(18);
  lv_in_app_pid     varchar2(18);
  lv_hu_master_name varchar2(45);
  lv_in_app_name    varchar2(45);
  lv_in_hu_kind     varchar2(30);
  lv_count          number;
  lv_org_id         varchar2(16);
  lv_SDOUNITNO      varchar2(16);
  lv_meta_addr_id   number;
  lv_qxcun_id       VARCHAR2(9);

begin
  /*出生申报获取传值url*/
  lv_surl := '';

  select hu_master_pid, hu_master_name, in_app_pid, in_app_name, in_hu_kind
    into lv_hu_master_pid,
         lv_hu_master_name,
         lv_in_app_pid,
         lv_in_app_name,
         lv_in_hu_kind
    from tc_webjj.t_bir_declare t
   where t.sdono = lv_sdono;
  lv_count := 0;
  select count(*)
    into lv_count
    from tc_rkxt.v_tp_huji_ck
   where pid = lv_in_app_pid
     and name = lv_in_app_name;
  if lv_count = 0 then
    return 'app_false'; --申请人信息有误
  end if;
  lv_count := 0;
  select count(*)
    into lv_count
    from tc_rkxt.v_tp_huji_ck
   where --name = lv_hu_master_name
    -- and pid = lv_hu_master_pid
      pid = lv_in_app_pid
     and name = lv_in_app_name;
  if lv_count = 0 then
    return 'false_hu'; --户信息有误
  end if;
  select hu_id, meta_addr_id, quxcun_id, org_id
    into lv_hu_id, lv_meta_addr_id, lv_qxcun_id, lv_org_id
    from tc_rkxt.v_tp_huji_ck
   where pid = lv_in_app_pid
     and name = lv_in_app_name;
  select need_back, state, SDOUNITNO
    into lv_send_flag, lv_state, lv_SDOUNITNO
    from tc_webjj.v_dobus
   where sdono = lv_sdono;
  select hu_id, person_id
    into lv_hu_id1, lv_person_id
    from tc_rkxt.v_tp_huji_ck
   where pid = lv_in_app_pid
     and name = lv_in_app_name;
  if lv_org_id <> lv_SDOUNITNO then
    return 'false_hu_orgid'; --提交单位不是该户所属的派出所
  end if;
  lv_surl := lv_surl || '=' || lv_in_hu_kind;
  lv_surl := lv_surl || '=' || lv_SDOUNITNO;
  lv_surl := lv_surl || '=' || lv_hu_id1;
  lv_surl := lv_surl || '=' || lv_meta_addr_id;
  lv_surl := lv_surl || '=' || lv_qxcun_id;


  lv_surl := lv_surl || '=' || lv_person_id;
  lv_surl := lv_surl || '=' || lv_hu_id1;

  if lv_send_flag = '需回寄' then
    lv_surl := lv_surl || '=1';
  else
    lv_surl := lv_surl || '=0';
  end if;
/*  if lv_state = '42' then
    -- 预约业务
    lv_surl := lv_surl || '&sdr=' || '888';
  end if;*/
  lv_surl := lv_surl || '=' || lv_sdono;

  return(lv_surl);
end fun_geturl_born;

/

