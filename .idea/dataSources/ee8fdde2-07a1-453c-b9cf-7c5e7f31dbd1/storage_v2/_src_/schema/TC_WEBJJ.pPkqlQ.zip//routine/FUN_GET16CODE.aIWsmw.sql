create function fun_get16code
(
  lvsdono number
)
 return varchar2 is
  sdono varchar2(500);
  lvxzqh varchar2(6);
  lvxlh varchar2(8);
  lvnet varchar2(1);
  lvother varchar2(1);
begin
     lvxzqh := '610000';
     select LPAD(lvsdono,8,'0') into lvxlh from dual;
     lvnet := '2';
     lvother := '0';
     sdono := lvxzqh||lvnet||lvother||lvxlh;
  return(sdono);
end fun_get16code;
/

