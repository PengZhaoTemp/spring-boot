create PROCEDURE          proc_bbs_delOnlinePolice
as
begin
  for lv_temp in (select npolice_id,flag,sdate,rowid from tc_webjj.t_bbs_onlinepolice where sdate+6/1440 < sysdate) loop
    delete tc_webjj.t_bbs_onlinepolice where rowid = lv_temp.rowid;
  end loop;
  commit;
  for lv_temp in (select rowid from tc_webjj.t_bbs_online where npolice_id is null or personid is null) loop
    delete tc_webjj.t_bbs_online where rowid = lv_temp.rowid;
  end loop;
  commit;
end;

/

