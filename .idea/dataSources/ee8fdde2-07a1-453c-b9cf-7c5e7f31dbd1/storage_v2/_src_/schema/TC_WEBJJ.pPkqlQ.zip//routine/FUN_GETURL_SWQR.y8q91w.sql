create function          fun_geturl_swqr(lvsdono varchar2)
  return varchar2 is
  lvsurl         varchar2(500);
  lv_PID         varchar2(18);
  lv_NAME        varchar2(50);
  lv_APP_PID     varchar2(18);
  lv_APP_NAME    varchar2(50);
  lv_count       number;
  lv_person_id   number;
  lv_hu_id       number;
  lv_bd_type     varchar2(20);
  lv_send_flag   varchar2(50);
  lvmeta_addr_id number;
  lvsbooking     varchar2(2);
  lv_sel_code    varchar(10);
  lv_sel_xzqh    varchar(100);
  lv_sbusno      VARCHAR2(6);
begin
  /*    市外迁入
  psn_apply_detail.jsp?opr_type=市外迁入&bd_type=投靠
  &createorenterhu=入户&come_hu_id=410&come_meta_addr_id=699
  &app_person_id=1268&app_hu_id=410&app_meta_addr_id=699
  &sel_xzqh=河北省迁安市&sel_xzqh_code=130283&sel_qyfw=省外

  psn_apply_detail_ksqy.jsp?opr_type=市外迁入&bd_type=投靠
  &createorenterhu=入户&come_hu_id=781&come_meta_addr_id=276
  &app_person_id=2518&app_hu_id=781&app_meta_addr_id=276
  &sel_xzqh=福建省福州市仓山区&sel_xzqh_code=350104&sel_qyfw=省内市外
  */
  lvsurl   := '';
  lv_count := 0;
  select PID, NAME, APP_PID, APP_NAME, APP_TYPE, REMOVECITY
    into lv_PID, lv_NAME, lv_APP_PID, lv_APP_NAME, lv_bd_type, lv_sel_xzqh
    from tc_webjj.T_REMOVETOHERE_DECLARE
   where sdono = lvsdono;
  select count(*)
    into lv_count
    from ccic_data.tbn_data c
   where c.sidentityid in (lv_PID, lv_APP_PID);
  if lv_count > 0 then
    return 'ccic_false'; --'ccic人员';
  end if;
  /* select count(*)
    into lv_count
    from TC_RKXT.v_tp_huji_ck m
   where 1 = 1
     and pid = lv_pid
     and name = lv_name;
  if lv_count = 0 then
    return 'ck_false'; --'常口不存在出错';
  end if;*/ --迁入对象本来就不是常口
  select count(*)
    into lv_count
    from TC_RKXT.v_tp_huji_ck m
   where 1 = 1
     and pid = lv_APP_PID
     and name = lv_APP_NAME;
  if lv_count = 0 then
    return 'app_false'; --'申请人不存在出错';
  end if;

  select region_id
    into lv_sel_code
    from tc_jcyw.t_region
   where name = lv_sel_xzqh
   and when_cancelled is null;

  select hu_id, person_id, meta_addr_id
    into lv_hu_id, lv_person_id, lvmeta_addr_id
    from tc_rkxt.v_tp_huji_ck
   where pid = lv_APP_PID
     and name = lv_APP_NAME;
  select need_back, sbooking, sbusno
    into lv_send_flag, lvsbooking, lv_sbusno
    from tc_webjj.v_dobus
   where sdono = lvsdono;
  if substr(lv_sel_code, 0, 3) = '350' then
    lvsurl := lvsurl ||
              'psn_apply_detail_ksqy.jsp?opr_type=市外迁入=省内市外';
  else
    lvsurl := lvsurl || 'psn_apply_detail.jsp?opr_type=市外迁入=省外';
    lvsurl := lvsurl || '=' || lv_sbusno;
  end if;
  lvsurl := lvsurl || '=入户=' || lv_bd_type;
  lvsurl := lvsurl || '=' || lvmeta_addr_id;
  lvsurl := lvsurl || '=' || lvmeta_addr_id;
  lvsurl := lvsurl || '=' || lv_person_id;
  lvsurl := lvsurl || '=' || lv_hu_id;
  lvsurl := lvsurl || '=' || lv_hu_id;

  lvsurl := lvsurl || '=' || lv_sel_xzqh;
  lvsurl := lvsurl || '=' || lv_sel_code;
  lvsurl := lvsurl || '=' || lvsdono;
  lvsurl := lvsurl || '=004';

  if lv_send_flag = '需回寄' then
    lvsurl := lvsurl || '=1';
  else
    lvsurl := lvsurl || '=0';
  end if;
  /*if lvsbooking = '1' then
    lvsurl := lvsurl || '&sdr=888';
  end if;*/
  return(lvsurl);
end fun_geturl_swqr;

/

