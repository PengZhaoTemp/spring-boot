create PROCEDURE          PROC_t_getpid   /*t_getpid*/
(
 lvsdono IN OUT VARCHAR2,  --办理编号
 lvhu_master_name VARCHAR2,  --户主姓名
 lvhu_master_pid VARCHAR2,  --户主身份证
 lvmaster_relation VARCHAR2,  --与户主的关系
 lvapplied_reason VARCHAR2,  --申领原因
 lvname VARCHAR2,  --姓　　名
 lvpid VARCHAR2,  --公民身份证号码
 lvgender VARCHAR2,  --性　　别
 lvnation VARCHAR2,  --民　　族
 lvdob DATE,  --出生日期
 lvaddr_region_id VARCHAR2,  --省  市 县
 lvaddress VARCHAR2,  --住　　址
 lvphotoid VARCHAR2,  --照片图片号
 lvphotourl varchar2,--照片保存路径
 lvapplied_name VARCHAR2,  --领证人姓名
 lvapplied_pid VARCHAR2,  --领证人身份证号
 lvissued_unti VARCHAR2,  --签发机关
 lvissued_untino VARCHAR2,  --签发机关编号
 lvsend_date DATE,  --签发日期
 lvstop_date DATE,  --截止日期
 lvcase_kind VARCHAR2,  --制证类型
 lvget_type VARCHAR2,  --领证方式
 lvstel VARCHAR2,  --联系电话
 lvsmemo VARCHAR2,  --备　　注
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
   INSERT into tc_webjj.t_getpid
    (
      sdono,   --办理编号
      hu_master_name,   --户主姓名
      hu_master_pid,   --户主身份证
      master_relation,   --与户主的关系
      applied_reason,   --申领原因
      name,   --姓　　名
      pid,   --公民身份证号码
      gender,   --性　　别
      nation,   --民　　族
      dob,   --出生日期
      addr_region_id,   --省  市 县
      address,   --住　　址
      photoid,   --照片图片号
      photourl,
      applied_name,   --领证人姓名
      applied_pid,   --领证人身份证号
      issued_unti,   --签发机关
      issued_untino,   --签发机关编号
      send_date,   --签发日期
      stop_date,   --截止日期
      case_kind,   --制证类型
      get_type,   --领证方式
      stel,   --联系电话
      smemo    --备　　注
    )values(
      lvsdono,   --办理编号
      lvhu_master_name,   --户主姓名
      lvhu_master_pid,   --户主身份证
      lvmaster_relation,   --与户主的关系
      lvapplied_reason,   --申领原因
      lvname,   --姓　　名
      lvpid,   --公民身份证号码
      lvgender,   --性　　别
      lvnation,   --民　　族
      lvdob,   --出生日期
      lvaddr_region_id,   --省  市 县
      lvaddress,   --住　　址
      lvphotoid,   --照片图片号
      lvphotourl,
      lvapplied_name,   --领证人姓名
      lvapplied_pid,   --领证人身份证号
      lvissued_unti,   --签发机关
      lvissued_untino,   --签发机关编号
      lvsend_date,   --签发日期
      lvstop_date,   --截止日期
      lvcase_kind,   --制证类型
      lvget_type,   --领证方式
      lvstel,   --联系电话
      lvsmemo    --备　　注
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_getpid
    Set
      sdono=lvsdono,   --办理编号
      hu_master_name=lvhu_master_name,   --户主姓名
      hu_master_pid=lvhu_master_pid,   --户主身份证
      master_relation=lvmaster_relation,   --与户主的关系
      applied_reason=lvapplied_reason,   --申领原因
      name=lvname,   --姓　　名
      pid=lvpid,   --公民身份证号码
      gender=lvgender,   --性　　别
      nation=lvnation,   --民　　族
      dob=lvdob,   --出生日期
      addr_region_id=lvaddr_region_id,   --省  市 县
      address=lvaddress,   --住　　址
      photoid=lvphotoid,   --照片图片号
      photourl=lvphotourl,
      applied_name=lvapplied_name,   --领证人姓名
      applied_pid=lvapplied_pid,   --领证人身份证号
      issued_unti=lvissued_unti,   --签发机关
      issued_untino=lvissued_untino,   --签发机关编号
      send_date=lvsend_date,   --签发日期
      stop_date=lvstop_date,   --截止日期
      case_kind=lvcase_kind,   --制证类型
      get_type=lvget_type,   --领证方式
      stel=lvstel,   --联系电话
      smemo=lvsmemo    --备　　注
    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_getpid
    Set
      sdono=lvsdono,   --办理编号
      hu_master_name=lvhu_master_name,   --户主姓名
      hu_master_pid=lvhu_master_pid,   --户主身份证
      master_relation=lvmaster_relation,   --与户主的关系
      applied_reason=lvapplied_reason,   --申领原因
      name=lvname,   --姓　　名
      pid=lvpid,   --公民身份证号码
      gender=lvgender,   --性　　别
      nation=lvnation,   --民　　族
      dob=lvdob,   --出生日期
      addr_region_id=lvaddr_region_id,   --省  市 县
      address=lvaddress,   --住　　址
      photoid=lvphotoid,   --照片图片号
      photourl=lvphotourl,
      applied_name=lvapplied_name,   --领证人姓名
      applied_pid=lvapplied_pid,   --领证人身份证号
      issued_unti=lvissued_unti,   --签发机关
      issued_untino=lvissued_untino,   --签发机关编号
      send_date=lvsend_date,   --签发日期
      stop_date=lvstop_date,   --截止日期
      case_kind=lvcase_kind,   --制证类型
      get_type=lvget_type,   --领证方式
      stel=lvstel,   --联系电话
      smemo=lvsmemo    --备　　注
    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_getpid
    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

