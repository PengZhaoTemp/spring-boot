create procedure          proc_hd_xs_info(lv_SID         in out varchar2,
                                            lv_SPEP_CON_ID varchar2,
                                            lv_SNAME       varchar2,
                                            lv_SEMAIL      varchar2,
                                            lv_STEL        varchar2,
                                            lv_SDETAIL     varchar2,
                                            lv_SIP         varchar2,
                                            lv_msg_return  in out varchar2) as
  lv_count number;
begin
  select tc_webjj.SEQ_HD_THREAD_INFO.nextval into lv_SID from dual;
  insert into tc_webjj.t_hd_thread_info t
    (SID,
     S_THREAD_INFO_ID,
     SNAME,
     SEMAIL,
     STEL,
     STHREAD_INFO,
     DINDATE,
     SIP,
     SISUSE,
     DBBJ,
     DBSJ)
  values
    (lv_SID,
     lv_SPEP_CON_ID,
     lv_SNAME,
     lv_SEMAIL,
     lv_STEL,
     lv_SDETAIL,
     sysdate,
     lv_SIP,
     '',
     '0',
     sysdate);
  lv_msg_return := '操作成功';
  commit;
end proc_hd_xs_info;

/

