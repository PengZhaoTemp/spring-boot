create view V_PEOPLE_LNF_INFO as
  select "NID",
       "GOODNAME",
       "GOODTYPE",
       decode(GOODTYPE,'B','交通工具类'
       ,'E','工艺首饰及文物类'
       ,'K','服饰'
       ,'M','家具日用杂货'
       ,'U','计算机'
       ,'V','通信'
       ,'X','票证单据'
       ,'Z','其他物品') goodtypecn,
       "GOODPROPERTY",
       to_char("OCCURTIME",'yyyy-mm-dd hh24:mi:ss') OCCURTIME,
       "OCCURADDRESS",
       "CONTACTS_POLICENAME",
       "CONTACTS_PHONE",
       "CONTACTS_UNIT",
       "DINDATE",
       "SREGMAN",
       "SREGUNIT",
       "SREGUNITCODE",
       "DBBJ",
       "DBSJ",
       "GOODPHOTO1",
       "GOODPHOTO2",
       "GOODPHOTO3",
       "GOODPHOTO4",
       "GOODPHOTO5",
       "ISDISPLAY",
       decode(ISDISPLAY,'0','不显示','显示') isdisplaycn
  from t_people_lnf_info
/

