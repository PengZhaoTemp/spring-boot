create FUNCTION          TO_BASE( P_DEC IN NUMBER, P_BASE IN NUMBER )
return varchar2
is
 l_str varchar2(383) default NULL;
 l_num number default p_dec;
 l_hex varchar2(24) default '0123456789ABCDEF';
begin
 if ( p_dec is null or p_base is null )
 then
  return null;
 end if;
 if ( trunc(p_dec) <> p_dec OR p_dec < 0 ) then
  raise PROGRAM_ERROR;
 end if;
 loop
  l_str := substr( l_hex, mod(l_num,p_base)+1, 1 ) || l_str;
  l_num := trunc( l_num/p_base );
  exit when ( l_num = 0 );
 end loop;
 return l_str;
end to_base;

/

