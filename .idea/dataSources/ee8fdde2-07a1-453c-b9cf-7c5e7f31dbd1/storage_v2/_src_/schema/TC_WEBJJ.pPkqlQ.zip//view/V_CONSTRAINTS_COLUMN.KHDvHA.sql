create view V_CONSTRAINTS_COLUMN as
  select cu.column_name,au.table_name,au.OWNER,ac.DATA_TYPE
   from user_cons_columns cu, user_constraints au ,all_tab_columns ac
  where cu.constraint_name = au.constraint_name
  and au.constraint_type = 'P'
  and au.owner = ac.OWNER
  and au.table_name = ac.TABLE_NAME
  and cu.column_name = ac.COLUMN_NAME
/

