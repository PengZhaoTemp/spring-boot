create view V_EXPRESSINTERFACE as
  select to_char(ddate, 'yyyy-mm-dd hh24:mi:ss') ddate,
       a.sconsignee,
       a.sdono,
       '<a href="javascript:PMDETAILDetail(''' || a.sexpno ||
       ''');"><font color=blue title="点击查看详细信息">' || a.sexpno || '</font></a>' as sexpno,
       a.sexpaddress,
       b.sdodata,
       a.stel,
       a.suserno,
       a.sexpno sno
  from tc_webjj.t_expressinterface a,tc_webjj.t_dobus b
  where a.sdono =b.sdono
  order by ddate desc
/

