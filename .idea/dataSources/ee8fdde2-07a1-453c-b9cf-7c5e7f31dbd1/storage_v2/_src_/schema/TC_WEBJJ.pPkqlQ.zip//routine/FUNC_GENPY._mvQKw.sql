create FUNCTION          FUNC_GENPY
/*
grant select on tc_jcyw.t_pinyin to tc_rkxt;
*/
(Phrase VarChar2,Usesimplepy VarChar2)  /* Created by wcp 2004.01.12 */
   Return VarChar2 is PinYinString VarChar2(600);
/*??????    Phrase ??
                  Usesimplepy ???? `1??`0?
         ???????????????????
               ????Delphi ?Frm_Genpy--??????Form???*/
 Hanz VarChar2(3);
 i number;
 j number;
 cursor Sel_PinYin IS select pinyin,simple_py from tc_jcyw.t_pinyin
   where ZI=Hanz ;  --   AND ROWNUM=1;--???????????.
 SPY_Record Sel_PinYin%rowtype;
 l_Phrase varchar2(600);
 Begin
 i:=1;
 PinYinString:='';
 l_Phrase:=phrase;
 l_Phrase:=replace(l_Phrase,'?','0');
 l_Phrase:=replace(l_Phrase,'?','1');
 l_Phrase:=replace(l_Phrase,'?','2');
 l_Phrase:=replace(l_Phrase,'?','3');
 l_Phrase:=replace(l_Phrase,'?','4');
 l_Phrase:=replace(l_Phrase,'?','5');
 l_Phrase:=replace(l_Phrase,'?','6');
 l_Phrase:=replace(l_Phrase,'?','7');
 l_Phrase:=replace(l_Phrase,'?','8');
 l_Phrase:=replace(l_Phrase,'?','9');
 l_Phrase:=replace(l_Phrase,'?','');
 l_Phrase:=replace(l_Phrase,'?','');
 l_Phrase:=replace(l_Phrase,'?','');
 While i<=Length(l_Phrase) Loop
   HanZ:=substr(l_Phrase,i,1);
     if Ascii(HanZ)<=127
     then
            PinYinString:=PinYinString||Hanz||';';
            i:=i+1;
     else
         HanZ:=substr(l_Phrase,i,1);
         i:=i+1;
         j:=0;
         OPEN sel_pinyin ;
         Loop
           FETCH sel_pinyin  into SPY_Record;
           if sel_pinyin%NOTFOUND then exit;
           else
                j:=j+1;
                if Usesimplepy='1' then
                PinYinString:=PinYinString||SPY_Record.Simple_PY||',';
                else
                PinYinString:=PinYinString||SPY_Record.PinYin||',';
                end if;
           end if;
         End Loop;
         if j=0 then PinYinString:=PinYinString||HanZ||',';
         End if;
         CLOSE sel_pinyin ;
          if substr(PinYinString,Length(PinYinString),1)=',' then
          PinYinString:=substr(PinYinString,1,Length(PinYinString)-1);
          end if;
          --PinYinString:=PinYinString||';';
      end if;
 End Loop;
 Return(PinYinString);
 End Func_GenPy;

/

