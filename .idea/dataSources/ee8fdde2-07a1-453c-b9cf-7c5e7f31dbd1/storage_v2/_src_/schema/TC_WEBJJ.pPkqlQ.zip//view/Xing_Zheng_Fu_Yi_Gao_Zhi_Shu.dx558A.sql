create view "行政复议告知书" as
  select sq.sdono "业务编号",
       sq.S_CF_UNIT "处罚单位",
       to_char(sq.S_CF_SDTIME,'yyyy-mm-dd') "处罚时间",
       to_char(sq.S_CF_SDTIME, 'yyyy') "年",
       to_char(sq.S_CF_SDTIME, 'mm') "月",
       to_char(sq.S_CF_SDTIME, 'dd') "日",
       sq.S_CF_CONTENT "处罚内容",
       sq.S_XZFY_UNIT "行政复议单位",
       to_char(tb.log_date, 'yyyy') || ' 年 ' || to_char(tb.log_date, 'mm') || ' 月 ' ||
       to_char(tb.log_date, 'dd') || ' 日 ' as "文件日期",
       '['||tb.film_num||']号' "文件编号",
       sq.s_Name||'：' "申请人",
       tb.TZ_UNIT "转达单位"
  from tc_webjj.t_xzfy_sq sq, tc_webjj.t_xzfy_table tb
 where sq.sdono = tb.sdono
 and tb.stype_code='12'
/

