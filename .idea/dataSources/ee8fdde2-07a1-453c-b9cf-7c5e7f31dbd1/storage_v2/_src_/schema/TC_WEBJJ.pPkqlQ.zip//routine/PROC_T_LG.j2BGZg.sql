create PROCEDURE          proc_t_lg   /*停车场*/
(
  lvsxh           IN OUT VARCHAR2,
  lvslgbm         VARCHAR2,
  lvslgmc         VARCHAR2,
  lvnfjs          NUMBER,
  lvncws          NUMBER,
  lvemptyroom     VARCHAR2,
  lvlon           NUMBER,
  lvlat          NUMBER,
  lvsdzxx         VARCHAR2,
  lvslxdh         VARCHAR2,
  lvspid          VARCHAR2,
  lv_ProcMode     Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
    Select tc_webjj.SEQ_T_LG_SXH.Nextval  into lvsxh From dual;    /*新闻编号序列*/
   INSERT into tc_webjj.t_lg
    (
  sxh          ,
  slgbm         ,
  slgmc,
  nfjs     ,
  ncws,
  emptyroom ,
  lon,
  lat,
  sdzxx,
  slxdh
    )values(
  lvsxh          ,
  lvslgbm         ,
  lvslgmc,
  lvnfjs     ,
  lvncws,
  lvemptyroom  ,
  lvlon ,
  lvlat,
  lvsdzxx,
  lvslxdh
    );

   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_lg
    Set
   sxh=lvsxh          ,
  slgbm=lvslgbm         ,
  slgmc=lvslgmc,
  nfjs=lvnfjs     ,
  ncws=lvncws,
  emptyroom=lvemptyroom,
  lon=lvlon,
  lat=lvlat,
  sdzxx=lvsdzxx,
  slxdh=lvslxdh

    Where 1=1
    and sxh=lvsxh   --新闻编号
    ;

END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_lg
    Set
       sxh=lvsxh          ,
  slgbm=lvslgbm         ,
  slgmc=lvslgmc,
  nfjs=lvnfjs     ,
  ncws=lvncws,
  emptyroom=lvemptyroom,
  lon=lvlon,
  lat=lvlat,
  sdzxx=lvsdzxx,
  slxdh=lvslxdh

    Where 1=1
    and sxh=lvsxh  --新闻编号
    ;

END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_lg
    Where 1=1
    and sxh=lvsxh   --新闻编号
    ;

END IF;
 Commit;
END; /*存储过程结束*/

