create PROCEDURE          PROC_t_removetohere_declare   /*T_REMOVETOHERE_DECLARE*/
(
 lvsdono IN OUT VARCHAR2,  --业务编号
 lvbtk_name VARCHAR2,  --被投靠人姓名
 lvbtk_pid VARCHAR2,  --被投靠人身份证
 lvhu_master_name VARCHAR2,  --户主姓名
 lvhu_master_pid VARCHAR2,  --户主身份证
 lvbtk_relation VARCHAR2,  --与被投靠人关系
 lvmaster_relation VARCHAR2,  --与户主关系
 lvapp_type VARCHAR2,  --申请类别
 lvapp_why_apply VARCHAR2,  --申报理由
 lvpid VARCHAR2,  --公民身份证
 lvname VARCHAR2,  --姓　　名
 lvchange_reason VARCHAR2,  --变动原因
 lvcity VARCHAR2,  --所属省市
 lvaddress VARCHAR2,  --详　　址
 lvapp_name VARCHAR2,  --申请人姓名
 lvapp_pid VARCHAR2,  --申请人身份证
 lvsypcs varchar2,--原户口所在地派出所
 lvhkzxfs varchar2,--户口注销方式
 lvwtr_name varchar2,--委托人姓名
 lvwtr_pid varchar2,--委托人身份证
 lvwtr_relation varchar2,--与落户人关系
 lvwtr_phone varchar2,--委托人联系方式
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
   INSERT into tc_webjj.t_removetohere_declare
    (
      sdono,   --业务编号
      btk_name,   --被投靠人姓名
      btk_pid,   --被投靠人身份证
      hu_master_name,   --户主姓名
      hu_master_pid,   --户主身份证
      btk_relation,   --与被投靠人关系
      master_relation,   --与户主关系
      app_type,   --申请类别
      app_why_apply,   --申报理由
      pid,   --公民身份证
      name,   --姓　　名
      change_reason,   --变动原因
      removecity,   --所属省市
      removeaddr,   --详　　址
      app_name,   --申请人姓名
      app_pid,    --申请人身份证
      sypcs,
      hkzxfs,
      wtr_name,
      wtr_pid,
      wtr_relation,
      wtr_phone
    )values(
      lvsdono,   --业务编号
      lvbtk_name,   --被投靠人姓名
      lvbtk_pid,   --被投靠人身份证
      lvhu_master_name,   --户主姓名
      lvhu_master_pid,   --户主身份证
      lvbtk_relation,   --与被投靠人关系
      lvmaster_relation,   --与户主关系
      lvapp_type,   --申请类别
      lvapp_why_apply,   --申报理由
      lvpid,   --公民身份证
      lvname,   --姓　　名
      lvchange_reason,   --变动原因
      lvcity,   --所属省市
      lvaddress,   --详　　址
      lvapp_name,   --申请人姓名
      lvapp_pid,    --申请人身份证
      lvsypcs,--原户口所在地派出所
       '1',--户口注销方式
        lvwtr_name,--委托人姓名
        lvwtr_pid,--委托人身份证
         lvwtr_relation,--与落户人关系
      lvwtr_phone--委托人联系方式
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_removetohere_declare
    Set
      sdono=lvsdono,   --业务编号
      btk_name=lvbtk_name,   --被投靠人姓名
      btk_pid=lvbtk_pid,   --被投靠人身份证
      hu_master_name=lvhu_master_name,   --户主姓名
      hu_master_pid=lvhu_master_pid,   --户主身份证
      btk_relation=lvbtk_relation,   --与被投靠人关系
      master_relation=lvmaster_relation,   --与户主关系
      app_type=lvapp_type,   --申请类别
      app_why_apply=lvapp_why_apply,   --申报理由
      pid=lvpid,   --公民身份证
      name=lvname,   --姓　　名
      change_reason=lvchange_reason,   --变动原因
      removecity=lvcity,   --所属省市
      removeaddr=lvaddress,   --详　　址
      app_name=lvapp_name,   --申请人姓名
      app_pid=lvapp_pid,    --申请人身份证
      sypcs=lvsypcs,
      hkzxfs='1',
      wtr_name=lvwtr_name,
      wtr_pid=lvwtr_pid,
      wtr_relation=lvwtr_relation,
      wtr_phone=lvwtr_phone
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;

IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_removetohere_declare
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

