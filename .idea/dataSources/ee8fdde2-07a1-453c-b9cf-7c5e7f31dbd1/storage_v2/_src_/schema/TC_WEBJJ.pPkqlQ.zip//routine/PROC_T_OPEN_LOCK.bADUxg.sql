create PROCEDURE          proc_t_open_lock   /*停车场*/
(
  lvsno           IN OUT VARCHAR2,
  lvsname         VARCHAR2,
  lvnlongitude    NUMBER,
  lvnlatitude     NUMBER,
  lvsaddress      VARCHAR2,
  lvstel          VARCHAR2,
  lvslinkman      VARCHAR2,
  lvspid          VARCHAR2,
  lv_ProcMode     Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
    Select tc_webjj.SEQ_T_OPEN_LOCK_SNO.Nextval  into lvsno From dual;    /*新闻编号序列*/
   INSERT into tc_webjj.t_open_lock
    (
  sno          ,
  sname         ,
  nlongitude,
  nlatitude     ,
  saddress,
  stel,
  slinkman,
  dregdate
    )values(
  lvsno          ,
  lvsname         ,
  lvnlongitude,
  lvnlatitude     ,
  lvsaddress,
  lvstel  ,
  lvslinkman ,
  sysdate
    );

   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_open_lock
    Set
   sno=lvsno          ,
  sname=lvsname         ,
  nlongitude=lvnlongitude,
  nlatitude=lvnlatitude     ,
  saddress=lvsaddress,
  stel=lvstel,
  slinkman=lvslinkman,
  dregdate=sysdate   --是否热点
    Where 1=1
    and sno=lvsno   --新闻编号
    ;

END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_open_lock
    Set
      sno=lvsno          ,
  sname=lvsname         ,
  nlongitude=lvnlongitude,
  nlatitude=lvnlatitude     ,
  saddress=lvsaddress,
  stel=lvstel,
  slinkman=lvslinkman,
  dregdate=sysdate   --是否热点
    Where 1=1
    and sno=lvsno   --新闻编号
    ;

END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_open_lock
    Where 1=1
    and sno=lvsno   --新闻编号
    ;

END IF;
 Commit;
END; /*存储过程结束*/

