create view V_APPLYMASTERIALS as
  select a.sno,
      a.SBUSNO,
       "SITEM",
       "SMUST",
       "SITEMSIZE",
       "NORDER",
       "SGROUP",
       "IMGURL",
       "ISUSED",
       "SREMARK",
       "IS_UPLOAD",
       b.exectype
  from tc_webjj.t_applymasterials a,tc_webjj.t_applymasterials_type b
  where a.SGROUP = b.sno
/

