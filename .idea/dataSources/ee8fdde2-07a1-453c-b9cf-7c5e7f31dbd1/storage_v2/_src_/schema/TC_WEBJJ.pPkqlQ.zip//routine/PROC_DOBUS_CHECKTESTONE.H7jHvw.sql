create procedure          proc_dobus_checktestone(
       lvsdono varchar2,
       lvsoperationno varchar2,
       lvskey varchar2,
       lvssecondcheck varchar2,
       lvsplanno   varchar2
) is
lvslogno varchar2(16);
lvsoperationname varchar2(30);
lvsusertype varchar2(1);
lvsresult varchar2(500);
lvcheckstate varchar2(1);
lvnotesno varchar2(16);
lvnotemsg varchar2(2000);
lvsapptel varchar2(20);
lvsappname varchar2(20);
lvsorgid varchar2(12);
lvsorgname varchar2(200);
begin
    select sapptel,sappname,sdounit,sdounitno into lvsapptel,lvsappname,lvsorgname,lvsorgid from tc_webjj.t_dobus where sdono=lvsdono;
    if lvssecondcheck = '0' then
       lvsresult := '学员信息核查失败，考试预约被退回';
       lvnotemsg := '您的驾驶证考试预约，学员信息核查失败，考试预约被退回。详情请登录长沙市网上公安局查看。';
       lvcheckstate := '2';
    elsif lvssecondcheck = '1' then
       lvsresult := '学员信息核查成功';
       lvnotemsg := '您的驾驶证考试预约，学员信息核查成功，正在为您获取预约场次。详情请登录长沙市网上公安局查看。';
       lvcheckstate :='1';
    elsif lvssecondcheck = '-1' then
       lvsresult := '学员信息核查异常，考试预约被退回,请重新申请。';
       lvnotemsg := '您的驾驶证考试预约，学员信息核查异常被退回，请稍后再试。详情请登录长沙市网上公安局查看。';
       lvcheckstate := '2';
    end if;
    update tc_webjj.t_dobus a set a.ssecondcheck = lvcheckstate,a.scontext=lvsresult where sdono = lvsdono;
    update tc_webjj.t_jj_test_one b set b.skey = lvskey,b.dbbj='0' where sdono = lvsdono;
    --日志
    select a.sname,a.stype into lvsoperationname,lvsusertype from tc_webjj.t_operation_deploy a where a.sno=lvsoperationno;
    proc_dobus_log_info(
      lvslogno,
      lvsplanno,
      lvsoperationno,
      lvsoperationname,
      lvsdono,
      lvsusertype,
      '',
      '自主预约',
      lvsorgid,
      lvsorgname,
      lvsresult
    );
    proc_dobus_nextflow(lvsdono);
    --发送短信
    PROC_t_notetask(
      lvnotesno,
      lvnotemsg,
      sysdate,
      lvsapptel,
      '0',
      '1',
      '0',
      null,
      'PMINSERT'
    );
    commit;
end proc_dobus_checktestone;

/

