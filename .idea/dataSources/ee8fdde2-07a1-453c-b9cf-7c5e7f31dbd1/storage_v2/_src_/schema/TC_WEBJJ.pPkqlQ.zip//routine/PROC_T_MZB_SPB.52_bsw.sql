create PROCEDURE          PROC_t_mzb_spb   /*T_MZB_SPB*/
(
 lvsno IN OUT VARCHAR2,  --编　　号
 lvsbg_name VARCHAR2,  --变更人姓名
 lvsbg_pid VARCHAR2,  --变更人身份证
 lvsbg_fm VARCHAR2,  --变更随父随母
 lvsbg_mz VARCHAR2,  --变更民族
 lvsbg_date DATE,  --变更时间
 lvsbg_bz VARCHAR2,  --允许变更标志0为可变更1为不可变
 lvsxg_date DATE,  --修改时间
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS

BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/

 select tc_webjj.seq_t_mzb_spb_sno.nextval into lvsno from dual;

   INSERT into tc_webjj.t_mzb_spb
    (
      sno,   --编　　号
      sbg_name,   --变更人姓名
      sbg_pid,   --变更人身份证
      sbg_fm,   --变更随父随母
      sbg_mz,   --变更民族
      sbg_date,   --变更时间
      sbg_bz,   --允许变更标志0为可变更1为不可变
      sxg_date,    --修改时间
      dbbj,
      dbsj
    )values(
      lvsno,   --编　　号
      lvsbg_name,   --变更人姓名
      lvsbg_pid,   --变更人身份证
      lvsbg_fm,   --变更随父随母
      lvsbg_mz,   --变更民族
      sysdate,   --变更时间
      '0',   --允许变更标志0为可变更1为不可变

      lvsxg_date,    --修改时间
      '0',
      sysdate
    );
   -- 返回值

END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_mzb_spb
    Set
      sno=lvsno,   --编　　号
      sbg_name=lvsbg_name,   --变更人姓名
      sbg_pid=lvsbg_pid,   --变更人身份证
      sbg_fm=lvsbg_fm,   --变更随父随母
      sbg_mz=lvsbg_mz,   --变更民族
      sbg_date=lvsbg_date,   --变更时间
      sbg_bz=lvsbg_bz,   --允许变更标志0为可变更1为不可变
      sxg_date=sysdate,    --修改时间
      dbbj='0',
      dbsj=sysdate
    Where 1=1
    and sno=lvsno   --编　　号
    ;
END IF;
/*IF lv_procMode='PMCANCEL'  THEN
   UPDATE tc_webjj.t_mzb_spb
    Set
      sno=lvsno,   --编　　号
      sbg_name=lvsbg_name,   --变更人姓名
      sbg_pid=lvsbg_pid,   --变更人身份证
      sbg_fm=lvsbg_fm,   --变更随父随母
      sbg_mz=lvsbg_mz,   --变更民族
      sbg_date=lvsbg_date,   --变更时间
      sbg_bz=lvsbg_bz,   --允许变更标志0为可变更1为不可变
      sxg_date=lvsxg_date    --修改时间
    Where 1=1
    and sno=lvsno   --编　　号
    ;
END IF; */
IF lv_procMode='PMDELETE' THEN    /*删除*/
    UPDATE tc_webjj.t_mzb_spb
    Set  szx_bz='1',
          dbbj='0',
          dbsj=sysdate
    Where 1=1
    and sno=lvsno   --编　　号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

