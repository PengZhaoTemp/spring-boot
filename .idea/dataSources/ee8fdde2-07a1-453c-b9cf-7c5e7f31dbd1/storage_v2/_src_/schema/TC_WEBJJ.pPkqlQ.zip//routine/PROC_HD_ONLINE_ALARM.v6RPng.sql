create procedure          proc_hd_online_alarm(lv_NID          in out number,
                                                 lv_SNAME        varchar2,
                                                 lv_SGENDER      varchar2,
                                                 lv_SAGE         number,
                                                 lv_SEMAIL       varchar2,
                                                 lv_STEL         varchar2,
                                                 lv_SWORKUNIT    varchar2,
                                                 lv_SADDRESS     varchar2,
                                                 lv_OCCURTIME    varchar2,
                                                 lv_OCCURADDRESS varchar2,
                                                 lv_SCONTENT     varchar2,
                                                 lv_SIP          varchar2,
                                                 lv_ProcMode     varchar2,
                                                 lv_msg_return   in out varchar2) as
  lv_count number;
begin
  if lv_ProcMode = 'PMINSERT' then

    select count(0)
      into lv_count
      from tc_webjj.T_HD_Online_alarm
     where SIP = lv_SIP
       and dindate > (sysdate - 1 / (24 * 60));
    if lv_count > 0 then
      lv_msg_return := '防止频繁操作';
    else
      select tc_webjj.SEQ_HD_ONLINE_ALARM_NID.nextval
        into lv_NID
        from dual;
      insert into tc_webjj.T_HD_Online_alarm
        (NID,
         SNAME,
         SGENDER,
         SAGE,
         SEMAIL,
         STEL,
         SWORKUNIT,
         SADDRESS,
         OCCURTIME,
         OCCURADDRESS,
         SCONTENT,
         SIP)
      values
        (lv_NID,
         lv_SNAME,
         lv_SGENDER,
         lv_SAGE,
         lv_SEMAIL,
         lv_STEL,
         lv_SWORKUNIT,
         lv_SADDRESS,
         to_date(lv_OCCURTIME,'yyyy-mm-dd hh24:mi:ss'),
         lv_OCCURADDRESS,
         lv_SCONTENT,
         lv_SIP);
      lv_msg_return := '操作成功';
    end if;
  end if;
  commit;
end proc_hd_online_alarm;

/

