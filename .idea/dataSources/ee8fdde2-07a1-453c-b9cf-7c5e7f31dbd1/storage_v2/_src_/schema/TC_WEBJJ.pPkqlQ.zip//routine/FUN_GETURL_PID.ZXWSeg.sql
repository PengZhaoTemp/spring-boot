create function          fun_geturl_pid(lv_pid  varchar2,
                                          lv_name varchar2,
                                          lv_slyy varchar2) return varchar2 is
  /*lv_slyy 申领原因  */
  lvsurl            varchar2(1000);
  lvADDR_FULL_NAME  VARCHAR2(300);
  lvDETAIL_ADDR     VARCHAR2(120);
  lvDOB             DATE;
  lvGENDER          VARCHAR2(21);
  lvGURARDIAN_1     VARCHAR2(45);
  lvGURARDIAN_1_PID VARCHAR2(18);
  lvGURARDIAN_2     VARCHAR2(45);
  lvGURARDIAN_2_PID VARCHAR2(18);
  lvHAOZUO          VARCHAR2(120);
  lvHAOZUO_DETAIL   VARCHAR2(120);
  lvHU_ID           number;
  lvHU_ID_NEW       VARCHAR2(20);
  lvHU_MASTER_INFO  VARCHAR2(80);
  lvHU_MASTER_NAME  VARCHAR2(45);
  lvMETA_ADDR_ID    number;
  lvNAME            VARCHAR2(45);
  lvNATION          VARCHAR2(15);
  lvORGNAME         VARCHAR2(120);
  lvORG_ID          VARCHAR2(12);
  lvPERSON_ID       number;
  lvPID             VARCHAR2(18);
  lvWARDSHIP_1      VARCHAR2(75);
  lvWARDSHIP_2      VARCHAR2(75);
  lvzxbz            VARCHAR2(3);
  lvxxlx            VARCHAR2(75); --'常口信息';
  lvczrkxxlink      varchar2(18);
  lvcan_sl          number;
  lv_count          number;
  lvflag            varchar2(180);
/*  lv_send_flag      varchar2(50);
  lv_state          varchar2(2);*/
begin
  lv_count := 0;
  begin
    select count(*)
      into lv_count
      from TC_RKXT.v_tp_huji_ck m
     where 1 = 1
       and pid = lv_pid
       and name = lv_name;
    if lv_count = 0 then
      return 'ck_false'; --'常口不存在出错';
    end if;
  end;

  begin
    select /*+first_rows(4)*/
     ADDR_FULL_NAME,
     DETAIL_ADDR,
     DOB,
     GENDER,
     GURARDIAN_1,
     GURARDIAN_1_PID,
     GURARDIAN_2,
     GURARDIAN_2_PID,
     HAOZUO,
     HAOZUO_DETAIL,
     HU_ID,
     HU_ID_NEW,
     HU_MASTER_INFO,
     HU_MASTER_NAME,
     META_ADDR_ID,
     NAME,
     NATION,
     ORGNAME,
     ORG_ID,
     PERSON_ID,
     PID,
     WARDSHIP_1,
     WARDSHIP_2,
     zxbz,
     xxlx,
     '' || pid || '' czrkxxlink,
     instr(tc_rkxt.func_pid_GetPsnStatus(person_id), '01zjsl') can_sl
      into lvADDR_FULL_NAME,
           lvDETAIL_ADDR,
           lvDOB,
           lvGENDER,
           lvGURARDIAN_1,
           lvGURARDIAN_1_PID,
           lvGURARDIAN_2,
           lvGURARDIAN_2_PID,
           lvHAOZUO,
           lvHAOZUO_DETAIL,
           lvHU_ID,
           lvHU_ID_NEW,
           lvHU_MASTER_INFO,
           lvHU_MASTER_NAME,
           lvMETA_ADDR_ID,
           lvNAME,
           lvNATION,
           lvORGNAME,
           lvORG_ID,
           lvPERSON_ID,
           lvPID,
           lvWARDSHIP_1,
           lvWARDSHIP_2,
           lvzxbz,
           lvxxlx,
           lvczrkxxlink,
           lvcan_sl
      from TC_RKXT.v_tp_huji_pid m
     where 1 = 1
       and pid = lv_pid
       and name = lv_name;
  exception
    when no_data_found then
      lvcan_sl := '0';
  end;

  if lvcan_sl <= 0 then
    lvsurl := 'menu_false'; --'该人不能办理申领二代证出错';
  else
    begin
      select tc_rkxt.fun_pid_checkslyy(lv_slyy, lvPERSON_ID)
        into lvflag
        from dual;
      if lvflag <> '1' then
        return 'slyy_false'; --lvflag; --申领原因验证错误
      end if;
    end;
    lvsurl := lvsurl || '=' || lvADDR_FULL_NAME;
    lvsurl := lvsurl || '=' || lvDETAIL_ADDR;
    lvsurl := lvsurl || '=' || to_char(lvDOB, 'yyyy-mm-dd');
    lvsurl := lvsurl || '=' || lvGENDER;
    lvsurl := lvsurl || '=' || lvGURARDIAN_1;
    lvsurl := lvsurl || '=' || lvGURARDIAN_1_PID;
    lvsurl := lvsurl || '=' || lvGURARDIAN_2;
    lvsurl := lvsurl || '=' || lvGURARDIAN_2_PID;
    lvsurl := lvsurl || '=' || lvHAOZUO;
    lvsurl := lvsurl || '=' || lvHAOZUO_DETAIL;
    lvsurl := lvsurl || '=' || lvHU_ID;
    lvsurl := lvsurl || '=' || lvHU_ID_NEW;
    lvsurl := lvsurl || '=' || lvHU_MASTER_INFO;
    lvsurl := lvsurl || '=' || lvHU_MASTER_NAME;
    lvsurl := lvsurl || '=' || lvMETA_ADDR_ID;
    lvsurl := lvsurl || '=' || lvNAME;
    lvsurl := lvsurl || '=' || lvNATION;
    lvsurl := lvsurl || '=' || lvORGNAME;
    lvsurl := lvsurl || '=' || lvORG_ID;
    lvsurl := lvsurl || '=' || lvPERSON_ID;
    lvsurl := lvsurl || '=' || lvPID;
    lvsurl := lvsurl || '=' || lvWARDSHIP_1;
    lvsurl := lvsurl || '=' || lvWARDSHIP_2;
    /* lvsurl := lvsurl || '&zxbz=' || lvzxbz ;
    lvsurl := lvsurl || '&xxlx=' || lvxxlx ;*/
    lvsurl := lvsurl || '=' || '1102001';
    lvsurl := lvsurl || '=' || '二代证受理';
    lvsurl := lvsurl || '=' || lvczrkxxlink;
 /*   select need_back, state
      into lv_send_flag, lv_state
      from tc_webjj.v_dobus
     where sdono = lv_sdono;
    if lv_send_flag = '需回寄' then
      lv_surl := lv_surl || '&send_flag=1';
    else
      lv_surl := lv_surl || '&send_flag=0';
    end if;
    if lv_state = '42' then
      -- 预约业务
      lv_surl := lv_surl || '&sdr=' || '888';
    end if;
    lv_surl := lv_surl || '&sdono=' || lv_sdono;*/
  end if;

  return(lvsurl);
end fun_geturl_pid;

/

