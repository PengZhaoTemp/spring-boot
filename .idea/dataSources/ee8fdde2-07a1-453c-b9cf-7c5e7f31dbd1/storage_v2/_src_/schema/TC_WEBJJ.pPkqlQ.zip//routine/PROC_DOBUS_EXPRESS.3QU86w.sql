create procedure          proc_dobus_express(
       lv_sdono varchar2
) is
lv_dobus  tc_webjj.t_dobus%rowtype;
begin
  begin
    select * into lv_dobus from tc_webjj.t_dobus where sdono=lv_sdono;
    --是否快递寄
    if lv_dobus.NEXPCHARGE>0 then
      insert into tc_webjj.t_weixin_express(
             sno,
             sdono,
             sstate,
             status,
             billno,
             dbbj,
            SEXPADDRESS,     --寄送地址（详细地址）/回寄地址
             SEXPPRO,        --寄送省份/回寄省份
             SEXPCITY,       --寄送市/回寄市
             SEXPAREA,       --寄送区县/回寄区县
             SEXPPOSTCODE,   --寄送邮政编码/回寄邮政编码
             SNAME,          --寄件人姓名/回寄人姓名
             SPID,           --寄件人身份证（根据需求可能不需要提供）/回寄人身份证
             STEL,           --寄件人联系方式/回寄人联系方式
             SDWNAME,        --寄件收件单位/回寄收件单位
             SDWADDRESS      --寄件收件单位地址/回寄收件单位地址

      )values(
             tc_webjj.seq_weixin_express_sno.nextval,
             lv_sdono,
             '1',
             '0',
             tc_webjj.seq_weixin_express_sno.nextval,
             '0',
              '',            --寄送地址（详细地址）/回寄地址
              '',            --寄送省份/回寄省份
              '',            --寄送市/回寄市
              '',            --寄送区县/回寄区县
              '',            --寄送邮政编码/回寄邮政编码
              '',            --寄件人姓名/回寄人姓名
              '',            --寄件人身份证（根据需求可能不需要提供）/回寄人身份证
              '',            --寄件人联系方式/回寄人联系方式
              '',            --寄件收件单位/回寄收件单位
              ''             --寄件收件单位地址/回寄收件单位地址
      );
    end if;
    --是否快递取
    if lv_dobus.NRECHARGE>0 then
      insert into tc_webjj.t_weixin_express(
             sno,
             sdono,
             sstate,
             billno,
             dbbj,
             SEXPADDRESS,     --寄送地址（详细地址）/回寄地址
             SEXPPRO,        --寄送省份/回寄省份
             SEXPCITY,       --寄送市/回寄市
             SEXPAREA,       --寄送区县/回寄区县
             SEXPPOSTCODE,   --寄送邮政编码/回寄邮政编码
             SNAME,          --寄件人姓名/回寄人姓名
             SPID,           --寄件人身份证（根据需求可能不需要提供）/回寄人身份证
             STEL,           --寄件人联系方式/回寄人联系方式
             SDWNAME,        --寄件收件单位/回寄收件单位
             SDWADDRESS      --寄件收件单位地址/回寄收件单位地址
      )values(
             tc_webjj.seq_weixin_express_sno.nextval,
             lv_sdono,
             '2',
             tc_webjj.seq_weixin_express_sno.nextval,
             '0',
              '',            --寄送地址（详细地址）/回寄地址
              '',            --寄送省份/回寄省份
              '',            --寄送市/回寄市
              '',            --寄送区县/回寄区县
              '',            --寄送邮政编码/回寄邮政编码
              '',            --寄件人姓名/回寄人姓名
              '',            --寄件人身份证（根据需求可能不需要提供）/回寄人身份证
              '',            --寄件人联系方式/回寄人联系方式
              '',            --寄件收件单位/回寄收件单位
              ''             --寄件收件单位地址/回寄收件单位地址
      );
    end if;
    commit;
  exception when others then
     null;
  end;
end;

/

