create procedure          proc_rentcar_check
(
   lvimgurl VARCHAR2,       --照片路径
   lvmylocation VARCHAR2,   --我的位置
   lvthingtype VARCHAR2,    --事件类型
   lvcomment VARCHAR2       --我的评论
)
as
begin
    insert into tc_webjj.t_photo_shot
    (
    SNO,                     --1 编号
    IMAGURL,                 --2 照片路径
    MYLOCATION,              --3 我的位置
    THINGTYPE,                --4 事件类型
    MYCOMMENT,               --5 评论
    DSHOTDATE,               --6 拍摄时间
    DBBJ,                    --7 打包标记
    DBSJ                     --8 打包时间

    )
    values
   (
 tc_weixin.fun_get16code(tc_webjj.SEQ_RENTCAR_CHECK_SID.nextval,'350201',2),--1 编号
  lvimgurl,      --2 照片路径
  lvmylocation,  --3 我的位置
  lvthingtype,   --4 事件类型
  lvcomment,     --5 我的评论
   sysdate,      --6 拍摄时间
     '0' ,
   sysdate
   );
end;

/

