create procedure          proc_add_WEBSITE_REPORT(
                                                    lv_REPORT_ID in out varchar2 ,
                                                    lv_WEBSITE_NAME varchar2,
                                                    lv_WEBSITE_URL varchar2,
                                                    lv_REPORT_CONTENT varchar2,
                                                    lv_INFORMANT varchar2,
                                                    lv_SEMAIL varchar2,
                                                    lv_STEL varchar2,
                                                    lv_SIP varchar2,
                                                    lv_msg_return in out varchar2
                                                    ) is
begin
  select SEQ_HD_WEBSITE_REPORT_NID.nextval into lv_REPORT_ID  from dual;
  insert into tc_webjj.T_HD_WEBSITE_REPORT(
REPORT_ID,
WEBSITE_NAME,
WEBSITE_URL,
REPORT_CONTENT,
INFORMANT,
SEMAIL,
STEL,
SIP
  )values(
lv_REPORT_ID,
lv_WEBSITE_NAME,
lv_WEBSITE_URL,
lv_REPORT_CONTENT,
lv_INFORMANT,
lv_SEMAIL,
lv_STEL,
lv_SIP
);
commit;
lv_msg_return :='举报成功';
end proc_add_WEBSITE_REPORT;

/

