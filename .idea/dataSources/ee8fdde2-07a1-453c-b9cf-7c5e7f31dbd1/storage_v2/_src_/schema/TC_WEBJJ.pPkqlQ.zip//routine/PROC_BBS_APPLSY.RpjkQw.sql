create procedure          proc_bbs_applsy  --用户留言

(

  lv_sno   varchar2, --留言编号

  lv_npolice_id   varchar2,  --民警序号

  lv_personid   varchar2,    --用户编号

  lv_bbs_title   varchar2,   --留言标题

  lv_bbs_texts   varchar2,   --留言内容

  --lv_bbs_date   varchar2,    --留言时间

  lv_procmode  varchar2 --模式

)

as

begin

  if lv_procmode = 'PMINSERT' then

    insert into tc_webjj.t_bbs_apply

    ( sno,

      npolice_id,

      personid,

      bbs_title,

      bbs_texts,

      bbs_date

    ) values (fun_get16code_pz(tc_webjj.seq_bbs_apply_sno.nextval),

      lv_npolice_id,

      lv_personid,

      lv_bbs_title,

      lv_bbs_texts,

      sysdate

    );

  end if;

end;

/

