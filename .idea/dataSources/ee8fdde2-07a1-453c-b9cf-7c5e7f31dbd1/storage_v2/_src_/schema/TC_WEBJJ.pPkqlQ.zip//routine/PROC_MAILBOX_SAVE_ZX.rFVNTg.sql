create procedure proc_mailbox_save_zx(
      --lvsid       in out        varchar2,
      lvsregion_name      varchar2,
      lvsregion_id        varchar2,
      lvstype       varchar2,
      lvstitle      varchar2,
      lvscontent    varchar2,
      lvsuserid     varchar2,
      lvsname       varchar2,
      lvsphone      varchar2,
      lvsphoneaddr  varchar2,
      lvsemail      varchar2,
      lvsaddress    varchar2,
      lvsmailip     varchar2,
      lvsgzdw       varchar2,
      lvbm_id       varchar2,
      lvsispublic    varchar2,
      lvssource    varchar2,
      lvjc_type    varchar2,
      lv_qxcode    varchar2,
      lv_qxname    varchar2,
      lv_addressxxdz varchar2,
      lv_REMARK1     varchar2,
      lv_REMARK2     varchar2,
      lv_REMARK3     varchar2
      
) as
lvsid varchar2(16);

lv_sname varchar(45);
lv_sphone varchar(20);
lv_saddress        varchar2(300);

begin
  --select tc_webjj.fun_get16code(tc_webjj.seq_portal_mailbox_sid.nextval) into lvsid from dual;
  -- SELECT ROUND(dbms_random.value*1000000)||LPAD(seq_applymasterdata_nid.nextval,8,'0') into lvsid from dual;
  --SELECT LPAD(tc_webjj.seq_portal_mailbox_sid.nextval,10,'0') into lvsid from dual;
   SELECT LPAD(tc_webjj.seq_portal_mailbox_sid.nextval,10,'0') into lvsid from dual;
   
   if lvsname='' or lvsname is null then
      select name,SHOME_PHONE,SNOW_FULL_ADDR into lv_sname, lv_sphone,lv_saddress from tc_webjj.t_commoner where PERSONID=lvsuserid and rownum<2;
   else
      lv_sname:=lvsname;
      lv_sphone:=lvsphone;
   end if;
   
  insert into tc_webjj.t_portal_mailbox(
     sid,
     sregion_name,
     sregion_id,
     stype,
     stitle,
     scontent,
     dcreatedate,
     suserid,
     sispublic,
     sname,
     sphone,
     sphoneaddr,
     semail,
     saddress,
     smailip,
     dmaildeadline,
     sisdone,
     sgzdw,
     zxbm,
     ssource,
     jc_type,
      QX_CODE,--省市区县编码
      QX_NAME,--个人所在省市区
      ADDRESS_XXDZ,--具体地址

      REMARK1,--现居住地省
      REMARK2,--现居住地市
      REMARK3,--现居住地区县
      xg_stype
  )values(
     lvsid,
     lvsregion_name,
     lvsregion_id,
     lvstype,
     lvstitle,
     lvscontent,
     sysdate,
     lvsuserid,
     lvsispublic,
     lv_sname,
     lv_sphone,
     lvsphoneaddr,
     lvsemail,
     lv_saddress,
     lvsmailip,
     sysdate+10,
     '0',
     lvsgzdw,
     lvbm_id,
     lvssource,
     lvjc_type,
     lv_qxcode,
     lv_qxname,
     lv_addressxxdz,
     lv_REMARK1,
     lv_REMARK2,
     lv_REMARK3,
     lvstype
  );
    if lvssource != '1' then
       PROC_dobus_count_(lvsuserid,'ly');
    end if;
  commit;
end proc_mailbox_save_zx;
/

