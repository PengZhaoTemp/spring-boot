create view V_BUS_FLOW as
  select
a.BUSFLOWNO,
a.SBUSNO,
a.FLOWNO,
a.FLOWSTEP,
b.flowname,
b.flowtype,
b.operrole,
b.dowork,
b.flowdemo,
'<input type=''text'' name=''netstep_'||FLOWSTEP||''' value='''||netstep||'''  class=''input_edit'' style=''width:50px'' kind=''dcNone''>' netstep_edit,
a.netstep
from tc_webjj.t_bus_flow a,tc_webjj.t_flownote_deploy b
where a.flowno = b.flowno
/

