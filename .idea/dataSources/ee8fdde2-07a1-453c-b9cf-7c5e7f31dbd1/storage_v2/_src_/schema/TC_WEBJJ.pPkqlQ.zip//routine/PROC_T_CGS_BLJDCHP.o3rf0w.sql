create PROCEDURE          PROC_t_cgs_bljdchp   /*T_CGS_BLJDCHP*/
(
 lvsdono IN OUT VARCHAR2,  --办理编号
 lvscarid VARCHAR2,  --车牌号码
 lvscar_type VARCHAR2,  --车辆类型
 lvsloginid VARCHAR2,  --登记证书编号
 lvscar_sbid VARCHAR2,  --车辆识别代号/车架号
 lvscar_fdjid VARCHAR2,  --发动机号
 lvscar_name VARCHAR2,  -- 机动车所有人
 lvscar_pid VARCHAR2,  --身份证明号/代码
 lvstel VARCHAR2,  --联系电话
 lvsadress VARCHAR2,  --通信地址
 lvsq_type VARCHAR2,  --申请类型
 lvsbhreason VARCHAR2,  --补换原因
 lvsmian VARCHAR2,  --一面两面
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS

BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/



   INSERT into tc_webjj.t_cgs_bljdchp
    (
      sdono,   --办理编号
      scarid,   --车牌号码
      scar_type,   --车辆类型
      sloginid,   --登记证书编号
      scar_sbid,   --车辆识别代号/车架号
      scar_fdjid,   --发动机号
      scar_name,   -- 机动车所有人
      scar_pid,   --身份证明号/代码
      stel,   --联系电话
      sadress,   --通信地址
      sq_type,   --申请类型
      sbhreason,   --补换原因
      smian    --一面两面
    )values(
      lvsdono,   --办理编号
      lvscarid,   --车牌号码
      lvscar_type,   --车辆类型
      lvsloginid,   --登记证书编号
      lvscar_sbid,   --车辆识别代号/车架号
      lvscar_fdjid,   --发动机号
      lvscar_name,   -- 机动车所有人
      lvscar_pid,   --身份证明号/代码
      lvstel,   --联系电话
      lvsadress,   --通信地址
      lvsq_type,   --申请类型
      lvsbhreason,   --补换原因

      lvsmian    --一面两面


    );
   -- 返回值

END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_cgs_bljdchp
    Set
      sdono=lvsdono,   --办理编号
      scarid=lvscarid,   --车牌号码
      scar_type=lvscar_type,   --车辆类型
      sloginid=lvsloginid,   --登记证书编号
      scar_sbid=lvscar_sbid,   --车辆识别代号/车架号
      scar_fdjid=lvscar_fdjid,   --发动机号
      scar_name=lvscar_name,   -- 机动车所有人
      scar_pid=lvscar_pid,   --身份证明号/代码
      stel=lvstel,   --联系电话
      sadress=lvsadress,   --通信地址
      sq_type=lvsq_type,   --申请类型
      sbhreason=lvsbhreason,   --补换原因
      smian=lvsmian    --一面两面
    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_cgs_bljdchp
    Set
      sdono=lvsdono,   --办理编号
      scarid=lvscarid,   --车牌号码
      scar_type=lvscar_type,   --车辆类型
      sloginid=lvsloginid,   --登记证书编号
      scar_sbid=lvscar_sbid,   --车辆识别代号/车架号
      scar_fdjid=lvscar_fdjid,   --发动机号
      scar_name=lvscar_name,   -- 机动车所有人
      scar_pid=lvscar_pid,   --身份证明号/代码
      stel=lvstel,   --联系电话
      sadress=lvsadress,   --通信地址
      sq_type=lvsq_type,   --申请类型
      sbhreason=lvsbhreason,   --补换原因
      smian=lvsmian    --一面两面
    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_cgs_bljdchp
    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

