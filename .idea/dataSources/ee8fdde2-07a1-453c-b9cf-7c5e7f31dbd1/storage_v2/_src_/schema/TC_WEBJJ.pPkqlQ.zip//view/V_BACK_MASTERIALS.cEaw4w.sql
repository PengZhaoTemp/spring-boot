create view V_BACK_MASTERIALS as
  select SID,
       a.SBUSNO,
       SBACKTYPE,
       decode(SBACKTYPE,'1','办理成功回寄','2','办理失败回寄') SBACKTYPECN,
       SMASTER,
       SIMGURL,
       SREMARK,
       SFLAG,
       decode(SFLAG,'0','已注销','1','有效') SFLAGCN,
       b.sbusname
  from tc_webjj.t_back_masterials a,
  tc_webjj.t_bus_deploy b
  where a.sbusno = b.sbusno
/

