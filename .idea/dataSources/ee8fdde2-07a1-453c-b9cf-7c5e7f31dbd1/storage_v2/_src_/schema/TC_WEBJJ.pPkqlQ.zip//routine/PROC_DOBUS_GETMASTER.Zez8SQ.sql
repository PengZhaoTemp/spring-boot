create procedure          proc_dobus_getmaster(
       lvsdono varchar2,
       lvsoperationno varchar2,
       lvsuserno           varchar2,--用户编号
       lvsusername         varchar2,--用户姓名
       lvsorgid            varchar2,--操作单位代码（群众的时候不需要操作单位）
       lvsorgname          varchar2,--操作单位名称（群众的时候不需要操作单位）
       lvsplanno           varchar2
) is
lvslogno varchar2(16);
lvsoperationname varchar2(16);
lvsusertype varchar2(1);
lvsresult varchar2(500);
begin
    --日志
    lvsresult := '亲，您已经接收材料，记得评价哦。';
    update tc_webjj.t_dobus set scontext = lvsresult where sdono=lvsdono;
    select a.sname,a.stype into lvsoperationname,lvsusertype from tc_webjj.t_operation_deploy a where a.sno=lvsoperationno;
    proc_dobus_log_info(
      lvslogno,
      lvsplanno,
      lvsoperationno,
      lvsoperationname,
      lvsdono,
      lvsusertype,
      lvsuserno,
      lvsusername,
      lvsorgid,
      lvsorgname,
      lvsresult
    );
    proc_dobus_nextflow(lvsdono);
    commit;
end proc_dobus_getmaster;

/

