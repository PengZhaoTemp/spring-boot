create procedure          proc_hd_pep_con_pj(lv_SID              in out number,
                                               lv_SPEP_CON_ID      varchar2, --民意征集主题编号
                                               lv_SPEP_CON_INFO_ID varchar2, --民意征集信息编号
                                               lv_SIP              varchar2,
                                               lv_SMANNER          varchar2,
                                               lv_ProcMode         varchar2,
                                               lv_msg_return       in out varchar2) as
  lv_count number;

begin
  if lv_ProcMode = 'PMINSERT' then
    select count(0)
      into lv_count
      from tc_webjj.t_hd_pep_con_pj
     where SPEP_CON_INFO_ID = lv_SPEP_CON_INFO_ID
       and SIP = lv_SIP;
    if lv_count = 0 then
      select tc_webjj.SEQ_HD_PEP_CON_PJ.nextval into lv_SID from dual; --民意征集点赞或反对情况编号
      insert into tc_webjj.t_hd_pep_con_pj
        (SID, SPEP_CON_ID, SPEP_CON_INFO_ID, SIP, SMANNER)
      values
        (lv_SID, lv_SPEP_CON_ID, lv_SPEP_CON_INFO_ID, lv_SIP, lv_SMANNER);
      lv_msg_return := '操作成功';
    else
      lv_msg_return := '您已经操作过了';
    end if;
  elsif lv_ProcMode = 'PMUPDATE' then
    update tc_webjj.t_hd_pep_con_pj
       set SMANNER = lv_SMANNER
     where SIP = lv_SIP
       and SPEP_CON_INFO_ID = lv_SPEP_CON_INFO_ID;
      lv_msg_return := '操作成功';
  end if;
  commit;
end proc_hd_pep_con_pj;

/

