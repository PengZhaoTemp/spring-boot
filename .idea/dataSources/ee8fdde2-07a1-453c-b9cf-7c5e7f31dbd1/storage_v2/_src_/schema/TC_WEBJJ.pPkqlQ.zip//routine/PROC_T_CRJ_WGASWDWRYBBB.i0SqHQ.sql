create PROCEDURE          PROC_t_crj_wgaswdwrybbb   /*T_CRJ_WGASWDWRYBBB*/
(
 lvsdono IN OUT VARCHAR2,  --业务编号
 lvsdw_mc VARCHAR2,  --单位名称
 lvsdw_lx VARCHAR2,  --单位类型
 lvsdw_sj_dz VARCHAR2,  --单位实际地址
 lvsdw_zc_zj VARCHAR2,  --单位注册资金
 lvsbn_snd_nse VARCHAR2,  --本年或上年度纳税额
 lvsdw_lx_dh VARCHAR2,  --单位联系电话
 lvsdw_frdb VARCHAR2,  --单位法人代表
 lvszjl VARCHAR2,  --总  经 理
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
   INSERT into tc_webjj.t_crj_wgaswdwrybbb
    (
      sdono,   --业务编号
      sdw_mc,   --单位名称
      sdw_lx,   --单位类型
      sdw_sj_dz,   --单位实际地址
      sdw_zc_zj,   --单位注册资金
      sbn_snd_nse,   --本年或上年度纳税额
      sdw_lx_dh,   --单位联系电话
      sdw_frdb,   --单位法人代表
      szjl    --总  经 理
    )values(
      lvsdono,   --业务编号
      lvsdw_mc,   --单位名称
      lvsdw_lx,   --单位类型
      lvsdw_sj_dz,   --单位实际地址
      lvsdw_zc_zj,   --单位注册资金
      lvsbn_snd_nse,   --本年或上年度纳税额
      lvsdw_lx_dh,   --单位联系电话
      lvsdw_frdb,   --单位法人代表
      lvszjl    --总  经 理
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_crj_wgaswdwrybbb
    Set
      sdono=lvsdono,   --业务编号
      sdw_mc=lvsdw_mc,   --单位名称
      sdw_lx=lvsdw_lx,   --单位类型
      sdw_sj_dz=lvsdw_sj_dz,   --单位实际地址
      sdw_zc_zj=lvsdw_zc_zj,   --单位注册资金
      sbn_snd_nse=lvsbn_snd_nse,   --本年或上年度纳税额
      sdw_lx_dh=lvsdw_lx_dh,   --单位联系电话
      sdw_frdb=lvsdw_frdb,   --单位法人代表
      szjl=lvszjl    --总  经 理
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_crj_wgaswdwrybbb
    Set
      sdono=lvsdono,   --业务编号
      sdw_mc=lvsdw_mc,   --单位名称
      sdw_lx=lvsdw_lx,   --单位类型
      sdw_sj_dz=lvsdw_sj_dz,   --单位实际地址
      sdw_zc_zj=lvsdw_zc_zj,   --单位注册资金
      sbn_snd_nse=lvsbn_snd_nse,   --本年或上年度纳税额
      sdw_lx_dh=lvsdw_lx_dh,   --单位联系电话
      sdw_frdb=lvsdw_frdb,   --单位法人代表
      szjl=lvszjl    --总  经 理
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_crj_wgaswdwrybbb
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

