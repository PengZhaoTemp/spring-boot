create procedure          proc_dobus_cancelled(
       lvsdono varchar2,
       lvsoperationno varchar2,
       lvsuserno           varchar2,--用户编号
       lvsusername         varchar2,--用户姓名
       lvsorgid            varchar2,--操作单位代码（群众的时候不需要操作单位）
       lvsorgname          varchar2,--操作单位名称（群众的时候不需要操作单位）
       lvsplanno           varchar2
) is
lvslogno varchar2(16);
lvsoperationname varchar2(16);
lvsusertype varchar2(1);
lvsresult varchar2(500);
lvbusflow tc_webjj.t_busflow_deploy%rowtype;
lvdobus tc_webjj.v_dobus%rowtype;
lv_splanno varchar2(16);
begin
    --日志
    lvsresult := '亲，您撤销申请了。';
    select a.sname,a.stype into lvsoperationname,lvsusertype from tc_webjj.t_operation_deploy a where a.sno=lvsoperationno;
    proc_dobus_log_info(
      lvslogno,
      lvsplanno,
      lvsoperationno,
      lvsoperationname,
      lvsdono,
      lvsusertype,
      lvsuserno,
      lvsusername,
      lvsorgid,
      lvsorgname,
      lvsresult
    );
    select * into lvdobus from tc_webjj.v_dobus where sdono = lvsdono;
    begin
      select * into lvbusflow from tc_webjj.t_busflow_deploy a where sbusno=lvdobus.sbusno and a.sflowtaxis=99 and a.sflowstatus='1';
      select tc_webjj.fun_get16code(tc_webjj.seq_busflow_splanno.nextval) into lv_splanno from dual;
      insert into tc_webjj.t_busflow_plan(
             splanno,sflowno,sdono,nstepnum,dendtime,scomplete
      )values(
             lv_splanno,
             lvbusflow.sflowno,
             lvsdono,
             lvdobus.nstepnum+1,
             sysdate,
             '1'
      );
      update tc_webjj.t_busflow_plan a set a.scomplete='1',a.dendtime=sysdate where splanno = lvdobus.splanno;
      update tc_webjj.t_dobus b set b.state=lvbusflow.sbusstatuscode,b.splanno=lv_splanno,b.soperationsno=lvbusflow.soperationno,b.scontext=lvsresult where sdono=lvsdono;
    exception
    when others then
      update tc_webjj.t_dobus b set b.state='33',b.soperationsno=lvbusflow.soperationno,b.scontext=lvsresult where sdono=lvsdono;
    end;

    commit;
end proc_dobus_cancelled;

/

