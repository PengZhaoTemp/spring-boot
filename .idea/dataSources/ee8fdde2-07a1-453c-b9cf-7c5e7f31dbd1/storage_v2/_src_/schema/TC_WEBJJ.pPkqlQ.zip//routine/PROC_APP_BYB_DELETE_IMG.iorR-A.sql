create procedure          PROC_APP_BYB_DELETE_IMG (
  imgName VARCHAR2--图片名称
) is
begin
  delete from tc_webjj.t_applymasterdata where SMASTERIALSPATH=imgName;
end PROC_APP_BYB_DELETE_IMG;

/

