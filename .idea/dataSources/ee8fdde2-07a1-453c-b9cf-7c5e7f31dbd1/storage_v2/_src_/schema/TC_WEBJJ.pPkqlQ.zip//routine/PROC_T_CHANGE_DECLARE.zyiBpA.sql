create PROCEDURE          PROC_t_change_declare   /*T_CHANGE_DECLARE*/
(
 lvsdono IN OUT VARCHAR2,  --办理编号
 lvapp_type  VARCHAR2,  --变更类型
 lvapp_why_apply VARCHAR2,  --变更理由
 lvpid VARCHAR2,  --公民身份号码
 lvname VARCHAR2,  --姓　　名
 lvgender VARCHAR2,  --性　　别
 lvused_name VARCHAR2,  --曾  用 名
 lvnation VARCHAR2,  --民　　族
 lvnative_country VARCHAR2,  --籍贯（国家地区）
 lvnative_place VARCHAR2,  --籍贯（省市县区）
 lvdob DATE,  --出生日期
 lvapp_pid VARCHAR2,  --申请人公民身份号码
 lvapp_name VARCHAR2,  --申请人姓名
 lvmemo VARCHAR2,  --备　　注
 lvsnewvalue VARCHAR2,  --变更新值
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
   INSERT into tc_webjj.t_change_declare
    (
      sdono,   --办理编号
      app_type,   --变更类型
      app_why_apply,   --变更理由
      pid,   --公民身份号码
      name,   --姓　　名
      gender,   --性　　别
      used_name,   --曾  用 名
      nation,   --民　　族
      native_country,   --籍贯（国家地区）
      native_place,   --籍贯（省市县区）
      dob,   --出生日期
      app_pid,   --申请人公民身份号码
      app_name,   --申请人姓名
      memo,   --备　　注
      snewvalue    --变更新值
    )values(
      lvsdono,   --办理编号
      lvapp_type,   --变更类型
      lvapp_why_apply,   --变更理由
      lvpid,   --公民身份号码
      lvname,   --姓　　名
      lvgender,   --性　　别
      lvused_name,   --曾  用 名
      lvnation,   --民　　族
      lvnative_country,   --籍贯（国家地区）
      lvnative_place,   --籍贯（省市县区）
      lvdob,   --出生日期
      lvapp_pid,   --申请人公民身份号码
      lvapp_name,   --申请人姓名
      lvmemo,   --备　　注
      lvsnewvalue    --变更新值
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_change_declare
    Set
      sdono=lvsdono,   --办理编号
      app_type=lvapp_type,   --变更类型
      app_why_apply=lvapp_why_apply,   --变更理由
      pid=lvpid,   --公民身份号码
      name=lvname,   --姓　　名
      gender=lvgender,   --性　　别
      used_name=lvused_name,   --曾  用 名
      nation=lvnation,   --民　　族
      native_country=lvnative_country,   --籍贯（国家地区）
      native_place=lvnative_place,   --籍贯（省市县区）
      dob=lvdob,   --出生日期
      app_pid=lvapp_pid,   --申请人公民身份号码
      app_name=lvapp_name,   --申请人姓名
      memo=lvmemo,   --备　　注
      snewvalue=lvsnewvalue    --变更新值
    Where 1=1
    and sdono=lvsdono
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_change_declare
    Set
      sdono=lvsdono,   --办理编号
      app_type=lvapp_type,   --变更类型
      app_why_apply=lvapp_why_apply,   --变更理由
      pid=lvpid,   --公民身份号码
      name=lvname,   --姓　　名
      gender=lvgender,   --性　　别
      used_name=lvused_name,   --曾  用 名
      nation=lvnation,   --民　　族
      native_country=lvnative_country,   --籍贯（国家地区）
      native_place=lvnative_place,   --籍贯（省市县区）
      dob=lvdob,   --出生日期
      app_pid=lvapp_pid,   --申请人公民身份号码
      app_name=lvapp_name,   --申请人姓名
      memo=lvmemo,   --备　　注
      snewvalue=lvsnewvalue    --变更新值
    Where 1=1
    and sdono=lvsdono
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_change_declare
    Where 1=1
    and sdono=lvsdono
    ;
END IF;
 Commit;
END; /*存储过程结束*/

