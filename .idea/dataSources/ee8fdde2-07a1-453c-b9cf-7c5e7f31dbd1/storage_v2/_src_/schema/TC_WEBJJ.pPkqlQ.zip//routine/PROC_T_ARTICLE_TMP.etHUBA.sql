create PROCEDURE          PROC_t_article_tmp   /*T_ARTICLE_TMP*/
(
 lvsid IN OUT VARCHAR2,  --编　　号
 lvlcategory VARCHAR2,  --所属栏目
  lvscategory VARCHAR2,  --所属类别
 lvtitle VARCHAR2,  --标　　题
 lvhomephoto VARCHAR2,  --图片展示
 lveditor VARCHAR2,  --作　　者
 lvddate DATE,  --发布时间
 lvcontent BLOB,  --内　　容
 lvdbbj VARCHAR2,  --dbbj
 lvdbsj DATE,  --dbsj
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
    Select TC_WEBJJ.SEQ_T_ARTICLE_TMP_SID.Nextval  into lvsid From dual;    /*编　　号序列*/
   INSERT into tc_webjj.t_article_tmp
    (
      sid,   --编　　号
      lcategory,   --所属栏目
      scategory,   --所属类别
      title,   --标　　题
      homephoto,   --图片展示
      editor,   --作　　者
      ddate,   --发布时间
      content,   --内　　容
      dbbj,   --dbbj
      dbsj    --dbsj
    )values(
      lvsid,   --编　　号
      lvlcategory,   --所属栏目
      lvscategory,   --所属类别
      lvtitle,   --标　　题
      lvhomephoto,   --图片展示
      lveditor,   --作　　者
      lvddate,   --发布时间
      lvcontent,   --内　　容
      lvdbbj,   --dbbj
      lvdbsj    --dbsj
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_article_tmp
    Set
      sid=lvsid,   --编　　号
      lcategory=lvlcategory,   --所属栏目
      scategory=lvscategory,   --所属类别
      title=lvtitle,   --标　　题
      homephoto=lvhomephoto,   --图片展示
      editor=lveditor,   --作　　者
      ddate=lvddate,   --发布时间
      content=lvcontent,   --内　　容
      dbbj=lvdbbj,   --dbbj
      dbsj=lvdbsj    --dbsj
    Where 1=1
    and sid=lvsid   --编　　号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_article_tmp
    Set
      sid=lvsid,   --编　　号
      lcategory=lvlcategory,   --所属栏目
      scategory=lvscategory,   --所属类别
      title=lvtitle,   --标　　题
      homephoto=lvhomephoto,   --图片展示
      editor=lveditor,   --作　　者
      ddate=lvddate,   --发布时间
      content=lvcontent,   --内　　容
      dbbj=lvdbbj,   --dbbj
      dbsj=lvdbsj    --dbsj
    Where 1=1
    and sid=lvsid   --编　　号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_article_tmp
    Where 1=1
    and sid=lvsid   --编　　号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

