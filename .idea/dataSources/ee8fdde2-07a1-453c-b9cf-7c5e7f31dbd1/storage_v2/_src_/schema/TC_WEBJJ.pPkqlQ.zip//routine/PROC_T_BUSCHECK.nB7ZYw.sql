create procedure          proc_t_busCheck  --业务审核配置
(
  lv_sno  varchar2,  --序号
  lv_sbusno  varchar2,  --业务编码
  lv_check_true  varchar2,  --审核项合格表述
  lv_check_false  varchar2,  --审核项不合格表述
  --lv_when_logged  varchar2,  --登记时间
  lv_procmode  varchar2 --模式
)
as
begin
  if lv_procmode = 'PMINSERT' then
    insert into tc_webjj.t_bus_check_deploy
    ( sno,
      sbusno,
      check_true,
      check_false,
      when_logged
    )
    values (fun_get16code_pz(tc_webjj.seq_bus_check_deploy.nextval),
      lv_sbusno,
      lv_check_true,
      lv_check_false,
      sysdate
      );
  elsif lv_procmode = 'PMUPDATE' then
    update tc_webjj.t_bus_check_deploy set
        sbusno = lv_sbusno,
        check_true = lv_check_true,
        check_false = lv_check_false,
        when_logged = sysdate
      where sno = lv_sno;
  elsif lv_procmode = 'PMDELETE' then
    delete tc_webjj.t_bus_check_deploy where sno = lv_sno;
  end if;
end;

/

