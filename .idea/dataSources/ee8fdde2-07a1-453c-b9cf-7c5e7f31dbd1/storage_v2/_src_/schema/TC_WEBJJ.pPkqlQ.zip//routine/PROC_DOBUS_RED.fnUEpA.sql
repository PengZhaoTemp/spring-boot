create procedure          PROC_DOBUS_RED
(
ssnodo VARCHAR2,---------红点的存储过程
ssuerno VARCHAR2

)
as
begin
  update  tc_webjj.T_DOBUS set  READTYPE ='1' where SDONO =ssnodo and suserno=ssuerno;
  commit;

end PROC_DOBUS_RED;

/

