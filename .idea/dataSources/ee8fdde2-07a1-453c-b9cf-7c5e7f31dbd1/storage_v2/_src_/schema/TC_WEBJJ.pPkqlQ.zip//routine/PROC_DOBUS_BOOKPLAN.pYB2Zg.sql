create procedure          proc_dobus_bookplan(
       lvsdono varchar2,
       lvsoperationno varchar2,
       lvtestsresult varchar2,
       lvsplanno   varchar2,
       lverrmsg    varchar2,
       lvjhid      varchar2
) is
lvslogno varchar2(16);
lvsoperationname varchar2(30);
lvsusertype varchar2(1);
lvsresult varchar2(500);
lvnotesno varchar2(16);
lvnotemsg varchar2(2000);
lvsapptel varchar2(20);
lvsappname varchar2(20);
lvsorgid varchar2(12);
lvsorgname varchar2(200);
lvksjh tc_webjj.v_testone_ksjh%rowtype;
begin
    select * into lvksjh from tc_webjj.v_testone_ksjh where jhid=to_number(lvjhid) and sdono=lvsdono;
    select sapptel,sappname,sdounit,sdounitno into lvsapptel,lvsappname,lvsorgname,lvsorgid from tc_webjj.t_dobus where sdono=lvsdono;
    if lvtestsresult = '0' then
       lvsresult := '场次预约失败，原因：'||lverrmsg;
       lvnotemsg := '场次预约失败，考试预约被退回，原因：'||lverrmsg||'。详情请登录长沙市网上公安局查看。';
    elsif lvtestsresult = '1' then
       lvsresult := '场次预约成功：'||lvksjh.kcdd||' '||lvksjh.ksrq||' '||lvksjh.kskm||' '||lvksjh.kscc;
       lvnotemsg := '场次预约成功，场次：'||lvksjh.kcdd||' '||lvksjh.ksrq||' '||lvksjh.kskm||' '||lvksjh.kscc||'。详情请登录长沙市网上公安局查看。';
    elsif lvtestsresult = '-1' then
       lvsresult := '场次预约失败，原因：'||lverrmsg;
       lvnotemsg := '场次预约失败，原因：'||lverrmsg||'。详情请登录长沙市网上公安局查看。';
    end if;
    update tc_webjj.t_dobus a set a.scontext=lvsresult where sdono = lvsdono;
    update tc_webjj.t_jj_test_one b set b.sresult = lvtestsresult,b.dbbj='0' where sdono = lvsdono;
    --日志
    select a.sname,a.stype into lvsoperationname,lvsusertype from tc_webjj.t_operation_deploy a where a.sno=lvsoperationno;
    proc_dobus_log_info(
      lvslogno,
      lvsplanno,
      lvsoperationno,
      lvsoperationname,
      lvsdono,
      lvsusertype,
      '',
      '自主预约',
      lvsorgid,
      lvsorgname,
      lvsresult
    );
    proc_dobus_nextflow(lvsdono);
    --发送短信
    PROC_t_notetask(
      lvnotesno,
      lvnotemsg,
      sysdate,
      lvsapptel,
      '0',
      '1',
      '0',
      null,
      'PMINSERT'
    );
    commit;
end proc_dobus_bookplan;

/

