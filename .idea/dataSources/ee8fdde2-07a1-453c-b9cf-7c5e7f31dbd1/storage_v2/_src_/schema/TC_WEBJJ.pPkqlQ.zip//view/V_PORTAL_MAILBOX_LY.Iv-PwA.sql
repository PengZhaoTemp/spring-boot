create view V_PORTAL_MAILBOX_LY as
  select a.sid,a.sname,tc_jcyw.fun_get_orgname(substr(a.sregion_id,0,4)||'00000000') as orgname,
 a.sregion_name,a.sregion_id,
 a.sphone,a.dcreatedate,
 decode(a.zxbm,'1','治安咨询','2','交警咨询','3','出入境咨询','4','其他') zxbm,
a.stitle,
 to_char(a.dmaildeadline, 'yyyy-mm-dd') dmaildeadline,
 decode(a.sstate,'0','未回复','1','未回复','2','未回复','3','审批未通过','4','已回复','6','已发布撤回') sstate,
  a.sstate as sstate01,
 a.issave,decode(a.jc_type,'1','PC版','2','手机版') jc_type,
 decode(a.ssource,'1','门户网站','2','微信','3','人民日报APP','4','支付宝服务窗','5','微博','6','互联网+') ssource,
 decode(a.dbbj,'','未转入','已转入') dbbj01,
 a.dbbj,a.dbsj,a.dreplydate,a.sreplyuser,a.spdate,
  --decode(a.ispublic,'0','未公开','1','公开')ispublic,
 -- decode(a.ishot,'0','不是热点','1','热点') ishot,
  --decode(a.issend,'0','未发送','1','发送')issend,
    decode(a.ispublic,'0','否','1','是')ispublic,
  decode(a.ishot,'0','否','1','是') ishot,
  decode(a.issend,'0','否','1','是')issend,
  a.REMARK8,
  a.SCONTENT,
 b.name,
 b.shome_phone,
 tc_webjj.fun_uncrypkey(b.pid) as pid
 from tc_webjj.t_portal_mailbox a left join tc_webjj.t_commoner b on a.suserid=b.personid
 where 1=1
 --and (a.issave is null or a.issave='0')
  and a.ssource='6'
  --and (a.dbbj is null or a.dbbj='5')
   --and sstate in ('0','1','2','6')
  -- and zxbm like '%治安%'
  and b.sstate='1'
   --order by a.dcreatedate desc
/

