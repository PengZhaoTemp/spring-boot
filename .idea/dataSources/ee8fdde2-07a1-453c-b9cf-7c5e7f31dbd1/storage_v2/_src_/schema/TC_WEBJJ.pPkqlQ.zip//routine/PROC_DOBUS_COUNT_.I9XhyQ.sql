create PROCEDURE PROC_dobus_count_
(
  lvpersonid       varchar2,--办理编号
  lvsbusdotype     varchar2   --1-办理 2-预约 3-查询 4-下载
)
as
    lvsno_count number;
    lvdobus_count tc_webjj.t_dobus_count%rowtype;
    CURSOR cur_user_tj IS select decode(sbusdotype, '1', 'sb', '2', 'yy', '3', 'cx') as sbusdotype,
       count(1) gr_num  from tc_webjj.t_dobus where suserno = lvpersonid group by sbusdotype union all
       select 'ly' ly_count,count(1) couq from tc_webjj.t_portal_mailbox t, tc_webjj.t_commoner a where t.ssource = '6'
       and (t.issave is null or t.issave = '0')
       and t.suserid = a.personid
       and a.personid =lvpersonid ;
     yy_count number:=0;
     sb_count number:=0;
     cx_count number:=0;
     ly_count number:=0;
    begin
    select count(1) into lvsno_count from t_dobus_count where personid = lvpersonid;
    if lvsno_count = 0 then 
             FOR user_row IN cur_user_tj LOOP
               if user_row.sbusdotype = 'yy' then
                 yy_count:=user_row.gr_num;
               elsif  user_row.sbusdotype = 'sb' then
                 sb_count:=user_row.gr_num;
               elsif  user_row.sbusdotype = 'cx' then
                 cx_count:=user_row.gr_num;
               elsif  user_row.sbusdotype = 'ly' then
                 ly_count:=user_row.gr_num;
               end if;
            END LOOP;
            insert into tc_webjj.t_dobus_count(
                  personid,--用户编号
                  yy_count,--预约数
                  sb_count,--申报数
                  cx_count,--查询数
                  ly_count--留言数

           )values(
                  lvpersonid,
                  yy_count,
                  sb_count,
                  cx_count,
                  ly_count
           );
    elsif lvsno_count != 0 then 
        select  * into lvdobus_count from tc_webjj.t_dobus_count where personid = lvpersonid;
        update tc_webjj.t_dobus_count set 
              yy_count = decode (lvsbusdotype,'2',lvdobus_count.yy_count+1,lvdobus_count.yy_count),
              sb_count = decode (lvsbusdotype,'1',lvdobus_count.sb_count+1,lvdobus_count.sb_count),
              cx_count = decode (lvsbusdotype,'3',lvdobus_count.cx_count+1,lvdobus_count.cx_count),
              ly_count = decode (lvsbusdotype,'ly',lvdobus_count.ly_count+1,lvdobus_count.ly_count)
        where personid = lvpersonid ;
    end if;
   Commit; 
end ;
/

