create procedure          proc_people_ftl_info(lv_SID             in out varchar2,
                                                 lv_GOODNAME        varchar2,
                                                 lv_GOODTYPE        varchar2,
                                                 lv_GOODPROPERTY    varchar2,
                                                 lv_OCCURTIME_START varchar2,
                                                 lv_OCCURTIME_END   varchar2,
                                                 lv_OCCURADDRESS    varchar2,
                                                 lv_CONTACTS_NAME   varchar2,
                                                 lv_CONTACTS_PHONE  varchar2,
                                                 lv_WEBSITE_CODE    varchar2,
                                                 lv_GOODPHOTO1      varchar2,
                                                 lv_GOODPHOTO2      varchar2,
                                                 lv_GOODPHOTO3      varchar2,
                                                 lv_GOODPHOTO4      varchar2,
                                                 lv_GOODPHOTO5      varchar2,
                                                 lv_SIP             varchar2,
                                                 lv_ProcMode        varchar2,
                                                 lv_msg_return      in out varchar2) as
  lv_count number;

begin
  if lv_ProcMode = 'PMINSERT' then
    select count(0)
      into lv_count
      from tc_webjj.t_people_ftl_info
     where SIP = lv_SIP
       and dindate > (sysdate - 1 / (24 * 60));
    if lv_count > 0 then
      lv_msg_return := '防止频繁操作';
    else
      select tc_webjj.fun_get_hdbh('FTL') into lv_SID from dual;
      insert into tc_webjj.t_people_ftl_info
        (SID,
         GOODNAME,
         GOODTYPE,
         GOODPROPERTY,
         OCCURTIME_START,
         OCCURTIME_END,
         OCCURADDRESS,
         CONTACTS_NAME,
         CONTACTS_PHONE,
         GOODPHOTO1,
         GOODPHOTO2,
         GOODPHOTO3,
         GOODPHOTO4,
         GOODPHOTO5,
         WEBSITE_CODE,
         SIP)
      values
        (lv_SID,
         lv_GOODNAME,
         lv_GOODTYPE,
         lv_GOODPROPERTY,
         to_date(lv_OCCURTIME_START, 'yyyy-mm-dd hh24:mi:ss'),
         to_date(lv_OCCURTIME_END, 'yyyy-mm-dd hh24:mi:ss'),
         lv_OCCURADDRESS,
         lv_CONTACTS_NAME,
         lv_CONTACTS_PHONE,
         lv_GOODPHOTO1,
         lv_GOODPHOTO2,
         lv_GOODPHOTO3,
         lv_GOODPHOTO4,
         lv_GOODPHOTO5,
         lv_WEBSITE_CODE,
         lv_SIP);
      lv_msg_return := '操作成功';
    end if;
  end if;
  commit;
end proc_people_ftl_info;

/

