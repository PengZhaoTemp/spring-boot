create procedure          proc_hd_pep_con_info(lv_SID           in out varchar2,
                                                 lv_SPEP_CON_ID   varchar2,
                                                 lv_SNAME         varchar2,
                                                 lv_SEMAIL        varchar2,
                                                 lv_STEL          varchar2,
                                                 lv_SDETAIL       varchar2,
                                                 lv_SIP           varchar2,
                                                 lv_SRETURN       varchar2,
                                                 lv_SEXA_STATUS   varchar2,
                                                 lv_SEXA_MAN      varchar2,
                                                 lv_SEXA_UNIT     varchar2,
                                                 lv_SEXA_UNITCODE varchar2,
                                                 lv_ProcMode      varchar2,
                                                 lv_msg_return    in out varchar2) as
  lv_count number;
begin
  if lv_ProcMode = 'PMINSERT' then
    select count(0)
      into lv_count
      from tc_webjj.t_hd_pep_con_info
     where SPEP_CON_ID = lv_SPEP_CON_ID
       and SIP = lv_SIP;
    if lv_count = 0 then
      select tc_webjj.fun_get_hdbh('PCI') into lv_SID from dual; --业务咨询编号
      insert into tc_webjj.t_hd_pep_con_info
        (Sid, SPEP_CON_ID, Sname, Semail, Stel, sdetail, Sip)
      values
        (lv_SID,
         lv_SPEP_CON_ID,
         lv_SNAME,
         lv_SEMAIL,
         lv_STEL,
         lv_SDETAIL,
         lv_SIP);
      lv_msg_return := '返回的业务编号：' || lv_SID ||
                       '，感谢您提出的宝贵意见！';
    else
      lv_msg_return := '您已经反馈过了，谢谢！（每条IP地址只能反馈一次）';
    end if;
  end if;
  commit;
end proc_hd_pep_con_info;

/

