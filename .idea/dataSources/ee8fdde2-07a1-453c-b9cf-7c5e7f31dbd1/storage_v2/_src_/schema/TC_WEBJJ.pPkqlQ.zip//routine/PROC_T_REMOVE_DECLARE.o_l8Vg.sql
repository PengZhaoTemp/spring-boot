create PROCEDURE          PROC_t_remove_declare   /*T_REMOVE_DECLARE*/
(
 lvsdono IN OUT VARCHAR2,  --办理编号
 lvmaster_name VARCHAR2,  --户主姓名
 lvmaster_pid VARCHAR2,  --户主身份证号
 lvmaster_relation VARCHAR2,  --与户主关系
 lvnewrelation VARCHAR2,  --与持证人关系
 lvapp_type IN OUT VARCHAR2,  --变更类型
 lvout_category VARCHAR2,  --迁移原因
 lvqianyino VARCHAR2,  --迁移证号
 lvname VARCHAR2,  --姓　　名
 lvpid VARCHAR2,  --公民身份号码
 lvused_name VARCHAR2,  --曾  用 名
 lvgender VARCHAR2,  --性　　别
 lvnation VARCHAR2,  --民　　族
 lvnative_country VARCHAR2,  --籍贯（国家地区）
 lvnative_place VARCHAR2,  --籍贯（省市县区）
 lvdob DATE,  --出生日期
 lvzhunqianno VARCHAR2,  --准迁证号
 lvremovecity VARCHAR2,  --迁往地省市县区
 lvremoveaddr VARCHAR2,  --迁往地详细地址
 lvapp_pid VARCHAR2,  --申请人公民身份号码
 lvapp_name VARCHAR2,  --申请人姓名
 lvmemo VARCHAR2,  --备　　注
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
   INSERT into tc_webjj.t_remove_declare
    (
      sdono,   --办理编号
      master_name,   --户主姓名
      master_pid,   --户主身份证号
      master_relation,   --与户主关系
      newrelation,   --与持证人关系
      app_type,   --变更类型
      out_category,   --迁移原因
      qianyino,   --迁移证号
      name,   --姓　　名
      pid,   --公民身份号码
      used_name,   --曾  用 名
      gender,   --性　　别
      nation,   --民　　族
      native_country,   --籍贯（国家地区）
      native_place,   --籍贯（省市县区）
      dob,   --出生日期
      zhunqianno,   --准迁证号
      removecity,   --迁往地省市县区
      removeaddr,   --迁往地详细地址
      app_pid,   --申请人公民身份号码
      app_name,   --申请人姓名
      memo    --备　　注
    )values(
      lvsdono,   --办理编号
      lvmaster_name,   --户主姓名
      lvmaster_pid,   --户主身份证号
      lvmaster_relation,   --与户主关系
      lvnewrelation,   --与持证人关系
      lvapp_type,   --变更类型
      lvout_category,   --迁移原因
      lvqianyino,   --迁移证号
      lvname,   --姓　　名
      lvpid,   --公民身份号码
      lvused_name,   --曾  用 名
      lvgender,   --性　　别
      lvnation,   --民　　族
      lvnative_country,   --籍贯（国家地区）
      lvnative_place,   --籍贯（省市县区）
      lvdob,   --出生日期
      lvzhunqianno,   --准迁证号
      lvremovecity,   --迁往地省市县区
      lvremoveaddr,   --迁往地详细地址
      lvapp_pid,   --申请人公民身份号码
      lvapp_name,   --申请人姓名
      lvmemo    --备　　注
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_remove_declare
    Set
      sdono=lvsdono,   --办理编号
      master_name=lvmaster_name,   --户主姓名
      master_pid=lvmaster_pid,   --户主身份证号
      master_relation=lvmaster_relation,   --与户主关系
      newrelation=lvnewrelation,   --与持证人关系
      app_type=lvapp_type,   --变更类型
      out_category=lvout_category,   --迁移原因
      qianyino=lvqianyino,   --迁移证号
      name=lvname,   --姓　　名
      pid=lvpid,   --公民身份号码
      used_name=lvused_name,   --曾  用 名
      gender=lvgender,   --性　　别
      nation=lvnation,   --民　　族
      native_country=lvnative_country,   --籍贯（国家地区）
      native_place=lvnative_place,   --籍贯（省市县区）
      dob=lvdob,   --出生日期
      zhunqianno=lvzhunqianno,   --准迁证号
      removecity=lvremovecity,   --迁往地省市县区
      removeaddr=lvremoveaddr,   --迁往地详细地址
      app_pid=lvapp_pid,   --申请人公民身份号码
      app_name=lvapp_name,   --申请人姓名
      memo=lvmemo    --备　　注
    Where 1=1
    and sdono=lvsdono   --变更类型
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_remove_declare
    Set
      sdono=lvsdono,   --办理编号
      master_name=lvmaster_name,   --户主姓名
      master_pid=lvmaster_pid,   --户主身份证号
      master_relation=lvmaster_relation,   --与户主关系
      newrelation=lvnewrelation,   --与持证人关系
      app_type=lvapp_type,   --变更类型
      out_category=lvout_category,   --迁移原因
      qianyino=lvqianyino,   --迁移证号
      name=lvname,   --姓　　名
      pid=lvpid,   --公民身份号码
      used_name=lvused_name,   --曾  用 名
      gender=lvgender,   --性　　别
      nation=lvnation,   --民　　族
      native_country=lvnative_country,   --籍贯（国家地区）
      native_place=lvnative_place,   --籍贯（省市县区）
      dob=lvdob,   --出生日期
      zhunqianno=lvzhunqianno,   --准迁证号
      removecity=lvremovecity,   --迁往地省市县区
      removeaddr=lvremoveaddr,   --迁往地详细地址
      app_pid=lvapp_pid,   --申请人公民身份号码
      app_name=lvapp_name,   --申请人姓名
      memo=lvmemo    --备　　注
    Where 1=1
    and  sdono=lvsdono   --变更类型
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_remove_declare
    Where 1=1
    and sdono=lvsdono   --变更类型
    ;
END IF;
 Commit;
END; /*存储过程结束*/

