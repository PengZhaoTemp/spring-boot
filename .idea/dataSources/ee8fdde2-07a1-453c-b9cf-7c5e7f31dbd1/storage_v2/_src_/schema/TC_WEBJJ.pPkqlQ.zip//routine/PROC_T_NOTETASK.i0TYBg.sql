create PROCEDURE          PROC_t_notetask   /*T_NOTETASK*/
(
 lvsno IN OUT VARCHAR2,
 lvsnote VARCHAR2,
 lvstel VARCHAR2,
 lvssendflag VARCHAR2,
 lv_ProcMode Varchar2
)
AS
  lvno VARCHAR2(36);
BEGIN
  --begin TRAN
    if (lvsnote is null or lvsnote = '') or (lvstel is null or lvstel = '') then  
        return;
    elsif lv_procMode='PMINSERT' THEN   
        select 'W'||TC_WEBJJ.SEQ_T_NOTETASK_NNO.Nextval into lvsno from dual;
        INSERT into TC_WEBJJ.t_notetask
        (
          sno,  
          snote,  
          dsenddate,   
          stel,   
          ssendflag

        )values(
          lvsno,   
          lvsnote,   
          SYSDATE,   
          lvstel,   
          lvssendflag
        );
    END IF;

 Commit;
END;
/

