create function get_dobus_jklist(
lv_sbusno varchar2,
lv_sdono  varchar2
) return number is
  lv_result number;
begin
 
  if '1201'=lv_sbusno then--警情查询  
      select count(*) into lv_result from TC_WEBJJ.T_FZ_JQCZ where sdono=lv_sdono  ;
  end if;
  
    if '1202'=lv_sbusno then--案件查询
        select decode(count(*),0,0,1,sum(tc_webjj.get_dobus_jkdbsj(dbbj,dbsj))) into  lv_result from TC_WEBJJ.T_FZ_ajsl where sdono=lv_sdono  ;
      end if; 
  if '1205'=lv_sbusno then--投诉查询
    select decode(count(*),0,0,1,sum(tc_webjj.get_dobus_jkdbsj(dbbj,dbsj))) into lv_result from TC_WEBJJ.T_FZ_tscx where sdono=lv_sdono  ;
   end if;
    
    if '01a2'=lv_sbusno then--非规范汉字
      select decode(count(*),0,0,1,sum(tc_webjj.get_dobus_jkdbsj(dbbj,dbsj))) into lv_result from TC_WEBJJ.T_HZ_XSYRQMCMCX where sdono=lv_sdono  ;
    end if;
    
   if '01a3'=lv_sbusno then--非规范汉字
   --TC_WEBJJ.T_ZA_FGFHZCX
    select decode(count(*),0,0,1,sum(tc_webjj.get_dobus_jkdbsj(dbbj,dbsj))) into lv_result from tc_webjj.t_hz_xmfgfhzcx where sdono=lv_sdono  ;  
   end if;
    
   if '03a6'=lv_sbusno then--报废车辆查询
     select decode(count(*),0,0,1,sum(tc_webjj.get_dobus_jkdbsj(dbbj,dbsj))) into lv_result from TC_WEBJJ.T_CLBF_SELECT where sdono=lv_sdono  ;  
   end if;
   if '03a4'=lv_sbusno then--机动车违法查询
      select decode(count(*),0,0,1,sum(tc_webjj.get_dobus_jkdbsj(dbbj,dbsj))) into lv_result from TC_WEBJJ.T_JDCWF_SELECT where sdono=lv_sdono  ;
    end if;
   if '03a5'=lv_sbusno then--驾驶证记分查询
       select decode(count(*),0,0,1,sum(tc_webjj.get_dobus_jkdbsj(dbbj,dbsj))) into lv_result from TC_WEBJJ.T_JDCJF_SELECT where sdono=lv_sdono  ;
   end if; 
  if '01a4'=lv_sbusno then--身份证办理进度查询
      select decode(count(*),0,0,1,sum(tc_webjj.get_dobus_jkdbsj(dbbj,dbsj))) into lv_result from TC_WEBJJ.T_HZ_SFZBLJDCX where sdono=lv_sdono  ;
  end if; 
 /* if '01a2'=lv_sbusno then--新生婴儿起名重名查询
   select decode(count(*),0,0,1,sum(tc_webjj.get_dobus_jkdbsj(dbbj,dbsj))) into lv_result from TC_WEBJJ.T_HZ_CMCX where sdono=lv_sdono  ;
  end if; */
  if '01F1'=lv_sbusno then--重名查询
     select decode(count(*),0,0,1,sum(tc_webjj.get_dobus_jkdbsj(dbbj,dbsj))) into lv_result from TC_WEBJJ.T_HZ_CMCX where sdono=lv_sdono  ;
  end if; 
  if '0228'=lv_sbusno then--居住证办理进度查询
     select decode(count(*),0,0,1,sum(tc_webjj.get_dobus_jkdbsj(dbbj,dbsj))) into lv_result from TC_WEBJJ.T_ZA_JZZBLJDCX where sdono=lv_sdono  ;
  end if; 
  if '0216'=lv_sbusno then--防伪印章真伪查询
     select decode(count(*),0,0,1,sum(tc_webjj.get_dobus_jkdbsj(dbbj,dbsj))) into lv_result from TC_WEBJJ.T_ZA_FWYZZWCY where sdono=lv_sdono  ;
  end if;
 if '1017'=lv_sbusno then--制证进度查询
    select decode(count(*),0,0,1,sum(tc_webjj.get_dobus_jkdbsj(dbbj,dbsj))) into lv_result from TC_WEBJJ.T_CRJ_ZZJDCX where sdono=lv_sdono  ;
 end if;
  return lv_result;
end;
/

