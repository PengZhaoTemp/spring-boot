create procedure          proc_t_busType  --业务类型
(
  lv_sbusno  varchar2,  --业务编码
  lv_sbsort  varchar2,  --业务大类名
  lv_sssort  varchar2,  --业务小类名
  lv_sdobus  varchar2,  --业务操作
  lv_sdobooking  varchar2,  --只预约办理
  lv_nchstandard  varchar2,  --办理资费标准
  lv_nbocharge  varchar2,  --预约办理资费标准
  lv_sbusintro  varchar2,  --业务介绍
  lv_sstatus  varchar2,  --状态(开通，关闭)
  --lv_dokdate  varchar2,  --开通时间
  lv_surl  varchar2,  --申报URL
  lv_sretype  varchar2,  -- 是否必须回寄
  lv_sexp     varchar2,  --寄送材料说明
  lv_sreexp   varchar2,  --回寄材料说明
  lv_procmode  varchar2  --
)
as
lv_date date := sysdate;
begin
  if lv_sstatus = '关闭' then
    lv_date := '';
  elsif /*lv_sstatus = '' or*/ lv_sstatus is null then
    lv_date := '';
  end if;
  if lv_procmode = 'PMINSERT' then
    insert into tc_webjj.t_bus_deploy
    ( sbusno,
      sbsort,
      sssort,
      sdobus,
      sdobooking,
      nchstandard,
      nbocharge,
      sbusintro,
      sstatus,
      dokdate,
      surl,
      sretype,
      sexp,
      sreexp
   )values (lv_sbusno,
      lv_sbsort,
      lv_sssort,
      lv_sdobus,
      lv_sdobooking,
      lv_nchstandard,
      lv_nbocharge,
      utl_raw.cast_to_raw(lv_sbusintro),
      lv_sstatus,
      lv_date,
      lv_surl,
      lv_sretype,
      lv_sexp,
      lv_sreexp
   );
  elsif lv_procmode = 'PMUPDATE' then
    update tc_webjj.t_bus_deploy set
      sbsort = lv_sbsort,
      sssort = lv_sssort,
      sdobus = lv_sdobus,
      sdobooking = lv_sdobooking,
      nchstandard = lv_nchstandard,
      nbocharge = lv_nbocharge,
      sbusintro = sys.utl_raw.cast_to_raw(lv_sbusintro),
      sstatus = lv_sstatus,
      dokdate = lv_date,
      surl = lv_surl,
      sretype = lv_sretype,
      sexp = lv_sexp,
      sreexp = lv_sreexp
      where sbusno = lv_sbusno;
  elsif lv_procmode = 'PMDELETE' then
    delete tc_webjj.t_bus_deploy where sbusno = lv_sbusno;
  end if;
end;

/

