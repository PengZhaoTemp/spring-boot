create procedure          proc_hd_online_talk(
lv_sid in out varchar2,
lv_SONLINE_IVID varchar2,
lv_SNLINE_IVUSER_ID varchar2,
lv_SDETAIL varchar2,
lv_msg_return   in out varchar2
) as
begin
  select tc_webjj.SEQ_HD_ONLINE_TALK.nextval into lv_sid from dual;
  insert into T_HD_ONLINE_TALK(
  SID,
  SONLINE_IVID,
  SNLINE_IVUSER_ID,
  DINDATE,
  SDETAIL
  )values(
  lv_SID,
  lv_SONLINE_IVID,
  lv_SNLINE_IVUSER_ID,
  sysdate,
  lv_SDETAIL
  );
  lv_msg_return := '操作成功';
  commit;
end proc_hd_online_talk;

/

