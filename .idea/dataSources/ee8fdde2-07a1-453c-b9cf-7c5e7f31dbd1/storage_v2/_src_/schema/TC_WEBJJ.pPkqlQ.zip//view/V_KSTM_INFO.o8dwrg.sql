create view V_KSTM_INFO as
  select tmno,
         ('' || substr(tmtitle, 0, 15) || '') tmtitle,
         substr(sjtitle, 0, 15) sjtitle,
         decode(tmtype, '0', '单选', '1', '多选', '2', '简答题') tmtype,
         tmgrade,
         to_char(tmdate, 'yyyy-MM-dd hh24:mi:ss') tmdate01,
         tmdate,
         decode(tmstate, '0', '未开通', '1', '开通') tmstate,
         a.sjno
    from tc_webjj.zxzj_kstm a, tc_webjj.zxzj_kslx b
   where 1 = 1
     and a.sjno = b.sjno
/

