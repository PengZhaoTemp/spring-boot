create procedure          t_rentcar_check_second
(
   lvpid VARCHAR2,        --号牌号码
   lvname VARCHAR2,        -- 车辆识别代号CAR_SBDM
   lvphone VARCHAR2,      --承租人电话
   lvcarnumber VARCHAR2,  --车牌号码,不使用
   lvinputid VARCHAR2--登记人ID

)
as

begin
    insert into tc_webjj.t_rentcar_check
    (
    SID,PID,NAME,TEL,
    CARNO,REGDATE,REGERID,RESULT,
    CCIC,
    SDONO,
    CAR_SBDM,
    DBSJ,DBBJ
    )values
   (
   tc_weixin.fun_get16code(tc_webjj.SEQ_RENTCAR_CHECK_SID.nextval,'350201',2),
   lvinputid,
   'not use',
   lvphone,
   lvpid,
   sysdate,
   lvinputid,
   NULL,
   NULL,
   tc_weixin.fun_get16code(tc_weixin.seq_weixin_dobus_sdono.nextval,'350201',2),
   lvname,
   sysdate,
   '0'
   -- '100','234','test','1','234',sysdate,0
   );
end t_rentcar_check_second;

/

