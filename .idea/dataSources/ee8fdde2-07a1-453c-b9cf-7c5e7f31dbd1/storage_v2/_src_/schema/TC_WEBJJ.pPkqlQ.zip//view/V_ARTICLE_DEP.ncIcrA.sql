create view V_ARTICLE_DEP as
  select a."SID",a."LCATEGORY",a."TITLE",a."HOMEPHOTO",a."EDITOR",a."DDATE",a."CONTENT",a."DEPID",a."DBBJ",a."DBSJ" ,b.de_name,b.top_pic,b.job_content,b.tonggao  from tc_webjj.t_article_dep a ,tc_webjj.t_department b where a.depid=b.nid
/

