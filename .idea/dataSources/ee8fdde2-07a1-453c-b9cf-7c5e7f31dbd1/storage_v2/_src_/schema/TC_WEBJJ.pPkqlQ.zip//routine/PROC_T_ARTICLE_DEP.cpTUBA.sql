create PROCEDURE          PROC_t_article_dep   /*T_ARTICLE_DeP*/
(
 lvsid IN OUT VARCHAR2,  --编　　号
 lvlcategory VARCHAR2,  --所属栏目
 lvtitle VARCHAR2,  --标　　题
 lvhomephoto VARCHAR2,  --图片展示
 lveditor VARCHAR2,  --作　　者
 lvddate DATE,  --发布时间
 lvcontent BLOB,  --内　　容
 lvdepid VARCHAR2,  --所属部门编号
 lvdbbj VARCHAR2,  --dbbj
 lvdbsj DATE,  --dbsj
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
    Select to_char(TC_WEBJJ.SEQ_T_ARTICLE_DEP_SID.Nextval)  into lvsid From dual;    /*编　　号序列*/
   INSERT into tc_webjj.t_article_dep
    (
      sid,   --编　　号
      lcategory,   --所属栏目
      title,   --标　　题
      homephoto,   --图片展示
      editor,   --作　　者
      ddate,   --发布时间
      content,   --内　　容
      depid,   --所属部门编号
      dbbj,   --dbbj
      dbsj    --dbsj
    )values(
      lvsid,   --编　　号
      lvlcategory,   --所属栏目
      lvtitle,   --标　　题
      lvhomephoto,   --图片展示
      lveditor,   --作　　者
      lvddate,   --发布时间
      lvcontent,   --内　　容
      lvdepid,   --所属部门编号
      lvdbbj,   --dbbj
      lvdbsj    --dbsj
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_article_dep
    Set
      sid=lvsid,   --编　　号
      lcategory=lvlcategory,   --所属栏目
      title=lvtitle,   --标　　题
      homephoto=lvhomephoto,   --图片展示
      editor=lveditor,   --作　　者
      ddate=lvddate,   --发布时间
      content=lvcontent,   --内　　容
      depid=lvdepid,   --所属部门编号
      dbbj=lvdbbj,   --dbbj
      dbsj=lvdbsj    --dbsj
    Where 1=1
    and sid=lvsid   --编　　号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_article_dep
    Set
      sid=lvsid,   --编　　号
      lcategory=lvlcategory,   --所属栏目
      title=lvtitle,   --标　　题
      homephoto=lvhomephoto,   --图片展示
      editor=lveditor,   --作　　者
      ddate=lvddate,   --发布时间
      content=lvcontent,   --内　　容
      depid=lvdepid,   --所属部门编号
      dbbj=lvdbbj,   --dbbj
      dbsj=lvdbsj    --dbsj
    Where 1=1
    and sid=lvsid   --编　　号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_article_dep
    Where 1=1
    and sid=lvsid   --编　　号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

