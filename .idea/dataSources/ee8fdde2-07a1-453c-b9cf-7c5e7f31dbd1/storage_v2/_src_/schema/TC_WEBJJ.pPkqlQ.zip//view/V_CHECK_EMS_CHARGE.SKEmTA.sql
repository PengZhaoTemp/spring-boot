create view V_CHECK_EMS_CHARGE as
  select c.cou, d.sdetail_addr,d.sshort_name,(c.cou*20) as zncharge
  from tc_jcyw.t_org d,
       (select count(*) as cou, t.sdounitno
          from tc_webjj.t_dobus t, tc_webjj.t_chargecenter b
         where t.sdono = b.sdono
           and t.nrecharge <> 0
           and t.nrecharge is not null
         group by sdounitno) c
 where c.sdounitno = d.sunit_code
 order by c.cou desc
/

