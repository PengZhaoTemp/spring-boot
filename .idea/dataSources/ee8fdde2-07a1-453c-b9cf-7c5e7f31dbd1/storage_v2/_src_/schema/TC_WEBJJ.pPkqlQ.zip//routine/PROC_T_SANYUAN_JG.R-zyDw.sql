create PROCEDURE          PROC_t_sanyuan_jg /*T_SANYUAN_JG*/
(lvsno          IN OUT VARCHAR2, --编　　号
 lvstm_type     VARCHAR2, --题目类型0单选1多选2是非
 lvstm_shuliang VARCHAR2, --该类型题目数量
 lvstm_rytype   VARCHAR2, --人员分类（1安全员爆破员2 仓库管理员）
 lvsxg_id       VARCHAR2, --修改人id
 lvsxg_time     DATE, --修改时间
 lvstm_fenshu   VARCHAR2, --题目分数
 lvsjdl_no      VARCHAR2,
 lv_ProcMode    Varchar2 /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/) AS
BEGIN
  --begin TRAN
  IF lv_procMode = 'PMINSERT' THEN
    /*登记*/
    Select tc_webjj.SEQ_T_SANYUAN_JG_SNO.Nextval into lvsno From dual; /*编　　号序列*/
    INSERT into tc_webjj.t_sanyuan_jg
      (sno, --编　　号
       stm_type, --题目类型0单选1多选2是非
       stm_shuliang, --该类型题目数量
       stm_rytype, --人员分类（1安全员爆破员2 仓库管理员）
       sxg_id, --修改人id
       sxg_time, --修改时间
       stm_fenshu, --题目分数
       sjdl_no
       )
    values
      (lvsno, --编　　号
       lvstm_type, --题目类型0单选1多选2是非
       lvstm_shuliang, --该类型题目数量
       lvstm_rytype, --人员分类（1安全员爆破员2 仓库管理员）
       lvsxg_id, --修改人id
       sysdate, --修改时间
       lvstm_fenshu, --题目分数
       lvsjdl_no
       );
    -- 返回值
  END IF;
  IF lv_procMode = 'PMUPDATE' THEN
    /*更新*/
    UPDATE tc_webjj.t_sanyuan_jg
       Set sno          = lvsno, --编　　号
           stm_type     = lvstm_type, --题目类型0单选1多选2是非
           stm_shuliang = lvstm_shuliang, --该类型题目数量
           stm_rytype   = lvstm_rytype, --人员分类（1安全员爆破员2 仓库管理员）
           sxg_id       = lvsxg_id, --修改人id
           sxg_time     = sysdate, --修改时间
           stm_fenshu   = lvstm_fenshu, --题目分数
           sjdl_no      = lvsjdl_no
     Where 1 = 1
       and sno = lvsno --编　　号
    ;
    /*添加变更记录*/
    INSERT into tc_webjj.t_sanyuan_jg_alter
      select sno, --编　　号
             stm_type, --题目类型0单选1多选2是非
             stm_shuliang, --该类型题目数量
             stm_rytype, --人员分类（1安全员爆破员2 仓库管理员）
             sxg_id, --修改人id
             sxg_time, --修改时间
             stm_fenshu, --题目分数
             SYSDATE,
             sjdl_no
        from tc_webjj.t_sanyuan_jg
       where sno = lvsno;

  END IF;
  IF lv_procMode = 'PMCANCEL' THEN
    /*注销*/
    UPDATE tc_webjj.t_sanyuan_jg
       Set sno          = lvsno, --编　　号
           stm_type     = lvstm_type, --题目类型0单选1多选2是非
           stm_shuliang = lvstm_shuliang, --该类型题目数量
           stm_rytype   = lvstm_rytype, --人员分类（1安全员爆破员2 仓库管理员）
           sxg_id       = lvsxg_id, --修改人id
           sxg_time     = sysdate, --修改时间
           stm_fenshu   = lvstm_fenshu, --题目分数
           sjdl_no      = lvsjdl_no
     Where 1 = 1
       and sno = lvsno --编　　号
    ;
    INSERT into tc_webjj.t_sanyuan_jg_alter
      select sno, --编　　号
             stm_type, --题目类型0单选1多选2是非
             stm_shuliang, --该类型题目数量
             stm_rytype, --人员分类（1安全员爆破员2 仓库管理员）
             sxg_id, --修改人id
             sxg_time, --修改时间
             stm_fenshu, --题目分数
             SYSDATE,
             sjdl_no
        from tc_webjj.t_sanyuan_jg
       where sno = lvsno;
  END IF;
  IF lv_procMode = 'PMDELETE' THEN
    /*删除*/
    DElETE FROM tc_webjj.t_sanyuan_jg
     Where 1 = 1
       and sno = lvsno --编　　号
    ;
  END IF;
  Commit;
END; /*存储过程结束*/

