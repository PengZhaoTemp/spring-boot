create PROCEDURE          proc_card_table_alert   /*proc_card_table*/

AS
  CURSOR a IS SELECT * FROM tc_webjj.t_card_table t WHERE 1=1 AND (t.fs_flag='0' OR t.fs_flag  IS NULL);
  lv_date  DATE;
  lv_qx    NUMBER;

BEGIN
  --begin TRAN
  SELECT to_date(to_char(SYSDATE,'yyyy-mm-dd'),'yyyy-mm-dd') INTO lv_date FROM dual;

  FOR r IN a LOOP
      lv_qx:=lv_date-r.qf_yxqx;
      IF lv_qx<=3 THEN
          INSERT INTO tc_webjj.t_notemobile
         (
                snoteno   ,
                sdono     ,
                suserno   ,
                snote     ,
                dsenddate ,
                stel      ,
                dbbj      ,
                dbsj      ,
                sreadflag
         )VALUES(
                tc_webjj.fun_get16code_pz(tc_webjj.SEQ_t_notemobile_SNOTENO.nextval),
                '',
                r.suserno,
                '您的'||decode(r.zj_type,'0','行驶证','1','驾驶证','2','护照','证件')||'即将过期',
                SYSDATE,
                '',
                '0',
                SYSDATE,
                '0'
         );
      END IF;
      UPDATE tc_webjj.t_card_table SET fs_flag='1' WHERE nid=r.nid;
      COMMIT;
  END LOOP;
END ;

/

