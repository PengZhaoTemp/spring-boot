create view V_BUSFLOW_DEPLOY as
  SELECT SFLOWNO,
      a.SBUSNO,
       SFLOWTAXIS,
       SFLOWNAME,
       SFLOWTYPE,
       decode(SFLOWTYPE,'1','正常流程','2','判断流程','3','审批流程') SFLOWTYPECN,
       SREMARK,
       a.sbusstatuscode,
       SOPERATIONNO,
      a.SNOTENO,
       SNEXTTAXIS,
       SJUDGETABLE,
       SJUDGEFIELD,
       SFLOWSTATUS,
       decode(SFLOWSTATUS,'0','已注销','1','有效') SFLOWSTATUSCN,
       b.sbusname,
       b.sbustypename,
       c.sbusstatusname,
       d.snotemsg,
       a.sshowtype
  FROM TC_WEBJJ.T_BUSFLOW_DEPLOY a
  ,tc_webjj.t_bus_deploy b
  ,tc_webjj.t_busstatus_deploy c,
  tc_webjj.t_note_deploy d
  WHERE a.sbusno = b.sbusno
  AND a.sbusstatuscode = c.sbusstatuscode(+)
  AND a.snoteno=d.snoteno(+)
/

