create function          fun_bg_content
(
       lvsodno varchar2
)
 return varchar2 is
  bg_content varchar2(1000);
  bg_time    varchar2(100);
  bg_xm      varchar2(100);
  bgq_content varchar2(1000);
  bgh_content varchar2(1000);
begin
     select to_char(sysdate,'yyyy-mm-dd') into bg_time from dual ;
     select sxg_xm into bg_xm from tc_webjj.t_sanyuan_change_info where sdono=lvsodno ;
     select sxgq_content into bgq_content from tc_webjj.t_sanyuan_change_info where sdono=lvsodno;
     select sxgh_content into bgh_content from tc_webjj.t_sanyuan_change_info where sdono=lvsodno;
     IF bg_xm='sname' THEN
       bg_xm:='姓名';
     END IF;
     IF bg_xm='sbk_unit' THEN
       bg_xm:='所在单位';
     END IF;
     bg_content:=bg_time||bg_xm||'由'||bgq_content||'改为'||bgh_content;
  return(bg_content);
end fun_bg_content;

/

