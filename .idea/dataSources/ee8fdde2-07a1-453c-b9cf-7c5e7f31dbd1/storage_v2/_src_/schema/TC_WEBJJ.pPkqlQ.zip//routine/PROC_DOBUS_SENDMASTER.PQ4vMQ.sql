create procedure proc_dobus_sendmaster(
       lvsdono varchar2,
       lvsoperationno varchar2,
       lvsexpno       varchar2,
       lvsuserno           varchar2,--用户编号
       lvsusername         varchar2,--用户姓名
       lvsorgid            varchar2,--操作单位代码（群众的时候不需要操作单位）
       lvsorgname          varchar2--操作单位名称（群众的时候不需要操作单位）
) is
lvdobus tc_webjj.t_dobus%rowtype;
lvslogno varchar2(16);
lvsoperationname varchar2(16);
lvsusertype varchar2(1);
lvsresult varchar2(500);
begin
   lvsresult := '亲，您的材料已寄出，快递单号：'||lvsexpno;
   --sendflowno   04 将邮政支付信息推送给实有人口
   update tc_webjj.t_dobus s set sexpno = lvsexpno,s.scontext=lvsresult,sendflowno='04' where sdono = lvsdono;
   --增加一条寄送信息
   select * into lvdobus from tc_webjj.t_dobus where sdono = lvsdono;
   INSERT into tc_webjj.t_expressinterface
    (
      sexpno,   --快递单号
      sexpaddress,   --收件地址
      spostcode,   --邮政编码
      sconsignee,   --收  件 人
      stel,   --电　　话
      scarrier,   --快  递 员
      nexpcharge,   --快  递 费
      sexpcourse,   --物流描述
      suserno,    --用户编号
      sdono,
      dbbj,
      dbsj,
      SEXPTYPE,
      sno
    )values(
      lvsexpno,   --快递单号
      lvdobus.sexpaddress,   --收件地址
      lvdobus.sexppostcode,   --邮政编码
      lvdobus.sconsignee,   --收  件 人
      lvdobus.scontel,   --电　　话
      '',   --快  递 员
      null,   --快  递 费
      '',   --物流描述
      lvdobus.suserno,    --用户编号
      lvsdono,
      '0',
      sysdate,
      '1',
      'W'||lvsdono
    );
    --日志 

    select a.sname,a.stype into lvsoperationname,lvsusertype from tc_webjj.t_operation_deploy a where a.sno=lvsoperationno;
    proc_dobus_log_info(
      lvslogno,
      lvdobus.splanno,
      lvsoperationno,
      lvsoperationname,
      lvsdono,
      lvsusertype,
      lvsuserno,
      lvsusername,
      lvsorgid,
      lvsorgname,
      lvsresult
    );
    proc_dobus_nextflow(lvsdono);
    commit;
end proc_dobus_sendmaster;
/

