create PROCEDURE          PROC_t_xzfy_sq   /*T_XZFY_SQ*/
(
 lvsdono IN OUT VARCHAR2,  --办理编号
 lvs_cf_unit VARCHAR2,  --处罚单位/被申请人
 lvs_cf_sdtime DATE,  --处罚决定书送达时间
 lvs_cf_bh VARCHAR2,  --处罚决定书编号
 lvs_cf_jl varchar2,
 lvs_cf_fk varchar2,
 lvs_cf_content VARCHAR2,  --处罚内容
 lvs_sq_name VARCHAR2,  --委托人姓名
 lvs_sq_pid VARCHAR2,  --委托人身份证
 lvs_relation VARCHAR2,  --与被处罚人关系
 lvstel VARCHAR2,  --联系电话/委托人联系电话
 lvs_yjdz VARCHAR2,  --邮寄地址
 lvs_cxsq VARCHAR2,  --撤销申请标记0/1/2/3
 lvs_cx_reason VARCHAR2,  --撤销原因
 lvs_result VARCHAR2,  --决议结果
 lvs_name VARCHAR2,  --申  请 人
 lvs_sex VARCHAR2,  --性　　别
 lvs_birth DATE,  --出生日期
 lvs_pid VARCHAR2,  --身份证号码
 lvs_unit VARCHAR2,  --工作单位
 lvs_address VARCHAR2,  --住　　所
 lvs_postcode VARCHAR2,  --邮政编码
 lvs_tel VARCHAR2,  --电　　话
 lvs_unit_name VARCHAR2,  --组织名称
 lvs_unit_address VARCHAR2,  --住　　所
 lvs_unit_code VARCHAR2,  --邮政编码
 lvs_unit_tel VARCHAR2,  --电　　话
 lvs_unit_dbr VARCHAR2,  --法定代表/主要负责人
 lvs_unit_zw VARCHAR2,  --职　　务
 lvs_xzfy_qq VARCHAR2,  --行政复议请求
 lvs_reason VARCHAR2,  --事实和理由
 lvs_xzfy_unit VARCHAR2,  --s_xzfy_unit
 lvs_xzfy_type varchar2,
 lvs_xzfy_jtxw varchar2,
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS

BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/



   INSERT into tc_webjj.t_xzfy_sq
    (
      sdono,   --办理编号
      s_cf_unit,   --处罚单位/被申请人
      s_cf_sdtime,   --处罚决定书送达时间
      s_cf_bh,   --处罚决定书编号
      s_cf_jl,
      s_cf_fk,
      s_cf_content,   --处罚内容
      s_sq_name,   --委托人姓名
      s_sq_pid,   --委托人身份证
      s_relation,   --与被处罚人关系
      stel,   --联系电话/委托人联系电话
      s_yjdz,   --邮寄地址
      s_cxsq,   --撤销申请标记
      s_cx_reason,   --撤销原因
      s_result,   --决议结果
      s_name,   --申  请 人
      s_sex,   --性　　别
      s_birth,   --出生日期
      s_pid,   --身份证号码
      s_unit,   --工作单位
      s_address,   --住　　所
      s_postcode,   --邮政编码
      s_tel,   --电　　话
      s_unit_name,   --组织名称
      s_unit_address,   --住　　所
      s_unit_code,   --邮政编码
      s_unit_tel,   --电　　话
      s_unit_dbr,   --法定代表/主要负责人
      s_unit_zw,   --职　　务
      s_xzfy_qq,   --行政复议请求
      s_reason,   --事实和理由
      s_xzfy_unit,    --s_xzfy_unit
      xzfy_type,
      xzfy_jtxw
    )values(
      lvsdono,   --办理编号
      lvs_cf_unit,   --处罚单位/被申请人
      lvs_cf_sdtime,   --处罚决定书送达时间
      lvs_cf_bh,   --处罚决定书编号
      lvs_cf_jl,
      lvs_cf_fk,
      lvs_cf_content,   --处罚内容
      lvs_sq_name,   --委托人姓名
      lvs_sq_pid,   --委托人身份证
      lvs_relation,   --与被处罚人关系
      lvstel,   --联系电话/委托人联系电话
      lvs_yjdz,   --邮寄地址
      '0',   --撤销申请标记0/1
      lvs_cx_reason,   --撤销原因
      lvs_result,   --决议结果
      lvs_name,   --申  请 人
      lvs_sex,   --性　　别
      lvs_birth,   --出生日期
      lvs_pid,   --身份证号码
      lvs_unit,   --工作单位
      lvs_address,   --住　　所
      lvs_postcode,   --邮政编码
      lvs_tel,   --电　　话
      lvs_unit_name,   --组织名称
      lvs_unit_address,   --住　　所
      lvs_unit_code,   --邮政编码
      lvs_unit_tel,   --电　　话
      lvs_unit_dbr,   --法定代表/主要负责人
      lvs_unit_zw,   --职　　务
      lvs_xzfy_qq,   --行政复议请求
      lvs_reason,   --事实和理由

      lvs_xzfy_unit,    --s_xzfy_unit
      lvs_xzfy_type,
      lvs_xzfy_jtxw

    );
   -- 返回值

END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_xzfy_sq
    Set
      sdono=lvsdono,   --办理编号
      s_cf_unit=lvs_cf_unit,   --处罚单位/被申请人
      s_cf_sdtime=lvs_cf_sdtime,   --处罚决定书送达时间
      s_cf_bh=lvs_cf_bh,   --处罚决定书编号
      s_cf_jl=lvs_cf_jl,
      s_cf_fk=lvs_cf_fk,
      s_cf_content=lvs_cf_content,   --处罚内容
      s_sq_name=lvs_sq_name,   --委托人姓名
      s_sq_pid=lvs_sq_pid,   --委托人身份证
      s_relation=lvs_relation,   --与被处罚人关系
      stel=lvstel,   --联系电话/委托人联系电话
      s_yjdz=lvs_yjdz,   --邮寄地址
      s_cxsq=lvs_cxsq,   --撤销申请标记0/1
      s_cx_reason=lvs_cx_reason,   --撤销原因
      s_result=lvs_result,   --决议结果
      s_name=lvs_name,   --申  请 人
      s_sex=lvs_sex,   --性　　别
      s_birth=lvs_birth,   --出生日期
      s_pid=lvs_pid,   --身份证号码
      s_unit=lvs_unit,   --工作单位
      s_address=lvs_address,   --住　　所
      s_postcode=lvs_postcode,   --邮政编码
      s_tel=lvs_tel,   --电　　话
      s_unit_name=lvs_unit_name,   --组织名称
      s_unit_address=lvs_unit_address,   --住　　所
      s_unit_code=lvs_unit_code,   --邮政编码
      s_unit_tel=lvs_unit_tel,   --电　　话
      s_unit_dbr=lvs_unit_dbr,   --法定代表/主要负责人
      s_unit_zw=lvs_unit_zw,   --职　　务
      s_xzfy_qq=lvs_xzfy_qq,   --行政复议请求
      s_reason=lvs_reason,   --事实和理由
      s_xzfy_unit=lvs_xzfy_unit,    --s_xzfy_unit
      xzfy_type=lvs_xzfy_type,
      xzfy_jtxw=lvs_xzfy_jtxw
    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_xzfy_sq
    Set
      sdono=lvsdono,   --办理编号
      s_cf_unit=lvs_cf_unit,   --处罚单位/被申请人
      s_cf_sdtime=lvs_cf_sdtime,   --处罚决定书送达时间
      s_cf_bh=lvs_cf_bh,   --处罚决定书编号
      s_cf_jl=lvs_cf_jl,
      s_cf_fk=lvs_cf_fk,
      s_cf_content=lvs_cf_content,   --处罚内容
      s_sq_name=lvs_sq_name,   --委托人姓名
      s_sq_pid=lvs_sq_pid,   --委托人身份证
      s_relation=lvs_relation,   --与被处罚人关系
      stel=lvstel,   --联系电话/委托人联系电话
      s_yjdz=lvs_yjdz,   --邮寄地址
      s_cxsq=lvs_cxsq,   --撤销申请标记0/1
      s_cx_reason=lvs_cx_reason,   --撤销原因
      s_result=lvs_result,   --决议结果
      s_name=lvs_name,   --申  请 人
      s_sex=lvs_sex,   --性　　别
      s_birth=lvs_birth,   --出生日期
      s_pid=lvs_pid,   --身份证号码
      s_unit=lvs_unit,   --工作单位
      s_address=lvs_address,   --住　　所
      s_postcode=lvs_postcode,   --邮政编码
      s_tel=lvs_tel,   --电　　话
      s_unit_name=lvs_unit_name,   --组织名称
      s_unit_address=lvs_unit_address,   --住　　所
      s_unit_code=lvs_unit_code,   --邮政编码
      s_unit_tel=lvs_unit_tel,   --电　　话
      s_unit_dbr=lvs_unit_dbr,   --法定代表/主要负责人
      s_unit_zw=lvs_unit_zw,   --职　　务
      s_xzfy_qq=lvs_xzfy_qq,   --行政复议请求
      s_reason=lvs_reason,   --事实和理由
      s_xzfy_unit=lvs_xzfy_unit,    --s_xzfy_unit
      xzfy_type=lvs_xzfy_type,
      xzfy_jtxw=lvs_xzfy_jtxw
    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_xzfy_sq
    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

