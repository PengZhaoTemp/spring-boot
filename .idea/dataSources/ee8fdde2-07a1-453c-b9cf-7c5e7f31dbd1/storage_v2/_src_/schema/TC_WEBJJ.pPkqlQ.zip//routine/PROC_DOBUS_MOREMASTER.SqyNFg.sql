create procedure          proc_dobus_moremaster(
       lvsdono varchar2,
       lvsoperationno varchar2,
       lvsplanno       varchar2,
       lvsuserno           varchar2,--用户编号
       lvsusername         varchar2,--用户姓名
       lvsorgid            varchar2,--操作单位代码（群众的时候不需要操作单位）
       lvsorgname          varchar2--操作单位名称（群众的时候不需要操作单位）
) is
lvslogno varchar2(16);
lvsoperationname varchar2(16);
lvsusertype varchar2(1);
lvsresult varchar2(500);
begin
    lvsresult := '已将您补充的材料提交审核。';
    update tc_webjj.t_applymasterdata a set a.sfirstcheck='0',a.sfirstresult='',a.dbbj='0' where sdono=lvsdono and (sfirstcheck='3' OR dbbj='1');
    
    --日志

    select a.sname,a.stype into lvsoperationname,lvsusertype from tc_webjj.t_operation_deploy a where a.sno=lvsoperationno;
    proc_dobus_log_info(
      lvslogno,
      lvsplanno,
      lvsoperationno,
      lvsoperationname,
      lvsdono,
      lvsusertype,
      lvsuserno,
      lvsusername,
      lvsorgid,
      lvsorgname,
      lvsresult
    );
    proc_dobus_nextflow(lvsdono);
    
    update tc_webjj.t_dobus set scontext = lvsresult,dbbj='0' where sdono=lvsdono;
    commit;
end proc_dobus_moremaster;
/

