create procedure proc_dobus_pay(
       lvsdono varchar2,
       lvsoperationno varchar2,
       lvsuserno      varchar2,
       lvsusername    varchar2,
       lvsorgid       varchar2,
       lvsorgname     varchar2,
       lvsplanno      varchar2,
       lvslogreault    varchar2



) is
lvslogno varchar2(16);
lvsoperationname varchar2(16);
lvsusertype varchar2(1);
lvsresult varchar2(500);
begin

  lvsresult := lvslogreault;
  --sendflowno 05 推送工本费给实有人口
  update tc_webjj.t_dobus d  set scontext = lvsresult,sendflowno='05' where sdono = lvsdono;
  proc_dobus_pay_next(lvsdono,'2');

  select a.sname,a.stype into lvsoperationname,lvsusertype from tc_webjj.t_operation_deploy a where a.sno=lvsoperationno;
  --写入操作日志
  proc_dobus_log_info(
      lvslogno,
      lvsplanno,
      lvsoperationno,
      lvsoperationname,
      lvsdono,
      lvsusertype,
      lvsuserno,
      lvsusername,
      lvsorgid,
      lvsorgname,
      lvsresult
  );
  proc_dobus_nextflow(lvsdono);
  commit;
end;

/

