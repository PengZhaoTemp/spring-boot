create PROCEDURE          proc_t_car_stop   /*停车场*/
(
  lvsno           IN OUT VARCHAR2,
  lvsname         VARCHAR2,
  lvnparking      NUMBER,
  lvnfreeparking  NUMBER,
  lvsparkingfee   VARCHAR2,
  lvnlongitude    NUMBER,
  lvnlatitude     NUMBER,
  lvsparkingintro VARCHAR2,
  lvsaddress      VARCHAR2,
  lvsparkingimage VARCHAR2,
  lvspid          VARCHAR2,
  lvglyname       VARCHAR2,
  lv_ProcMode     Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
    Select tc_webjj.SEQ_T_CAR_STOP_SNO.Nextval  into lvsno From dual;    /*新闻编号序列*/
   INSERT into tc_webjj.t_car_stop
    (
  sno          ,
  sname         ,
  nparking      ,
  nfreeparking ,
  sparkingfee   ,
  nlongitude,
  nlatitude     ,
  sparkingintro ,
  saddress,
  sparkingimage ,
  dregdate
    )values(
  lvsno          ,
  lvsname         ,
  lvnparking      ,
  lvnfreeparking ,
  lvsparkingfee   ,
  lvnlongitude,
  lvnlatitude     ,
  lvsparkingintro ,
  lvsaddress,
  lvsparkingimage ,
  sysdate
    );
 INSERT into tc_webjj.t_car_stop_admin
    (
  sno          ,
  spid         ,
  glyname,
  dregdate
  )values(
  lvsno          ,
  lvspid         ,
  lvglyname      ,
   sysdate
    );

   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_car_stop
    Set
   sno=lvsno          ,
  sname=lvsname         ,
  nparking=lvnparking     ,
  nfreeparking=lvnfreeparking ,
  sparkingfee=lvsparkingfee   ,
  nlongitude=lvnlongitude,
  nlatitude=lvnlatitude     ,
  sparkingintro=lvsparkingintro ,
  saddress=lvsaddress,
  sparkingimage=lvsparkingimage ,
  dregdate=sysdate   --是否热点
    Where 1=1
    and sno=lvsno   --新闻编号
    ;
UPDATE tc_webjj.t_car_stop_admin
    Set
   sno=lvsno          ,
  spid=lvspid         ,
  glyname=lvglyname   ,
  dregdate=sysdate   --是否热点
    Where 1=1
    and sno=lvsno   --新闻编号
    ;


END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_car_stop
    Set
      sno=lvsno          ,
  sname=lvsname         ,
  nparking=lvnparking     ,
  nfreeparking=lvnfreeparking ,
  sparkingfee=lvsparkingfee   ,
  nlongitude=lvnlongitude,
  nlatitude=lvnlatitude     ,
  sparkingintro=lvsparkingintro ,
  saddress=lvsaddress,
  sparkingimage=lvsparkingimage ,
  dregdate=sysdate   --是否热点
    Where 1=1
    and sno=lvsno   --新闻编号
    ;
UPDATE tc_webjj.t_car_stop_admin
    Set
      sno=lvsno          ,
  spid=lvspid        ,
  glyname=lvglyname   ,
   dregdate=sysdate   --是否热点
    Where 1=1
    and sno=lvsno   --新闻编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_car_stop
    Where 1=1
    and sno=lvsno   --新闻编号
    ;
   DElETE FROM tc_webjj.t_car_stop_admin
    Where 1=1
    and sno=lvsno   --新闻编号
    ;

END IF;
 Commit;
END; /*存储过程结束*/

