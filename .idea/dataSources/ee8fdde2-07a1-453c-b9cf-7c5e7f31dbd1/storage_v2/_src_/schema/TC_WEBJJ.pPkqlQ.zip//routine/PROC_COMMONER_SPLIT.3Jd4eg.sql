create procedure proc_commoner_split is
  cursor c_base IS
    select personid, name, pid, shome_phone
      from t_commoner
     where when_logged <
           to_date('2019-04-28 00:00:00', 'yyyy-mm-dd hh24:mi:ss')
       and rownum < 100000;
  c_row       c_base%rowtype;
  commoner_id varchar2(48);
begin
  FOR c_row in c_base loop
    select md5(c_row.personid) into commoner_id from dual;
  
    insert into tc_webjj.t_commoner_pid
      (id, pid)
    values
      (commoner_id, c_row.pid);
    insert into tc_webjj.t_commoner_name
      (id, name)
    values
      (commoner_id, c_row.name);
    insert into tc_webjj.t_commoner_phone
      (id, shome_phone)
    values
      (commoner_id, c_row.shome_phone);
  end loop;

  COMMIT;
end proc_commoner_split;
/

