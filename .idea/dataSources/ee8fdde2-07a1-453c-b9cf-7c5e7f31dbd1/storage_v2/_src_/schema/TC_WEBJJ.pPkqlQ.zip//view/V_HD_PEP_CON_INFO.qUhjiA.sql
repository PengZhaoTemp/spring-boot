create view V_HD_PEP_CON_INFO as
  select a.sid,
       a.spep_con_id,
       a.sdetail,
       a.sname,
       a.semail,
       a.stel,
       a.sip,
       decode(a.sexa_status, '', '未审核', '0', '不通过', '1', '通过') sexa_status,
       (select count(0) from tc_webjj.t_hd_pep_con_pj t where t.spep_con_info_id=a.sid and t.smanner='1' ) as support_cnt,
       (select count(0) from tc_webjj.t_hd_pep_con_pj t where t.spep_con_info_id=a.sid and t.smanner='0' ) as opposition_cnt,
       a.dindate
  from tc_webjj.t_hd_pep_con_info a
/

