create PROCEDURE          PROC_t_crj_zxtabledj   /*T_CRJ_ZXTABLEDJ*/
(
 lvsdono IN OUT VARCHAR2,  --业务编号
 lvspid VARCHAR2,  --身份证号码
 lvsnamex VARCHAR2,  --姓
 lvsnamem VARCHAR2,  --名
 lvsex VARCHAR2,  --性　　别
 lvsnamepinx VARCHAR2,  --拼  音 姓
 lvsnamepinm VARCHAR2,  --拼  音 名
 lvsminzu VARCHAR2,  --民　　族
 lvdbirth DATE,  --出生日期
 lvsbirthplace VARCHAR2,  --出  生 地
 lvszzmm VARCHAR2,  --政治面貌
 lvshyzk VARCHAR2,  --婚姻状况
 lvdjhsj DATE,  --结婚时间
 lvsjhdjadr VARCHAR2,  --结婚登记地址
 lvshukouadr VARCHAR2,  --户口所在地
 lvspcs VARCHAR2,  --所属派出所
 lvshomeadr VARCHAR2,  --家庭住址
 lvshometel VARCHAR2,  --联系电话
 lvsunitname VARCHAR2,  --服务处所
 lvszw VARCHAR2,  --职　　务
 lvsunitadr VARCHAR2,  --服务处所地址
 lvsunittel VARCHAR2,  --联系电话
 lvstowhere VARCHAR2,  --前  往 地
 lvssq_type VARCHAR2,  --申请种类
 lvssq_reason VARCHAR2,  --申请事由
 lvsxxrs VARCHAR2,  --偕行子女人数
 lvsgaqs_relation VARCHAR2,  --与申请人关系
 lvsgaqs_name VARCHAR2,  --姓　　名
 lvsgaqs_sex VARCHAR2,  --性　　别
 lvsgaqs_birth DATE,  --出生日期
 lvsgaqs_pid VARCHAR2,  --港澳居民身份证号码
 lvsgawl_txpid VARCHAR2,  --港澳居民来往内地通行证号码
 lvsgadj VARCHAR2,  --何时何地何因在港澳定居
 lvsgalxfs VARCHAR2,  --港澳联络地址及联系电话
 lvsgaqs_relation1 VARCHAR2,  --与申请人关系
 lvsgaqs_name1 VARCHAR2,  --姓　　名
 lvsgaqs_sex1 VARCHAR2,  --性　　别
 lvsgaqs_birth1 DATE,  --出生日期
 lvsgaqs_pid1 VARCHAR2,  --港澳居民身份证号码
 lvsgawl_txpid1 VARCHAR2,  --港澳居民来往内地通行证号码
 lvsgadj1 VARCHAR2,  --何时何地何因在港澳定居
 lvsgalxfs1 VARCHAR2,  --港澳联络地址及联系电话
 lvsjtcy_cw VARCHAR2,  --家庭主要成员称谓
 lvsjtcy_name VARCHAR2,  --姓　　名
 lvsjtcy_pid VARCHAR2,  --身份证号码
 lvsjtcy_unit VARCHAR2,  --服务处所
 lvsjtcy_address VARCHAR2,  --家庭住址
 lvsjtcy_cw1 VARCHAR2,  --家庭主要成员称谓
 lvsjtcy_name1 VARCHAR2,  --姓　　名
 lvsjtcy_pid1 VARCHAR2,  --身份证号码
 lvsjtcy_unit1 VARCHAR2,  --服务处所
 lvsjtcy_address1 VARCHAR2,  --家庭住址
 lvsjtcy_cw2 VARCHAR2,  --家庭主要成员称谓
 lvsjtcy_name2 VARCHAR2,  --姓　　名
 lvsjtcy_pid2 VARCHAR2,  --身份证号码
 lvsjtcy_unit2 VARCHAR2,  --服务处所
 lvsjtcy_address2 VARCHAR2,  --家庭住址
 lvsjtcy_cw3 VARCHAR2,  --家庭主要成员称谓
 lvsjtcy_name3 VARCHAR2,  --姓　　名
 lvsjtcy_pid3 VARCHAR2,  --身份证号码
 lvsjtcy_unit3 VARCHAR2,  --服务处所
 lvsjtcy_address3 VARCHAR2,  --家庭住址
 lvsgrjl VARCHAR2,  --个人简历
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS

BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/



   INSERT into tc_webjj.t_crj_zxtabledj
    (
      sdono,   --业务编号
      spid,   --身份证号码
      snamex,   --姓
      snamem,   --名
      sex,   --性　　别
      snamepinx,   --拼  音 姓
      snamepinm,   --拼  音 名
      sminzu,   --民　　族
      dbirth,   --出生日期
      sbirthplace,   --出  生 地
      szzmm,   --政治面貌
      shyzk,   --婚姻状况
      djhsj,   --结婚时间
      sjhdjadr,   --结婚登记地址
      shukouadr,   --户口所在地
      spcs,   --所属派出所
      shomeadr,   --家庭住址
      shometel,   --联系电话
      sunitname,   --服务处所
      szw,   --职　　务
      sunitadr,   --服务处所地址
      sunittel,   --联系电话
      stowhere,   --前  往 地
      ssq_type,   --申请种类
      ssq_reason,   --申请事由
      sxxrs,   --偕行子女人数
      sgaqs_relation,   --与申请人关系
      sgaqs_name,   --姓　　名
      sgaqs_sex,   --性　　别
      sgaqs_birth,   --出生日期
      sgaqs_pid,   --港澳居民身份证号码
      sgawl_txpid,   --港澳居民来往内地通行证号码
      sgadj,   --何时何地何因在港澳定居
      sgalxfs,   --港澳联络地址及联系电话
      sgaqs_relation1,   --与申请人关系
      sgaqs_name1,   --姓　　名
      sgaqs_sex1,   --性　　别
      sgaqs_birth1,   --出生日期
      sgaqs_pid1,   --港澳居民身份证号码
      sgawl_txpid1,   --港澳居民来往内地通行证号码
      sgadj1,   --何时何地何因在港澳定居
      sgalxfs1,   --港澳联络地址及联系电话
      sjtcy_cw,   --家庭主要成员称谓
      sjtcy_name,   --姓　　名
      sjtcy_pid,   --身份证号码
      sjtcy_unit,   --服务处所
      sjtcy_address,   --家庭住址
      sjtcy_cw1,   --家庭主要成员称谓
      sjtcy_name1,   --姓　　名
      sjtcy_pid1,   --身份证号码
      sjtcy_unit1,   --服务处所
      sjtcy_address1,   --家庭住址
      sjtcy_cw2,   --家庭主要成员称谓
      sjtcy_name2,   --姓　　名
      sjtcy_pid2,   --身份证号码
      sjtcy_unit2,   --服务处所
      sjtcy_address2,   --家庭住址
      sjtcy_cw3,   --家庭主要成员称谓
      sjtcy_name3,   --姓　　名
      sjtcy_pid3,   --身份证号码
      sjtcy_unit3,   --服务处所
      sjtcy_address3,   --家庭住址
      sgrjl    --个人简历
    )values(
      lvsdono,   --业务编号
      lvspid,   --身份证号码
      lvsnamex,   --姓
      lvsnamem,   --名
      lvsex,   --性　　别
      lvsnamepinx,   --拼  音 姓
      lvsnamepinm,   --拼  音 名
      lvsminzu,   --民　　族
      lvdbirth,   --出生日期
      lvsbirthplace,   --出  生 地
      lvszzmm,   --政治面貌
      lvshyzk,   --婚姻状况
      lvdjhsj,   --结婚时间
      lvsjhdjadr,   --结婚登记地址
      lvshukouadr,   --户口所在地
      lvspcs,   --所属派出所
      lvshomeadr,   --家庭住址
      lvshometel,   --联系电话
      lvsunitname,   --服务处所
      lvszw,   --职　　务
      lvsunitadr,   --服务处所地址
      lvsunittel,   --联系电话
      lvstowhere,   --前  往 地
      lvssq_type,   --申请种类
      lvssq_reason,   --申请事由
      lvsxxrs,   --偕行子女人数
      lvsgaqs_relation,   --与申请人关系
      lvsgaqs_name,   --姓　　名
      lvsgaqs_sex,   --性　　别
      lvsgaqs_birth,   --出生日期
      lvsgaqs_pid,   --港澳居民身份证号码
      lvsgawl_txpid,   --港澳居民来往内地通行证号码
      lvsgadj,   --何时何地何因在港澳定居
      lvsgalxfs,   --港澳联络地址及联系电话
      lvsgaqs_relation1,   --与申请人关系
      lvsgaqs_name1,   --姓　　名
      lvsgaqs_sex1,   --性　　别
      lvsgaqs_birth1,   --出生日期
      lvsgaqs_pid1,   --港澳居民身份证号码
      lvsgawl_txpid1,   --港澳居民来往内地通行证号码
      lvsgadj1,   --何时何地何因在港澳定居
      lvsgalxfs1,   --港澳联络地址及联系电话
      lvsjtcy_cw,   --家庭主要成员称谓
      lvsjtcy_name,   --姓　　名
      lvsjtcy_pid,   --身份证号码
      lvsjtcy_unit,   --服务处所
      lvsjtcy_address,   --家庭住址
      lvsjtcy_cw1,   --家庭主要成员称谓
      lvsjtcy_name1,   --姓　　名
      lvsjtcy_pid1,   --身份证号码
      lvsjtcy_unit1,   --服务处所
      lvsjtcy_address1,   --家庭住址
      lvsjtcy_cw2,   --家庭主要成员称谓
      lvsjtcy_name2,   --姓　　名
      lvsjtcy_pid2,   --身份证号码
      lvsjtcy_unit2,   --服务处所
      lvsjtcy_address2,   --家庭住址
      lvsjtcy_cw3,   --家庭主要成员称谓
      lvsjtcy_name3,   --姓　　名
      lvsjtcy_pid3,   --身份证号码
      lvsjtcy_unit3,   --服务处所
      lvsjtcy_address3,   --家庭住址

      lvsgrjl    --个人简历


    );
   -- 返回值

END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_crj_zxtabledj
    Set
      sdono=lvsdono,   --业务编号
      spid=lvspid,   --身份证号码
      snamex=lvsnamex,   --姓
      snamem=lvsnamem,   --名
      sex=lvsex,   --性　　别
      snamepinx=lvsnamepinx,   --拼  音 姓
      snamepinm=lvsnamepinm,   --拼  音 名
      sminzu=lvsminzu,   --民　　族
      dbirth=lvdbirth,   --出生日期
      sbirthplace=lvsbirthplace,   --出  生 地
      szzmm=lvszzmm,   --政治面貌
      shyzk=lvshyzk,   --婚姻状况
      djhsj=lvdjhsj,   --结婚时间
      sjhdjadr=lvsjhdjadr,   --结婚登记地址
      shukouadr=lvshukouadr,   --户口所在地
      spcs=lvspcs,   --所属派出所
      shomeadr=lvshomeadr,   --家庭住址
      shometel=lvshometel,   --联系电话
      sunitname=lvsunitname,   --服务处所
      szw=lvszw,   --职　　务
      sunitadr=lvsunitadr,   --服务处所地址
      sunittel=lvsunittel,   --联系电话
      stowhere=lvstowhere,   --前  往 地
      ssq_type=lvssq_type,   --申请种类
      ssq_reason=lvssq_reason,   --申请事由
      sxxrs=lvsxxrs,   --偕行子女人数
      sgaqs_relation=lvsgaqs_relation,   --与申请人关系
      sgaqs_name=lvsgaqs_name,   --姓　　名
      sgaqs_sex=lvsgaqs_sex,   --性　　别
      sgaqs_birth=lvsgaqs_birth,   --出生日期
      sgaqs_pid=lvsgaqs_pid,   --港澳居民身份证号码
      sgawl_txpid=lvsgawl_txpid,   --港澳居民来往内地通行证号码
      sgadj=lvsgadj,   --何时何地何因在港澳定居
      sgalxfs=lvsgalxfs,   --港澳联络地址及联系电话
      sgaqs_relation1=lvsgaqs_relation1,   --与申请人关系
      sgaqs_name1=lvsgaqs_name1,   --姓　　名
      sgaqs_sex1=lvsgaqs_sex1,   --性　　别
      sgaqs_birth1=lvsgaqs_birth1,   --出生日期
      sgaqs_pid1=lvsgaqs_pid1,   --港澳居民身份证号码
      sgawl_txpid1=lvsgawl_txpid1,   --港澳居民来往内地通行证号码
      sgadj1=lvsgadj1,   --何时何地何因在港澳定居
      sgalxfs1=lvsgalxfs1,   --港澳联络地址及联系电话
      sjtcy_cw=lvsjtcy_cw,   --家庭主要成员称谓
      sjtcy_name=lvsjtcy_name,   --姓　　名
      sjtcy_pid=lvsjtcy_pid,   --身份证号码
      sjtcy_unit=lvsjtcy_unit,   --服务处所
      sjtcy_address=lvsjtcy_address,   --家庭住址
      sjtcy_cw1=lvsjtcy_cw1,   --家庭主要成员称谓
      sjtcy_name1=lvsjtcy_name1,   --姓　　名
      sjtcy_pid1=lvsjtcy_pid1,   --身份证号码
      sjtcy_unit1=lvsjtcy_unit1,   --服务处所
      sjtcy_address1=lvsjtcy_address1,   --家庭住址
      sjtcy_cw2=lvsjtcy_cw2,   --家庭主要成员称谓
      sjtcy_name2=lvsjtcy_name2,   --姓　　名
      sjtcy_pid2=lvsjtcy_pid2,   --身份证号码
      sjtcy_unit2=lvsjtcy_unit2,   --服务处所
      sjtcy_address2=lvsjtcy_address2,   --家庭住址
      sjtcy_cw3=lvsjtcy_cw3,   --家庭主要成员称谓
      sjtcy_name3=lvsjtcy_name3,   --姓　　名
      sjtcy_pid3=lvsjtcy_pid3,   --身份证号码
      sjtcy_unit3=lvsjtcy_unit3,   --服务处所
      sjtcy_address3=lvsjtcy_address3,   --家庭住址
      sgrjl=lvsgrjl    --个人简历
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_crj_zxtabledj
    Set
      sdono=lvsdono,   --业务编号
      spid=lvspid,   --身份证号码
      snamex=lvsnamex,   --姓
      snamem=lvsnamem,   --名
      sex=lvsex,   --性　　别
      snamepinx=lvsnamepinx,   --拼  音 姓
      snamepinm=lvsnamepinm,   --拼  音 名
      sminzu=lvsminzu,   --民　　族
      dbirth=lvdbirth,   --出生日期
      sbirthplace=lvsbirthplace,   --出  生 地
      szzmm=lvszzmm,   --政治面貌
      shyzk=lvshyzk,   --婚姻状况
      djhsj=lvdjhsj,   --结婚时间
      sjhdjadr=lvsjhdjadr,   --结婚登记地址
      shukouadr=lvshukouadr,   --户口所在地
      spcs=lvspcs,   --所属派出所
      shomeadr=lvshomeadr,   --家庭住址
      shometel=lvshometel,   --联系电话
      sunitname=lvsunitname,   --服务处所
      szw=lvszw,   --职　　务
      sunitadr=lvsunitadr,   --服务处所地址
      sunittel=lvsunittel,   --联系电话
      stowhere=lvstowhere,   --前  往 地
      ssq_type=lvssq_type,   --申请种类
      ssq_reason=lvssq_reason,   --申请事由
      sxxrs=lvsxxrs,   --偕行子女人数
      sgaqs_relation=lvsgaqs_relation,   --与申请人关系
      sgaqs_name=lvsgaqs_name,   --姓　　名
      sgaqs_sex=lvsgaqs_sex,   --性　　别
      sgaqs_birth=lvsgaqs_birth,   --出生日期
      sgaqs_pid=lvsgaqs_pid,   --港澳居民身份证号码
      sgawl_txpid=lvsgawl_txpid,   --港澳居民来往内地通行证号码
      sgadj=lvsgadj,   --何时何地何因在港澳定居
      sgalxfs=lvsgalxfs,   --港澳联络地址及联系电话
      sgaqs_relation1=lvsgaqs_relation1,   --与申请人关系
      sgaqs_name1=lvsgaqs_name1,   --姓　　名
      sgaqs_sex1=lvsgaqs_sex1,   --性　　别
      sgaqs_birth1=lvsgaqs_birth1,   --出生日期
      sgaqs_pid1=lvsgaqs_pid1,   --港澳居民身份证号码
      sgawl_txpid1=lvsgawl_txpid1,   --港澳居民来往内地通行证号码
      sgadj1=lvsgadj1,   --何时何地何因在港澳定居
      sgalxfs1=lvsgalxfs1,   --港澳联络地址及联系电话
      sjtcy_cw=lvsjtcy_cw,   --家庭主要成员称谓
      sjtcy_name=lvsjtcy_name,   --姓　　名
      sjtcy_pid=lvsjtcy_pid,   --身份证号码
      sjtcy_unit=lvsjtcy_unit,   --服务处所
      sjtcy_address=lvsjtcy_address,   --家庭住址
      sjtcy_cw1=lvsjtcy_cw1,   --家庭主要成员称谓
      sjtcy_name1=lvsjtcy_name1,   --姓　　名
      sjtcy_pid1=lvsjtcy_pid1,   --身份证号码
      sjtcy_unit1=lvsjtcy_unit1,   --服务处所
      sjtcy_address1=lvsjtcy_address1,   --家庭住址
      sjtcy_cw2=lvsjtcy_cw2,   --家庭主要成员称谓
      sjtcy_name2=lvsjtcy_name2,   --姓　　名
      sjtcy_pid2=lvsjtcy_pid2,   --身份证号码
      sjtcy_unit2=lvsjtcy_unit2,   --服务处所
      sjtcy_address2=lvsjtcy_address2,   --家庭住址
      sjtcy_cw3=lvsjtcy_cw3,   --家庭主要成员称谓
      sjtcy_name3=lvsjtcy_name3,   --姓　　名
      sjtcy_pid3=lvsjtcy_pid3,   --身份证号码
      sjtcy_unit3=lvsjtcy_unit3,   --服务处所
      sjtcy_address3=lvsjtcy_address3,   --家庭住址
      sgrjl=lvsgrjl    --个人简历
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_crj_zxtabledj
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

