create procedure          Proc_t_remove_declare_SDONO
(
     lvoldsdono VARCHAR2,  --办理编号
     lvReturn in out varchar2 --新办理编号
)
as
  cursor c is
     select * from tc_webjj.t_remove_declare
     where 1=1
     and sdono=lvoldsdono ;  --办理编号
      r c%rowtype;

BEGIN
   select TC_WEBJJ.fun_get16code(TC_WEBJJ.SEQ_T_DOBUS_SDONO.Nextval)  into  lvReturn from dual  where 1=1;
   for r in c loop
   INSERT into tc_webjj.t_remove_declare
    (
      sdono,   --办理编号
      master_name,   --户主姓名
      master_pid,   --户主身份证号
      master_relation,   --与户主关系
      newrelation,   --与持证人关系
      app_type,   --变更类型
      out_category,   --迁移原因
      qianyino,   --迁移证号
      name,   --姓　　名
      pid,   --公民身份号码
      used_name,   --曾  用 名
      gender,   --性　　别
      nation,   --民　　族
      native_country,   --籍贯（国家地区）
      native_place,   --籍贯（省市县区）
      dob,   --出生日期
      zhunqianno,   --准迁证号
      removecity,   --迁往地省市县区
      removeaddr,   --迁往地详细地址
      app_pid,   --申请人公民身份号码
      app_name,   --申请人姓名
      memo    --备　　注
    )values(
      lvReturn,   --办理编号
      r.master_name,   --户主姓名
      r.master_pid,   --户主身份证号
      r.master_relation,   --与户主关系
      r.newrelation,   --与持证人关系
      r.app_type,   --变更类型
      r.out_category,   --迁移原因
      r.qianyino,   --迁移证号
      r.name,   --姓　　名
      r.pid,   --公民身份号码
      r.used_name,   --曾  用 名
      r.gender,   --性　　别
      r.nation,   --民　　族
      r.native_country,   --籍贯（国家地区）
      r.native_place,   --籍贯（省市县区）
      r.dob,   --出生日期
      r.zhunqianno,   --准迁证号
      r.removecity,   --迁往地省市县区
      r.removeaddr,   --迁往地详细地址
      r.app_pid,   --申请人公民身份号码
      r.app_name,   --申请人姓名
      r.memo    --备　　注
    );
    commit;
    end loop;
END;

/

