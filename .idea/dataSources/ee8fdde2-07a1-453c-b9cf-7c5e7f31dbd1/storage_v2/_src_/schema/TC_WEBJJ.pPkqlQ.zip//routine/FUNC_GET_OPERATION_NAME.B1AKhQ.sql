create FUNCTION          FUNC_GET_OPERATION_NAME
(

     lvoperations varchar2
)
 return varchar2
is
  lvReturn varchar2(3000);
  lvtemp varchar2(200);
  lvone varchar2(16);
  inddh number;
  lvcnt number;
  lvoper tc_webjj.t_operation_deploy%rowtype;
BEGIN
  /*lvedit := '<a href=''' ||
              lvsurl || '&step='||lvflowstep||'&procflag=PMSAVE&procmode=PMUPDATE&busno=' ||
              lvsbusno || '&sdono=' || lvsdono || '&sbooking=' || lvsbooking ||
              '''><img src=''/webjjcss/edit.gif'' /><font color=blue>编 辑</font></a>';*/
  lvtemp := lvoperations;
  lvReturn := '';
  lvcnt := 0;
  while length(lvtemp) > 0 loop
       select instr(lvtemp,',',1,1) into inddh from dual;
       if inddh = 0 then
          lvone := lvtemp;
          lvtemp := '';
       else if inddh >0 then
              lvone := substr(lvtemp,1,inddh-1);
              lvtemp := substr(lvtemp,inddh+1,length(lvtemp));
            end if;
       end if;
       select * into lvoper from tc_webjj.t_operation_deploy d where d.sno= lvone;
          if lvReturn is null then

             lvReturn := lvoper.sname;
             --lvReturn := '<a href=''' ||lvoper.surl || '?sbusno=' ||lvsbusno || '&sdono=' || lvsdono  ||'&soperationno=' || lvone  ||'''><img src='''||lvoper.simgurl||''' /><font color=blue>'||lvoper.sname||'</font></a>';
          else
             lvReturn := lvReturn ||','||lvoper.sname;
          end if;
          lvcnt :=lvcnt + 1;
   end loop;

  return lvReturn;
END;

/

