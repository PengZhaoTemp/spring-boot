create view V_DOBUS_PZ as
  select t.sdono, t.applyno,v.sbusno,v.SUSERNO
      from tc_webjj.t_removetohere_declare t, tc_webjj.v_dobus v
     where t.sdono = v.SDONO
       and t.applyno is not null
       and v.state in ('22', '50', '51')
union all
    select t.sdono, t.applyno,v.sbusno,v.SUSERNO
      from tc_webjj.t_sw_lihu_declare t, tc_webjj.v_dobus v
     where t.sdono = v.SDONO
       and t.applyno is not null
       and v.state in ('22', '50', '51')
union all
    select t.sdono, t.applyno,v.sbusno,v.SUSERNO
      from tc_webjj.t_change_declare t, tc_webjj.v_dobus v
     where t.sdono = v.SDONO
       and t.applyno is not null
       and v.state in ('22', '50', '51')
/

