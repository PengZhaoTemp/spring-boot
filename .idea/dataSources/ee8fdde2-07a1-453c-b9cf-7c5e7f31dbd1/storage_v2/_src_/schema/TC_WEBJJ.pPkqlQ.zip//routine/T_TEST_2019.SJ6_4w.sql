create procedure t_test_2019 
as
 
  Cursor sor is
    select sdono from t_dobus where sapptel = '15399059623';
begin
  for i in sor LOOP
  
    begin    
      DBMS_OUTPUT.PUT_LINE(i.sdono||'------>');
    end;
  
  end LOOP;
end;

/

