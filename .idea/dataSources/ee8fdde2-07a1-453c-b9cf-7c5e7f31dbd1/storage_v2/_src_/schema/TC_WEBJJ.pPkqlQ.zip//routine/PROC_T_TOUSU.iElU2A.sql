create PROCEDURE          PROC_t_tousu   /*T_DEPARTMENT*/
(
 lvnid IN OUT VARCHAR2,  --编　　号
 lvts_type VARCHAR2,  --类型
 lvgongkai VARCHAR2,      --是否公开
 lvts_name VARCHAR2,      --姓名
 lvts_tel VARCHAR2,  --用户电话
 lvts_password VARCHAR2,  --密码
 lvts_content VARCHAR2,  --投诉内容
 lvemail VARCHAR2,  --邮件
 lvtitle VARCHAR2,  --标题
 lvdbbj VARCHAR2,  --dbbj
 lvdbsj DATE  --dbsj
)
AS
BEGIN
  --begin TRAN
    Select tc_weBJJ.SEQ_T_DEPARTMENT_NID.Nextval  into lvnid From dual;    /*编　　号序列*/
   INSERT into tc_webjj.t_tousu
    (
      nid,  --编　　号
      ts_type ,  --类型
      gongkai ,      --是否公开
      ts_name ,      --姓名
      ts_tel ,  --用户电话
      ts_password ,  --密码
      ts_content ,  --投诉内容
      email ,  --邮件
      title ,  --标题
      dbbj ,  --dbbj
      dbsj   --dbsj
    )values(
       lvnid ,  --编　　号
       lvts_type ,  --类型
       lvgongkai ,      --是否公开
       lvts_name ,      --姓名
       lvts_tel ,  --用户电话
       lvts_password ,  --密码
       lvts_content ,  --投诉内容
       lvemail ,  --邮件
       lvtitle ,  --标题
       lvdbbj ,  --dbbj
       lvdbsj   --dbsj
    );
   -- 返回值

 Commit;
END; /*存储过程结束*/

