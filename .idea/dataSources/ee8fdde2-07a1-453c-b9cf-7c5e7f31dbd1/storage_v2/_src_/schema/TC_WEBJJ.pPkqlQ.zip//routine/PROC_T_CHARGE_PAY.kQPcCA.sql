create procedure          proc_t_charge_pay
(
    lvsdono VARCHAR2,         --事务编号
    lvsbusno VARCHAR2         --事务编号
)
is
    lvFLOSTEP varchar2(50);   --2个临时变量
    lvBUSFLOWNO varchar2(50);
begin
----------------------------------------------------------------------
   -- select flowstep+1 flowstep from tc_webjj.v_dobus where sdono = lvsdono;
   -- lvFLOSTEP:=flowstep;

    select flowstep+1 flowstep into lvFLOSTEP from tc_webjj.v_dobus where sdono =lvsdono;
----------------------------------------------------------------------
    --select busflowno from tc_webjj.t_bus_flow where flowstep = lvFLOSTEP and sbusno=lvsbusno;
    --lvBUSFLOWNO:=busflowno;

    select busflowno into lvBUSFLOWNO from tc_webjj.t_bus_flow where flowstep = lvFLOSTEP and sbusno=lvsbusno;

    update tc_webjj.t_dobus set dbbj='0',state='21',flownote=lvBUSFLOWNO where sdono =lvsdono;

end proc_t_charge_pay;

/

