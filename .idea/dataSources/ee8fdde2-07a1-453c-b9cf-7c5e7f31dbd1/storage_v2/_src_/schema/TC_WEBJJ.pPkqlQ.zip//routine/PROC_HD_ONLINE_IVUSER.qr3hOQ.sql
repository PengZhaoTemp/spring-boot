create procedure          proc_hd_ONLINE_IVUSER(
                                       lv_sid in out varchar2,
                                       lv_Sonline_ivID varchar2,
                                       lv_SUSERTYPE varchar2,
                                       lv_SNAME varchar2,
                                       lv_Stel varchar2,
                                       lv_snickname varchar2,
                                       lv_Sip varchar2,
                                       lv_msg_return   in out varchar2
                                        ) as

begin
  select tc_webjj.SEQ_HD_ONLINE_IVUSER.nextval into lv_sid from dual;
  insert into TC_WEBJJ.T_HD_ONLINE_IVUSER(
  SID,
  SONLINE_IVID,
  SUSERTYPE,
  SNAME,
  STEL,
  SNICKNAME,
  SIP,
  DINDATE
  )values(
  lv_sid,
  lv_Sonline_ivID,
  lv_SUSERTYPE,
  lv_SNAME,
  lv_Stel,
  lv_snickname,
  lv_Sip,
  sysdate
  );
  lv_msg_return :='操作成功';
  commit;
end proc_hd_ONLINE_IVUSER;

/

