create procedure          proc_success_banli(lv_sdono varchar2,
                                               lvuserno varchar2) as
  lv_sbusno    VARCHAR2(16);
  lv_send_flag VARCHAR2(50);
  lv_sp_flag   varchar2(2);
  lv_state     varchar2(2);
  lv_userno    VARCHAR2(16);
  lv_note      VARCHAR2(500); --短信信息
begin
  /*办理成功状态修改*/
  lv_sp_flag :='0';
  select sbusno, need_back, suserno
    into lv_sbusno, lv_send_flag, lv_userno
    from tc_webjj.v_dobus
   where sdono = lv_sdono;
  select verify
    into lv_sp_flag
    from tc_webjj.t_bus_deploy
   where sbusno = lv_sbusno;
  if lv_sp_flag = '0' then
    --不需要审批
    if lv_send_flag = '需回寄' then
      lv_state := '23';
    else
      lv_state := '41';
    end if;
  end if;
  update tc_webjj.t_dobus
     set state = lv_state, SACCEPTDATE = sysdate, SACCEPTMAN = lvuserno
   where sdono = lv_sdono;

  select fun_note_start(lv_sdono) into lv_note from dual;--查询短信的头部
  if lv_state = '23' then
    lv_note := lv_note || '等待打印回寄中!';
  elsif lv_state = '41' then
    lv_note := lv_note || '该业务已完成!';
  end if;

  insert into tc_webjj.T_NETNOTE --填写短息
    (snoteno, suserno, sdono, snote, DRECDATE)
  values
    (tc_webjj.fun_get16code_pz(tc_webjj.SEQ_T_NETNOTE_SNOTENO.nextval),
     lv_userno,
     lv_sdono,
     lv_note,
     sysdate);

  insert into tc_webjj.t_notemobile--填写短息
    (snoteno, suserno, sdono, snote, stel, DSENDDATE)
  values
    (tc_webjj.fun_get16code_pz(tc_webjj.SEQ_t_notemobile_SNOTENO.nextval),
     lv_userno,
     lv_sdono,
     lv_note,
     (select shome_phone
        from tc_webjj.t_commoner
       where personid =lv_userno
         and rownum < 2),
     sysdate);

end proc_success_banli;

/

