create FUNCTION          FUN_UNCRYPKEY(SRC_CHAR VARCHAR2)
return varchar2
As
  KeyLen Pls_Integer;
  KeyPos Pls_Integer;
  offset Pls_Integer;
  dest varchar2(300);
  SrcPos Pls_Integer;
  SrcAsc Pls_Integer;
  Key varchar2(300);
  src varchar2(75);
  tmp varchar2(3);
  tmp_srcAsc Pls_Integer;
  raw_data1    RAW(6);
  raw_data2    RAW(6);
  tmp_key Pls_Integer;
Begin
  src:=upper(src_char);
  Key:='PassWord';
  KeyLen:=length(key);
  KeyPos:=0;
  SrcPos:=3;
  SrcAsc:=0;
  offset:=to_dec(substr(src,1,2));
  while SrcPos<length(src) loop
    srcasc:=to_dec(substr(src,srcpos,2));
    if KeyPos < KeyLen then KeyPos:= KeyPos + 1 ;
      else KeyPos:=1;
    end if;
    raw_data1:=HEXTORAW(to_hex(srcAsc));
    tmp_key:=ascii(substr(key,keypos,1));
    raw_data2:=HEXTORAW(to_hex(tmp_key));
    tmp:=UTL_RAW.BIT_XOR(raw_data2,raw_data1);
    --select UTL_RAW.BIT_XOR(raw_data2,raw_data1) into tmp from dual;
    tmp_srcAsc:=to_dec(tmp);
    if tmp_srcasc<=offset then
      tmp_srcasc:=255+ tmp_srcasc-offset;
    else
      tmp_srcasc:=tmp_srcasc-offset;
    end if;
    dest := dest||chr(tmp_srcasc);
    offset := srcasc;
    srcpos := srcpos +2;
  end loop;
  return dest;
end;

/

