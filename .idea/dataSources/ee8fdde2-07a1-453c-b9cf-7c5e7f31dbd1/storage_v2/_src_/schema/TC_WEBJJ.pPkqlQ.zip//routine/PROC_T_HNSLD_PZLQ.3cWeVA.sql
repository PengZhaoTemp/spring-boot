create PROCEDURE          PROC_t_hnsld_pzlq   /*T_HNSLD_PZLQ*/
(
 lvsdono IN OUT VARCHAR2,  --业务编号
 lvsld_name VARCHAR2,  --狩猎队名称
 lvsname VARCHAR2,  --人员姓名
 lvssex VARCHAR2,  --性别（字典）
 lvsbirth DATE,  --出生年月
 lvsnation VARCHAR2,  --民族（字典）
 lvsaddress VARCHAR2,  --详细地址
 lvspid VARCHAR2,  --身份证号码
 lvszzmm VARCHAR2,  --政治面貌(字典)
 lvsfqk VARCHAR2,  --是否有前科1有0没有
 lvhealth VARCHAR2,  --健康情况
 lvwhcd VARCHAR2,  --文化程度
 lvqiang_type VARCHAR2,  --枪　　型
 lvqiang_no VARCHAR2,  --枪　　号
 lvxd_quyu VARCHAR2,  --限定区域
 lvsq_reason VARCHAR2,  --申请理由
 lvbg_unit VARCHAR2,  --保管单位
 lvxj_bmyj VARCHAR2,  --县级部门意见
 lvxj_bmsj DATE,  --部门意见时间
 lvxj_spyj VARCHAR2,  --县级审批人意见
 lvxj_spsj DATE,  --审批意见时间
 lvsj_bmyj VARCHAR2,  --市级部门意见
 lvsj_bmsj DATE,  --部门意见时间
 lvsj_spyj VARCHAR2,  --市级审批人意见
 lvsj_spsj DATE,  --审批意见时间
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS

BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/



   INSERT into tc_webjj.t_hnsld_pzlq
    (
      sdono,   --业务编号
      sld_name,   --狩猎队名称
      sname,   --人员姓名
      ssex,   --性别（字典）
      sbirth,   --出生年月
      snation,   --民族（字典）
      saddress,   --详细地址
      spid,   --身份证号码
      szzmm,   --政治面貌(字典)
      sfqk,   --是否有前科1有0没有
      health,   --健康情况
      whcd,   --文化程度
      qiang_type,   --枪　　型
      qiang_no,   --枪　　号
      xd_quyu,   --限定区域
      sq_reason,   --申请理由
      bg_unit,   --保管单位
      xj_bmyj,   --县级部门意见
      xj_bmsj,   --部门意见时间
      xj_spyj,   --县级审批人意见
      xj_spsj,   --审批意见时间
      sj_bmyj,   --市级部门意见
      sj_bmsj,   --部门意见时间
      sj_spyj,   --市级审批人意见
      sj_spsj    --审批意见时间
    )values(
      lvsdono,   --业务编号
      lvsld_name,   --狩猎队名称
      lvsname,   --人员姓名
      lvssex,   --性别（字典）
      lvsbirth,   --出生年月
      lvsnation,   --民族（字典）
      lvsaddress,   --详细地址
      lvspid,   --身份证号码
      lvszzmm,   --政治面貌(字典)
      lvsfqk,   --是否有前科1有0没有
      lvhealth,   --健康情况
      lvwhcd,   --文化程度
      lvqiang_type,   --枪　　型
      lvqiang_no,   --枪　　号
      lvxd_quyu,   --限定区域
      lvsq_reason,   --申请理由
      lvbg_unit,   --保管单位
      lvxj_bmyj,   --县级部门意见
      lvxj_bmsj,   --部门意见时间
      lvxj_spyj,   --县级审批人意见
      lvxj_spsj,   --审批意见时间
      lvsj_bmyj,   --市级部门意见
      lvsj_bmsj,   --部门意见时间
      lvsj_spyj,   --市级审批人意见

      lvsj_spsj    --审批意见时间


    );
   -- 返回值

END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_hnsld_pzlq
    Set
      sdono=lvsdono,   --业务编号
      sld_name=lvsld_name,   --狩猎队名称
      sname=lvsname,   --人员姓名
      ssex=lvssex,   --性别（字典）
      sbirth=lvsbirth,   --出生年月
      snation=lvsnation,   --民族（字典）
      saddress=lvsaddress,   --详细地址
      spid=lvspid,   --身份证号码
      szzmm=lvszzmm,   --政治面貌(字典)
      sfqk=lvsfqk,   --是否有前科1有0没有
      health=lvhealth,   --健康情况
      whcd=lvwhcd,   --文化程度
      qiang_type=lvqiang_type,   --枪　　型
      qiang_no=lvqiang_no,   --枪　　号
      xd_quyu=lvxd_quyu,   --限定区域
      sq_reason=lvsq_reason,   --申请理由
      bg_unit=lvbg_unit,   --保管单位
      xj_bmyj=lvxj_bmyj,   --县级部门意见
      xj_bmsj=lvxj_bmsj,   --部门意见时间
      xj_spyj=lvxj_spyj,   --县级审批人意见
      xj_spsj=lvxj_spsj,   --审批意见时间
      sj_bmyj=lvsj_bmyj,   --市级部门意见
      sj_bmsj=lvsj_bmsj,   --部门意见时间
      sj_spyj=lvsj_spyj,   --市级审批人意见
      sj_spsj=lvsj_spsj    --审批意见时间
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_hnsld_pzlq
    Set
      sdono=lvsdono,   --业务编号
      sld_name=lvsld_name,   --狩猎队名称
      sname=lvsname,   --人员姓名
      ssex=lvssex,   --性别（字典）
      sbirth=lvsbirth,   --出生年月
      snation=lvsnation,   --民族（字典）
      saddress=lvsaddress,   --详细地址
      spid=lvspid,   --身份证号码
      szzmm=lvszzmm,   --政治面貌(字典)
      sfqk=lvsfqk,   --是否有前科1有0没有
      health=lvhealth,   --健康情况
      whcd=lvwhcd,   --文化程度
      qiang_type=lvqiang_type,   --枪　　型
      qiang_no=lvqiang_no,   --枪　　号
      xd_quyu=lvxd_quyu,   --限定区域
      sq_reason=lvsq_reason,   --申请理由
      bg_unit=lvbg_unit,   --保管单位
      xj_bmyj=lvxj_bmyj,   --县级部门意见
      xj_bmsj=lvxj_bmsj,   --部门意见时间
      xj_spyj=lvxj_spyj,   --县级审批人意见
      xj_spsj=lvxj_spsj,   --审批意见时间
      sj_bmyj=lvsj_bmyj,   --市级部门意见
      sj_bmsj=lvsj_bmsj,   --部门意见时间
      sj_spyj=lvsj_spyj,   --市级审批人意见
      sj_spsj=lvsj_spsj    --审批意见时间
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_hnsld_pzlq
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

