create PROCEDURE          PROC_t_sanyuan_info   /*T_SANYUAN_INFO*/
(
 lvspsnno IN OUT VARCHAR2,  --人员编号
 lvsdono VARCHAR2,  --业务编号
 lvspid VARCHAR2,  --身份证号
 lvsname VARCHAR2,  --姓　　名
 lvsxueli VARCHAR2,  --学　　历
 lvscity VARCHAR2,  --所属省市
 lvssffz VARCHAR2,  --有无犯罪记录0无 1有
 lvssfbs VARCHAR2,  --有无重大病史0无 1有
 lvstel VARCHAR2,  --联系方式
 lvsaddress VARCHAR2,  --通信地址
 lvsanyuan_zj VARCHAR2,  --证件号码
 lvszkz VARCHAR2,  --准  考 证
 lvsbk_type VARCHAR2,  --报考类型
 lvsbk_time DATE,  --报考时间
 lvszz_time DATE,  --制证时间
 lvszj_yxq VARCHAR2,  --证件有效期
 lvslingqu VARCHAR2,  --是否被领取0否 1是
 lvszt_fenshu VARCHAR2,  --最近一次做题分数
 lvszb_record VARCHAR2,  --作弊记录
 lvsksqk VARCHAR2,  --备  注 1
 lvsol2 VARCHAR2,  --备  注 2
 lvsol3 VARCHAR2,  --备  注 3
 lvsol4 VARCHAR2,  --备  注 4
 lvsbk_unit varchar2,--报考人所在单位
 lvsbk_jg varchar2,--报考人籍贯
 lvsbk_sex varchar2,--报考人性别
 lvstjpid varchar2,--提交人身份证
 lvstjname varchar2,--提交人姓名
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS

BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/


 select tc_webjj.seq_t_sanyuan_info_spsnno.nextval into lvspsnno from dual;
   INSERT into tc_webjj.t_sanyuan_info
    (
      spsnno,   --人员编号
      sdono,   --业务编号
      spid,   --身份证号
      sname,   --姓　　名
      sxueli,   --学　　历
      scity,   --所属省市
      ssffz,   --有无犯罪记录0无 1有
      ssfbs,   --有无重大病史0无 1有
      stel,   --联系方式
      saddress,   --通信地址
      sanyuan_zj,   --证件号码
      szkz,   --准  考 证
      sbk_type,   --报考类型
      sbk_time,   --报考时间
      szz_time,   --制证时间
      szj_yxq,   --证件有效期
      slingqu,   --是否被领取0否 1是
      szt_fenshu,   --最近一次做题分数
      szb_record,   --作弊记录
      sksqk,   --备  注 1
      sol2,   --备  注 2
      sol3,   --备  注 3
      sol4,    --备  注 4
      sbk_unit,
      sbk_jg,
      sbk_sex,
      stjpid,
      stjname
    )values(
      lvspsnno,   --人员编号
      lvsdono,   --业务编号
      lvspid,   --身份证号
      lvsname,   --姓　　名
      lvsxueli,   --学　　历
      lvscity,   --所属省市
      lvssffz,   --有无犯罪记录0无 1有
      lvssfbs,   --有无重大病史0无 1有
      lvstel,   --联系方式
      lvsaddress,   --通信地址
      lvsanyuan_zj,   --证件号码
      lvszkz,   --准  考 证
      lvsbk_type,   --报考类型
      sysdate,   --报考时间
      lvszz_time,   --制证时间
      lvszj_yxq,   --证件有效期
      lvslingqu,   --是否被领取0否 1是
      lvszt_fenshu,   --最近一次做题分数
      lvszb_record,   --作弊记录
      '0',   --备  注 1
      lvsol2,   --备  注 2
      lvsol3,   --备  注 3

      lvsol4,    --备  注 4
      lvsbk_unit,
      lvsbk_jg,
      lvsbk_sex,
      lvstjpid,
      lvstjname

    );
   -- 返回值

END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_sanyuan_info
    Set
      spsnno=lvspsnno,   --人员编号
      sdono=lvsdono,   --业务编号
      spid=lvspid,   --身份证号
      sname=lvsname,   --姓　　名
      sxueli=lvsxueli,   --学　　历
      scity=lvscity,   --所属省市
      ssffz=lvssffz,   --有无犯罪记录0无 1有
      ssfbs=lvssfbs,   --有无重大病史0无 1有
      stel=lvstel,   --联系方式
      saddress=lvsaddress,   --通信地址
      sanyuan_zj=lvsanyuan_zj,   --证件号码
      szkz=lvszkz,   --准  考 证
      sbk_type=lvsbk_type,   --报考类型
      sbk_time=lvsbk_time,   --报考时间
      szz_time=lvszz_time,   --制证时间
      szj_yxq=lvszj_yxq,   --证件有效期
      slingqu=lvslingqu,   --是否被领取0否 1是
      szt_fenshu=lvszt_fenshu,   --最近一次做题分数
      szb_record=lvszb_record,   --作弊记录
      sksqk=lvsksqk,   --备  注 1
      sol2=lvsol2,   --备  注 2
      sol3=lvsol3,   --备  注 3
      sol4=lvsol4,    --备  注 4
      sbk_unit=lvsbk_unit,
      sbk_jg=lvsbk_jg,
      sbk_sex=lvsbk_sex,
      stjpid=lvstjpid,
      stjname=lvstjname
    Where 1=1
    and spsnno=lvspsnno   --人员编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_sanyuan_info
    Set
      spsnno=lvspsnno,   --人员编号
      sdono=lvsdono,   --业务编号
      spid=lvspid,   --身份证号
      sname=lvsname,   --姓　　名
      sxueli=lvsxueli,   --学　　历
      scity=lvscity,   --所属省市
      ssffz=lvssffz,   --有无犯罪记录0无 1有
      ssfbs=lvssfbs,   --有无重大病史0无 1有
      stel=lvstel,   --联系方式
      saddress=lvsaddress,   --通信地址
      sanyuan_zj=lvsanyuan_zj,   --证件号码
      szkz=lvszkz,   --准  考 证
      sbk_type=lvsbk_type,   --报考类型
      sbk_time=lvsbk_time,   --报考时间
      szz_time=lvszz_time,   --制证时间
      szj_yxq=lvszj_yxq,   --证件有效期
      slingqu=lvslingqu,   --是否被领取0否 1是
      szt_fenshu=lvszt_fenshu,   --最近一次做题分数
      szb_record=lvszb_record,   --作弊记录
      sksqk=lvsksqk,   --备  注 1
      sol2=lvsol2,   --备  注 2
      sol3=lvsol3,   --备  注 3
      sol4=lvsol4,    --备  注 4
      sbk_unit=lvsbk_unit,
      sbk_jg=lvsbk_jg,
      sbk_sex=lvsbk_sex,
      stjpid=lvstjpid,
      stjname=lvstjname
    Where 1=1
    and spsnno=lvspsnno   --人员编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_sanyuan_info
    Where 1=1
    and spsnno=lvspsnno   --人员编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

