create view V_FIELD_DEPLOY as
  select a.TABLE_NAME,
       column_name,
       data_length,
       b."SNO",
       b."STABLENAME",
       b."STABLENAMECN",
       b."SFIELDNAME",
       b."SFIELDNAMECN",
       b."SFIELDINFO",
       b."DBBJ",
       b."DBSJ",
       b."SFIELDTYPE",
       b."SFIELDLENGHT",
       b."SFIELDCHECK",
       b."SFIELDTAXIS",
       b."SFIELDGROUP",
       b."SBUSNO",
       b."SNULLABLE",
       b."SFIELDBOX",
       b."SCLEWID",
       b."SCLEW",
       b."SNERR",
       b."SCLEWOBJ",
       b."SZDCODEID",
       b."SZDSAVETYPE",
       b."SFIELDKIND",
       b.status
from all_tab_columns a, tc_webjj.t_field_deploy b
where a.COLUMN_NAME = b.sfieldname(+)
and a.OWNER||'.'||a.TABLE_NAME = b.stablename(+)
and lower(owner) = 'tc_webjj'
/

