create procedure          Proc_t_bir_declare_SDONO
(
     lvoldsdono VARCHAR2,  --办理编号
     lvReturn in out varchar2 --新办理编号
)
as
   cursor c is
     select * from tc_webjj.t_bir_declare
     where sdono=lvoldsdono;
  r c%rowtype;

BEGIN
   select TC_WEBJJ.fun_get16code(TC_WEBJJ.SEQ_T_DOBUS_SDONO.Nextval)  into  lvReturn from dual  where 1=1;
   for r in c loop
   INSERT into tc_webjj.t_bir_declare
    (
      hu_master_name,   --户主姓名
      hu_master_pid,   --户主公民身份号码
      master_relation,   --与户主关系
      when_logged,   --与与户主关系创建时间
      pid,   --公民身份号码
      name,   --姓　　名
      gender,   --性　　别
      used_name,   --曾  用 名
      nation,   --民　　族
      native_country,   --籍贯（国家地区）
      native_place,   --籍贯（省市县区）
      dob,   --出生日期
      dob_time,   --出生时间
      natal_country,   --出生地（国家地区）
      natal_place,   --出生地（省市县区）
      natal_xiang,   --出生地详址
      gurardian_1_id,   --监护人1编号
      gurardian_1_pid,   --监护人1公民身份号码
      gurardian_1,   --监护人1姓名
      wardship_1,   --与监护人1关系
      gurardian_2_id,   --监护人2编号
      gurardian_2_pid,   --监护人2公民身份号码
      gurardian_2,   --监护人2姓名
      wardship_2,   --与监护人2关系
      fa_person_id,   --父亲人员编号
      fa_pid,   --父亲公民身份号码
      fa_name,   --父亲姓名
      ma_person_id,   --母亲人员编号
      ma_pid,   --母亲公民身份号码
      ma_name,   --母亲姓名
      bloodtype,   --血　　型
      scontact,   --联系方式
      in_kind_code,   --出生类别代码
      in_category_code,   --出生原因代码
      in_category,   --出生原因(申报原因)
      born_card_no,   --出生证号码
      natal_card_date,   --出生证签发日期
      when_in,   --出生申报时间
      send_hu,   --是否要打印户口本
      in_hu_kind,   --落户类型
      sdono,   --办理编号
      in_app_pid,   --申请人公民身份号码
      in_app_name,   --申请人姓名
      memo    --备　　注
    )values(
      r.hu_master_name,   --户主姓名
      r.hu_master_pid,   --户主公民身份号码
      r.master_relation,   --与户主关系
      sysdate,   --与与户主关系创建时间
      r.pid,   --公民身份号码
      r.name,   --姓　　名
      r.gender,   --性　　别
      r.used_name,   --曾  用 名
      r.nation,   --民　　族
      r.native_country,   --籍贯（国家地区）
      r.native_place,   --籍贯（省市县区）
      r.dob,   --出生日期
      r.dob_time,   --出生时间
      r.natal_country,   --出生地（国家地区）
      r.natal_place,   --出生地（省市县区）
      r.natal_xiang,   --出生地详址
      r.gurardian_1_id,   --监护人1编号
      r.gurardian_1_pid,   --监护人1公民身份号码
      r.gurardian_1,   --监护人1姓名
      r.wardship_1,   --与监护人1关系
      r.gurardian_2_id,   --监护人2编号
      r.gurardian_2_pid,   --监护人2公民身份号码
      r.gurardian_2,   --监护人2姓名
      r.wardship_2,   --与监护人2关系
      r.fa_person_id,   --父亲人员编号
      r.fa_pid,   --父亲公民身份号码
      r.fa_name,   --父亲姓名
      r.ma_person_id,   --母亲人员编号
      r.ma_pid,   --母亲公民身份号码
      r.ma_name,   --母亲姓名
      r.bloodtype,   --血　　型
      r.scontact,   --联系方式
      r.in_kind_code,   --出生类别代码
      r.in_category_code,   --出生原因代码
      r.in_category,   --出生原因(申报原因)
      r.born_card_no,   --出生证号码
      r.natal_card_date,   --出生证签发日期
      sysdate,   --出生申报时间
      r.send_hu,   --是否要打印户口本
      r.in_hu_kind,   --落户类型
      lvReturn,   --办理编号
      r.in_app_pid,   --申请人公民身份号码
      r.in_app_name,   --申请人姓名
      r.memo    --备　　注
    );
    commit;
    end loop;
END;

/

