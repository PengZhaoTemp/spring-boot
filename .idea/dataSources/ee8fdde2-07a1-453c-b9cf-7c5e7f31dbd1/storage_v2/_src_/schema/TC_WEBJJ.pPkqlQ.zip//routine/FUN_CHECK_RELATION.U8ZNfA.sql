create function          fun_check_relation(lv_pid         varchar2,
                                              lv_name        varchar2,
                                              lv_master_pid  varchar2,
                                              lv_master_name varchar2,
                                              lv_relation    varchar2)
  return varchar2 is
  /*检查 两人并检查关系 */
  lvsurl   varchar2(50);
  lv_count number;
begin
  lvsurl:='true';
  lv_count := 0;
  select count(*) into lv_count
    from tc_rkxt.v_tp_huji_ck
   where pid = lv_pid
     and name = lv_name;
  if lv_count = 0 then
    return 'ck_duix';--申请对象信息错误
  end if;
  lv_count := 0;
  select count(*) into lv_count
    from tc_rkxt.v_tp_huji_ck
   where pid = lv_master_pid
     and name = lv_master_name;
  if lv_count = 0 then
    return 'ck_hu';--户主信息错误
  end if;
  lv_count := 0;
  select count(*) into lv_count
    from tc_rkxt.v_tp_huji_ck
   where pid = lv_pid
     and name = lv_name
     and hu_master_pid = lv_master_pid
     and hu_master_name = lv_master_name
     and MASTER_RELATION = lv_relation;
  if lv_count = 0 then
    return 'relation';--申请对象与户主关系错误
  end if;
  return(lvsurl);
end fun_check_relation;

/

