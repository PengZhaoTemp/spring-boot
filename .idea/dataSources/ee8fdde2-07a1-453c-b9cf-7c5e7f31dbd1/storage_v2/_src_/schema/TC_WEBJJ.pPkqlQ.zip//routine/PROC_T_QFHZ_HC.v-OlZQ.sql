create PROCEDURE          PROC_t_qfhz_hc   /*T_QFHZ_HC*/
(
 lvsdono IN OUT VARCHAR2,  --业务编号
 lvsname VARCHAR2,  --姓　　名
 lvsex VARCHAR2,  --性　　别
 lvsphone VARCHAR2,  --联系电话
 lvspid VARCHAR2,  --身  份 证
 lvdcsrq DATE,  --出生日期
 lvshj VARCHAR2,  --户籍地址
 lvszj_type VARCHAR2,  --证件种类
 lvszjbh VARCHAR2,  --证件编号
 lvsqfjg VARCHAR2,  --签发机关
 lvqfrq DATE,  --签发日期
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
   INSERT into tc_webjj.t_qfhz_hc
    (
      sdono,   --业务编号
      sname,   --姓　　名
      sex,   --性　　别
      sphone,   --联系电话
      spid,   --身  份 证
      dcsrq,   --出生日期
      shj,   --户籍地址
      szj_type,   --证件种类
      szjbh,   --证件编号
      sqfjg,   --签发机关
      qfrq ,   --签发日期
      dbbj,
      dbsj
    )values(
      lvsdono,   --业务编号
      lvsname,   --姓　　名
      lvsex,   --性　　别
      lvsphone,   --联系电话
      lvspid,   --身  份 证
      lvdcsrq,   --出生日期
      lvshj,   --户籍地址
      lvszj_type,   --证件种类
      lvszjbh,   --证件编号
      lvsqfjg,   --签发机关
      lvqfrq  ,  --签发日期
      '0',
      sysdate
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_qfhz_hc
    Set
      sdono=lvsdono,   --业务编号
      sname=lvsname,   --姓　　名
      sex=lvsex,   --性　　别
      sphone=lvsphone,   --联系电话
      spid=lvspid,   --身  份 证
      dcsrq=lvdcsrq,   --出生日期
      shj=lvshj,   --户籍地址
      szj_type=lvszj_type,   --证件种类
      szjbh=lvszjbh,   --证件编号
      sqfjg=lvsqfjg,   --签发机关
      qfrq=lvqfrq ,   --签发日期
      dbbj='0',
      dbsj=sysdate
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_qfhz_hc
    Set
      sdono=lvsdono,   --业务编号
      sname=lvsname,   --姓　　名
      sex=lvsex,   --性　　别
      sphone=lvsphone,   --联系电话
      spid=lvspid,   --身  份 证
      dcsrq=lvdcsrq,   --出生日期
      shj=lvshj,   --户籍地址
      szj_type=lvszj_type,   --证件种类
      szjbh=lvszjbh,   --证件编号
      sqfjg=lvsqfjg,   --签发机关
      qfrq=lvqfrq ,   --签发日期
      dbbj='0',
      dbsj=sysdate
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_qfhz_hc
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

