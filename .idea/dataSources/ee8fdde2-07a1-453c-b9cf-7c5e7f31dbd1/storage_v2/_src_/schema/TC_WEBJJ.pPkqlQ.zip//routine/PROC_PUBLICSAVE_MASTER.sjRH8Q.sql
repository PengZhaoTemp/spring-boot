create procedure          proc_publicsave_master
(      lvsdono varchar2,
       lvsitem_sno varchar2,
       lvsitem_files varchar2,
       lv_ProcFlag varchar2
)
is
lvsitem_sno_one varchar2(16);
lvsitem_sno_temp varchar2(500);
lvsitem_files_one varchar2(4000);
lvsitem_files_temp varchar2(4000);

lvsno_master varchar2(16);
lvsitem_file_one varchar2(100);

lvdbbj varchar2(1);

lvindexnum number;
begin
  delete from tc_webjj.t_applymasterdata where sdono = lvsdono;
  if lv_ProcFlag = 'PMSUBMIT' then
     lvdbbj := '0';
  else
     lvdbbj := '1';
  end if;

  lvsitem_sno_temp := lvsitem_sno;
  lvsitem_files_temp := lvsitem_files;
  while length(lvsitem_sno_temp)>0 loop
        --获取sno
        lvindexnum := instr(lvsitem_sno_temp,',');
        if lvindexnum = 0 then
           lvsitem_sno_one := lvsitem_sno_temp;
           lvsitem_sno_temp := '';
        else
           lvsitem_sno_one := substr(lvsitem_sno_temp,1,lvindexnum-1);
           lvsitem_sno_temp := substr(lvsitem_sno_temp,lvindexnum+1,length(lvsitem_sno_temp));
        end if;
        --获取文件路径
        lvindexnum := instr(lvsitem_files_temp,';');
        if lvindexnum = 0 then
          lvsitem_files_one :=  lvsitem_files_temp;
          lvsitem_files_temp := '';
        else
          lvsitem_files_one := substr(lvsitem_files_temp,1,lvindexnum-1);
          lvsitem_files_temp := substr(lvsitem_files_temp,lvindexnum+1,length(lvsitem_files_temp));
        end if;

        if length(lvsitem_files_one) = 0 then
           select tc_webjj.fun_get16code(tc_webjj.seq_applymasterdata_nid.nextval) into lvsno_master from dual;
           insert into tc_webjj.t_applymasterdata(
                  SNO,sdono,smasterialsno,smasterialsname,dbbj
           )
           select lvsno_master,
                  lvsdono,
                  a.sno,
                  a.sitem,
                  lvdbbj
             from tc_webjj.t_applymasterials a
            where sno = lvsitem_sno_one;
        else
           while length(lvsitem_files_one) > 0 loop
                 lvindexnum := instr(lvsitem_files_one,',');
                 if lvindexnum = 0 then
                    lvsitem_file_one := lvsitem_files_one;
                    lvsitem_files_one := '';
                 else
                    lvsitem_file_one := substr(lvsitem_files_one,1,lvindexnum-1);
                    lvsitem_files_one := substr(lvsitem_files_one,lvindexnum+1,length(lvsitem_files_one));
                 end if;
                 select tc_webjj.fun_get16code(tc_webjj.seq_applymasterdata_nid.nextval) into lvsno_master from dual;
                 insert into tc_webjj.t_applymasterdata(
                        SNO,sdono,smasterialsno,smasterialsname,smasterialspath,dbbj
                 )
                 select lvsno_master,
                        lvsdono,
                        a.sno,
                        a.sitem,
                        lvsitem_file_one,
                        lvdbbj
                   from tc_webjj.t_applymasterials a
                  where sno = lvsitem_sno_one;

           end loop;
        end if;
  end loop;
  commit;
end proc_publicsave_master;

/

