create view V_DOBUS_HJYW as
  select sdono,name,pid from t_bir_declare
  union all
  select sdono,name,pid from T_DEATH_DECLARE
/

