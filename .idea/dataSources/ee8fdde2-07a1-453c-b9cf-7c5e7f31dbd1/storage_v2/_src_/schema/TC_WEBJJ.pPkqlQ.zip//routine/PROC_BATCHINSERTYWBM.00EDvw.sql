create PROCEDURE proc_batchInsertYwbm
(
       tablename varchar2,
       sjbmc varchar2
)as
       sqlddl varchar2(500);
       uptablename varchar2(50);
BEGIN
  begin
       uptablename:=upper(tablename);
       --拼接建表语句
       sqlddl:='create table '||uptablename||'(sdono VARCHAR2(20) not null, sname VARCHAR2(45), spid  VARCHAR2(18), dbbj  VARCHAR2(1) default 0 not null,dbsj  DATE) tablespace WEBJJ_DATA pctfree 10 initrans 1 maxtrans 255 storage ( initial 64K next 1M  minextents 1 maxextents unlimited ) ';
       --执行建表语句
       execute immediate sqlddl;
       --配置传输表
       insert into tc_tools.t_sjps_sendcondition values('610100',uptablename,'1=1 and dbbj=0','0','解文件包','D:\\recive\\sj\\接收数据\\',uptablename,'0','192.168.0.3','','','','');
       --配置解包数据
       insert into tc_tools.t_sjps_sendcondition values('610100',uptablename,'1=1 and dbbj=0','0','打包工具','',uptablename,'0','10.5.55.43','','','','');
       --添加sendpack 表数据
       insert into tc_tools.t_sjps_sendpack values(uptablename,'陕西省网上警局','','','TABLE',sjbmc,'','30','',uptablename,uptablename,'sdono','sdono','varchar2','dbbj,dbsj','2,nowdate','','dbbj,dbsj',uptablename,'dbbj=''2''','','','','');
       --grant all table tablename to tc_tools;
    end;
END;
/

