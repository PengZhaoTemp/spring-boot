create function          fun_note_start(lv_sdono varchar2)
  return varchar2 is
  lv_note_start varchar2(500);
  lv_sbusno     varchar2(6);
  lv_booking    varchar2(2);
  lv_note_bo    varchar2(500);
begin
  /*获取短信的头部*/
  /*001  户籍业务    出生申报
  002  户籍业务    死亡注销
  003  户籍业务    户口迁移
  004  户籍业务    入户
  005  户籍业务    立户
  006  户籍业务    销户
  007  户籍业务    项目变更
  008  户籍业务    户内成员与户主关系调整
  020  身份证业务  身份证申领
  021  身份证业务  身份证证件照片采集
  022  身份证业务  身份证换证
  024  身份证业务  身份证丢失补领
  025  身份证业务  身份证领证确认
  030  治安防范    重点单位申报
  040  出入境业务  网上自助申请
  041 出入境业务 在线填表
  042 出入境业务 网上自助受理
  050 网上报警    110网上报警
  061 车管所业务 补领行驶证
  062 车管所业务 补领机动车号牌
  063 车管所业务 补检验合格标志
  064 车管所业务 行驶证通信地址变更
  065 车管所业务 行驶证联系电话变更
  066 车管所业务 机动车检验预约
  067 车管所业务 补领驾驶证
  068 车管所业务 驾驶证通信地址变更
  069 车管所业务 驾驶证联系电话变更
  070 行政复议*/
  select sbusno, nvl(SBOOKING, 0)
    into lv_sbusno, lv_booking
    from tc_webjj.t_dobus
   where sdono = lv_sdono;
  lv_note_bo := '';
  if lv_booking = '1' then
    lv_note_bo := '预约的信息：';
  else
    lv_note_bo := '的信息：';
  end if;
  if lv_sbusno = '001' then
    select '关于' || d.name || '的' || t.sssort || lv_note_bo
      into lv_note_start
      from tc_webjj.v_dobus t, tc_webjj.t_bir_declare d
     where t.sdono = d.sdono
       and t.SDONO = lv_sdono;
  elsif lv_sbusno = '002' then
    select '关于' || d.name || '的' || t.sssort || lv_note_bo
      into lv_note_start
      from tc_webjj.v_dobus t, tc_webjj.t_death_declare d
     where t.sdono = d.sdono
       and t.SDONO = lv_sdono;
  elsif lv_sbusno = '020' or lv_sbusno = '022' or lv_sbusno = '024' then
    select '关于' || d.name || '的' || t.sssort || lv_note_bo
      into lv_note_start
      from tc_webjj.v_dobus t, tc_webjj.t_getpid d
     where t.sdono = d.sdono
       and t.SDONO = lv_sdono;
  elsif lv_sbusno = '003' then
    select '关于' || d.name || '的' || t.sssort || lv_note_bo
      into lv_note_start
      from tc_webjj.v_dobus t, tc_webjj.t_remove_declare d
     where t.sdono = d.sdono
       and t.SDONO = lv_sdono;
  elsif lv_sbusno = '007' then
    select '关于' || d.name || '的' || t.sssort || lv_note_bo
      into lv_note_start
      from tc_webjj.v_dobus t, tc_webjj.t_change_declare d
     where t.sdono = d.sdono
       and t.SDONO = lv_sdono;
  elsif lv_sbusno = '009' then
    select '关于' || d.name || '的' || t.sssort || lv_note_bo
      into lv_note_start
      from tc_webjj.v_dobus t, tc_webjj.t_removetohere_declare d
     where t.sdono = d.sdono
       and t.SDONO = lv_sdono;
  elsif lv_sbusno = '005' then
    select '关于' || d.name || '的' || t.sssort || lv_note_bo
      into lv_note_start
      from tc_webjj.v_dobus t, tc_webjj.T_SW_LIHU_DECLARE d
     where t.sdono = d.sdono
       and t.SDONO = lv_sdono;
  elsif lv_sbusno = '008' then
    select '关于' || d.name || '的' || t.sssort || lv_note_bo
      into lv_note_start
      from tc_webjj.v_dobus t, tc_webjj.T_CHANGE_RELATION d
     where t.sdono = d.sdono
       and t.SDONO = lv_sdono;
  elsif lv_sbusno = '061' then
    select '关于' || d.SCAR_NAME || '的' || t.sssort || lv_note_bo
      into lv_note_start
      from tc_webjj.v_dobus t, tc_webjj.t_cgs_blxsz d
     where t.sdono = d.sdono
       and t.SDONO = lv_sdono;
  elsif lv_sbusno = '062' then
    select '关于' || d.SCAR_NAME || '的' || t.sssort || lv_note_bo
      into lv_note_start
      from tc_webjj.v_dobus t, tc_webjj.t_cgs_bljdchp d
     where t.sdono = d.sdono
       and t.SDONO = lv_sdono;
  elsif lv_sbusno = '063' then
    select '关于' || d.SCAR_NAME || '的' || t.sssort || lv_note_bo
      into lv_note_start
      from tc_webjj.v_dobus t, tc_webjj.t_cgs_bljyhgbz d
     where t.sdono = d.sdono
       and t.SDONO = lv_sdono;
  elsif lv_sbusno = '064' then
    select '关于' || d.SCAR_NAME || '的' || t.sssort || lv_note_bo
      into lv_note_start
      from tc_webjj.v_dobus t, tc_webjj.t_cgs_txdzbg d
     where t.sdono = d.sdono
       and t.SDONO = lv_sdono;
  elsif lv_sbusno = '065' then
    select '关于' || d.SCAR_NAME || '的' || t.sssort || lv_note_bo
      into lv_note_start
      from tc_webjj.v_dobus t, tc_webjj.t_cgs_lxdhbg d
     where t.sdono = d.sdono
       and t.SDONO = lv_sdono;
  elsif lv_sbusno = '066' then
    select '关于' || d.name || '的' || t.sssort || lv_note_bo
      into lv_note_start
      from tc_webjj.v_dobus t, tc_webjj.T_CHANGE_RELATION d
     where t.sdono = d.sdono
       and t.SDONO = lv_sdono;
  elsif lv_sbusno = '070' then
    select '关于' || d.S_NAME || '的' || t.sssort || lv_note_bo
      into lv_note_start
      from tc_webjj.v_dobus t, tc_webjj.t_xzfy_sq d
     where t.sdono = d.sdono
       and t.SDONO = lv_sdono;
  end if;

  return(lv_note_start);
end fun_note_start;

/

