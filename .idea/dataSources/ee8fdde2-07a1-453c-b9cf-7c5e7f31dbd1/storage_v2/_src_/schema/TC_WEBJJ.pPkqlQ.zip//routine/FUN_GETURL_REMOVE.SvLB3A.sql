create function          fun_geturl_remove(lvsdono varchar2)
  return varchar2 is
  lvsurl       varchar2(500);
  lv_PID       varchar2(18);
  lv_NAME      varchar2(50);
  lv_APP_PID   varchar2(18);
  lv_APP_NAME  varchar2(50);
  lv_count     number;
  lv_person_id number;
  lv_hu_id     number;
  lv_bd_type   varchar2(20);
  lv_send_flag varchar2(50);
begin
  /*    迁出市外
  transouthubysheet.jsp?opr_type=迁出市外&bd_type=投靠
  &person_id=2364&hu_id=744&stuff=@(LVNCL_ID:765)(LVNCL_NAME:准迁证)@
  */
  lvsurl   := '';
  lv_count := 0;
  select PID, NAME, APP_PID, APP_NAME
    into lv_PID, lv_NAME, lv_APP_PID, lv_APP_NAME
    from tc_webjj.t_remove_declare
   where sdono = lvsdono;
  select count(*)
    into lv_count
    from ccic_data.tbn_data c
   where c.sidentityid in (lv_PID, lv_APP_PID);
  if lv_count > 0 then
    return 'ccic_false'; --'ccic人员';
  end if;
  select count(*)
    into lv_count
    from TC_RKXT.v_tp_huji_ck m
   where 1 = 1
     and pid = lv_pid
     and name = lv_name;
  if lv_count = 0 then
    return 'ck_false'; --'常口不存在出错';
  end if;
  select count(*)
    into lv_count
    from TC_RKXT.v_tp_huji_ck m
   where 1 = 1
     and pid = lv_APP_PID
     and name = lv_APP_NAME;
  if lv_count = 0 then
    return 'app_false'; --'申请人不存在出错';
  end if;
  select hu_id, person_id
    into lv_hu_id, lv_person_id
    from tc_rkxt.v_tp_huji_ck
   where pid = lv_pid
     and name = lv_name;
  select app_type
    into lv_bd_type
    from tc_webjj.t_remove_declare
   where sdono = lvsdono;
  lvsurl := '=' || lv_bd_type;
  lvsurl := lvsurl || '=' || lv_person_id;
  lvsurl := lvsurl || '=' || lv_hu_id;
  lvsurl := lvsurl || '=' || lvsdono;
  select need_back
    into lv_send_flag
    from tc_webjj.v_dobus
   where sdono = lvsdono;
  if lv_send_flag = '需回寄' then
    lvsurl := lvsurl || '=1';
  else
    lvsurl := lvsurl || '=0';
  end if;
  return(lvsurl);
end fun_geturl_remove;

/

