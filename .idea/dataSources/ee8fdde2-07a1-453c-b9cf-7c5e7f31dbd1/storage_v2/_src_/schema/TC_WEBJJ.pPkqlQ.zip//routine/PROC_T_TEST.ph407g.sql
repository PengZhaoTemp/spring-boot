create PROCEDURE          PROC_t_test   /*T_TEST*/
(
 lvusername IN OUT VARCHAR2,  --姓　　名
 lvuserage VARCHAR2,  --年纪
 lvusersex VARCHAR2,  --性别
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS

BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/



   INSERT into tc_webjj.t_test
    (
      username,   --姓　　名
      userage,   --年纪
      usersex    --性别
    )values(
      lvusername,   --姓　　名
      lvuserage,   --年纪

      lvusersex    --性别


    );
   -- 返回值

END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_test
    Set
      username=lvusername,   --姓　　名
      userage=lvuserage,   --年纪
      usersex=lvusersex    --性别
    Where 1=1
    and username=lvusername   --姓　　名
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_test
    Set
      username=lvusername,   --姓　　名
      userage=lvuserage,   --年纪
      usersex=lvusersex    --性别
    Where 1=1
    and username=lvusername   --姓　　名
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_test
    Where 1=1
    and username=lvusername   --姓　　名
    ;
END IF;
 Commit;
END; /*存储过程结束*/

