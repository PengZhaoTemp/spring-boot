create trigger DOBUSTOTEMP
  after insert or update
  on T_DOBUS
  for each row
  declare
    integrity_error exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;
    nsdono          varchar2(36);
    nstate          varchar2(2);
    nname           varchar2(30);
    npid            varchar2(18);
    ncount          integer;
PRAGMA AUTONOMOUS_TRANSACTION;
begin
if inserting then
    select count(1)  INTO ncount from tc_webjj.t_gab_source where userName=:NEW.sappname AND pid=:NEW.SAPPPID and phone=:NEW.sapptel;
    if ncount > 0 then
        insert into tc_webjj.t_dobus_info_temp(temp_sdono,temp_state,temp_name,temp_pid) values(:NEW.sdono,:NEW.state,:NEW.sappname,:new.sapppid);
    end if;
elsif updating then
    select count(1)  INTO ncount from tc_webjj.t_bus_complete_record where sdono = :OLD.sdono;
    if :NEW.state = '43' and ncount < 1 then
       insert into tc_webjj.t_bus_complete_record(sdono,suserno,last_operation_date,estimate_del_date,handle) 
        select a.sdono sdono,a.suserno suserno,decode(b.dendtime,null,sysdate,b.dendtime) last_operation_date,(decode(b.dendtime,null,sysdate,b.dendtime)+7) estimate_del_date,'0' handle
         from t_dobus a,t_busflow_plan b, t_busflow_deploy c
           where 1=1
             and a.sdono = b.sdono
             and b.sflowno = c.sflowno
             and c.soperationno = '4301001000000050'
             and a.sdono = :OLD.sdono
             and b.scomplete = '1';
    end if;
    --更新公安部信息
    update tc_webjj.t_dobus_info_temp set temp_sdono=:NEW.sdono,temp_state=:NEW.state,temp_name=:NEW.sappname,temp_pid=:NEW.sapppid,temp_flag='0' where temp_sdono=:OLD.sdono;
    end if;
COMMIT;
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
/

