create view V_APPLYMASTERIALS_TYPE as
  SELECT SNO,
       SBUSNO,
       SITEMTYPE,
       SITEMDEMO,
       EXECTYPE,
       DECODE(EXECTYPE, '1', '上传图片', '2', '寄送原件', '3', '上传和寄送') EXECTYPECN,
       SBUSTYPE,
       DECODE(SBUSTYPE, '0', '个人业务材料', '1', '企业业务材料', '') SBUSTYPECN,
       SFLAG,
       DECODE(SFLAG,'0','已注销','1','有效') SFLAGCN,
       SLOGO
  FROM TC_WEBJJ.T_APPLYMASTERIALS_TYPE ORDER BY SNO
/

