create PROCEDURE          PROC_t_yhwh_sq   /*T_YHWH_SQ*/
(
 lvsdono IN OUT VARCHAR2,  --业务编号
 lvsaddr VARCHAR2,  --活动地点
 lvshjms VARCHAR2,  --环境描述
 lvdtime DATE,  --活动时间
 lvsxz VARCHAR2,  --活动性质
 lvsgm VARCHAR2,  --活动规模
 lvsrfzy_fa VARCHAR2,  --燃放作业方案
 lvsq_name varchar2,
 lvsq_pid varchar2,
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS

BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/



   INSERT into tc_webjj.t_yhwh_sq
    (
      sdono,   --业务编号
      saddr,   --活动地点
      shjms,   --环境描述
      dtime,   --活动时间
      sxz,   --活动性质
      sgm,   --活动规模
      srfzy_fa,    --燃放作业方案
      sq_name,
      sq_pid,
      dbbj,
      dbsj
    )values(
      lvsdono,   --业务编号
      lvsaddr,   --活动地点
      lvshjms,   --环境描述
      lvdtime,   --活动时间
      lvsxz,   --活动性质
      lvsgm,   --活动规模

      lvsrfzy_fa,    --燃放作业方案
      lvsq_name,
      lvsq_pid,
      '0',
      sysdate

    );
   -- 返回值

END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_yhwh_sq
    Set
      sdono=lvsdono,   --业务编号
      saddr=lvsaddr,   --活动地点
      shjms=lvshjms,   --环境描述
      dtime=lvdtime,   --活动时间
      sxz=lvsxz,   --活动性质
      sgm=lvsgm,   --活动规模
      srfzy_fa=lvsrfzy_fa ,   --燃放作业方案
      sq_name=lvsq_name,
      sq_pid=lvsq_pid,
      dbbj='0',
      dbsj=sysdate
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_yhwh_sq
    Set
      sdono=lvsdono,   --业务编号
      saddr=lvsaddr,   --活动地点
      shjms=lvshjms,   --环境描述
      dtime=lvdtime,   --活动时间
      sxz=lvsxz,   --活动性质
      sgm=lvsgm,   --活动规模
      srfzy_fa=lvsrfzy_fa,    --燃放作业方案
      sq_name=lvsq_name,
      sq_pid=lvsq_pid,
      dbbj='0',
      dbsj=sysdate
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_yhwh_sq
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

