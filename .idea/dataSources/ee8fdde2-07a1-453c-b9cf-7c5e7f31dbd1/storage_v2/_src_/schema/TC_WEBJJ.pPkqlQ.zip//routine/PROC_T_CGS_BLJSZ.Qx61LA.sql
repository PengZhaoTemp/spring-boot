create PROCEDURE          PROC_t_cgs_bljsz   /*T_CGS_BLJSZ*/
(
 lvsdono IN OUT VARCHAR2,  --办理编号
 lvsdabh VARCHAR2,  --档案编号
 lvsname VARCHAR2,  --姓　　名
 lvssex VARCHAR2,  --性　　别
 lvspid VARCHAR2,  --身份证号码
 lvsaddress VARCHAR2,  --身份证地址
 lvstel VARCHAR2,  -- 联系电话
 lvszjcx VARCHAR2,  --准驾车型
 lvsbl_reason VARCHAR2,  --补领原因
 lvspic VARCHAR2,  --近期六个月照片
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS

BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/



   INSERT into tc_webjj.t_cgs_bljsz
    (
      sdono,   --办理编号
      sdabh,   --档案编号
      sname,   --姓　　名
      ssex,   --性　　别
      spid,   --身份证号码
      saddress,   --身份证地址
      stel,   -- 联系电话
      szjcx,   --准驾车型
      sbl_reason,   --补领原因
      spic
    )values(
      lvsdono,   --办理编号
      lvsdabh,   --档案编号
      lvsname,   --姓　　名
      lvssex,   --性　　别
      lvspid,   --身份证号码
      lvsaddress,   --身份证地址
      lvstel,   -- 联系电话
      lvszjcx,   --准驾车型
      lvsbl_reason,  --补领原因
      lvspic



    );
   -- 返回值

END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_cgs_bljsz
    Set
      sdono=lvsdono,   --办理编号
      sdabh=lvsdabh,   --档案编号
      sname=lvsname,   --姓　　名
      ssex=lvssex,   --性　　别
      spid=lvspid,   --身份证号码
      saddress=lvsaddress,   --身份证地址
      stel=lvstel,   -- 联系电话
      szjcx=lvszjcx,   --准驾车型
      sbl_reason=lvsbl_reason   --补领原因

    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_cgs_bljsz
    Set
      sdono=lvsdono,   --办理编号
      sdabh=lvsdabh,   --档案编号
      sname=lvsname,   --姓　　名
      ssex=lvssex,   --性　　别
      spid=lvspid,   --身份证号码
      saddress=lvsaddress,   --身份证地址
      stel=lvstel,   -- 联系电话
      szjcx=lvszjcx,   --准驾车型
      sbl_reason=lvsbl_reason   --补领原因

    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_cgs_bljsz
    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

