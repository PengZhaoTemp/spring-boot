create view V_DOBUS_COUNT as
  select
    a.personid as personid,
    (select count(1) from tc_webjj.t_dobus where suserno = a.personid and sbusdotype ='2') as yy_count,
    (select count(1) from tc_webjj.t_dobus where suserno = a.personid and sbusdotype ='1') as sb_count,
    (select count(1) from tc_webjj.t_dobus where suserno = a.personid and sbusdotype ='3') as cx_count,
    '0' as ly_count
  from tc_webjj.t_commoner a
  where length(a.spwd) >20 and a.shome_phone not like '%X'
/

