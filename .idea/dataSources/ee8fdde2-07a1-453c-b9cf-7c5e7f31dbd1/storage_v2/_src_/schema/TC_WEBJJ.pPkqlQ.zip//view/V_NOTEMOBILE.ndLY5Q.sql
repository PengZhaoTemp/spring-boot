create view V_NOTEMOBILE as
  select snoteno,
       a.suserno,
       a.sdono,
       b.sdodata,
       snote,
       to_char(dsenddate, 'yyyy-mm-dd hh24:mi:ss') dsenddate,
       sreadflag,
      '<div align=center>'||decode(sreadflag,'0','<img src=/webjjcss/newmsgstatus.gif title=\"未读\" />','1','<img src=/webjjcss/msgreaded.gif title=\"已读\"/>')||'</div>' as sreadflagimg
  from tc_webjj.t_notemobile a,tc_webjj.t_dobus b
 where 1 = 1
   and a.sdono is not null
   and a.sdono = b.sdono
 order by sreadFlag, dsenddate desc
/

