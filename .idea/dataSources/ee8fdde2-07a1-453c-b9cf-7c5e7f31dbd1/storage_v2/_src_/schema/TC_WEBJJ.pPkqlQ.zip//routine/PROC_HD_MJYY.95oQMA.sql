create procedure          proc_hd_mjyy(lv_SID   in out number,
                                         lv_SPOILCE_ID  varchar2,
                                         lv_SPID        varchar2,
                                         lv_SNAME       varchar2,
                                         lv_STEL      varchar2,
                                         lv_DDATE       varchar2,
                                         lv_SDETAIL       varchar2,
                                         lv_PERSONID     varchar2,
                                         lv_ProcMode     varchar2,
                                         lv_msg_return   in out varchar2 )as
 lv_count number;

 begin
 if lv_ProcMode='PMINSERT' then
    select  TC_WEBJJ.SEQ_HD_appointment.nextval into lv_SID from dual;
    insert into TC_WEBJJ.T_HD_POLICE_appointment
    (SID,
     SPOILCE_ID,
     SPID,
     SNAME,
     STEL,
     DDATE,
     SDETAIL,
     SPERSONID)
     values
     (lv_SID,
     lv_SPOILCE_ID,
     lv_SPID,
     lv_SNAME,
     lv_STEL,
     to_date(lv_DDATE,'yyyy-mm-dd') ,
     lv_SDETAIL,
     lv_PERSONID);
     lv_msg_return:='操作成功';
elsif  lv_ProcMode='PMCANCEL' then
 update TC_WEBJJ.T_HD_POLICE_appointment set sstatus='1',dbbj='0' where sid=lv_SID;
 lv_msg_return:='取消成功';
 else
 lv_msg_return:='存储过程错误';
 end if;
     commit;
     end proc_hd_mjyy;

/

