create PROCEDURE          PROC_t_chargecenter_wfjkcharge(
 lvschargeno IN OUT VARCHAR2,  --支付编号
 lvsdono VARCHAR2,  --办理编号
 lvsuserno VARCHAR2,  --用户编码
 lvsaccounts VARCHAR2,  --账　　号
 lvsdealacc VARCHAR2,  --交易账号
 lvnmoney NUMBER,  --金　　额
 lvsmemo VARCHAR2,  --备　　注
 lvddealdate DATE,  --交易时间
 lvsemssend varchar2,--是否寄送
 lvsbooking varchar2,--是否预约
 lvmerabbr  varchar2,--商户名称
 lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
lvflowstep number;
lvsbusno varchar2(5);
lvflownote number;
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
    Select tc_webjj.fun_get16code(tc_WEBJJ.SEQ_T_CHARGECENTER_SCHARGENO.Nextval)  into lvschargeno From dual;    /*支付编号序列*/
    select flowstep+1,sbusno into lvflowstep,lvsbusno from tc_webjj.v_dobus where sdono=lvsdono;
    select busflowno into lvflownote from tc_webjj.t_bus_flow where sbusno = lvsbusno and flowstep=lvflowstep;
    UPDATE tc_webjj.t_dobus
    set
      state='21',
     dbbj='0',
     dbsj=sysdate,
     flownote = lvflownote
    where sdono=lvsdono;

   INSERT into tc_webjj.t_chargecenter
    (
      schargeno,   --支付编号
      sdono,   --办理编号
      suserno,   --用户编码
      saccounts,   --账　　号
      sdealacc,   --交易账号
      nmoney,   --金　　额
      smemo,   --备　　注
      ddealdate,   --交易时间
      nsercharge,   --服务资费
      nexpcharge,   --快递资费
      nrecharge,    --回寄资费
      merabbr,
      dbbj,
      dbsj
    )values(
      lvschargeno,   --支付编号
      lvsdono,   --办理编号
      lvsuserno,   --用户编码
      lvsaccounts,   --账　　号
      lvsdealacc,   --交易账号
      lvnmoney,   --金　　额
      lvsmemo,   --备　　注
      sysdate,   --交易时间
      '0',   --服务资费
      '0',   --快递资费
      '0',    --回寄资费
      lvmerabbr,
      '0',
      sysdate
    );
   -- 返回值
END IF;

 Commit;
END; /*存储过程结束*/

