create view V_KDXXCXST as
  select to_char(A.ddate, 'yyyy-mm-dd hh24:mi:ss') ddate,
       a.sdono,
       a.sexpno,
       a.sexptype,
       b.sdounit,
       b.sconsignee,
       b.srecon,
       b.sappname,
       b.suserno,
       a.ddate ddate_time
  from tc_webjj.t_expressinterface a, tc_webjj.t_dobus b
 where a.sdono = b.sdono
 order by sdono
/

