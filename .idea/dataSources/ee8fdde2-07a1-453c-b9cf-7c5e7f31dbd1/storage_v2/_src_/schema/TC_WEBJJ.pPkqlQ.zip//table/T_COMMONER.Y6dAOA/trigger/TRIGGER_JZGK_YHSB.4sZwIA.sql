create trigger TRIGGER_JZGK_YHSB
  after insert or update
  on T_COMMONER
  for each row
  declare
  -- local variables here
  countv int;
begin
   if :NEW.NAME is not null then
     select count(*) INTO countv from T_JZGK_YHSB where personid = :NEW.PERSONID;
     if countv <= 0 then
       -- update T_JZGK_YHSB set name = :NEW.NAME where personid = :NEW.PERSONID;
       insert into T_JZGK_YHSB(personid,name,create_date,cardno) values(:NEW.PERSONID,:NEW.NAME,:NEW.WHEN_LOGGED,tc_webjj.fun_uncrypkey(:NEW.Pid));
     --else
       --insert into T_JZGK_YHSB(personid,name,create_date) values(:NEW.PERSONID,:NEW.NAME,:NEW.WHEN_LOGGED);
     end if;
  end if;
end trigger_jzgk_yhsb;
/

