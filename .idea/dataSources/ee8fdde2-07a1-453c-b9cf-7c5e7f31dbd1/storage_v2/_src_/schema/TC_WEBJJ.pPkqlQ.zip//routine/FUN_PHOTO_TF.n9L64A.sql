create function          fun_photo_tf(lv_pid varchar2, lv_name varchar2)
  return varchar2 is
  /*检查 是否需要采集人像
      不需要采集照片的情况：
          二代证有效期    采集的人像有效期
           五年            三年
           十年或二十年    五年
           长期            十年
  */
  lvsurl         varchar2(50);
  lv_count       number;
  lv_count_photo number;
  lv_when_logged date; /*照片采集时间*/
  lv_useful_life varchar2(9); /*证件有效期限*/
  lv_person_id   varchar2(30);
  lv_image_id    number;
begin
  lvsurl := 'need';
  select person_id
    into lv_person_id
    from tc_rkxt.t_person
   where pid = lv_pid
     and name = lv_name;
  lv_count := 0;
  select count(*)
    into lv_count
    from tc_rkxt.t_pid_info
   where card_status = '有效'
     and pid_kind = '2'
     and person_id = lv_person_id;
  if lv_count = 0 then
    --没办理过二代证
    return 'need'; --需采集
  end if;
  if lv_count = 1 then
    --有办理过
    select image_id, useful_life
      into lv_image_id, lv_useful_life
      from tc_rkxt.t_pid_info
     where card_status = '有效'
       and pid_kind = '2'
       and person_id = lv_person_id; --取得二代证期限和图片编号
    select count(*)
      into lv_count_photo
      from tc_rkxt.t_photo
     where photo_id = lv_image_id; --取得图片采集时间
    if lv_count_photo > 0 then
      select max(when_registered)
        into lv_when_logged
        from tc_rkxt.t_photo
       where photo_id = lv_image_id; --取得图片采集时间
      if lv_useful_life = '5年' then
        if floor((sysdate - lv_when_logged) / 365) < 3 then
          return 'noneed';
        else
          return 'need';
        end if;
      elsif lv_useful_life = '10年' or lv_useful_life = '20年' then
        if floor((sysdate - lv_when_logged) / 365) < 5 then
          return 'noneed';
        else
          return 'need';
        end if;
      elsif lv_useful_life = '长期' then
        if floor((sysdate - lv_when_logged) / 365) < 10 then
          return 'noneed';
        else
          return 'need';
        end if;
      else
        return 'need';
      end if;
    else
      return 'need'; --数据库中没有照片数据
    end if;
  end if;
  return(lvsurl);
end fun_photo_tf;

/

