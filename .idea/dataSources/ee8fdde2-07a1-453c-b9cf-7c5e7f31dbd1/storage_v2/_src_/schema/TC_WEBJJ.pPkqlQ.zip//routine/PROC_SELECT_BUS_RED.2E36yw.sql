create procedure          PROC_SELECT_BUS_RED
(
ssnodo VARCHAR2,---------红点的存储过程
ssuerno VARCHAR2

) as
begin
  update  tc_webjj.T_SELECT_BUS set  READTYPE ='1' where  SDONO=ssnodo  and  SUERNO=ssuerno;
  commit;

end PROC_SELECT_BUS_RED;

/

