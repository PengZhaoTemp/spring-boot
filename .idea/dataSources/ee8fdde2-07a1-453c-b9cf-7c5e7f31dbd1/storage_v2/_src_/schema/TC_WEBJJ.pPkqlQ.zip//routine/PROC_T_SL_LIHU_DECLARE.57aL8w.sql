create PROCEDURE          PROC_t_sl_lihu_declare   /*t_sl_lihu_declare*/
(
 lvsdono IN OUT VARCHAR2,  --业务编号
 lvmaster_relation VARCHAR2,  --与户主关系
 lvhu_kind_name VARCHAR2,  --户别：集体户 家庭户
 lvchange_reason VARCHAR2,  --变动原因
 lvaddr varchar2,--立户地址
 lvqu varchar2,--立户区县
 lvtoponym varchar2,--立户所在地
 lvname VARCHAR2,  --姓　　名
 lvpid VARCHAR2,  --公民身份证
 lvapp_name VARCHAR2,  --申请人姓名
 lvapp_pid VARCHAR2,  --申请人身份证
 lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
   INSERT into tc_webjj.t_sl_lihu_declare
    (
      sdono,   --业务编号
      master_relation,   --与户主关系
      hu_kind_name,   --户别：集体户 家庭户
      change_reason,   --变动原因
      addr,
      qu,
      toponym,
      name,   --姓　　名
      pid,   --公民身份证
      app_name,   --申请人姓名
      app_pid  --申请人身份证
    )values(
      lvsdono,  --业务编号
     lvmaster_relation,  --与户主关系
     lvhu_kind_name,  --户别：集体户 家庭户
     lvchange_reason,  --变动原因
     lvaddr,--立户地址
     lvqu,--立户区县
     lvtoponym,--立户所在地
     lvname,  --姓　　名
     lvpid,  --公民身份证
     lvapp_name,  --申请人姓名
     lvapp_pid  --申请人身份证
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_sl_lihu_declare
    Set
      sdono=lvsdono,   --业务编号
      master_relation=lvmaster_relation,   --与户主关系
      hu_kind_name=lvhu_kind_name,   --户别：集体户 家庭户
      change_reason=lvchange_reason,   --变动原因
      addr=lvaddr,
      qu=lvqu,
      toponym=lvtoponym,
      name=lvname,   --姓　　名
      pid=lvpid,   --公民身份证
      app_name=lvapp_name,   --申请人姓名
      app_pid=lvapp_pid   --申请人身份证
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_sl_lihu_declare
    Set
      sdono=lvsdono,   --业务编号
      master_relation=lvmaster_relation,   --与户主关系
      hu_kind_name=lvhu_kind_name,   --户别：集体户 家庭户
      change_reason=lvchange_reason,   --变动原因
      addr=lvaddr,
      qu=lvqu,
      toponym=lvtoponym,
      name=lvname,   --姓　　名
      pid=lvpid,   --公民身份证
      app_name=lvapp_name,   --申请人姓名
      app_pid=lvapp_pid   --申请人身份证
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_sl_lihu_declare
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

