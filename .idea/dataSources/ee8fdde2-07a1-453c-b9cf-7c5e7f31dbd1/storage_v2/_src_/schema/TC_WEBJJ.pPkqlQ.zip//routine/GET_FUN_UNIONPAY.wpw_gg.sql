create function get_fun_unionpay(lv_name varchar2,lv_type varchar2) return varchar2 is
  lv_res varchar2(100);
begin

  if lv_type='1' then

    select sbusname into lv_res  from tc_webjj.t_bus_deploy where sbusno=lv_name and sstatus='开通' and rownum<2;

  end if;
  --查询对应支付机构名称
  if lv_type='2' then
    --select  orgname into lv_res from tc_jcyw.t_org where sunit_code =substr(lv_name,0,6)||'000000' and DCANCEL_APP_DATE is null and rownum<2;
    select dzorgname into lv_res from TC_JCYW.t_zfdz_org where orgid = lv_name;

  end if;
  
  if lv_type='3' then

    select  cz_code into lv_res from tc_jcyw.t_cz_org where hlw_code =substr(lv_name,0,6)||'000000' and rownum<2;

  end if;
  --查询对应支付机构编码
  if lv_type='4' then

     select dzorgid into lv_res from TC_JCYW.t_zfdz_org where orgid = lv_name;

  end if;
  
  return(lv_res);
end;
/

