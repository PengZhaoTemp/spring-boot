create PROCEDURE          PROC_t_bir_declare /*出生申报表*/

(

 lvhu_master_name  VARCHAR2, --户主姓名

 lvhu_master_pid VARCHAR2, --户主公民身份号码

 lvmaster_relation VARCHAR2, --与户主关系

 lvwhen_logged DATE, --与与户主关系创建时间

 lvpid VARCHAR2, --公民身份号码

 lvname VARCHAR2, --姓　　名

 lvgender VARCHAR2, --性　　别

 lvused_name VARCHAR2, --曾  用 名

 lvnation VARCHAR2, --民　　族

 lvnative_country VARCHAR2, --籍贯（国家地区）

 lvnative_place VARCHAR2, --籍贯（省市县区）

 lvdob DATE, --出生日期

 lvdob_time VARCHAR2, --出生时间

 lvnatal_country VARCHAR2, --出生地（国家地区）

 lvnatal_place VARCHAR2, --出生地（省市县区）

 lvnatal_xiang VARCHAR2, --出生地详址

 lvgurardian_1_id NUMBER, --监护人1编号

 lvgurardian_1_pid VARCHAR2, --监护人1公民身份号码

 lvgurardian_1 VARCHAR2, --监护人1姓名

 lvwardship_1 VARCHAR2, --与监护人1关系

 lvgurardian_2_id NUMBER, --监护人2编号

 lvgurardian_2_pid VARCHAR2, --监护人2公民身份号码

 lvgurardian_2 VARCHAR2, --监护人2姓名

 lvwardship_2 VARCHAR2, --与监护人2关系

 lvfa_person_id NUMBER, --父亲人员编号

 lvfa_pid VARCHAR2, --父亲公民身份号码

 lvfa_name VARCHAR2, --父亲姓名

 lvma_person_id NUMBER, --母亲人员编号

 lvma_pid VARCHAR2, --母亲公民身份号码

 lvma_name VARCHAR2, --母亲姓名

 lvbloodtype VARCHAR2, --血　　型

 lvscontact VARCHAR2, --联系方式

 lvin_category VARCHAR2, --出生原因

 lvborn_card_no VARCHAR2, --出生证号码

 lvnatal_card_date DATE, --出生证签发日期

 lvwhen_in DATE, --出生申报时间

 lvsend_hu NUMBER, --是否要打印户口本

 lvin_hu_kind VARCHAR2, --落户类型

 lvin_app_name varchar2,--申请人姓名

 lvin_app_pid varchar2,--申请人身份证号
 lvmemo varchar2,--备注
 lvsdono IN OUT VARCHAR2, --办理编号

 lvsbusno VARCHAR2,  --业务编码
 lvsdounit VARCHAR2,  --办理单位
 lvsdounitno VARCHAR2,  --办理单位编码
 lvsuserno VARCHAR2,  --用户编码
 lvstate IN OUT VARCHAR2,  --状　　态
 lvsbooking VARCHAR2,  --是否预约
 lvdbookingdate DATE,  --预约时间
 lvsnotealert VARCHAR2,  --是否短信提醒
 lvncharge NUMBER,  --支付金额
 lvnsercharge NUMBER,  --服务资费
 lvnexpcharge NUMBER,  --快递资费
 lvnrecharge NUMBER,  --回寄资费
 lvsexpno VARCHAR2,  --快递单号
 lvsexpaddress VARCHAR2,  --快递地址
 lvsexppostcode VARCHAR2,  --快递地址邮政编码
 lvsconsignee VARCHAR2,  --收  件 人
 lvscontel VARCHAR2,  --收件人联系电话
 lvsnetbus VARCHAR2,  --是否网上下单
 lvsreno VARCHAR2,  --回寄快递单号
 lvsreaddress VARCHAR2,  --回寄地址
 lvsrepostcode VARCHAR2,  --回寄地址邮政编码
 lvsrecon VARCHAR2,  --回寄收件人
 lvsrecontel VARCHAR2,  --回寄收件人联系电话
 lvddecdate DATE,  --申报时间
 lvschecker VARCHAR2,  --审  核 人
 lvdcheckdate DATE,  --审核时间
 lvsacceptman VARCHAR2,  --受  理 人
 lvsacceptdate DATE,  --受理时间
 lvsunreason VARCHAR2,  --退回原因
 lvsopinion VARCHAR2,  --评价内容
 lvsserattitude VARCHAR2,  --服务态度得分
 lvsefficiency VARCHAR2,  --办事效率得分
 lvssatisfaction VARCHAR2,  --满  意 度
 lvsopdate DATE,  --评价时间
 --lvsdodata varchar2,--业务数据概要
 lvsprocity varchar2,--回寄地址
 lvaddress varchar2,--回寄详细地址
 lvsreems IN OUT varchar2,--是否回寄材料
 lvsemssend varchar2,
 lv_ProcMode Varchar2, /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
 lv_ProcFlag varchar2 --区别是保存还是提交
 )

 AS

BEGIN


  --begin TRAN
  IF lv_ProcFlag='PMSAVE' THEN
      lvstate:='10';
    ELSIF lv_ProcFlag='PMSUBMIT'  THEN
      lvstate:='11';
       IF lvncharge=0 THEN
       lvstate:='20';
        END IF;
     END IF;

  IF lv_procMode = 'PMINSERT' THEN
    /*登记*/

    INSERT into tc_webjj.t_bir_declare

      (
       sdono,--业务编号
       hu_master_name, --户主姓名

       hu_master_pid, --户主公民身份号码

       master_relation, --与户主关系

       when_logged, --与与户主关系创建时间

       pid, --公民身份号码

       name, --姓　　名

       gender, --性　　别

       used_name, --曾  用 名

       nation, --民　　族

       native_country, --籍贯（国家地区）

       native_place, --籍贯（省市县区）

       dob, --出生日期

       dob_time, --出生时间

       natal_country, --出生地（国家地区）

       natal_place, --出生地（省市县区）

       natal_xiang, --出生地详址

       gurardian_1_id, --监护人1编号

       gurardian_1_pid, --监护人1公民身份号码

       gurardian_1, --监护人1姓名

       wardship_1, --与监护人1关系

       gurardian_2_id, --监护人2编号

       gurardian_2_pid, --监护人2公民身份号码

       gurardian_2, --监护人2姓名

       wardship_2, --与监护人2关系

       fa_person_id, --父亲人员编号

       fa_pid, --父亲公民身份号码

       fa_name, --父亲姓名

       ma_person_id, --母亲人员编号

       ma_pid, --母亲公民身份号码

       ma_name, --母亲姓名

       bloodtype, --血　　型

       scontact, --联系方式

       in_category, --出生原因

       born_card_no, --出生证号码

       natal_card_date, --出生证签发日期

       when_in, --出生申报时间

       send_hu, --是否要打印户口本

       in_hu_kind,--落户类型
       in_app_name,
       in_app_pid ,
       memo
      )
    values
      (
       lvsdono,
       lvhu_master_name, --户主姓名

       lvhu_master_pid, --户主公民身份号码

       lvmaster_relation, --与户主关系

       sysdate, --与与户主关系创建时间

       lvpid, --公民身份号码

       lvname, --姓　　名

       lvgender, --性　　别

       lvused_name, --曾  用 名

       lvnation, --民　　族

       lvnative_country, --籍贯（国家地区）

       lvnative_place, --籍贯（省市县区）

       lvdob, --出生日期

       lvdob_time, --出生时间

       lvnatal_country, --出生地（国家地区）

       lvnatal_place, --出生地（省市县区）

       lvnatal_xiang, --出生地详址

       lvgurardian_1_id, --监护人1编号

       lvgurardian_1_pid, --监护人1公民身份号码

       lvgurardian_1, --监护人1姓名

       lvwardship_1, --与监护人1关系

       lvgurardian_2_id, --监护人2编号

       lvgurardian_2_pid, --监护人2公民身份号码

       lvgurardian_2, --监护人2姓名

       lvwardship_2, --与监护人2关系

       lvfa_person_id, --父亲人员编号

       lvfa_pid, --父亲公民身份号码

       lvfa_name, --父亲姓名

       lvma_person_id, --母亲人员编号

       lvma_pid, --母亲公民身份号码

       lvma_name, --母亲姓名

       lvbloodtype, --血　　型

       lvscontact, --联系方式

       lvin_category, --出生原因

       lvborn_card_no, --出生证号码

       lvnatal_card_date, --出生证签发日期

       lvwhen_in, --出生申报时间

       lvsend_hu, --是否要打印户口本

       lvin_hu_kind, --落户类型
       lvin_app_name,
       lvin_app_pid,
       lvmemo
       );
        INSERT into tc_webjj.t_dobus
    (
      sdono,   --办理编号
      sbusno,   --业务编码
      sdounit,   --办理单位
      sdounitno,   --办理单位编码
      suserno,   --用户编码
      state,   --状　　态
      sbooking,   --是否预约
      dbookingdate,   --预约时间
      snotealert,   --是否短信提醒
      ncharge,   --支付金额
      nsercharge,   --服务资费
      nexpcharge,   --快递资费
      nrecharge,   --回寄资费
      sexpno,   --快递单号
      sexpaddress,   --快递地址
      sexppostcode,   --快递地址邮政编码
      sconsignee,   --收  件 人
      scontel,   --收件人联系电话
      snetbus,   --是否网上下单
      sreno,   --回寄快递单号
      sreaddress,   --回寄地址
      srepostcode,   --回寄地址邮政编码
      srecon,   --回寄收件人
      srecontel,   --回寄收件人联系电话
      ddecdate,   --申报时间
      schecker,   --审  核 人
      dcheckdate,   --审核时间
      sacceptman,   --受  理 人
      sacceptdate,   --受理时间
      sunreason,   --退回原因
      sopinion,   --评价内容
      sserattitude,   --服务态度得分
      sefficiency,   --办事效率得分
      ssatisfaction,   --满  意 度
      sopdate,   --评价时间
      sdodata,
      sprocity,
      address,
      sreems,
      semssend
    )values(
      lvsdono,   --办理编号
      lvsbusno,   --业务编码
      lvsdounit,   --办理单位
      lvsdounitno,   --办理单位编码
      lvsuserno,   --用户编码
      lvstate,   --状　　态
      lvsbooking,   --是否预约
      lvdbookingdate,   --预约时间
      lvsnotealert,   --是否短信提醒
      lvncharge,   --支付金额
      lvnsercharge,   --服务资费
      lvnexpcharge,   --快递资费
      lvnrecharge,   --回寄资费
      lvsexpno,   --快递单号
      lvsexpaddress,   --快递地址
      lvsexppostcode,   --快递地址邮政编码
      lvsconsignee,   --收  件 人
      lvscontel,   --收件人联系电话
      lvsnetbus,   --是否网上下单
      lvsreno,   --回寄快递单号
      lvsprocity||lvaddress,   --回寄地址
      lvsrepostcode,   --回寄地址邮政编码
      lvsrecon,   --回寄收件人
      lvsrecontel,   --回寄收件人联系电话
      sysdate,   --申报时间
      lvschecker,   --审  核 人
      lvdcheckdate,   --审核时间
      lvsacceptman,   --受  理 人
      lvsacceptdate,   --受理时间
      lvsunreason,   --退回原因
      lvsopinion,   --评价内容
      lvsserattitude,   --服务态度得分
      lvsefficiency,   --办事效率得分
      lvssatisfaction,   --满  意 度

      lvsopdate,    --评价时间
      '出生儿：'||lvname,
      lvsprocity,
      lvaddress,
      lvsreems,
      lvsemssend
    );

    -- 返回值

  END IF;

  IF lv_procMode = 'PMUPDATE' THEN
    /*更新*/

    UPDATE tc_webjj.t_bir_declare

       Set hu_master_name = lvhu_master_name, --户主姓名

           hu_master_pid = lvhu_master_pid, --户主公民身份号码

           master_relation = lvmaster_relation, --与户主关系

           when_logged = lvwhen_logged, --与与户主关系创建时间

           pid = lvpid, --公民身份号码

           name = lvname, --姓　　名

           gender = lvgender, --性　　别

           used_name = lvused_name, --曾  用 名

           nation = lvnation, --民　　族

           native_country = lvnative_country, --籍贯（国家地区）

           native_place = lvnative_place, --籍贯（省市县区）

           dob = lvdob, --出生日期

           dob_time = lvdob_time, --出生时间

           natal_country = lvnatal_country, --出生地（国家地区）

           natal_place = lvnatal_place, --出生地（省市县区）

           natal_xiang = lvnatal_xiang, --出生地详址

           gurardian_1_id = lvgurardian_1_id, --监护人1编号

           gurardian_1_pid = lvgurardian_1_pid, --监护人1公民身份号码

           gurardian_1 = lvgurardian_1, --监护人1姓名

           wardship_1 = lvwardship_1, --与监护人1关系

           gurardian_2_id = lvgurardian_2_id, --监护人2编号

           gurardian_2_pid = lvgurardian_2_pid, --监护人2公民身份号码

           gurardian_2 = lvgurardian_2, --监护人2姓名

           wardship_2 = lvwardship_2, --与监护人2关系

           fa_person_id = lvfa_person_id, --父亲人员编号

           fa_pid = lvfa_pid, --父亲公民身份号码

           fa_name = lvfa_name, --父亲姓名

           ma_person_id = lvma_person_id, --母亲人员编号

           ma_pid = lvma_pid, --母亲公民身份号码

           ma_name = lvma_name, --母亲姓名

           bloodtype = lvbloodtype, --血　　型

           scontact = lvscontact, --联系方式

            in_category = lvin_category, --出生原因

           born_card_no = lvborn_card_no, --出生证号码

           natal_card_date = lvnatal_card_date, --出生证签发日期

           when_in = lvwhen_in, --出生申报时间

           send_hu = lvsend_hu, --是否要打印户口本

           in_hu_kind = lvin_hu_kind, --落户类型
           in_app_name=lvin_app_name,
           in_app_pid=lvin_app_pid,
           memo=lvmemo
       Where 1 = 1

       and sdono = lvsdono --办理编号

    ;
     UPDATE tc_webjj.t_dobus

    Set

      sdono=lvsdono,   --办理编号

      sbusno=lvsbusno,   --业务编码

      sdounit=lvsdounit,   --办理单位

      sdounitno=lvsdounitno,   --办理单位编码

      suserno=lvsuserno,   --用户编码

      state=lvstate,   --状　　态

      sbooking=lvsbooking,   --是否预约

      dbookingdate=lvdbookingdate,   --预约时间

      snotealert=lvsnotealert,   --是否短信提醒

      ncharge=lvncharge,   --支付金额

      nsercharge=lvnsercharge,   --服务资费

      nexpcharge=lvnexpcharge,   --快递资费

      nrecharge=lvnrecharge,   --回寄资费

      sexpno=lvsexpno,   --快递单号

      sexpaddress=lvsexpaddress,   --快递地址

      sexppostcode=lvsexppostcode,   --快递地址邮政编码

      sconsignee=lvsconsignee,   --收  件 人

      scontel=lvscontel,   --收件人联系电话

      snetbus=lvsnetbus,   --是否网上下单

      sreno=lvsreno,   --回寄快递单号

      sreaddress=lvsprocity||lvaddress,   --回寄地址

      srepostcode=lvsrepostcode,   --回寄地址邮政编码

      srecon=lvsrecon,   --回寄收件人

      srecontel=lvsrecontel,   --回寄收件人联系电话

      ddecdate=sysdate,   --申报时间

      schecker=lvschecker,   --审  核 人

      dcheckdate=lvdcheckdate,   --审核时间

      sacceptman=lvsacceptman,   --受  理 人

      sacceptdate=lvsacceptdate,   --受理时间

      sunreason=lvsunreason,   --退回原因

      sopinion=lvsopinion,   --评价内容

      sserattitude=lvsserattitude,   --服务态度得分

      sefficiency=lvsefficiency,   --办事效率得分

      ssatisfaction=lvssatisfaction,   --满  意 度

      sopdate=lvsopdate,    --评价时间
      sdodata='出生儿：'||lvname,
      sprocity=lvsprocity,
      address=lvaddress,
      sreems=lvsreems,
      semssend=lvsemssend
    Where 1=1

    and sdono=lvsdono   --办理编号

    ;
  END IF;

  IF lv_procMode = 'PMDELETE' THEN
    /*删除*/

    DElETE FROM tc_webjj.t_bir_declare

     Where 1 = 1

       and sdono = lvsdono --办理编号

    ;
   DElETE FROM tc_webjj.t_dobus
    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
  END IF;

  Commit;

END; /*存储过程结束*/

