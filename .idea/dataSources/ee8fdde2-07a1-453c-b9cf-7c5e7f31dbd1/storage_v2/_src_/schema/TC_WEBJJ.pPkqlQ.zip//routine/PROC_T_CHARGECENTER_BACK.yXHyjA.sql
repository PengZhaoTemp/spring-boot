create procedure          Proc_t_chargecenter_back
(
     lvoldsdono VARCHAR2,  --办理编号
     lvschargeno IN OUT varchar2--支付编号
)
as
    cursor a is
     select *  from tc_webjj.t_chargecenter
     where 1=1
     and sdono=lvoldsdono;   --支付编号
   r a%rowtype;

BEGIN
  select  fun_get16code(tc_webjj.seq_t_chargecenter_schargeno.Nextval) into  lvschargeno from dual where 1=1;
   for r in a loop
   INSERT into tc_webjj.t_chargecenter
    (
      schargeno,   --支付编号
      sdono,   --办理编号
      suserno,   --用户编码
      saccounts,   --账　　号
      sdealacc,   --交易账号
      nmoney,   --金　　额
      smemo,   --备　　注
      ddealdate,   --交易时间
      nsercharge,   --服务资费
      nexpcharge,   --快递资费
      nrecharge    --回寄资费
    )values(
      lvschargeno,   --支付编号
      lvoldsdono,   --办理编号
      r.suserno,   --用户编码
      r.saccounts,   --账　　号
      r.sdealacc,   --交易账号
      -r.nmoney,   --金　　额
      r.smemo,   --备　　注
      sysdate,   --交易时间
      -r.nsercharge,   --服务资费
      -r.nexpcharge,   --快递资费
      -r.nrecharge    --回寄资费
    );
    end loop;
        UPDATE tc_webjj.t_dobus
    Set
    state='32'
    where sdono=lvoldsdono;
    commit;

END;

/

