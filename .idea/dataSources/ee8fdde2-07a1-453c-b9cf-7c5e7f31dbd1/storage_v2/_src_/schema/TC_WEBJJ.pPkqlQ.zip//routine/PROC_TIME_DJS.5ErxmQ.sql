create PROCEDURE PROC_time_djs --时间倒计时
(v_sdono in varchar2,
 v_xy    OUT VARCHAR2
 
 ) as
  icount number;

BEGIN
  select count(1)
    into icount
    from t_bus_complete_record
   where sdono = v_sdono ;
   
   if icount =0  then 
       
       select '七天' into v_xy from dual;
       dbms_output.put_line(v_xy);
       
   else
      select 
       case
         when trunc(last_operation_date) = trunc(sysdate) then
          '七天'
         when trunc(last_operation_date - interval '-1' day) = trunc(sysdate) then
          '六天'
         when trunc(last_operation_date - interval '-2' day) = trunc(sysdate) then
          '五天'
         when trunc(last_operation_date - interval '-3' day) = trunc(sysdate) then
          '四天'
         when trunc(last_operation_date - interval '-4' day) = trunc(sysdate) then
          '三天'
         when trunc(last_operation_date - interval '-5' day) = trunc(sysdate) then
          '二天'
         when trunc(last_operation_date - interval '-6' day) = trunc(sysdate) then
          '一天'
         else
          '零天'
       end YX
        into v_xy
        from t_bus_complete_record
      
       where sdono = v_sdono
       order by last_operation_date desc;
       dbms_output.put_line(v_xy);

end if;




EXCEPTION
  --异常处理语句段
WHEN NO_DATA_FOUND THEN dbms_output.put_line('NO_DATA_FOUND');

END;
/

