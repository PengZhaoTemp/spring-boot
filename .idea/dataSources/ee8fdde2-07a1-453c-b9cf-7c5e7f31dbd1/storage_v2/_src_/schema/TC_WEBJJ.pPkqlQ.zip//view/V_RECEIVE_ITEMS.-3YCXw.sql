create view V_RECEIVE_ITEMS as
  select  t.sid,
t.sitemname,
(select sname from tc_webjj.t_lost_item_types where sid=t.sbigtype)sbigtype,
(select sname from tc_webjj.t_lost_item_types where sid=t.ssmalltype)ssmalltype,
t.sgetername,
to_char(t.dgetbackdate,'yyyy-mm-dd hh24:mi:ss')dgetbackdate,
t.sgetremark,
t.sitempic,
t.sgetpic,
t.sgetertel,
t.sgeterpid,
t.sgetaddr,
(t.sgetername||'于'||to_char(t.dgetbackdate,'yyyy-mm-dd hh24:mi:ss')||'在'||t.sgetaddr||'领取了'||t.sitemname)remark
from tc_webjj.t_found_item t
where t.sisgetback='1' and t.zxbz='0'
/

