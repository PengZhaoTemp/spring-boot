create PROCEDURE          PROC_t_notemobile   /*T_NOTEMOBILE*/
(
 lvsnoteno IN OUT VARCHAR2,  --短信编号
 lvsdono VARCHAR2,  --办理编号
 lvsuserno VARCHAR2,  --用户编号
 lvsnote VARCHAR2,  --短信内容
 lvdsenddate DATE,  --发送时间
 lvstel VARCHAR2,  --手机号码
 lvssendflag VARCHAR2,  --发送标志
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
    Select TC_WEBJJ.SEQ_T_NETNOTE_SNOTENO.Nextval  into lvsnoteno From dual;    /*短信编号序列*/
   INSERT into tc_webjj.t_notemobile
    (
      snoteno,   --短信编号
      sdono,   --办理编号
      suserno,   --用户编号
      snote,   --短信内容
      dsenddate,   --发送时间
      stel,   --手机号码
      ssendflag    --发送标志
    )values(
      lvsnoteno,   --短信编号
      lvsdono,   --办理编号
      lvsuserno,   --用户编号
      lvsnote,   --短信内容
      lvdsenddate,   --发送时间
      lvstel,   --手机号码
      lvssendflag    --发送标志
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_notemobile
    Set
      snoteno=lvsnoteno,   --短信编号
      sdono=lvsdono,   --办理编号
      suserno=lvsuserno,   --用户编号
      snote=lvsnote,   --短信内容
      dsenddate=lvdsenddate,   --发送时间
      stel=lvstel,   --手机号码
      ssendflag=lvssendflag    --发送标志
    Where 1=1
    and snoteno=lvsnoteno   --短信编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_notemobile
    Set
      snoteno=lvsnoteno,   --短信编号
      sdono=lvsdono,   --办理编号
      suserno=lvsuserno,   --用户编号
      snote=lvsnote,   --短信内容
      dsenddate=lvdsenddate,   --发送时间
      stel=lvstel,   --手机号码
      ssendflag=lvssendflag    --发送标志
    Where 1=1
    and snoteno=lvsnoteno   --短信编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_notemobile
    Where 1=1
    and snoteno=lvsnoteno   --短信编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

