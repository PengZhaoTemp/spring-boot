create view V_DOBUS_XML as
  select a.sdono source_id,sbusno,'hz' b_id,to_char(ddecdate,'yyyymmddhhmiss') sqtime,c.name sqname,
         c.pid sqpid,c.shome_phone sqtel,sdounitno,(select name from v_dobus_hjyw h where h.sdono=a.sdono) w_name,
         (select pid from v_dobus_hjyw h where h.sdono=a.sdono) w_pid,
         (select born_card_no from t_bir_declare h where h.sdono=a.sdono) born_card_no,
         (select to_char(dob,'yyyymmdd') from t_bir_declare h where h.sdono=a.sdono) dob,
         (select nation from t_bir_declare h where h.sdono=a.sdono) nation,
         (select to_char(date_of_death,'yyyymmdd') from T_DEATH_DECLARE h where h.sdono=a.sdono) date_of_death,
         (select out_category from T_DEATH_DECLARE h where h.sdono=a.sdono) out_category,
         (select sunit from T_DEATH_DECLARE h where h.sdono=a.sdono) sunit,
         (select death_no from T_DEATH_DECLARE h where h.sdono=a.sdono) death_no
    from tc_webjj.t_dobus a, tc_webjj.t_commoner c Where 1=1
   and a.suserNo = c.personid
/

