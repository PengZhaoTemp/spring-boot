create PROCEDURE          PROC_t_bbs_online   /*T_BBS_ONLINE*/
(
 lvsno IN OUT VARCHAR2,  --咨询编号
 lvnpolice_id VARCHAR2,  --民警编号
 lvpersonid VARCHAR2,  --用户编号
 lvsip VARCHAR2,  --咨询用户ip地址
 lvsdate DATE,  --咨询开始时间
 lvjsdate DATE,  --咨询结束时间
 lvconnflag VARCHAR2,  --连接标识 0：未连接，1：连接成功，2：断开连接
 lvtexts BLOB,  --咨询内容
 lvpflag VARCHAR2,  --民警发送消息标志位 1：发送了新的消息
 lvuflag VARCHAR2,  --客户发送消息标志位 1：发送了新的消息
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
    Select TC_WEBJJ.SEQ_BBS_ONLINE_SNO.Nextval  into lvsno From dual;    /*咨询编号序列*/
   INSERT into tc_webjj.t_bbs_online
    (
      sno,   --咨询编号
      npolice_id,   --民警编号
      personid,   --用户编号
      sip,   --咨询用户ip地址
      sdate,   --咨询开始时间
      jsdate,   --咨询结束时间
      connflag,   --连接标识 0：未连接，1：连接成功，2：断开连接
      texts,   --咨询内容
      pflag,   --民警发送消息标志位 1：发送了新的消息
      uflag    --客户发送消息标志位 1：发送了新的消息
    )values(
      lvsno,   --咨询编号
      lvnpolice_id,   --民警编号
      lvpersonid,   --用户编号
      lvsip,   --咨询用户ip地址
      lvsdate,   --咨询开始时间
      lvjsdate,   --咨询结束时间
      lvconnflag,   --连接标识 0：未连接，1：连接成功，2：断开连接
      lvtexts,   --咨询内容
      lvpflag,   --民警发送消息标志位 1：发送了新的消息
      lvuflag    --客户发送消息标志位 1：发送了新的消息
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_bbs_online
    Set
      sno=lvsno,   --咨询编号
      npolice_id=lvnpolice_id,   --民警编号
      personid=lvpersonid,   --用户编号
      sip=lvsip,   --咨询用户ip地址
      sdate=lvsdate,   --咨询开始时间
      jsdate=lvjsdate,   --咨询结束时间
      connflag=lvconnflag,   --连接标识 0：未连接，1：连接成功，2：断开连接
      texts=lvtexts,   --咨询内容
      pflag=lvpflag,   --民警发送消息标志位 1：发送了新的消息
      uflag=lvuflag    --客户发送消息标志位 1：发送了新的消息
    Where 1=1
    and sno=lvsno   --咨询编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_bbs_online
    Set
      sno=lvsno,   --咨询编号
      npolice_id=lvnpolice_id,   --民警编号
      personid=lvpersonid,   --用户编号
      sip=lvsip,   --咨询用户ip地址
      sdate=lvsdate,   --咨询开始时间
      jsdate=lvjsdate,   --咨询结束时间
      connflag=lvconnflag,   --连接标识 0：未连接，1：连接成功，2：断开连接
      texts=lvtexts,   --咨询内容
      pflag=lvpflag,   --民警发送消息标志位 1：发送了新的消息
      uflag=lvuflag    --客户发送消息标志位 1：发送了新的消息
    Where 1=1
    and sno=lvsno   --咨询编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_bbs_online
    Where 1=1
    and sno=lvsno   --咨询编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

