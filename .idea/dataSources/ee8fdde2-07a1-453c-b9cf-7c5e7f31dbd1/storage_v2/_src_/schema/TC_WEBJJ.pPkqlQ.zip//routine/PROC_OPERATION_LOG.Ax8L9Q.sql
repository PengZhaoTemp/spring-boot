create procedure    proc_operation_log(--系统操作日志
       lvnid in out varchar2,--业务ID
       lvip varchar2,--IP地址
       lvdate varchar2,--访问时间
       lvhtml varchar2,--访问页面
       lvsource varchar2,--访问来源（页面，地址）
       lvwindow varchar2,--操作系统
       lvtype  varchar2,--浏览器类型
       lvmoblie varchar2,--终端类型
       lvclint  varchar2,--客户端分辨率
       lvuserid varchar2,--用户ID
       lvprocmode varchar2,--PMINSERT插入 PMUPDATE修改 PMDELETE删除
       lvcityname varchar2,--用户所在城市
       lvcarrieroperator varchar2,--运营商
       lvret   in out varchar --预留字段
) is
  lv_nid varchar(16);
begin
  if 'PMINSERT'=lvprocmode then--PMINSERT插入
    select tc_webjj.seq_operation_log.nextval into lvnid from dual;
    insert into tc_webjj.t_operation_log(
          nid ,--业务ID
          operation_ip,--IP地址
          operation_date,--访问时间
          operation_html,--访问页面
          operation_source,--访问来源（页面，地址）
          operation_window,--操作系统
          operation_type,--浏览器类型
          operation_moblie,--终端类型
          operation_clint,--客户端分辨率
          operation_userid,--用户ID
          OPERATION_CARRIEROPERATOR,--用户使用网络运营商
          OPERATION_city --用户所在城市
    )values(
           lvnid,
           lvip,
           to_date(lvdate,'yyyy-MM-dd hh24:mi:ss'),
           lvhtml,
           lvsource,
           lvwindow,
           lvtype,
           lvmoblie,
           lvclint,
           lvuserid,
           lvcarrieroperator,
           lvcityname
    );
  end if;
   if 'PMUPDATE'=lvprocmode then--PMUPDATE修改
     update tc_webjj.t_operation_log
     set 
          operation_ip=lvip,--IP地址
          operation_date=lvdate,--访问时间
          operation_html=lvhtml,--访问页面
          operation_source=lvsource,--访问来源（页面，地址）
          operation_window=lvwindow,--操作系统
          operation_type=lvtype,--浏览器类型
          operation_moblie=lvmoblie,--终端类型
          operation_clint=lvclint,--客户端分辨率
          operation_userid=lvuserid,--用户ID
          OPERATION_CARRIEROPERATOR=lvcarrieroperator,--用户使用网络运营商
          OPERATION_city=lvcityname --用户所在城市
     where nid=lvnid;
  end if;
   if 'PMDELETE'=lvprocmode then--PMDELETE删除
    update tc_webjj.t_operation_log set zxbz='1'
    where nid=lvnid;
  end if;
  
  commit;
      
end;
/

