create PROCEDURE          PROC_DELETEDATA
(
    lvsdono VARCHAR2
) is
begin
  update tc_webjj.t_dobus d set d.zxbz='1' where sdono=lvsdono;
 Commit;
end proc_deletedata;

/

