create view V_BUS_UNIT_DEPLOY as
  select a.NID,
       a.SBUSNO,
       a.SQUCODE,
       a.SORGID,
       a.ZXBZ,
       a.ZXSJ,
       a.SORGNAME,
       b.sunit_code,
       b.orgname,
       b.stel_no,
       b.sdetail_addr,
       b.sunit_post_code
  from tc_webjj.T_BUS_UNIT_DEPLOY a,
  tc_jcyw.t_org b
  where a.sorgid=b.sunit_code
/

