create view V_OWNER_TABLE as
  select a.owner,a.table_name,b.comments from all_tables a,all_tab_comments b
where a.tablespace_name in ('WEBJJ_DATA','INDEX_DATA','JCYW_DATA')
and a.owner = b.owner(+)
and a.table_name = b.table_name(+)
/

