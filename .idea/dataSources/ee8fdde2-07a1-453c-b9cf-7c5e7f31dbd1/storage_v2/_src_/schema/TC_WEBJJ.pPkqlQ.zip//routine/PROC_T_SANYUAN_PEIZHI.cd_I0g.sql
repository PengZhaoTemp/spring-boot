create PROCEDURE          PROC_t_sanyuan_peizhi   /*T_SANYUAN_PEIZHI*/
(
 lvstmno IN OUT VARCHAR2,  --题目编号
 lvstm_type VARCHAR2,  --题目类型0单选1多选2是非
 lvstm_rytype VARCHAR2,  --人员分类（1安全员爆破员2 仓库管理员）
 lvstm_fenshu VARCHAR2,  --题目分数
 lvstm_answer VARCHAR2,  --题目答案
 lvstm_choose VARCHAR2,  --题目选项
 lvslr_id VARCHAR2,  --录入人id
 lvslr_time DATE,  --录入时间
 lvstm_content VARCHAR2,  --题目内容
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
    Select tc_webjj.SEQ_T_SANYUAN_PEIZHI_STMNO.Nextval  into lvstmno From dual;    /*题目编号序列*/
   INSERT into tc_webjj.t_sanyuan_peizhi
    (
      stmno,   --题目编号
      stm_type,   --题目类型0单选1多选2是非
      stm_rytype,   --人员分类（1安全员爆破员2 仓库管理员）
      stm_fenshu,   --题目分数
      stm_answer,   --题目答案
      stm_choose,   --题目选项
      slr_id,   --录入人id
      slr_time,   --录入时间
      stm_content    --题目内容
    )values(
      lvstmno,   --题目编号
      lvstm_type,   --题目类型0单选1多选2是非
      lvstm_rytype,   --人员分类（1安全员爆破员2 仓库管理员）
      lvstm_fenshu,   --题目分数
      lvstm_answer,   --题目答案
      lvstm_choose,   --题目选项
      lvslr_id,   --录入人id
      sysdate,   --录入时间
      lvstm_content    --题目内容
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_sanyuan_peizhi
    Set
      stmno=lvstmno,   --题目编号
      stm_type=lvstm_type,   --题目类型0单选1多选2是非
      stm_rytype=lvstm_rytype,   --人员分类（1安全员爆破员2 仓库管理员）
      stm_fenshu=lvstm_fenshu,   --题目分数
      stm_answer=lvstm_answer,   --题目答案
      stm_choose=lvstm_choose,   --题目选项
      slr_id=lvslr_id,   --录入人id
      slr_time=sysdate,   --录入时间
      stm_content=lvstm_content    --题目内容
    Where 1=1
    and stmno=lvstmno   --题目编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_sanyuan_peizhi
    Set
      stmno=lvstmno,   --题目编号
      stm_type=lvstm_type,   --题目类型0单选1多选2是非
      stm_rytype=lvstm_rytype,   --人员分类（1安全员爆破员2 仓库管理员）
      stm_fenshu=lvstm_fenshu,   --题目分数
      stm_answer=lvstm_answer,   --题目答案
      stm_choose=lvstm_choose,   --题目选项
      slr_id=lvslr_id,   --录入人id
      slr_time=sysdate,   --录入时间
      stm_content=lvstm_content    --题目内容
    Where 1=1
    and stmno=lvstmno   --题目编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_sanyuan_peizhi
    Where 1=1
    and stmno=lvstmno   --题目编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

