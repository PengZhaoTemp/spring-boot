create function          fun_getShowMinut(lv_num    varchar2,
                                            unit_flag varchar2)
  return varchar2 is
  lvMinut varchar2(500);
begin
  lvMinut := '';
  /*评价查看页面显示*/
  if unit_flag = '1' then
    if lv_num = '1' then
      lvMinut := '<span style="color:red;">★☆☆☆☆☆☆☆☆☆</span>';
    end if;
    if lv_num = '2' then
      lvMinut := '<span style="color:red;">★★☆☆☆☆☆☆☆☆</span>';
    end if;
    if lv_num = '3' then
      lvMinut := '<span style="color:red;">★★★☆☆☆☆☆☆☆</span>';
    end if;
    if lv_num = '4' then
      lvMinut := '<span style="color:red;">★★★★☆☆☆☆☆☆</span>';
    end if;
    if lv_num = '5' then
      lvMinut := '<span style="color:red;">★★★★★☆☆☆☆☆</span>';
    end if;
    if lv_num = '6' then
      lvMinut := '<span style="color:red;">★★★★★★☆☆☆☆</span>';
    end if;
    if lv_num = '7' then
      lvMinut := '<span style="color:red;">★★★★★★★☆☆☆</span>';
    end if;
    if lv_num = '8' then
      lvMinut := '<span style="color:red;">★★★★★★★★☆☆</span>';
    end if;
    if lv_num = '9' then
      lvMinut := '<span style="color:red;">★★★★★★★★★☆</span>';
    end if;
    if lv_num = '10' then
      lvMinut := '<span style="color:red;">★★★★★★★★★★</span>';
    end if;
    if lv_num = '0' then
      lvMinut := '<span style="color:red;">☆☆☆☆☆☆☆☆☆☆</span>';
    end if;
  else
    if lv_num = '1' then
      lvMinut := '<img src="/webjjcss/pj1.gif"/>非常满意!';
    end if;
    if lv_num = '2' then
      lvMinut := '<img src="/webjjcss/pj2.gif"/>很满意!';
    end if;
    if lv_num = '3' then
      lvMinut := '<img src="/webjjcss/pj3.gif"/>一般!';
    end if;
    if lv_num = '4' then
      lvMinut := '<img src="/webjjcss/pj4.gif"/>不满意!';
    end if;
  end if;
  if lvMinut is null then
    lvMinut := '数据错误！无法显示！';
  end if;
  return(lvMinut);
end fun_getShowMinut;

/

