create procedure          proc_t_applymasterdata(
   lvsdono VARCHAR2,    --办理编号
   lvsmasterialsno VARCHAR2,  --材料编号
   lvsmasterialsname VARCHAR2,  --材料名称
   lvsmasterialspath VARCHAR2  --材料路径
) is
begin
  insert into tc_webjj.t_applymasterdata
    (
    SNO,--1 序列
    SDONO,--2事务编号
    SMASTERIALSNO,--3材料编号
    SMASTERIALSNAME,--4材料名称
    SMASTERIALSPATH,--5材料路径
    DUPLOAD,        --6
    DBBJ          --7打包标记
    )values
   (
   tc_weixin.fun_get16code(tc_webjj.seq_applymasterdata_nid.nextval,'350201',2),--序列
   lvsdono,                          --2 事务编号
   lvsmasterialsno,                  --3材料编号
   lvsmasterialsname,                --4材料名称
   lvsmasterialspath,                --5材料路径
   null,                             --6
   0                                --7打包标记
   );
end proc_t_applymasterdata;

/

