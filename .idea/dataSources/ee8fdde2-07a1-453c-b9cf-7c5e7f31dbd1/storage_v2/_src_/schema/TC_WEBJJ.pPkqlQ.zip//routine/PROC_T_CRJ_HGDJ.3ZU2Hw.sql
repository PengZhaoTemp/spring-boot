create PROCEDURE          PROC_t_crj_hgdj   /*T_CRJ_HGDJ*/
(
 lvsdono IN OUT VARCHAR2,  --业务编号
 lvsname VARCHAR2,  --姓　　名
 lvssex VARCHAR2,  --性　　別
 lvscsrq DATE,  --出生日期
 lvscsd VARCHAR2,  --出  生 地
 lvshf VARCHAR2,  --婚　　否
 lvslxdh VARCHAR2,  --联系电话
 lvsycchhkzz_yhzgx VARCHAR2,  --原常住户口住址、与户主关系
 lvsndjzz VARCHAR2,  --拟定居住址
 lvsmcrjsczjmc_hm VARCHAR2,  --末次入境所持证件的名称和号码
 lvsmcrjsj_ka VARCHAR2,  --末次入境时间和口岸
 lvsjzgjlzmmc_hm VARCHAR2,  --居住国居留证明名称和号码
 lvsjzgzz VARCHAR2,  --居住过住址
 lvsname1 VARCHAR2,  --姓  名 1
 lvscw1 VARCHAR2,  --称  谓 1
 lvsbri1 DATE,  --出生日期1
 lvsjhrzjh1 VARCHAR2,  --身份证号码1
 lvsjtzz1 VARCHAR2,  --家庭住址1
 lvsname2 VARCHAR2,  --姓  名 2
 lvscw2 VARCHAR2,  --称  谓 2
 lvsbri2 DATE,  --出生日期2
 lvsjhrzjh2 VARCHAR2,  --身份证号码2
 lvsjtzz2 VARCHAR2,  --家庭住址2
 lvsname3 VARCHAR2,  --姓  名 3
 lvscw3 VARCHAR2,  --称  谓 3
 lvsbri3 DATE,  --出生日期3
 lvsjhrzjh3 VARCHAR2,  --身份证号码3
 lvsjtzz3 VARCHAR2,  --家庭住址3
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
   INSERT into tc_webjj.t_crj_hgdj
    (
      sdono,   --业务编号
      sname,   --姓　　名
      ssex,   --性　　別
      scsrq,   --出生日期
      scsd,   --出  生 地
      shf,   --婚　　否
      slxdh,   --联系电话
      sycchhkzz_yhzgx,   --原常住户口住址、与户主关系
      sndjzz,   --拟定居住址
      smcrjsczjmc_hm,   --末次入境所持证件的名称和号码
      smcrjsj_ka,   --末次入境时间和口岸
      sjzgjlzmmc_hm,   --居住国居留证明名称和号码
      sjzgzz,   --居住过住址
      sname1,   --姓  名 1
      scw1,   --称  谓 1
      sbri1,   --出生日期1
      sjhrzjh1,   --身份证号码1
      sjtzz1,   --家庭住址1
      sname2,   --姓  名 2
      scw2,   --称  谓 2
      sbri2,   --出生日期2
      sjhrzjh2,   --身份证号码2
      sjtzz2,   --家庭住址2
      sname3,   --姓  名 3
      scw3,   --称  谓 3
      sbri3,   --出生日期3
      sjhrzjh3,   --身份证号码3
      sjtzz3    --家庭住址3
    )values(
      lvsdono,   --业务编号
      lvsname,   --姓　　名
      lvssex,   --性　　別
      lvscsrq,   --出生日期
      lvscsd,   --出  生 地
      lvshf,   --婚　　否
      lvslxdh,   --联系电话
      lvsycchhkzz_yhzgx,   --原常住户口住址、与户主关系
      lvsndjzz,   --拟定居住址
      lvsmcrjsczjmc_hm,   --末次入境所持证件的名称和号码
      lvsmcrjsj_ka,   --末次入境时间和口岸
      lvsjzgjlzmmc_hm,   --居住国居留证明名称和号码
      lvsjzgzz,   --居住过住址
      lvsname1,   --姓  名 1
      lvscw1,   --称  谓 1
      lvsbri1,   --出生日期1
      lvsjhrzjh1,   --身份证号码1
      lvsjtzz1,   --家庭住址1
      lvsname2,   --姓  名 2
      lvscw2,   --称  谓 2
      lvsbri2,   --出生日期2
      lvsjhrzjh2,   --身份证号码2
      lvsjtzz2,   --家庭住址2
      lvsname3,   --姓  名 3
      lvscw3,   --称  谓 3
      lvsbri3,   --出生日期3
      lvsjhrzjh3,   --身份证号码3
      lvsjtzz3    --家庭住址3
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_crj_hgdj
    Set
      sdono=lvsdono,   --业务编号
      sname=lvsname,   --姓　　名
      ssex=lvssex,   --性　　別
      scsrq=lvscsrq,   --出生日期
      scsd=lvscsd,   --出  生 地
      shf=lvshf,   --婚　　否
      slxdh=lvslxdh,   --联系电话
      sycchhkzz_yhzgx=lvsycchhkzz_yhzgx,   --原常住户口住址、与户主关系
      sndjzz=lvsndjzz,   --拟定居住址
      smcrjsczjmc_hm=lvsmcrjsczjmc_hm,   --末次入境所持证件的名称和号码
      smcrjsj_ka=lvsmcrjsj_ka,   --末次入境时间和口岸
      sjzgjlzmmc_hm=lvsjzgjlzmmc_hm,   --居住国居留证明名称和号码
      sjzgzz=lvsjzgzz,   --居住过住址
      sname1=lvsname1,   --姓  名 1
      scw1=lvscw1,   --称  谓 1
      sbri1=lvsbri1,   --出生日期1
      sjhrzjh1=lvsjhrzjh1,   --身份证号码1
      sjtzz1=lvsjtzz1,   --家庭住址1
      sname2=lvsname2,   --姓  名 2
      scw2=lvscw2,   --称  谓 2
      sbri2=lvsbri2,   --出生日期2
      sjhrzjh2=lvsjhrzjh2,   --身份证号码2
      sjtzz2=lvsjtzz2,   --家庭住址2
      sname3=lvsname3,   --姓  名 3
      scw3=lvscw3,   --称  谓 3
      sbri3=lvsbri3,   --出生日期3
      sjhrzjh3=lvsjhrzjh3,   --身份证号码3
      sjtzz3=lvsjtzz3    --家庭住址3
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_crj_hgdj
    Set
      sdono=lvsdono,   --业务编号
      sname=lvsname,   --姓　　名
      ssex=lvssex,   --性　　別
      scsrq=lvscsrq,   --出生日期
      scsd=lvscsd,   --出  生 地
      shf=lvshf,   --婚　　否
      slxdh=lvslxdh,   --联系电话
      sycchhkzz_yhzgx=lvsycchhkzz_yhzgx,   --原常住户口住址、与户主关系
      sndjzz=lvsndjzz,   --拟定居住址
      smcrjsczjmc_hm=lvsmcrjsczjmc_hm,   --末次入境所持证件的名称和号码
      smcrjsj_ka=lvsmcrjsj_ka,   --末次入境时间和口岸
      sjzgjlzmmc_hm=lvsjzgjlzmmc_hm,   --居住国居留证明名称和号码
      sjzgzz=lvsjzgzz,   --居住过住址
      sname1=lvsname1,   --姓  名 1
      scw1=lvscw1,   --称  谓 1
      sbri1=lvsbri1,   --出生日期1
      sjhrzjh1=lvsjhrzjh1,   --身份证号码1
      sjtzz1=lvsjtzz1,   --家庭住址1
      sname2=lvsname2,   --姓  名 2
      scw2=lvscw2,   --称  谓 2
      sbri2=lvsbri2,   --出生日期2
      sjhrzjh2=lvsjhrzjh2,   --身份证号码2
      sjtzz2=lvsjtzz2,   --家庭住址2
      sname3=lvsname3,   --姓  名 3
      scw3=lvscw3,   --称  谓 3
      sbri3=lvsbri3,   --出生日期3
      sjhrzjh3=lvsjhrzjh3,   --身份证号码3
      sjtzz3=lvsjtzz3    --家庭住址3
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_crj_hgdj
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

