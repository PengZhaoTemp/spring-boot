create procedure          proc_dobus_pay_next(
       lvsdono varchar2,
       lvtask varchar2  --1-快递费 2--工本费
) is
lvdobus tc_webjj.t_dobus%rowtype;
lvNSERCHARGE number;
lvNEXPCHARGE number;
lvNRECHARGE number;
lvNMONEY number;
BEGIN
   select * into lvdobus from tc_webjj.t_dobus where sdono = lvsdono;
   if lvtask='1' then
      lvNSERCHARGE := 0;
      lvNEXPCHARGE := LVDOBUS.NEXPCHARGE;
      lvNRECHARGE := LVDOBUS.NRECHARGE;
      lvNMONEY := LVDOBUS.NEXPCHARGE + LVDOBUS.NRECHARGE;
   else
      lvNSERCHARGE := LVDOBUS.NSERCHARGE;
      lvNEXPCHARGE := 0;
      lvNRECHARGE := 0;
      lvNMONEY := LVDOBUS.NSERCHARGE;
   end if;
       INSERT INTO TC_WEBJJ.T_CHARGECENTER
           (SDONO, NMONEY, SMEMO, DDEALDATE, NSERCHARGE, NEXPCHARGE, NRECHARGE, DBBJ,char_id,suserno)
       VALUES
           (LVSDONO,
            lvNMONEY,
            '陕西支付测试',
            SYSDATE,
            lvNSERCHARGE,
            lvNEXPCHARGE,
            lvNRECHARGE,
            '0',tc_webjj.seq_t_chargecenter_id.nextval,LVDOBUS.Suserno);

   commit;
end proc_dobus_pay_next;

/

