create PROCEDURE          PROC_reback_xzfy   /*T_XZFY_SQ*/
(
 lvsdono IN OUT VARCHAR2,  --办理编号
 lvs_cx_reason VARCHAR2,  --撤销原因
 lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS

BEGIN

IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_xzfy_sq
    Set
      s_cxsq='1',   --撤销申请标记0/1
      s_cx_reason=lvs_cx_reason   --撤销原因

    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
    UPDATE tc_webjj.t_dobus
    Set
       state='29'
    where 1=1
    and sdono=lvsdono;
END IF;

 Commit;
END; /*存储过程结束*/

