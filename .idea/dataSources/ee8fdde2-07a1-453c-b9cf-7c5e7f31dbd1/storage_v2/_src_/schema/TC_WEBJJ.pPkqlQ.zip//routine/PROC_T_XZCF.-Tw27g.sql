create PROCEDURE          PROC_t_xzcf   /*T_XZCF*/
(
 lvsdono IN OUT VARCHAR2,  --业务编号
 lvSWS_TYPE VARCHAR2,  --文书
 lvSWS_NF VARCHAR2,  --年份
 lvSWS_HS VARCHAR2,  --号数
 lvS_NAME VARCHAR2,  --姓名
 lvS_ZJH VARCHAR2,  --证件号
 lvs_money VARCHAR2,  --处罚金额
 lvS_JLTS VARCHAR2,  --拘留天数
 lvS_dxzz VARCHAR2,  --吊销执照
 lvS_wftype VARCHAR2,  --违法行为类型
 lvS_qtcf VARCHAR2,  --其他处罚
 lvS_sfjg VARCHAR2,  --是否警告
 lvS_sypj VARCHAR2,  --索要票据
 lvS_sq_name VARCHAR2,  --填写人姓名
 lvS_sq_sfz VARCHAR2,  --填写人身份证
 lvS_jksj date,  --缴款日期
 lvS_ajbh VARCHAR2,  --案件编号
 lvS_rybh VARCHAR2,  --人员编号
 lvS_lxfs VARCHAR2,  --联系方式
 lvS_badw VARCHAR2,  --办案单位
 lvs_hjdz varchar2, --回寄地址
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS

BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/



   INSERT into tc_webjj.t_xzcf
    (
      SDONO,
      SWS_TYPE,
      SWS_NF,
      SWS_HS,
      S_NAME,
      S_ZJH,
      S_MONEY,
      S_JLTS,
      S_DXZZ,
      S_WFTYPE,
      S_QTCF,
      S_SFJG,
      S_SYPJ,
      S_SQ_NAME,
      S_SQ_SFZ,
      S_JKSJ,
      S_AJBH,
      S_RYBH,
      S_LXFS,
      S_BADW,
      s_hjdz
    )values(
      lvsdono,  --业务编号
       lvSWS_TYPE,  --文书
       lvSWS_NF,  --年份
       lvSWS_HS,  --号数
       lvS_NAME,  --姓名
       lvS_ZJH,  --证件号
       lvs_money ,  --处罚金额
       lvS_JLTS ,  --拘留天数
       lvS_dxzz,  --吊销执照
       lvS_wftype,  --违法行为类型
       lvS_qtcf,  --其他处罚
       lvS_sfjg,  --是否警告
       lvS_sypj,  --索要票据
       lvS_sq_name,  --填写人姓名
       lvS_sq_sfz ,  --填写人身份证
       lvS_jksj,  --缴款日期
       lvS_ajbh,  --案件编号
       lvS_rybh,  --人员编号
       lvS_lxfs,  --联系方式
       lvS_badw,  --办案单位
       lvs_hjdz
     );
   -- 返回值

END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_xzcf
    Set
       SWS_TYPE=lvSWS_TYPE,  --文书
       SWS_NF=lvSWS_NF,  --年份
       SWS_HS=lvSWS_HS,  --号数
       S_NAME=lvS_NAME,  --姓名
       S_ZJH=lvS_ZJH,  --证件号
       s_money=lvs_money ,  --处罚金额
       S_JLTS =lvS_JLTS ,  --拘留天数
       S_dxzz=lvS_dxzz,  --吊销执照
       S_wftype=lvS_wftype,  --违法行为类型
       S_qtcf=lvS_qtcf,  --其他处罚
       S_sfjg=lvS_sfjg,  --是否警告
       S_sypj=lvS_sypj,  --索要票据
       S_sq_name=lvS_sq_name,  --填写人姓名
       S_sq_sfz=lvS_sq_sfz ,  --填写人身份证
       S_jksj=lvS_jksj,  --缴款日期
       S_ajbh=lvS_ajbh,  --案件编号
       S_rybh=lvS_rybh,  --人员编号
       S_lxfs=lvS_lxfs,  --联系方式
       S_badw=lvS_badw,  --办案单位
       s_hjdz=lvs_hjdz
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_xzcf
    Set
      SWS_TYPE=lvSWS_TYPE,  --文书
       SWS_NF=lvSWS_NF,  --年份
       SWS_HS=lvSWS_HS,  --号数
       S_NAME=lvS_NAME,  --姓名
       S_ZJH=lvS_ZJH,  --证件号
       s_money=lvs_money ,  --处罚金额
       S_JLTS =lvS_JLTS ,  --拘留天数
       S_dxzz=lvS_dxzz,  --吊销执照
       S_wftype=lvS_wftype,  --违法行为类型
       S_qtcf=lvS_qtcf,  --其他处罚
       S_sfjg=lvS_sfjg,  --是否警告
       S_sypj=lvS_sypj,  --索要票据
       S_sq_name=lvS_sq_name,  --填写人姓名
       S_sq_sfz=lvS_sq_sfz ,  --填写人身份证
       S_jksj=lvS_jksj,  --缴款日期
       S_ajbh=lvS_ajbh,  --案件编号
       S_rybh=lvS_rybh,  --人员编号
       S_lxfs=lvS_lxfs,  --联系方式
       S_badw=lvS_badw,  --办案单位
       s_hjdz=lvs_hjdz
       Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_xzcf
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

