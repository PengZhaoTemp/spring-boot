create function get_dobus_jkdbsj(lv_dbbj varchar2,lv_date date) return number is
  lv_Result number;
begin
  if lv_dbbj is null or lv_dbbj='' or lv_dbbj='0' then
     lv_Result:=2;
  else if lv_date is null or lv_date='' then
       lv_Result:=3;
  else if (sysdate-lv_date)*24*3600>30  then
         lv_Result:=1; 
  end if;
  end if;
  end if;
  return lv_Result;
end;
/

