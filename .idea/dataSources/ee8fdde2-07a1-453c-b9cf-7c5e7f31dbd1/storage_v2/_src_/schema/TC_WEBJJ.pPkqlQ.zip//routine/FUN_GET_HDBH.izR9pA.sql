create function          fun_get_hdbh(lv_stype_en varchar2 --三位
                                                 ) --获取互动编号
 return varchar2 is
  lv_hdbh varchar2(32);--如信箱表ID MSG-20151111111628-RSQ745

begin
  if length(lv_stype_en) <> 3 then
    lv_hdbh := '';
  else
    lv_hdbh := upper(lv_stype_en) || '-' ||
               to_char(sysdate, 'yyyymmddhh24miss') || '-' ||
               upper(DBMS_RANDOM.STRING('A', 3)) ||
               lpad(trunc(dbms_random.value(1, 999)), 3, '0');
  end if;
  return(lv_hdbh);
end;

/

