create PROCEDURE          PROC_t_field_deploy   /*T_FIELD_DEPLOY*/
(
 lvsno IN OUT VARCHAR2,  --字段编码
 lvstablename VARCHAR2,  --表　　名
 lvstablenamecn VARCHAR2,  --中文表名
 lvsfieldname VARCHAR2,  --字  段 名
 lvsfieldnamecn VARCHAR2,  --中文字段名
 lvsfieldinfo VARCHAR2,  --字段说明
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
  select TC_WEBJJ.SEQ_T_FIELD_DEPLOY_SNO.Nextval into lvsno from dual;
   INSERT into tc_webjj.t_field_deploy
    (
      sno,   --字段编码
      stablename,   --表　　名
      stablenamecn,   --中文表名
      sfieldname,   --字  段 名
      sfieldnamecn,   --中文字段名
      sfieldinfo    --字段说明
    )values(
      lvsno,   --字段编码
      lvstablename,   --表　　名
      lvstablenamecn,   --中文表名
      lvsfieldname,   --字  段 名
      lvsfieldnamecn,   --中文字段名
      lvsfieldinfo    --字段说明
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_field_deploy
    Set
      sno=lvsno,   --字段编码
      stablename=lvstablename,   --表　　名
      stablenamecn=lvstablenamecn,   --中文表名
      sfieldname=lvsfieldname,   --字  段 名
      sfieldnamecn=lvsfieldnamecn,   --中文字段名
      sfieldinfo=lvsfieldinfo    --字段说明
    Where 1=1
    and sno=lvsno   --字段编码
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_field_deploy
    Set
      sno=lvsno,   --字段编码
      stablename=lvstablename,   --表　　名
      stablenamecn=lvstablenamecn,   --中文表名
      sfieldname=lvsfieldname,   --字  段 名
      sfieldnamecn=lvsfieldnamecn,   --中文字段名
      sfieldinfo=lvsfieldinfo    --字段说明
    Where 1=1
    and sno=lvsno   --字段编码
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_field_deploy
    Where 1=1
    and sno=lvsno   --字段编码
    ;
END IF;
 Commit;
END; /*存储过程结束*/

