create view V_PORTAL_MAILBOX as
  select a.sid,
       a.sorgid,
       a.sorgname,
       a.stype,
       a.stitle,
       a.scontent,
       a.dcreatedate,
       a.sreply,
       a.dreplydate,
       a.suserid,
       a.sreplyuser,
       a.sassigntype,
       a.sispublic,
       a.sreplytype,
       a.sleaderreport,
       a.sname,
       a.sphone,
       a.semail,
       a.saddress,
       a.smailip,
       a.dmaildeadline,
       a.sisdone,
       a.sreturncause,
       a.sstate,
       b.typename,
       b.oldcode oldtypecode
  from t_portal_mailbox a,tc_webjj.t_portal_type b
  where a.stype=b.typecode
/

