create PROCEDURE          PROC_t_syks_choose   /*T_SYKS_CHOOSE*/
(
 lvch_no IN OUT VARCHAR2,  --题目编号
 lvch_question VARCHAR2,  --题目内容
 lvch_answer VARCHAR2,  --题目答案
 lvch_a VARCHAR2,  --a  选 项
 lvch_b VARCHAR2,  --b  选 项
 lvch_c VARCHAR2,  --c  选 项
 lvch_d VARCHAR2,  --d  选 项
 lvch_e VARCHAR2,  --e  选 项
 lvch_f VARCHAR2,  --f  选 项
 lvch_type VARCHAR2,  --选择题类型
 lvch_type_name VARCHAR2,  --单选/多选
 lvwho_logged VARCHAR2,  --录  入 人
 lvwhen_logged DATE,  --录入时间
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
lvch_name varchar2(50);
BEGIN
  --begin TRAN
  if lvch_type = '11' then
     lvch_name:='单选题';
  else
      lvch_name:='多选题';
  end if;
IF lv_procMode='PMINSERT' THEN    /*登记*/
    Select TC_WEBJJ.SEQ_T_SYKS_CHOOSE_CH_NO.Nextval  into lvch_no From dual;    /*题目编号序列*/
   INSERT into tc_webjj.t_syks_choose
    (
      ch_no,   --题目编号
      ch_question,   --题目内容
      ch_answer,   --题目答案
      ch_a,   --a  选 项
      ch_b,   --b  选 项
      ch_c,   --c  选 项
      ch_d,   --d  选 项
      ch_e,   --e  选 项
      ch_f,   --f  选 项
      ch_type,   --选择题类型
      ch_type_name,   --单选/多选
      who_logged,   --录  入 人
      when_logged    --录入时间
    )values(
      lvch_no,   --题目编号
      lvch_question,   --题目内容
      lvch_answer,   --题目答案
      lvch_a,   --a  选 项
      lvch_b,   --b  选 项
      lvch_c,   --c  选 项
      lvch_d,   --d  选 项
      lvch_e,   --e  选 项
      lvch_f,   --f  选 项
      lvch_type,   --选择题类型
      lvch_name,   --单选/多选
      lvwho_logged,   --录  入 人
      sysdate    --录入时间
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_syks_choose
    Set
      ch_no=lvch_no,   --题目编号
      ch_question=lvch_question,   --题目内容
      ch_answer=lvch_answer,   --题目答案
      ch_a=lvch_a,   --a  选 项
      ch_b=lvch_b,   --b  选 项
      ch_c=lvch_c,   --c  选 项
      ch_d=lvch_d,   --d  选 项
      ch_e=lvch_e,   --e  选 项
      ch_f=lvch_f,   --f  选 项
      ch_type=lvch_type,   --选择题类型
      ch_type_name=lvch_name,   --单选/多选
      who_logged=lvwho_logged,   --录  入 人
      when_logged=sysdate    --录入时间
    Where 1=1
    and ch_no=lvch_no   --题目编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_syks_choose
    Set
      ch_no=lvch_no,   --题目编号
      ch_question=lvch_question,   --题目内容
      ch_answer=lvch_answer,   --题目答案
      ch_a=lvch_a,   --a  选 项
      ch_b=lvch_b,   --b  选 项
      ch_c=lvch_c,   --c  选 项
      ch_d=lvch_d,   --d  选 项
      ch_e=lvch_e,   --e  选 项
      ch_f=lvch_f,   --f  选 项
      ch_type=lvch_type,   --选择题类型
      ch_type_name=lvch_name,   --单选/多选
      who_logged=lvwho_logged,   --录  入 人
      when_logged=sysdate     --录入时间
    Where 1=1
    and ch_no=lvch_no   --题目编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_syks_choose
    Where 1=1
    and ch_no=lvch_no   --题目编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

