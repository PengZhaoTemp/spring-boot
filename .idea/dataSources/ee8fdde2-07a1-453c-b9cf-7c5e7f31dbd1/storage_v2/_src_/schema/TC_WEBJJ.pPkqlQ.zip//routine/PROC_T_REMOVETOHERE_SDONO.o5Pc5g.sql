create procedure          Proc_t_removetohere_SDONO
(
     lvoldsdono VARCHAR2,  --办理编号
     lvReturn in out varchar2 --新办理编号
)
as
  cursor c is
     select * from tc_webjj.t_removetohere_declare
     where 1=1
     and sdono=lvoldsdono;   --公民身份号码
  r c%rowtype;

BEGIN
   select TC_WEBJJ.fun_get16code(TC_WEBJJ.SEQ_T_DOBUS_SDONO.Nextval)  into  lvReturn from dual  where 1=1;
   for r in c loop
   INSERT into tc_webjj.t_removetohere_declare
    (
      sdono,   --业务编号
      btk_name,   --被投靠人姓名
      btk_pid,   --被投靠人身份证
      hu_master_name,   --户主姓名
      hu_master_pid,   --户主身份证
      btk_relation,   --与被投靠人关系
      master_relation,   --与户主关系
      app_type,   --申请类别
      app_why_apply,   --申报理由
      pid,   --公民身份证
      name,   --姓　　名
      change_reason,   --变动原因
      removecity,   --所属省市
      removeaddr,   --详　　址
      app_name,   --申请人姓名
      app_pid,    --申请人身份证
      sypcs,
      hkzxfs,
      wtr_name,
      wtr_pid,
      wtr_relation,
      wtr_phone
    )values(
     lvReturn,   --业务编号
      r.btk_name,   --被投靠人姓名
      r.btk_pid,   --被投靠人身份证
      r.hu_master_name,   --户主姓名
      r.hu_master_pid,   --户主身份证
      r.btk_relation,   --与被投靠人关系
      r.master_relation,   --与户主关系
      r.app_type,   --申请类别
      r.app_why_apply,   --申报理由
      r.pid,   --公民身份证
      r.name,   --姓　　名
      r.change_reason,   --变动原因
      r.removecity,   --所属省市
      r.removeaddr,   --详　　址
      r.app_name,   --申请人姓名
      r.app_pid,    --申请人身份证
      r.sypcs,
      '1',
      r.wtr_name,
      r.wtr_pid,
      r.wtr_relation,
      r.wtr_phone
    );
    commit;
    end loop;
END;

/

