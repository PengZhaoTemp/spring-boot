create procedure proc_portal_mailbox_log(
      lvnid in out varchar,    
      lvsid varchar,    
      lvstate varchar,   
      lvnr  varchar,
      lvip  varchar
) is
begin
  select tc_webjj.seq_portal_mailbox_log.nextval into lvnid from dual;
  insert into tc_webjj.t_portal_mailbox_log(
         nid,
         sid,
         state,
         nr,
         otime,
         ip,
         dbbj
  )values(
         lvnid,
         lvsid,
         lvstate,
         lvnr,
         sysdate,
         lvip,
         '0'
  );
  commit;
end;
/

