create PROCEDURE          PROC_t_crj_wszzsq   /*T_CRJ_WSZZSQ*/
(
 lvsdono IN OUT VARCHAR2,  --办理编号
 lvsname VARCHAR2,  --姓　　名
 lvspid VARCHAR2,  --身  份 证
 lvstel VARCHAR2,  --联系电话
 lvsadress VARCHAR2,  --通信地址
 lvssq_type VARCHAR2,  --申请类别
 lvs_qs VARCHAR2,  --是否签收  0未签收 1已签收
 lvs_qs_date DATE,  --签收时间
 lvsjj_adr VARCHAR2,  --寄件地址
 lvssj_adr VARCHAR2,  --收件地址
 lvs_txz varchar2,    --往来港澳通行证号
 lvssj_tel varchar2,
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS

BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/



   INSERT into tc_webjj.t_crj_wszzsq
    (
      sdono,   --办理编号
      sname,   --姓　　名
      spid,   --身  份 证
      stel,   --联系电话
      sadress,   --通信地址
      ssq_type,   --申请类别
      s_qs,   --是否签收  0未签收 1已签收
      s_qs_date,   --签收时间
      sjj_adr,   --寄件地址
      ssj_adr,    --收件地址
      s_txz,
      ssj_tel
    )values(
      lvsdono,   --办理编号
      lvsname,   --姓　　名
      lvspid,   --身  份 证
      lvstel,   --联系电话
      lvsadress,   --通信地址
      lvssq_type,   --申请类别
      '0',   --是否签收  0未签收 1已签收
      lvs_qs_date,   --签收时间
      lvsjj_adr,   --寄件地址
      lvssj_adr,    --收件地址
      lvs_txz,
      lvssj_tel

    );
   -- 返回值

END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_crj_wszzsq
    Set
      sdono=lvsdono,   --办理编号
      sname=lvsname,   --姓　　名
      spid=lvspid,   --身  份 证
      stel=lvstel,   --联系电话
      sadress=lvsadress,   --通信地址
      ssq_type=lvssq_type,   --申请类别
      s_qs=lvs_qs,   --是否签收  0未签收 1已签收
      s_qs_date=lvs_qs_date,   --签收时间
      sjj_adr=lvsjj_adr,   --寄件地址
      ssj_adr=lvssj_adr,    --收件地址
      s_txz=lvs_txz,
      ssj_tel=lvssj_tel
    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_crj_wszzsq
    Set
      sdono=lvsdono,   --办理编号
      sname=lvsname,   --姓　　名
      spid=lvspid,   --身  份 证
      stel=lvstel,   --联系电话
      sadress=lvsadress,   --通信地址
      ssq_type=lvssq_type,   --申请类别
      s_qs=lvs_qs,   --是否签收  0未签收 1已签收
      s_qs_date=lvs_qs_date,   --签收时间
      sjj_adr=lvsjj_adr,   --寄件地址
      ssj_adr=lvssj_adr,    --收件地址
      s_txz=lvs_txz,
      ssj_tel=lvssj_tel
    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_crj_wszzsq
    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

