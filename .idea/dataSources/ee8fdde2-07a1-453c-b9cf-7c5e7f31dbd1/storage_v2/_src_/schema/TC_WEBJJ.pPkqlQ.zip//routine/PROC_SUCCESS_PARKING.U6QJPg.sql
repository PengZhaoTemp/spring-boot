create procedure          proc_success_parking
(
   proc_nparking NUMBER,
   proc_nfree NUMBER,
   proc_sparkingintro VARCHAR2,
   proc_saddress VARCHAR2,
   proc_sno VARCHAR2
) is
begin
   UPDATE tc_webjj.t_car_stop
   Set
      NPARKING = proc_nparking,
      NFREEPARKING = proc_nfree,
      SPARKINGINTRO = proc_sparkingintro,
      SADDRESS = proc_saddress
    Where SNO = proc_sno;
    Commit;
end proc_success_parking;

/

