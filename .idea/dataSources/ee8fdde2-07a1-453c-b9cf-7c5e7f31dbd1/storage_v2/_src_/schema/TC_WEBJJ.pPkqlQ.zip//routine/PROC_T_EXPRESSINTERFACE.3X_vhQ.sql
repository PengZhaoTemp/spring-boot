create PROCEDURE          PROC_t_expressinterface   /*T_EXPRESSINTERFACE*/
(
 lvsexpno IN OUT VARCHAR2,  --快递单号
 lvsexpaddress VARCHAR2,  --收件地址
 lvspostcode VARCHAR2,  --邮政编码
 lvsconsignee VARCHAR2,  --收  件 人
 lvstel VARCHAR2,  --电　　话
 lvscarrier VARCHAR2,  --快  递 员
 lvnexpcharge NUMBER,  --快  递 费
 lvsexpcourse VARCHAR2,  --物流描述
 lvsexpstate VARCHAR2,  --状　　态
 lvsuserno VARCHAR2,  --用户编号
 lvsdono varchar2,   --办理编号
 lvstep varchar2,
 lvsbusno varchar2,
 lv_flownote varchar2,
 lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
lvflownote number;
BEGIN


IF lv_procMode='PMINSERT' THEN    /*登记*/

  --begin TRAN   //已寄出原件
  begin
      select busflowno into lvflownote from v_bus_flow where sbusno=lvsbusno
      and flowstep=(select flowstep+1 from v_bus_flow where sbusno=lvsbusno and busflowno=lv_flownote);
   exception
   when others then
      lvflownote := '';
   end;
  update t_dobus set state='15',SEXPNO=lvsexpno,dbbj='0',dbsj=sysdate,flownote=lvflownote where  sdono=lvsdono ;

   --增加一条寄送信息
   INSERT into tc_webjj.t_expressinterface
    (
      sexpno,   --快递单号
      sexpaddress,   --收件地址
      spostcode,   --邮政编码
      sconsignee,   --收  件 人
      stel,   --电　　话
      scarrier,   --快  递 员
      nexpcharge,   --快  递 费
      sexpcourse,   --物流描述
      sexpstate,   --状　　态
      suserno,    --用户编号
      sdono,
      dbbj,
      dbsj
    )values(
      lvsexpno,   --快递单号
      lvsexpaddress,   --收件地址
      lvspostcode,   --邮政编码
      lvsconsignee,   --收  件 人
      lvstel,   --电　　话
      lvscarrier,   --快  递 员
      lvnexpcharge,   --快  递 费
      lvsexpcourse,   --物流描述
      lvsexpstate,   --状　　态
      lvsuserno,    --用户编号
      lvsdono,
      '0',
      sysdate
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_expressinterface
    Set
      sexpno=lvsexpno,   --快递单号
      sexpaddress=lvsexpaddress,   --收件地址
      spostcode=lvspostcode,   --邮政编码
      sconsignee=lvsconsignee,   --收  件 人
      stel=lvstel,   --电　　话
      scarrier=lvscarrier,   --快  递 员
      nexpcharge=lvnexpcharge,   --快  递 费
      sexpcourse=lvsexpcourse,   --物流描述
      sexpstate=lvsexpstate,   --状　　态
      suserno=lvsuserno,    --用户编号
      sdono=lvsdono,
      dbbj='0',
      dbsj=sysdate
    Where 1=1
    and sexpno=lvsexpno   --快递单号
    and sdono=lvsdono
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_expressinterface
    Set
      sexpno=lvsexpno,   --快递单号
      sexpaddress=lvsexpaddress,   --收件地址
      spostcode=lvspostcode,   --邮政编码
      sconsignee=lvsconsignee,   --收  件 人
      stel=lvstel,   --电　　话
      scarrier=lvscarrier,   --快  递 员
      nexpcharge=lvnexpcharge,   --快  递 费
      sexpcourse=lvsexpcourse,   --物流描述
      sexpstate=lvsexpstate,   --状　　态
      suserno=lvsuserno,    --用户编号
       sdono=lvsdono,
       dbbj='0',
      dbsj=sysdate
    Where 1=1
    and sexpno=lvsexpno   --快递单号
     and sdono=lvsdono
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_expressinterface
    Where 1=1
    and sexpno=lvsexpno   --快递单号
     and sdono=lvsdono
    ;
END IF;
 Commit;
END; /*存储过程结束*/

