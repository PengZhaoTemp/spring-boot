create procedure          PROC_APP_LESSEE(
   lvpid VARCHAR2,        --承租人身份证号
   lvname VARCHAR2,        --承租人姓名
   lvphone VARCHAR2,      --承租人电话
   lvinputid VARCHAR2--登记人ID
)
as
begin
    insert into tc_webjj.t_rentcar_check
    (
    SID,PID,NAME,TEL,
    CARNO,REGDATE,REGERID,RESULT,
    CCIC,
    SDONO,
    DBSJ,DBBJ
    )values
   (
   tc_weixin.fun_get16code(tc_webjj.SEQ_RENTCAR_CHECK_SID.nextval,'350201',2),
   lvpid,
   lvname,
   lvphone,
   'null',
   sysdate,
   lvinputid,
   NULL,
   NULL,
   tc_weixin.fun_get16code(tc_weixin.seq_weixin_dobus_sdono.nextval,'350201',2),
   sysdate,
   '0'
   -- '100','234','test','1','234',sysdate,0
   );

    insert into tc_webjj.t_roomer_check
    (
    SID,
    PID,NAME,TEL,ADDRESS,REGDATE,REGERID,RESULT,CCIC,
    SDONO,
    DBSJ,DBBJ
    )values
   (
   tc_weixin.fun_get16code(tc_webjj.SEQ_ROOMER_CHECK_SID.nextval,'350201',2),
   lvpid,
   lvname,
   lvphone,
   'null',
   sysdate,
   lvinputid,
   NULL,
   NULL,
  tc_weixin.fun_get16code(tc_weixin.seq_weixin_dobus_sdono.nextval,'350201',2),
   sysdate,
   '0'
   -- '100','234','test','1','234',sysdate,0
   );

end PROC_APP_LESSEE;

/

