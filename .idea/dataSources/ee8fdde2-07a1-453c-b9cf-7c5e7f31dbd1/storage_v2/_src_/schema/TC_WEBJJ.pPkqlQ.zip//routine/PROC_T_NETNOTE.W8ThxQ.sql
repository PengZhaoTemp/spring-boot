create PROCEDURE          PROC_t_netnote   /*T_NETNOTE*/
(
 lvsnoteno IN OUT VARCHAR2,  --短信编号
 lvsuserno VARCHAR2,  --用户编号
 lvsdono VARCHAR2,  --办理编号
 lvsnote VARCHAR2,  --短信内容
 lvdrecdate DATE,  --接收时间
 lvsreadflag VARCHAR2,  --sreadflag
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
    Select TC_WEBJJ.SEQ_T_NETNOTE_SNOTENO.Nextval  into lvsnoteno From dual;    /*短信编号序列*/
   INSERT into tc_webjj.t_netnote
    (
      snoteno,   --短信编号
      suserno,   --用户编号
      sdono,   --办理编号
      snote,   --短信内容
      drecdate,   --接收时间
      sreadflag    --sreadflag
    )values(
      lvsnoteno,   --短信编号
      lvsuserno,   --用户编号
      lvsdono,   --办理编号
      lvsnote,   --短信内容
      lvdrecdate,   --接收时间
      lvsreadflag    --sreadflag
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_netnote
    Set
      snoteno=lvsnoteno,   --短信编号
      suserno=lvsuserno,   --用户编号
      sdono=lvsdono,   --办理编号
      snote=lvsnote,   --短信内容
      drecdate=lvdrecdate,   --接收时间
      sreadflag=lvsreadflag    --sreadflag
    Where 1=1
    and snoteno=lvsnoteno   --短信编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_netnote
    Set
      snoteno=lvsnoteno,   --短信编号
      suserno=lvsuserno,   --用户编号
      sdono=lvsdono,   --办理编号
      snote=lvsnote,   --短信内容
      drecdate=lvdrecdate,   --接收时间
      sreadflag=lvsreadflag    --sreadflag
    Where 1=1
    and snoteno=lvsnoteno   --短信编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_netnote
    Where 1=1
    and snoteno=lvsnoteno   --短信编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

