create function          fun_EncrypKey(src_char varchar2)
return varchar2
as
  idx number;
  KeyLen number;
  KeyPos number;
  offset number;
  dest varchar2(200);
  SrcPos number;
  SrcAsc number;
  TmpSrcAsc number;
  Key varchar2(200);
  src varchar2(50);
  tmp varchar2(2);
  tmp_srcAsc varchar2(2);
  raw_data1    RAW(6);
  raw_data2    RAW(6);
  tmp_key number;
begin
  if src_char is  null then
    return null;
  end if;
  select upper(src_char) into src from dual;
  Key:='PassWord';
  select length(key) into KeyLen from dual;
  KeyPos:=0;
  SrcPos:=0;
  SrcAsc:=0;
  offset:=193;
  dest:=to_hex(offset);
  for srcpos  in 1 .. length(src) loop
    SrcAsc:=mod (ascii(substr(src,srcpos,1))+offset,255);
    if KeyPos < KeyLen then KeyPos:= KeyPos + 1 ;
      else KeyPos:=1;
    end if;
    raw_data1:=HEXTORAW(to_hex(srcAsc));
    tmp_key:=ascii(substr(key,keypos,1));
    raw_data2:=HEXTORAW(to_hex(tmp_key));
    select UTL_RAW.BIT_XOR(raw_data2,raw_data1) into tmp from dual;
    dest:=dest || tmp;
    offset:=to_dec(tmp);
  end loop;
  return dest;
end;
/

