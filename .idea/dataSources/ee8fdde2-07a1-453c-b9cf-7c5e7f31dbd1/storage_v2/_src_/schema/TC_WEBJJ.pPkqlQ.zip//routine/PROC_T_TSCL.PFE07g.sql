create PROCEDURE          PROC_t_tscl   /*T_TSCL*/
(
 lvsno IN OUT VARCHAR2,  --编　　号
 lvts_name VARCHAR2,  --投  诉 人
 lvts_pid VARCHAR2,  --投诉人身份证
 lvts_bm VARCHAR2,  --投诉部门
 lvts_bt VARCHAR2,  --投诉标题
 lvts_content VARCHAR2,  --投诉内容
 lvts_time DATE,  --投诉时间
 lvre_time DATE,  --反馈日期
 lvre_name varchar2,
 lvre_code varchar2,
 lvre_content varchar2,
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS

BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/

 select   tc_webjj.SEQ_T_TSCL_SNO.nextval into lvsno from dual ;

   INSERT into tc_webjj.t_tscl
    (
      sno,   --编　　号
      ts_name,   --投  诉 人
      ts_pid,   --投诉人身份证
      ts_bm,   --投诉部门
      ts_bt,   --投诉标题
      ts_content,   --投诉内容
      ts_time,    --投诉时间
      re_time,
      re_name,
      re_code,
      re_content
    )values(
      lvsno,   --编　　号
      lvts_name,   --投  诉 人
      lvts_pid,   --投诉人身份证
      lvts_bm,   --投诉部门
      lvts_bt,   --投诉标题
      lvts_content,   --投诉内容

      sysdate ,   --投诉时间
      lvre_time,
      lvre_name,
      lvre_code,
      lvre_content
    );
   -- 返回值

END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_tscl
    Set
      sno=lvsno,   --编　　号
      ts_name=lvts_name,   --投  诉 人
      ts_pid=lvts_pid,   --投诉人身份证
      ts_bm=lvts_bm,   --投诉部门
      ts_bt=lvts_bt,   --投诉标题
      ts_content=lvts_content,   --投诉内容
      ts_time=lvts_time,    --投诉时间
      re_time=sysdate,
      re_name=lvre_name,
      re_code=lvre_code,
      re_content=lvre_content
    Where 1=1
    and sno=lvsno   --编　　号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_tscl
    Set
      sno=lvsno,   --编　　号
      ts_name=lvts_name,   --投  诉 人
      ts_pid=lvts_pid,   --投诉人身份证
      ts_bm=lvts_bm,   --投诉部门
      ts_bt=lvts_bt,   --投诉标题
      ts_content=lvts_content,   --投诉内容
      ts_time=lvts_time,    --投诉时间
      re_time=sysdate,
      re_name=lvre_name,
      re_code=lvre_code,
      re_content=lvre_content
    Where 1=1
    and sno=lvsno   --编　　号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_tscl
    Where 1=1
    and sno=lvsno   --编　　号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

