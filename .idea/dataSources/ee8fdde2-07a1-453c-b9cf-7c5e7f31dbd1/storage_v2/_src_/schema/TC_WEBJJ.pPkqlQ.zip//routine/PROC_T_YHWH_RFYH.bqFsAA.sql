create PROCEDURE          PROC_t_yhwh_rfyh
(
 lvsno in out varchar2,--序号
 lvsdono VARCHAR2,  --业务编号
 lvRf_time Date,  --燃放时间
 lvYh_type VARCHAR2,  --烟花爆竹种类
 lvYh_gg VARCHAR2,  --规格
 lvYh_shuliang varchar2,--数量
 lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
   select SEQ_T_yhwh_rfyh.Nextval into lvsno from dual;
   INSERT into tc_webjj.T_yhwh_rfyh
    (
      sno,
      sdono,
      Rf_time,
      Yh_type,
      Yh_gg,
      Yh_shuliang,
      dbbj,
      dbsj
    )values(
      lvsno ,
      lvsdono ,
      lvRf_time,
      lvYh_type,
      lvYh_gg,
      lvYh_shuliang,
      '0',
      sysdate
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.T_yhwh_rfyh
    Set
      sno=lvsno,
      sdono=lvsdono,
      Rf_time=lvRf_time,
      Yh_type=lvYh_type,
      Yh_gg=lvYh_gg,
      Yh_shuliang=lvYh_shuliang,
      dbbj='0',
      dbsj=sysdate
    Where 1=1
    and sno=lvsno
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.T_yhwh_rfyh
    Set
      sno=lvsno,
      sdono=lvsdono,
      Rf_time=lvRf_time,
      Yh_type=lvYh_type,
      Yh_gg=lvYh_gg,
      Yh_shuliang=lvYh_shuliang,
      dbbj='0',
      dbsj=sysdate
    Where 1=1
    and sno=lvsno
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    update tc_webjj.T_yhwh_rfyh set zxbj='1',dbbj='0',dbsj=sysdate
    Where 1=1
    and sno=lvsno
    ;
END IF;
 Commit;
END; /*存储过程结束*/

