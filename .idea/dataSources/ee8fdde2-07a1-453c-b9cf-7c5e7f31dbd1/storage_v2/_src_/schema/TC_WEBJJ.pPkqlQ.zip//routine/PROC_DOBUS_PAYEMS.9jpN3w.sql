create procedure proc_dobus_payems(
       lvsdono varchar2,
       lvsoperationno varchar2,
       lvssendtype varchar2,
       lvsuserno           varchar2,--用户编号
       lvsusername         varchar2,--用户姓名
       lvsorgid            varchar2,--操作单位代码（群众的时候不需要操作单位）
       lvsorgname          varchar2,--操作单位名称（群众的时候不需要操作单位）
       lvsplanno           varchar2
) is
lvslogno varchar2(16);
lvsoperationname varchar2(16);
lvsusertype varchar2(1);
lvsresult varchar2(500);
begin
    if to_number(lvssendtype) = 0 then
       --lvsresult := '您已经支付回寄快递费用，请将原材料送往办理单位。';
       lvsresult := '请将原材料送往办理单位。';
    elsif to_number(lvssendtype) > 0 then
       --lvsresult := '您已经支付快递费用，请准备好相关材料，等待中国邮政工作人员上门揽件。';
       lvsresult := '您已下单，请准备好相关材料，等待中国邮政工作人员上门揽件。';
    end if;
    tc_webjj.proc_dobus_pay_next(lvsdono,'1');
    update tc_webjj.t_dobus set
           scontext = lvsresult
           where sdono = lvsdono;
       --快递下单
     -- tc_webjj.proc_weixin_express(lvsdono);
    --日志
    select a.sname,a.stype into lvsoperationname,lvsusertype from tc_webjj.t_operation_deploy a where a.sno=lvsoperationno;
    proc_dobus_log_info(
      lvslogno,
      lvsplanno,
      lvsoperationno,
      lvsoperationname,
      lvsdono,
      lvsusertype,
      lvsuserno,
      lvsusername,
      lvsorgid,
      lvsorgname,
      lvsresult
    );
    proc_dobus_nextflow(lvsdono);
    commit;
end proc_dobus_payems;
/

