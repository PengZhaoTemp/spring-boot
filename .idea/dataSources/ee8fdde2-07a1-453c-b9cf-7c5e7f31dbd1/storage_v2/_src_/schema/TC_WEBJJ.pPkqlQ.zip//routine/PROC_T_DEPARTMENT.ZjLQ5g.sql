create PROCEDURE          PROC_t_department   /*T_DEPARTMENT*/
(
 lvnid IN OUT VARCHAR2,  --编　　号
 lvde_name VARCHAR2,  --部门名称
 lvde_tel VARCHAR2,  --部门电话
 lvjob_time VARCHAR2,      --办公时间
 lvjob_address VARCHAR2,      --办公地点
 lvtop_pic VARCHAR2,  --新闻图片
 lvjob_content VARCHAR2,  --工作职责
 lvtonggao VARCHAR2,  --部门通告
 lvnew_name VARCHAR2,  --模块一名称
 lvpart2_name VARCHAR2,  --模块二名称
 lvpart3_name VARCHAR2,  --模块三名称
 lvdbbj VARCHAR2,  --dbbj
 lvdbsj DATE,  --dbsj
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
    Select tc_weBJJ.SEQ_T_DEPARTMENT_NID.Nextval  into lvnid From dual;    /*编　　号序列*/
   INSERT into tc_webjj.t_department
    (
      nid,   --编　　号
      de_name,   --部门名称
      de_tel,   --部门电话
      job_time, --办公时间
      job_address,     --办公地点
      top_pic,   --新闻图片
      job_content,   --工作职责
      tonggao,   --部门通告
      new_name,   --模块一名称
      part2_name,   --模块二名称
      part3_name,   --模块三名称
      dbbj,   --dbbj
      dbsj    --dbsj
    )values(
      lvnid,   --编　　号
      lvde_name,   --部门名称
      lvde_tel,   --部门电话
      lvjob_time,         --办公时间
      lvjob_address,      --办公地点
      lvtop_pic,   --新闻图片
      lvjob_content,   --工作职责
      lvtonggao,   --部门通告
      lvnew_name,   --模块一名称
      lvpart2_name,   --模块二名称
      lvpart3_name,   --模块三名称
      lvdbbj,   --dbbj
      lvdbsj    --dbsj
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_department
    Set
      nid=lvnid,   --编　　号
      de_name=lvde_name,   --部门名称
      de_tel=lvde_tel,   --部门电话
      job_time=lvjob_time,         --办公时间
      job_address=lvjob_address,      --办公地点
      top_pic=lvtop_pic,   --新闻图片
      job_content=lvjob_content,   --工作职责
      tonggao=lvtonggao,   --部门通告
      new_name=lvnew_name,   --模块一名称
      part2_name=lvpart2_name,   --模块二名称
      part3_name=lvpart3_name,   --模块三名称
      dbbj=lvdbbj,   --dbbj
      dbsj=lvdbsj    --dbsj
    Where 1=1
    and nid=lvnid   --编　　号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_department
    Set
      nid=lvnid,   --编　　号
      de_name=lvde_name,   --部门名称
      de_tel=lvde_tel,   --部门电话
      job_time=lvjob_time,         --办公时间
      job_address=lvjob_address,      --办公地点
      top_pic=lvtop_pic,   --新闻图片
      job_content=lvjob_content,   --工作职责
      tonggao=lvtonggao,   --部门通告
      new_name=lvnew_name,   --模块一名称
      part2_name=lvpart2_name,   --模块二名称
      part3_name=lvpart3_name,   --模块三名称
      dbbj=lvdbbj,   --dbbj
      dbsj=lvdbsj    --dbsj
    Where 1=1
    and nid=lvnid   --编　　号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_department
    Where 1=1
    and nid=lvnid   --编　　号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

