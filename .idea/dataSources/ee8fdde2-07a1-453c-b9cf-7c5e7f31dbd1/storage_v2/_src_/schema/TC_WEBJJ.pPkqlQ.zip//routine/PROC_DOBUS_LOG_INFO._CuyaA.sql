create procedure          proc_dobus_log_info(
        lvslogno         in out   varchar2,--日志表
        lvsplanno           varchar2,--流程进度编号
        lvsoperationno      varchar2,--操作编号
        lvsoperationname    varchar2,--操作名称
        lvsdono             varchar2,--办理编号
        lvsusertype         varchar2,--1-民警 2-群众
        lvsuserno           varchar2,--用户编号
        lvsusername         varchar2,--用户姓名
        lvsorgid            varchar2,--操作单位代码（群众的时候不需要操作单位）
        lvsorgname          varchar2,--操作单位名称（群众的时候不需要操作单位）
        lvsresult            varchar2--操作结果（结果描述） 
) is
begin
   select tc_webjj.fun_get16code(tc_webjj.seq_dobus_slogno.nextval) into lvslogno from dual;
   insert into tc_webjj.t_dobus_log(
      slogno          ,
      splanno          ,
      soperationno    ,
      soperationname  ,
      sdono            ,
      susertype        ,
      suserno          ,
      susername        ,
      sorgid          ,
      sorgname        ,
      sresult          ,
      sdotime
   )values(
      lvslogno          ,
      lvsplanno          ,
      lvsoperationno    ,
      lvsoperationname  ,
      lvsdono            ,
      lvsusertype        ,
      lvsuserno          ,
      lvsusername        ,
      lvsorgid          ,
      lvsorgname        ,
      lvsresult          ,
      sysdate
   );
end proc_dobus_log_info;
/

