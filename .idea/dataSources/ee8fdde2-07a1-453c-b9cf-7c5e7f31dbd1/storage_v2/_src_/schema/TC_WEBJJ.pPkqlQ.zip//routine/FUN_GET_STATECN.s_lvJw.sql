create function          fun_get_statecn(
      lvstate varchar2,
      lvssendtype varchar2,
      lvsbusno varchar2
)
return varchar2
is
lvReturn varchar2(200);
begin

  if lvstate = '12' and lvssendtype = '亲自送' then
     lvReturn := '<img src=''/webjjcss/ems.gif'' />亲自送材料</img>';
  else
    if lvstate = '12' and lvsbusno = '0419' then
       lvReturn := '<img src=''/webjjcss/ems.gif'' />材料上传</img>';
     else

       select busstatusname into lvReturn from tc_webjj.t_busstatus_deploy where busstatuscode=lvstate;

    end if;
  end if;
  return lvReturn;
end fun_get_statecn;

/

