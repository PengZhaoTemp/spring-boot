create procedure          PROC_t_cgs_bljsz_SDONO
(
     lvoldsdono VARCHAR2,  --办理编号
     lvReturn in out varchar2 --新办理编号
)
as
  cursor c is
     select * from tc_webjj.t_cgs_bljsz
     where 1=1
     and sdono=lvoldsdono;   --公民身份号码
  r c%rowtype;

BEGIN
   select TC_WEBJJ.fun_get16code(TC_WEBJJ.SEQ_T_DOBUS_SDONO.Nextval)  into  lvReturn from dual  where 1=1;
   for r in c loop
   INSERT into tc_webjj.t_cgs_bljsz
    (
      sdono,   --办理编号
      sdabh,   --档案编号
      sname,   --姓　　名
      ssex,   --性　　别
      spid,   --身份证号码
      saddress,   --身份证地址
      stel,   -- 联系电话
      szjcx,   --准驾车型
      sbl_reason,   --补领原因
      spic    --近期六个月照片
    )values(
      lvReturn,   --办理编号
      r.sdabh,   --档案编号
      r.sname,   --姓　　名
      r.ssex,   --性　　别
      r.spid,   --身份证号码
      r.saddress,   --身份证地址
      r.stel,   -- 联系电话
      r.szjcx,   --准驾车型
      r.sbl_reason,   --补领原因
      r.spic    --近期六个月照片
    );
    commit;
    end loop;
END;

/

