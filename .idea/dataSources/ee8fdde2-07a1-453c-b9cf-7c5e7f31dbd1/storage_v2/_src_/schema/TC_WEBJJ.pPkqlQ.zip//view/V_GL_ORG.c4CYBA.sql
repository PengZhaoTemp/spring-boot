create view V_GL_ORG as
  select '01' stype,'1' unit_level, sunit_code,orgname,sshort_name from tc_jcyw.t_org where sunit_code like '61__00000000'  and substr(sunit_code,3,2)!=0 and dcancel_app_date is null
UNION ALL
--??????
select '01' stype,'2' unit_level,sunit_code,orgname,sshort_name from tc_jcyw.t_hzorg_dzb where sunit_code like '61____000000'  and substr(sunit_code,5,2)!=0 and dcancel_app_date is null
UNION ALL
--??????
select '01' stype,'3' unit_level,sunit_code,orgname,sshort_name from tc_jcyw.t_hzorg_dzb where sunit_code like '61______1200'  and dcancel_app_date is null
--??????????
UNION ALL
select '0101' stype,'1' unit_level, sunit_code,orgname,sshort_name from tc_jcyw.t_org where sunit_code like '61__00000000'  and substr(sunit_code,3,2)!=0 and dcancel_app_date is null
UNION ALL
--??????
select '0101' stype,'2' unit_level,sunit_code,orgname,sshort_name from tc_jcyw.t_hzorg_dzb where sunit_code like '61____000100'  and substr(sunit_code,5,2)!=0 and dcancel_app_date is null
UNION ALL
select '0102' stype,'1' unit_level, sunit_code,orgname,sshort_name from tc_jcyw.t_org where sunit_code like '61__00000000'  and substr(sunit_code,3,2)!=0 and dcancel_app_date is null
UNION ALL
--??????
select '0102' stype,'2' unit_level,sunit_code,orgname,sshort_name from tc_jcyw.t_hzorg_dzb where sunit_code like '61____000000'  and substr(sunit_code,5,2)!=0 and dcancel_app_date is null
UNION ALL
--??????
select '0102' stype,'3' unit_level,sunit_code,orgname,sshort_name from tc_jcyw.t_hzorg_dzb where sunit_code like '61____000100'  and dcancel_app_date is null
--??????????
UNION ALL
select  '0201' stype,'1' unit_level, sunit_code,orgname,sshort_name from tc_jcyw.t_zaorg_dzb where sunit_code like '61__00000000'  and substr(sunit_code,3,2)!=0 and sunit_code!='619800000000' and dcancel_app_date is null
UNION ALL
select  '0201' stype,'99' unit_level, sunit_code,orgname,sshort_name from tc_jcyw.t_zaorg_dzb where sunit_code like '61__00000000'  and substr(sunit_code,3,2)!=0 and dcancel_app_date is null
UNION ALL
--????????????
select '0201' stype,'2' unit_level,sunit_code,orgname,sshort_name from tc_jcyw.t_zaorg_dzb where sunit_code like '61____000000' and sunit_code<>'610297000000'  and substr(sunit_code,5,2)!=0  and dcancel_app_date is null
UNION ALL
--????????????
select '0201' stype,'3' unit_level,sunit_code,orgname,sshort_name from tc_jcyw.t_zaorg_dzb where sunit_code like '61______1200'  and dcancel_app_date is null
--????????
--??????????
UNION ALL
select  '0202' stype,'1' unit_level, sunit_code,orgname,sshort_name from tc_jcyw.t_zaorg_dzb where sunit_code like '61__00000000'  and substr(sunit_code,3,2)!=0 and sunit_code!='619800000000'  and dcancel_app_date is null
--????????????
UNION ALL
select '0202' stype,'2' unit_level,sunit_code,orgname,sshort_name from tc_jcyw.t_zaorg_dzb where (sunit_code like '61____000000'  and substr(sunit_code,5,2)!=0 or sunit_code like '61__00000200')  and dcancel_app_date is null
--????????????
UNION ALL
select '0202' stype,'3' unit_level,sunit_code,orgname,sshort_name from tc_jcyw.t_zaorg_dzb where sunit_code like '61____000200'  and dcancel_app_date is null
--????????
--????
union all
select  '0203' stype,'1' unit_level, sunit_code,orgname,sshort_name from tc_jcyw.t_zaorg_dzb where sunit_code like '61__00000000'  and substr(sunit_code,3,2)!=0 and sunit_code!='619800000000' and dcancel_app_date is null
union all
select '0203' stype,'2' unit_level,sunit_code,orgname,sshort_name from tc_jcyw.t_zaorg_dzb where sunit_code like '61__00000200'  and dcancel_app_date is null



--????????

--??????
UNION ALL
SELECT '03' stype,'1' unit_level , sunit_code,orgname,sshort_name from tc_jcyw.t_org where sunit_code like '61__00000000' and substr(sunit_code,3,2)!=0 and sunit_code!='619800000000' and dcancel_app_date is null
--????
UNION ALL
select '03' stype,'2' unit_level,sunit_code,orgname,sshort_name from tc_jcyw.t_org where sunit_code like '61__00__0301' and substr(sunit_code,3,2)!=0  and dcancel_app_date is null

--??????????(?????????? )
--??????
UNION ALL
SELECT '10' stype,'1' unit_level , sunit_code,orgname,sshort_name from tc_jcyw.t_org where sunit_code like '61__00000000' and substr(sunit_code,3,2)!=0 and sunit_code!='619800000000' and dcancel_app_date is null
--??????????
UNION ALL
select '10' stype,'2' unit_level ,sunit_code,orgname,sshort_name from tc_jcyw.t_crjorg_dzb where sunit_code like '61____000000'  and substr(sunit_code,5,2)!=0 or sunit_code like '61__00000401' and dcancel_app_date is null
--??????????
UNION ALL
SELECT '10' stype,'3' unit_level , sunit_code,orgname,sshort_name from tc_jcyw.t_crjorg_dzb where sunit_code like '61____000401' and dcancel_app_date is null
--?????????? ??????????????
union all
SELECT '1010' stype,'1' unit_level , sunit_code,orgname,sshort_name from tc_jcyw.t_org where sunit_code like '61__00000000' and substr(sunit_code,3,2)!=0 and sunit_code!='619800000000' and dcancel_app_date is null
union all
select '1010' stype,'2' unit_level ,sunit_code,orgname,sshort_name from tc_jcyw.t_crjorg_dzb where sunit_code like '61__00000000'  and substr(sunit_code,5,2)!=0 or sunit_code like '61__00000401' and dcancel_app_date is null


--????????
--????????
UNION ALL
SELECT '08' stype,'1' unit_level , sunit_code,orgname,sshort_name from tc_jcyw.t_org where sunit_code like '61__00000000' and sunit_code!='619800000000' and dcancel_app_date is null
--??????????????????
UNION ALL
select '08' stype,'2' unit_level ,sunit_code,orgname,sshort_name from tc_jcyw.t_org where  sunit_code like '61______0701'   and dcancel_app_date is null


--????????
--??????
UNION ALL
SELECT '06' stype,'1' unit_level , sunit_code,orgname,sshort_name from tc_jcyw.t_xforg_dzb  where sunit_code like '61__00000000' and substr(sunit_code,3,2)!=0 and sunit_code!='619800000000' and dcancel_app_date is null
--????????
UNION ALL
select '06' stype,'2' unit_level ,sunit_code,orgname,sshort_name from tc_jcyw.t_xforg_dzb where sunit_code like '61____000000'  and substr(sunit_code,5,2)!=0 or sunit_code like '61__00001000' and dcancel_app_date is null
--??????????
UNION ALL
SELECT '06' stype,'3' unit_level , sunit_code,orgname,sshort_name from tc_jcyw.t_xforg_dzb where sunit_code like '61____001000' and dcancel_app_date is null

--????????
UNION ALL
select '14' stype,'1' unit_level ,sunit_code,orgname,sshort_name from tc_jcyw.t_org where sunit_code='610100001100' and dcancel_app_date is null


--????????
--??????
UNION ALL
SELECT '05' stype,'1' unit_level , sunit_code,orgname,sshort_name from tc_jcyw.t_org where sunit_code like '61__00000000' and substr(sunit_code,3,2)!=0 and sunit_code!='619800000000' and sunit_code!='616100000000' and dcancel_app_date  is null
--????????
UNION ALL
select '05' stype,'2' unit_level ,sunit_code,orgname,sshort_name from tc_jcyw.t_waorg_dzb where sunit_code like '61____000000' and dcancel_app_date is null  and substr(sunit_code,5,2)!=0 or sunit_code like '61__00000800'
--????????
UNION ALL
SELECT '05' stype,'3' unit_level , sunit_code,orgname,sshort_name from tc_jcyw.t_waorg_dzb where sunit_code like '61____000800' and dcancel_app_date is null
--????????????
UNION ALL
SELECT '0501' stype,'1' unit_level , sunit_code,orgname,sshort_name from tc_jcyw.t_org where sunit_code like '61__00000000' and substr(sunit_code,3,2)!=0 and sunit_code!='619800000000' and sunit_code!='616100000000' and dcancel_app_date  is null
UNION ALL
select '0501' stype,'2' unit_level ,sunit_code,orgname,sshort_name from tc_jcyw.t_waorg_dzb where  sunit_code like '61__00000800' and dcancel_app_date is null
--????????
--??????
UNION ALL
SELECT '09' stype,'1' unit_level , sunit_code,orgname,sshort_name from tc_jcyw.t_org where sunit_code like '61__00000000' and substr(sunit_code,3,2)!=0 and sunit_code!='619800000000' and dcancel_app_date is null
--????????
UNION ALL
select '09' stype,'2' unit_level ,sunit_code,orgname,sshort_name from tc_jcyw.t_jdorg_dzb where sunit_code like '61____000000'  and substr(sunit_code,5,2)!=0 or sunit_code like '61__00000900' and dcancel_app_date is null

--????????
UNION ALL
SELECT '09' stype,'3' unit_level , sunit_code,orgname,sshort_name from tc_jcyw.t_jdorg_dzb where sunit_code like '61____000900' and dcancel_app_date is null
/

