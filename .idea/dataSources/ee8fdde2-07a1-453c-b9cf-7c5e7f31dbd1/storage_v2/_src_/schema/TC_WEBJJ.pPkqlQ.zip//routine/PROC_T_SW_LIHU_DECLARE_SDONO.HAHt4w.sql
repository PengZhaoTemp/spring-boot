create procedure          PROC_t_sw_lihu_declare_SDONO
(
     lvoldsdono VARCHAR2,  --办理编号
     lvReturn in out varchar2 --新办理编号
)
as
  cursor c is
     select * from tc_webjj.t_sw_lihu_declare
     where 1=1
     and sdono=lvoldsdono ;  --办理编号
      r c%rowtype;

BEGIN
   select TC_WEBJJ.fun_get16code(TC_WEBJJ.SEQ_T_DOBUS_SDONO.Nextval)  into  lvReturn from dual  where 1=1;
   for r in c loop
   INSERT into tc_webjj.t_sw_lihu_declare
    (
      sdono,   --业务编号
      master_relation,   --与户主关系
      app_type,   --申请类别
      app_why_apply,   --申报理由
      pid,   --公民身份证
      name,   --姓　　名
      change_reason,   --变动原因
      removecity,   --所属省市
      removeaddr,   --详　　址
      app_name,   --申请人姓名
      app_pid,   --申请人身份证
      applyno,   --派综申请编号
      sypcs,   --原户口所在派出所
      hkzxfs,   --户口注销方式
      wtr_name,   --投靠人姓名
      wtr_pid,   --投靠人身份证
      wtr_relation,   --与落户人关系
      wtr_phone,   --投靠人联系方式
      haozuo,   --门  牌 号
      seat,   --楼　　座
      room,   --室
      sxzjd_name,   --乡镇街道
      quxcun_name,   --居(村)委
      teamid,   --组
      building_name,   --小区（楼房）
      hu_kind_name,   --户别：集体户 家庭户
      sseat,   --楼座单位
      sroom,    --室  单 位
      addr,
      qu,
      toponym
    )values(
     lvReturn,   --业务编号
      r.master_relation,   --与户主关系
      r.app_type,   --申请类别
      r.app_why_apply,   --申报理由
      r.pid,   --公民身份证
      r.name,   --姓　　名
      r.change_reason,   --变动原因
      r.removecity,   --所属省市
      r.removeaddr,   --详　　址
      r.app_name,   --申请人姓名
      r.app_pid,   --申请人身份证
      r.applyno,   --派综申请编号
      r.sypcs,   --原户口所在派出所
      r.hkzxfs,   --户口注销方式
      r.wtr_name,   --投靠人姓名
      r.wtr_pid,   --投靠人身份证
      r.wtr_relation,   --与落户人关系
      r.wtr_phone,   --投靠人联系方式
      r.haozuo,   --门  牌 号
      r.seat,   --楼　　座
      r.room,   --室
      r.sxzjd_name,   --乡镇街道
      r.quxcun_name,   --居(村)委
      r.teamid,   --组
      r.building_name,   --小区（楼房）
      r.hu_kind_name,   --户别：集体户 家庭户
      r.sseat,   --楼座单位
      r.sroom,    --室  单 位
      r.addr,
      r.qu,
      r.toponym
    );
   -- 返回值

    commit;
    end loop;
END;

/

