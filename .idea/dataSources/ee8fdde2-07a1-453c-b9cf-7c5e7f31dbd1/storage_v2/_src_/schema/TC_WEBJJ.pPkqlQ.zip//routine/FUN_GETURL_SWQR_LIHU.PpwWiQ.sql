create function          fun_geturl_swqr_lihu(lvsdono varchar2)
  return varchar2 is
  lvsurl       varchar2(500);
  lv_PID       varchar2(18);
  lv_NAME      varchar2(50);
  lv_APP_PID   varchar2(18);
  lv_APP_NAME  varchar2(50);
  lv_count     number;
  lv_bd_type   varchar2(20);
  lv_send_flag varchar2(50);
  --lvmeta_addr_id  number;
  lvsbooking  varchar2(2);
  lv_sel_code varchar(10);
  lv_sel_xzqh varchar(100);
  lv_sbusno   VARCHAR2(6);
  lvaddr      varchar2(200);
  lvtoponym   varchar2(75);
  /*  lvTOPONYM       VARCHAR2(75); --Y     地名
  lvHAOZUO        VARCHAR2(120); --Y     门牌号
  lvSEAT          VARCHAR2(120); --Y     楼座
  lvROOM          VARCHAR2(45); --Y      室
  lvSXZJD_NAME    VARCHAR2(300); --Y     乡镇街道
  lvQUXCUN_NAME   VARCHAR2(300); --Y      居(村)委
  lvTEAMID        VARCHAR2(45); --Y      组
  lvBUILDING_NAME VARCHAR2(75); -- Y     小区（楼房）*/
  lvhu_kind_name varchar2(50); --户别

begin
  /*    市外迁入。立户
    psn_apply_detail.jsp?opr_type=市外迁入&bd_type=投资
  &createorenterhu=立户&come_hu_id=&come_meta_addr_id=93762
  &app_person_id=&app_hu_id=&app_meta_addr_id=
  &hu_name=&hu_kind_name=家庭户&sel_xzqh=北京市朝阳区&sel_xzqh_code=110105&sel_qyfw=省外
    */
  lvsurl   := '';
  lv_count := 0;
  select PID,
         NAME,
         APP_PID,
         APP_NAME,
         APP_TYPE,
         REMOVECITY,
         qu || toponym || addr,
         hu_kind_name,
         toponym
  /*   toponym,
  haozuo,
  seat,
  room,
  sxzjd_name,
  quxcun_name,
  teamid,
  building_name,
  hu_kind_name*/
    into lv_PID,
         lv_NAME,
         lv_APP_PID,
         lv_APP_NAME,
         lv_bd_type,
         lv_sel_xzqh,
         lvaddr,
         lvhu_kind_name,
         lvtoponym
  /*lvTOPONYM,
  lvHAOZUO,
  lvSEAT,
  lvROOM,
  lvSXZJD_NAME,
  lvQUXCUN_NAME,
  lvTEAMID,
  lvBUILDING_NAME,
  lvhu_kind_name*/
    from tc_webjj.T_SW_LIHU_DECLARE
   where sdono = lvsdono;
  select count(*)
    into lv_count
    from ccic_data.tbn_data c
   where c.sidentityid in (lv_PID, lv_APP_PID);
  if lv_count > 0 then
    return 'ccic_false'; --'ccic人员';
  end if;
  /*  select count(*)
    into lv_count
    from TC_JCYW.v_tp_meta_addr m
   where 1 = 1
     And property <> '已停用'
     and toponym like lvTOPONYM
     and building_name = lvBUILDING_NAME
     and haozuo = lvHAOZUO
     and sxzjd_name = lvSXZJD_NAME
     and seat like lvSEAT
     and quxcun_name = lvQUXCUN_NAME
     and teamid = lvTEAMID
     and room like lvROOM;
  if lv_count = 0 then
    return 'addr_false'; --'地址错误';
  end if;*/
  /*  select count(*)  不能作验证
    into lv_count
    from TC_RKXT.v_tp_huji_ck m
   where 1 = 1
     and pid = lv_APP_PID
     and name = lv_APP_NAME;
  if lv_count = 0 then
    return 'app_false'; --'申请人不存在出错';
  end if;*/

  select region_id
    into lv_sel_code
    from tc_jcyw.t_region
   where name = lv_sel_xzqh
     and when_cancelled is null;

  /*  select meta_addr_id
   into lvmeta_addr_id
   from TC_JCYW.v_tp_meta_addr m
  where 1 = 1
    And property <> '已停用'
    and toponym like lvTOPONYM
    and building_name = lvBUILDING_NAME
    and haozuo = lvHAOZUO
    and sxzjd_name = lvSXZJD_NAME
    and seat like lvSEAT
    and quxcun_name = lvQUXCUN_NAME
    and teamid = lvTEAMID
    and room like lvROOM;*/
  select need_back, sbooking, sbusno
    into lv_send_flag, lvsbooking, lv_sbusno
    from tc_webjj.v_dobus
   where sdono = lvsdono;
  if substr(lv_sel_code, 0, 3) = '350' then
    lvsurl := lvsurl ||
              '?url=/rkxt/hjgl/psn_apply_detail_ksqy.jsp=市外迁入=省内市外';
  else
    lvsurl := lvsurl ||
              '?url=/rkxt/hjgl/psn_apply_detail.jsp=市外迁入=省外';
  end if;
  lvsurl := lvsurl || '=立户=' || lv_bd_type;
  /*  lvsurl := lvsurl || '&come_meta_addr_id=' || lvmeta_addr_id;*/
  lvsurl := lvsurl || '=' || lvhu_kind_name;
  lvsurl := lvsurl || '=' || lv_sbusno;

  lvsurl := lvsurl || '=' || lv_sel_xzqh;
  lvsurl := lvsurl || '=' || lv_sel_code;
  lvsurl := lvsurl || '=' || lvsdono;
  lvsurl := lvsurl || '=' || lvTOPONYM;
  /*  lvsurl := lvsurl || '&ed_toponym=' || lvTOPONYM;
  lvsurl := lvsurl || '&ed_haozuo=' || lvHAOZUO;
  lvsurl := lvsurl || '&ed_seat=' || lvSEAT;
  lvsurl := lvsurl || '&ed_room=' || lvROOM;
  lvsurl := lvsurl || '&ed_xzjd_name=' || lvSXZJD_NAME;
  lvsurl := lvsurl || '&ed_quxcun_name=' || lvQUXCUN_NAME;
  lvsurl := lvsurl || '&ed_teamid=' || lvTEAMID;
  lvsurl := lvsurl || '&ed_building_name=' || lvBUILDING_NAME;*/
  lvsurl := lvsurl || '=' || lvaddr;
  --lvsurl := lvsurl || '&sbusno=005';
  if lv_send_flag = '需回寄' then
    lvsurl := lvsurl || '=1';
  else
    lvsurl := lvsurl || '=0';
  end if;
  if lvsbooking = '1' then
    lvsurl := lvsurl || '=888';
  end if;
  return(lvsurl);
end fun_geturl_swqr_lihu;

/

