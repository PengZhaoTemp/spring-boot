create PROCEDURE PROC_dobus_info   /*T_DOBUS*/
(
  lvsdono       in out   varchar2,--办理编号
  lvsbusno         varchar2,--业务编号
  lvsdodata        varchar2,--业务数据概要
  lvsdounit        varchar2,--办理单位名称
  lvsdounitno      varchar2,--办理单位代码
  lvsuserno        varchar2,--申请人编码
  lvsapppid        varchar2,--申请人公民身份号码
  lvsappname       varchar2,--申请人姓名
  lvsapptel        varchar2,--申请人联系电话
  lvsbusdotype     varchar2,--1-办理 2-预约 3-查询 4-下载
  lvncharge        number,--支付金额
  lvnsercharge     number,--服务资费
  lvnexpcharge     number,--快递资费
  lvnrecharge      number,--回寄资费
  lvsemssend       varchar2,--0-不需要 1-需要
  lvssendtype      varchar2,--1-快递 2-亲自送
  lvsexpaddress    varchar2,--寄送快递地址
  lvsexppostcode   varchar2,--寄送邮政编码
  lvsconsignee     varchar2,--寄送收件人
  lvscontel        varchar2,--寄送联系电话
  lvsreems         varchar2,--0-不需要 1-需要
  lvssbacktype     varchar2,--1-邮政速递 2-邮货到付 3-亲自取
  lvsreno          varchar2,--回寄快递单号
  lvsprocity       varchar2,--回寄省市区县
  lvsreaddress     varchar2,--回寄地址
  lvsrepostcode    varchar2,--回寄邮政编码
  lvsrecon         varchar2,--回寄收件人
  lvsrecontel      varchar2,--回寄联系电话
  lvmastertypesno  varchar2,--材料类编号
  lvsitem_sno      varchar2,--材料配置编号
  lvsitem_files    varchar2,--上传材料路径
  lvexectype       varchar2,--材料寄送方式
  lvcsource        varchar2, --0-网站 1-微信 2-手机
  lvdbookingdate   varchar2,
  lvsbotime        varchar2,
  lvswtrpid        varchar2,
  lvswtrname       varchar2,
  lvswtrtel        varchar2
)
AS
BEGIN
  begin
   --存储数据
   insert into tc_webjj.t_dobus(
          sdono          ,--办理编号
          sbusno         ,--业务编号
          sdodata        ,--业务数据概要
          sdounit        ,--办理单位名称
          sdounitno      ,--办理单位代码
          suserno        ,--申请人编码
          sapppid        ,--申请人公民身份号码
          sappname       ,--申请人姓名
          sapptel        ,--申请人联系电话
          sbusdotype     ,--1-办理 2-预约 3-查询 4-下载
          ncharge        ,  --支付金额
          nsercharge     ,  --服务资费
          nexpcharge     ,  --快递资费
          nrecharge      ,  --回寄资费
          semssend       ,--0-不需要 1-需要
          ssendtype      ,--1-快递 2-亲自送
          sexpaddress    ,--寄送快递地址
          sexppostcode   ,--寄送邮政编码
          sconsignee     ,--寄送收件人
          scontel        ,--寄送联系电话
          sreems         ,--0-不需要 1-需要
          ssbacktype     ,--1-邮政速递 2-邮货到付 3-亲自取
          sreno          ,--回寄快递单号
          sprocity       ,--回寄省市区县
          sreaddress     ,--回寄地址
          srepostcode    ,--回寄邮政编码
          srecon         ,--回寄收件人
          srecontel      ,--回寄联系电话
          mastertypesno  ,--材料类编号
          csource        , --0-网站 1-微信 2-手机
          ddecdate       ,
          exectype       ,
          dbookingdate   ,
          sbotime        ,
          dbbj           ,
          scontext       ,
          swtrpid        ,
          swtrname       ,
          swtrtel

   )values(
          lvsdono          ,--办理编号
          lvsbusno         ,--业务编号
          lvsdodata        ,--业务数据概要
          lvsdounit        ,--办理单位名称
          lvsdounitno      ,--办理单位代码
          lvsuserno        ,--申请人编码
          lvsapppid        ,--申请人公民身份号码
          lvsappname       ,--申请人姓名
          lvsapptel        ,--申请人联系电话
          lvsbusdotype     ,--1-办理 2-预约 3-查询 4-下载
          lvncharge        ,  --支付金额
          lvnsercharge     ,  --服务资费
          lvnexpcharge     ,  --快递资费 lvnexpcharge
          lvnrecharge      ,  --回寄资费 lvnrecharge
          lvsemssend       ,--0-不需要 1-需要
          lvssendtype      ,--1-快递 2-亲自送
          lvsexpaddress    ,--寄送快递地址
          lvsexppostcode   ,--寄送邮政编码
          lvsconsignee     ,--寄送收件人
          lvscontel        ,--寄送联系电话
          lvsreems         ,--0-不需要 1-需要
          decode(lvssbacktype,'','3',lvssbacktype)     ,--1-邮政速递 2-邮货到付 3-亲自取
          lvsreno          ,--回寄快递单号
          lvsprocity       ,--回寄省市区县
          lvsreaddress     ,--回寄地址
          lvsrepostcode    ,--回寄邮政编码
          lvsrecon         ,--回寄收件人
          lvsrecontel      ,--回寄联系电话
          lvmastertypesno  ,--材料类编号
          lvcsource        ,  --0-网站 1-微信 2-手机
          sysdate          ,
          lvexectype       ,
          to_date(lvdbookingdate,'yyyy-mm-dd')   ,
          lvsbotime,
          '0',
          '您的申报信息已经提交，电子材料正在预审中。',
          lvswtrpid,
          lvswtrname,
          lvswtrtel
   );
    if lvsbusdotype = '1' or lvsbusdotype = '2' then
    --写入材料信息
    if lvexectype = '1' or lvexectype = '3' then  --办理或预约类业务
        proc_publicsave_master(lvsdono,lvsitem_sno,lvsitem_files,'PMSUBMIT');
               --lvsitem_sno 材料编号 4110001000001405,4110001000001406,4110001000001407
               --lvsitem_files具体文件 材料路径集合      11.jpg,12.jpg;21.jpg;31.jpg,32.jpg
      elsif lvexectype = '2' then
         proc_applymasterdata_info(lvsdono,lvsitem_sno,'PMSAVE');
      end if;
      --设置流程节点
      proc_dobus_nextflow(lvsdono);
    elsif lvsbusdotype = '3' then  --查询类业务
         if lvsbusno='1202' or lvsbusno='1201' or lvsbusno='1205' then
            update tc_webjj.t_dobus b set b.state='71',b.dbbj='0',b.scontext='您的查询信息已经提交。' where sdono=lvsdono;
         else
            update tc_webjj.t_dobus b set b.state='70',b.dbbj='0',b.scontext='您的查询信息已经提交。' where sdono=lvsdono;
         end if ;
      
    end if;
    PROC_dobus_count_xx(lvsuserno,lvsbusdotype);
   Commit;
  exception when others then
        lvsdono:='ERROE:'||SQLCODE||'-'||SUBSTR(SQLERRM, 1, 50);    
  end;
END; /*存储过程结束*/

