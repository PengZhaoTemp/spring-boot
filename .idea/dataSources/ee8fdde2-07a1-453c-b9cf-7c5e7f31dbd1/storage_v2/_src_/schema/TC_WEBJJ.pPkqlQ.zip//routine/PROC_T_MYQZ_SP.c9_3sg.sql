create PROCEDURE          PROC_t_myqz_sp   /*T_MYQZ_SP*/
(
 lvsdono IN OUT VARCHAR2,  --业务编号
 lvsunitname VARCHAR2,  --申请单位名称
 lvsdbr VARCHAR2,  --法定代表人
 lvszyfzr VARCHAR2,  --主要负责人
 lvstel VARCHAR2,  --联系电话
 lvpsqy_name VARCHAR2,  --配售企业名称
 lvpsqy_dbr VARCHAR2,  --配售企业代表人
 lvpsqy_zyfzr VARCHAR2,  --主要负责人
 lvbwjg VARCHAR2,  --保卫机构
 lvpsqy_addr VARCHAR2,  --配售企业地址
 lvpsqz_type VARCHAR2,  --配售枪支种类和型号
 lvsj_zbryj VARCHAR2,  --市级主办人意见
 lvsj_ldyj VARCHAR2,  --市级领导意见
 lvshj_zbryj VARCHAR2,  --省级主办人意见
 lvshj_ldyj VARCHAR2,  --省级领导意见
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS

BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/



   INSERT into tc_webjj.t_myqz_sp
    (
      sdono,   --业务编号
      sunitname,   --申请单位名称
      sdbr,   --法定代表人
      szyfzr,   --主要负责人
      stel,   --联系电话
      psqy_name,   --配售企业名称
      psqy_dbr,   --配售企业代表人
      psqy_zyfzr,   --主要负责人
      bwjg,   --保卫机构
      psqy_addr,   --配售企业地址
      psqz_type,   --配售枪支种类和型号
      sj_zbryj,   --市级主办人意见
      sj_ldyj,   --市级领导意见
      shj_zbryj,   --省级主办人意见
      shj_ldyj    --省级领导意见
    )values(
      lvsdono,   --业务编号
      lvsunitname,   --申请单位名称
      lvsdbr,   --法定代表人
      lvszyfzr,   --主要负责人
      lvstel,   --联系电话
      lvpsqy_name,   --配售企业名称
      lvpsqy_dbr,   --配售企业代表人
      lvpsqy_zyfzr,   --主要负责人
      lvbwjg,   --保卫机构
      lvpsqy_addr,   --配售企业地址
      lvpsqz_type,   --配售枪支种类和型号
      lvsj_zbryj,   --市级主办人意见
      lvsj_ldyj,   --市级领导意见
      lvshj_zbryj,   --省级主办人意见

      lvshj_ldyj    --省级领导意见


    );
   -- 返回值

END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_myqz_sp
    Set
      sdono=lvsdono,   --业务编号
      sunitname=lvsunitname,   --申请单位名称
      sdbr=lvsdbr,   --法定代表人
      szyfzr=lvszyfzr,   --主要负责人
      stel=lvstel,   --联系电话
      psqy_name=lvpsqy_name,   --配售企业名称
      psqy_dbr=lvpsqy_dbr,   --配售企业代表人
      psqy_zyfzr=lvpsqy_zyfzr,   --主要负责人
      bwjg=lvbwjg,   --保卫机构
      psqy_addr=lvpsqy_addr,   --配售企业地址
      psqz_type=lvpsqz_type,   --配售枪支种类和型号
      sj_zbryj=lvsj_zbryj,   --市级主办人意见
      sj_ldyj=lvsj_ldyj,   --市级领导意见
      shj_zbryj=lvshj_zbryj,   --省级主办人意见
      shj_ldyj=lvshj_ldyj    --省级领导意见
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_myqz_sp
    Set
      sdono=lvsdono,   --业务编号
      sunitname=lvsunitname,   --申请单位名称
      sdbr=lvsdbr,   --法定代表人
      szyfzr=lvszyfzr,   --主要负责人
      stel=lvstel,   --联系电话
      psqy_name=lvpsqy_name,   --配售企业名称
      psqy_dbr=lvpsqy_dbr,   --配售企业代表人
      psqy_zyfzr=lvpsqy_zyfzr,   --主要负责人
      bwjg=lvbwjg,   --保卫机构
      psqy_addr=lvpsqy_addr,   --配售企业地址
      psqz_type=lvpsqz_type,   --配售枪支种类和型号
      sj_zbryj=lvsj_zbryj,   --市级主办人意见
      sj_ldyj=lvsj_ldyj,   --市级领导意见
      shj_zbryj=lvshj_zbryj,   --省级主办人意见
      shj_ldyj=lvshj_ldyj    --省级领导意见
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_myqz_sp
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

