create function          fun_geturl_zxhk(lvsdono varchar2)  --注销户口
  return varchar2 is
  lvsurl         varchar2(500);
  lv_PID         varchar2(18);
  lv_NAME        varchar2(50);
  lv_APP_PID     varchar2(18);
  lv_APP_NAME    varchar2(50);
  lv_count       number;
  lv_person_id   number;
  lv_hu_id       number;
  --lv_bd_type     varchar2(20);
  lv_opr_type    varchar2(50);
  lv_send_flag   varchar2(50);
  lvmeta_addr_id number;
  lvcancel_reason varchar2(100);
  lvsbooking  varchar2(2);
    lv_sbusno VARCHAR2(6);
begin
  /*    outcancelreg_zxhk.jsp?opr_type=参军人员注销&bd_type=参军入伍&person_id=9144&hu_id=3097&stuff=@(LVNCL_ID:733)(LVNCL_NAME:《入伍通知书》)@

outcancelreg_zxhk.jsp?opr_type=出国境定居&bd_type=出国境&person_id=9144&hu_id=3097&stuff=@(LVNCL_ID:734)(LVNCL_NAME:出入境管理部门出具的户口注销通知书)@

outcancelreg_zxhk.jsp?opr_type=失踪人员注销&bd_type=失踪注销&person_id=9144&hu_id=3097&stuff=@(LVNCL_ID:1168)(LVNCL_NAME:人民法院民事裁定书)@


outcancelreg_zxhk.jsp?opr_type=失踪人员注销&bd_type=失踪注销&person_id=9144&hu_id=3097&stuff=@(LVNCL_ID:1168)(LVNCL_NAME:人民法院民事裁定书)@(LVNCL_ID:1197)(LVNCL_NAME:责任区民警调查报告)@
  */
  lvsurl   := '';
  lv_count := 0;
  select PID, NAME, APP_PID, APP_NAME,cancel_reason
    into lv_PID, lv_NAME, lv_APP_PID, lv_APP_NAME,lvcancel_reason
    from tc_webjj.t_cancel_hukou
   where sdono = lvsdono;
  select count(*)
    into lv_count
    from ccic_data.tbn_data c
   where c.sidentityid in (lv_PID, lv_APP_PID);
  if lv_count > 0 then
    return 'ccic_false'; --'ccic人员';
  end if;
  select count(*)
    into lv_count
    from TC_RKXT.v_tp_huji_ck m
   where 1 = 1
     and pid = lv_pid
     and name = lv_name;
  if lv_count = 0 then
    return 'ck_false'; --'常口不存在出错';
  end if;
  select count(*)
    into lv_count
    from TC_RKXT.v_tp_huji_ck m
   where 1 = 1
     and pid = lv_APP_PID
     and name = lv_APP_NAME;
     dbms_output.put_line('lv_APP_PID=='||lv_APP_PID||'  lv_APP_NAME=='||lv_APP_NAME);
  if lv_count = 0 then
    return 'app_false'; --'申请人不存在出错';
  end if;

  select hu_id, person_id, meta_addr_id
    into lv_hu_id, lv_person_id, lvmeta_addr_id
    from tc_rkxt.v_tp_huji_ck
   where pid = lv_pid
     and name = lv_name;

  if lvcancel_reason = '出国境' then
     lv_opr_type := '出国境定居';
  elsif lvcancel_reason = '参军入伍' then
     lv_opr_type := '参军人员注销';
  elsif lvcancel_reason = '失踪注销' then
     lv_opr_type := '失踪人员注销';
  end if;

  lvsurl := 'opr_type=' || lv_opr_type;
  lvsurl := lvsurl || '=' || lvcancel_reason;
  lvsurl := lvsurl || '=' || lv_person_id;
  lvsurl := lvsurl || '=' || lv_hu_id;
  lvsurl := lvsurl || '=' || lvsdono;
  /*lvsurl := lvsurl || '=' || lv_hu_id;
  lvsurl := lvsurl || '=' || lvmeta_addr_id;
  lvsurl := lvsurl || '=' || lvmeta_addr_id;
  lvsurl := lvsurl || '=' || lvsdono;
  lvsurl := lvsurl || '=' || lvcancel_reason;*/
  select need_back,sbooking,sbusno
    into lv_send_flag,lvsbooking,lv_sbusno
    from tc_webjj.v_dobus
   where sdono = lvsdono;

  if lv_send_flag = '需回寄' then
    lvsurl := lvsurl || '=1';
  else
    lvsurl := lvsurl || '=0';
  end if;
   lvsurl := lvsurl || '='||lv_sbusno;
  if lvsbooking = '1' then
    lvsurl := lvsurl || '=1';
  end if;
  return(lvsurl);
end fun_geturl_zxhk;

/

