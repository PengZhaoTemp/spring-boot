create PROCEDURE          PROC_t_crj_zxtablewl   /*T_CRJ_ZXTABLEWL*/
(
 lvsdono IN OUT VARCHAR2,  --业务编号
 lvspid VARCHAR2,  --公民身份证号
 lvsnamex VARCHAR2,  --姓
 lvsnamem VARCHAR2,  --名
 lvsex VARCHAR2,  --性　　别
 lvsnamepinx VARCHAR2,  --拼  音 姓
 lvsnamepinm VARCHAR2,  --拼  音 名
 lvsminzu VARCHAR2,  --民　　族
 lvdbirth DATE,  --出生日期
 lvsbirthplace VARCHAR2,  --出  生 地
 lvszzmm VARCHAR2,  --政治面貌
 lvshukouadr VARCHAR2,  --户口所在地
 lvspcs VARCHAR2,  --所属派出所
 lvshomeadr VARCHAR2,  --家庭现住址
 lvshometel VARCHAR2,  --联系电话
 lvsunitname VARCHAR2,  --单位名称
 lvszw VARCHAR2,  --职　　务
 lvsunitadr VARCHAR2,  --单位地址
 lvsunittel VARCHAR2,  --联系电话
 lvssq_type VARCHAR2,  --申请类别
 lvstowhere VARCHAR2,  --前  往 地
 lvsytxzcode VARCHAR2,  --原通行证号码
 lvsyxq DATE,  --有效期至
 lvsqfd VARCHAR2,  --签  发 地
 lvssqqz_type VARCHAR2,  --申请签注种类
 lvssqqz_time VARCHAR2,  --申请签注时间
 lvsgaqs_name VARCHAR2,  --港澳亲属姓名
 lvsgaqs_sex VARCHAR2,  --港澳亲属性别
 lvsgaqs_birth DATE,  --港澳亲属出生日期
 lvsgaqs_pid VARCHAR2,  --港澳身份证号码
 lvsgaqs_relation VARCHAR2,  --sgaqs_relation
 lvsjtcy_cw VARCHAR2,  --家庭主要成员称谓
 lvsjtcy_name VARCHAR2,  --姓　　名
 lvsjtcy_age VARCHAR2,  --年　　龄
 lvsjtcy_work VARCHAR2,  --工作单位、职务
 lvsjtcy_address VARCHAR2,  --家庭住址
 lvsjtcy_cw1 VARCHAR2,  --家庭主要成员称谓1
 lvsjtcy_name1 VARCHAR2,  --姓  名 1
 lvsjtcy_age1 VARCHAR2,  --年  龄 1
 lvsjtcy_work1 VARCHAR2,  --工作单位、职务1
 lvsjtcy_address1 VARCHAR2,  --家庭住址1
 lvsjtcy_cw2 VARCHAR2,  --家庭主要成员称谓2
 lvsjtcy_name2 VARCHAR2,  --姓  名 2
 lvsjtcy_age2 VARCHAR2,  --年  龄 2
 lvsjtcy_work2 VARCHAR2,  --工作单位、职务2
 lvsjtcy_address2 VARCHAR2,  --家庭住址2
 lvsjtcy_cw3 VARCHAR2,  --家庭主要成员称谓3
 lvsjtcy_name3 VARCHAR2,  --姓  名 3
 lvsjtcy_age3 VARCHAR2,  --年  龄 3
 lvsjtcy_work3 VARCHAR2,  --工作单位、职务3
 lvsjtcy_address3 VARCHAR2,  --家庭住址3
 lvssqr_name VARCHAR2,  --申  请 人
 lvssqr_wtrname VARCHAR2,  --委  托 人
 lvssqr_time DATE,  --申请时间
 lvslz_type VARCHAR2,  --领证方式
 lvsyjadr VARCHAR2,  --邮寄地址
 lvssjr_name VARCHAR2,  --收件人姓名
 lvssj_code VARCHAR2,  --邮政编码
 lvssj_tel VARCHAR2,  --联系电话
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS

BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/



   INSERT into tc_webjj.t_crj_zxtablewl
    (
      sdono,   --业务编号
      spid,   --公民身份证号
      snamex,   --姓
      snamem,   --名
      sex,   --性　　别
      snamepinx,   --拼  音 姓
      snamepinm,   --拼  音 名
      sminzu,   --民　　族
      dbirth,   --出生日期
      sbirthplace,   --出  生 地
      szzmm,   --政治面貌
      shukouadr,   --户口所在地
      spcs,   --所属派出所
      shomeadr,   --家庭现住址
      shometel,   --联系电话
      sunitname,   --单位名称
      szw,   --职　　务
      sunitadr,   --单位地址
      sunittel,   --联系电话
      ssq_type,   --申请类别
      stowhere,   --前  往 地
      sytxzcode,   --原通行证号码
      syxq,   --有效期至
      sqfd,   --签  发 地
      ssqqz_type,   --申请签注种类
      ssqqz_time,   --申请签注时间
      sgaqs_name,   --港澳亲属姓名
      sgaqs_sex,   --港澳亲属性别
      sgaqs_birth,   --港澳亲属出生日期
      sgaqs_pid,   --港澳身份证号码
      sgaqs_relation,   --sgaqs_relation
      sjtcy_cw,   --家庭主要成员称谓
      sjtcy_name,   --姓　　名
      sjtcy_age,   --年　　龄
      sjtcy_work,   --工作单位、职务
      sjtcy_address,   --家庭住址
      sjtcy_cw1,   --家庭主要成员称谓1
      sjtcy_name1,   --姓  名 1
      sjtcy_age1,   --年  龄 1
      sjtcy_work1,   --工作单位、职务1
      sjtcy_address1,   --家庭住址1
      sjtcy_cw2,   --家庭主要成员称谓2
      sjtcy_name2,   --姓  名 2
      sjtcy_age2,   --年  龄 2
      sjtcy_work2,   --工作单位、职务2
      sjtcy_address2,   --家庭住址2
      sjtcy_cw3,   --家庭主要成员称谓3
      sjtcy_name3,   --姓  名 3
      sjtcy_age3,   --年  龄 3
      sjtcy_work3,   --工作单位、职务3
      sjtcy_address3,   --家庭住址3
      ssqr_name,   --申  请 人
      ssqr_wtrname,   --委  托 人
      ssqr_time,   --申请时间
      slz_type,   --领证方式
      syjadr,   --邮寄地址
      ssjr_name,   --收件人姓名
      ssj_code,   --邮政编码
      ssj_tel    --联系电话
    )values(
      lvsdono,   --业务编号
      lvspid,   --公民身份证号
      lvsnamex,   --姓
      lvsnamem,   --名
      lvsex,   --性　　别
      lvsnamepinx,   --拼  音 姓
      lvsnamepinm,   --拼  音 名
      lvsminzu,   --民　　族
      lvdbirth,   --出生日期
      lvsbirthplace,   --出  生 地
      lvszzmm,   --政治面貌
      lvshukouadr,   --户口所在地
      lvspcs,   --所属派出所
      lvshomeadr,   --家庭现住址
      lvshometel,   --联系电话
      lvsunitname,   --单位名称
      lvszw,   --职　　务
      lvsunitadr,   --单位地址
      lvsunittel,   --联系电话
      lvssq_type,   --申请类别
      lvstowhere,   --前  往 地
      lvsytxzcode,   --原通行证号码
      lvsyxq,   --有效期至
      lvsqfd,   --签  发 地
      lvssqqz_type,   --申请签注种类
      lvssqqz_time,   --申请签注时间
      lvsgaqs_name,   --港澳亲属姓名
      lvsgaqs_sex,   --港澳亲属性别
      lvsgaqs_birth,   --港澳亲属出生日期
      lvsgaqs_pid,   --港澳身份证号码
      lvsgaqs_relation,   --sgaqs_relation
      lvsjtcy_cw,   --家庭主要成员称谓
      lvsjtcy_name,   --姓　　名
      lvsjtcy_age,   --年　　龄
      lvsjtcy_work,   --工作单位、职务
      lvsjtcy_address,   --家庭住址
      lvsjtcy_cw1,   --家庭主要成员称谓1
      lvsjtcy_name1,   --姓  名 1
      lvsjtcy_age1,   --年  龄 1
      lvsjtcy_work1,   --工作单位、职务1
      lvsjtcy_address1,   --家庭住址1
      lvsjtcy_cw2,   --家庭主要成员称谓2
      lvsjtcy_name2,   --姓  名 2
      lvsjtcy_age2,   --年  龄 2
      lvsjtcy_work2,   --工作单位、职务2
      lvsjtcy_address2,   --家庭住址2
      lvsjtcy_cw3,   --家庭主要成员称谓3
      lvsjtcy_name3,   --姓  名 3
      lvsjtcy_age3,   --年  龄 3
      lvsjtcy_work3,   --工作单位、职务3
      lvsjtcy_address3,   --家庭住址3
      lvssqr_name,   --申  请 人
      lvssqr_wtrname,   --委  托 人
      lvssqr_time,   --申请时间
      lvslz_type,   --领证方式
      lvsyjadr,   --邮寄地址
      lvssjr_name,   --收件人姓名
      lvssj_code,   --邮政编码

      lvssj_tel    --联系电话


    );
   -- 返回值

END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_crj_zxtablewl
    Set
      sdono=lvsdono,   --业务编号
      spid=lvspid,   --公民身份证号
      snamex=lvsnamex,   --姓
      snamem=lvsnamem,   --名
      sex=lvsex,   --性　　别
      snamepinx=lvsnamepinx,   --拼  音 姓
      snamepinm=lvsnamepinm,   --拼  音 名
      sminzu=lvsminzu,   --民　　族
      dbirth=lvdbirth,   --出生日期
      sbirthplace=lvsbirthplace,   --出  生 地
      szzmm=lvszzmm,   --政治面貌
      shukouadr=lvshukouadr,   --户口所在地
      spcs=lvspcs,   --所属派出所
      shomeadr=lvshomeadr,   --家庭现住址
      shometel=lvshometel,   --联系电话
      sunitname=lvsunitname,   --单位名称
      szw=lvszw,   --职　　务
      sunitadr=lvsunitadr,   --单位地址
      sunittel=lvsunittel,   --联系电话
      ssq_type=lvssq_type,   --申请类别
      stowhere=lvstowhere,   --前  往 地
      sytxzcode=lvsytxzcode,   --原通行证号码
      syxq=lvsyxq,   --有效期至
      sqfd=lvsqfd,   --签  发 地
      ssqqz_type=lvssqqz_type,   --申请签注种类
      ssqqz_time=lvssqqz_time,   --申请签注时间
      sgaqs_name=lvsgaqs_name,   --港澳亲属姓名
      sgaqs_sex=lvsgaqs_sex,   --港澳亲属性别
      sgaqs_birth=lvsgaqs_birth,   --港澳亲属出生日期
      sgaqs_pid=lvsgaqs_pid,   --港澳身份证号码
      sgaqs_relation=lvsgaqs_relation,   --sgaqs_relation
      sjtcy_cw=lvsjtcy_cw,   --家庭主要成员称谓
      sjtcy_name=lvsjtcy_name,   --姓　　名
      sjtcy_age=lvsjtcy_age,   --年　　龄
      sjtcy_work=lvsjtcy_work,   --工作单位、职务
      sjtcy_address=lvsjtcy_address,   --家庭住址
      sjtcy_cw1=lvsjtcy_cw1,   --家庭主要成员称谓1
      sjtcy_name1=lvsjtcy_name1,   --姓  名 1
      sjtcy_age1=lvsjtcy_age1,   --年  龄 1
      sjtcy_work1=lvsjtcy_work1,   --工作单位、职务1
      sjtcy_address1=lvsjtcy_address1,   --家庭住址1
      sjtcy_cw2=lvsjtcy_cw2,   --家庭主要成员称谓2
      sjtcy_name2=lvsjtcy_name2,   --姓  名 2
      sjtcy_age2=lvsjtcy_age2,   --年  龄 2
      sjtcy_work2=lvsjtcy_work2,   --工作单位、职务2
      sjtcy_address2=lvsjtcy_address2,   --家庭住址2
      sjtcy_cw3=lvsjtcy_cw3,   --家庭主要成员称谓3
      sjtcy_name3=lvsjtcy_name3,   --姓  名 3
      sjtcy_age3=lvsjtcy_age3,   --年  龄 3
      sjtcy_work3=lvsjtcy_work3,   --工作单位、职务3
      sjtcy_address3=lvsjtcy_address3,   --家庭住址3
      ssqr_name=lvssqr_name,   --申  请 人
      ssqr_wtrname=lvssqr_wtrname,   --委  托 人
      ssqr_time=lvssqr_time,   --申请时间
      slz_type=lvslz_type,   --领证方式
      syjadr=lvsyjadr,   --邮寄地址
      ssjr_name=lvssjr_name,   --收件人姓名
      ssj_code=lvssj_code,   --邮政编码
      ssj_tel=lvssj_tel    --联系电话
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_crj_zxtablewl
    Set
      sdono=lvsdono,   --业务编号
      spid=lvspid,   --公民身份证号
      snamex=lvsnamex,   --姓
      snamem=lvsnamem,   --名
      sex=lvsex,   --性　　别
      snamepinx=lvsnamepinx,   --拼  音 姓
      snamepinm=lvsnamepinm,   --拼  音 名
      sminzu=lvsminzu,   --民　　族
      dbirth=lvdbirth,   --出生日期
      sbirthplace=lvsbirthplace,   --出  生 地
      szzmm=lvszzmm,   --政治面貌
      shukouadr=lvshukouadr,   --户口所在地
      spcs=lvspcs,   --所属派出所
      shomeadr=lvshomeadr,   --家庭现住址
      shometel=lvshometel,   --联系电话
      sunitname=lvsunitname,   --单位名称
      szw=lvszw,   --职　　务
      sunitadr=lvsunitadr,   --单位地址
      sunittel=lvsunittel,   --联系电话
      ssq_type=lvssq_type,   --申请类别
      stowhere=lvstowhere,   --前  往 地
      sytxzcode=lvsytxzcode,   --原通行证号码
      syxq=lvsyxq,   --有效期至
      sqfd=lvsqfd,   --签  发 地
      ssqqz_type=lvssqqz_type,   --申请签注种类
      ssqqz_time=lvssqqz_time,   --申请签注时间
      sgaqs_name=lvsgaqs_name,   --港澳亲属姓名
      sgaqs_sex=lvsgaqs_sex,   --港澳亲属性别
      sgaqs_birth=lvsgaqs_birth,   --港澳亲属出生日期
      sgaqs_pid=lvsgaqs_pid,   --港澳身份证号码
      sgaqs_relation=lvsgaqs_relation,   --sgaqs_relation
      sjtcy_cw=lvsjtcy_cw,   --家庭主要成员称谓
      sjtcy_name=lvsjtcy_name,   --姓　　名
      sjtcy_age=lvsjtcy_age,   --年　　龄
      sjtcy_work=lvsjtcy_work,   --工作单位、职务
      sjtcy_address=lvsjtcy_address,   --家庭住址
      sjtcy_cw1=lvsjtcy_cw1,   --家庭主要成员称谓1
      sjtcy_name1=lvsjtcy_name1,   --姓  名 1
      sjtcy_age1=lvsjtcy_age1,   --年  龄 1
      sjtcy_work1=lvsjtcy_work1,   --工作单位、职务1
      sjtcy_address1=lvsjtcy_address1,   --家庭住址1
      sjtcy_cw2=lvsjtcy_cw2,   --家庭主要成员称谓2
      sjtcy_name2=lvsjtcy_name2,   --姓  名 2
      sjtcy_age2=lvsjtcy_age2,   --年  龄 2
      sjtcy_work2=lvsjtcy_work2,   --工作单位、职务2
      sjtcy_address2=lvsjtcy_address2,   --家庭住址2
      sjtcy_cw3=lvsjtcy_cw3,   --家庭主要成员称谓3
      sjtcy_name3=lvsjtcy_name3,   --姓  名 3
      sjtcy_age3=lvsjtcy_age3,   --年  龄 3
      sjtcy_work3=lvsjtcy_work3,   --工作单位、职务3
      sjtcy_address3=lvsjtcy_address3,   --家庭住址3
      ssqr_name=lvssqr_name,   --申  请 人
      ssqr_wtrname=lvssqr_wtrname,   --委  托 人
      ssqr_time=lvssqr_time,   --申请时间
      slz_type=lvslz_type,   --领证方式
      syjadr=lvsyjadr,   --邮寄地址
      ssjr_name=lvssjr_name,   --收件人姓名
      ssj_code=lvssj_code,   --邮政编码
      ssj_tel=lvssj_tel    --联系电话
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_crj_zxtablewl
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

