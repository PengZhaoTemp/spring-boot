create PROCEDURE          PROC_t_dxhd_sp   /*T_DXHD_SP*/
(
 lvsdono IN OUT VARCHAR2,  --业务编号
 lvdtime DATE,  --活动时间
 lvsaddr VARCHAR2,  --活动地点
 lvs_fa_sm VARCHAR2,  --活动方案说明
 lvs_cyrs VARCHAR2,  --参与人数
 lvsq_name VARCHAR2,  --申  请 人
 lvsq_pid VARCHAR2,  --申请人身份证
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS

BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/



   INSERT into tc_webjj.t_dxhd_sp
    (
      sdono,   --业务编号
      dtime,   --活动时间
      saddr,   --活动地点
      s_fa_sm,   --活动方案说明
      s_cyrs,   --参与人数
      sq_name,   --申  请 人
      sq_pid    --申请人身份证
    )values(
      lvsdono,   --业务编号
      lvdtime,   --活动时间
      lvsaddr,   --活动地点
      lvs_fa_sm,   --活动方案说明
      lvs_cyrs,   --参与人数
      lvsq_name,   --申  请 人

      lvsq_pid    --申请人身份证


    );
   -- 返回值

END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_dxhd_sp
    Set
      sdono=lvsdono,   --业务编号
      dtime=lvdtime,   --活动时间
      saddr=lvsaddr,   --活动地点
      s_fa_sm=lvs_fa_sm,   --活动方案说明
      s_cyrs=lvs_cyrs,   --参与人数
      sq_name=lvsq_name,   --申  请 人
      sq_pid=lvsq_pid    --申请人身份证
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_dxhd_sp
    Set
      sdono=lvsdono,   --业务编号
      dtime=lvdtime,   --活动时间
      saddr=lvsaddr,   --活动地点
      s_fa_sm=lvs_fa_sm,   --活动方案说明
      s_cyrs=lvs_cyrs,   --参与人数
      sq_name=lvsq_name,   --申  请 人
      sq_pid=lvsq_pid    --申请人身份证
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_dxhd_sp
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

