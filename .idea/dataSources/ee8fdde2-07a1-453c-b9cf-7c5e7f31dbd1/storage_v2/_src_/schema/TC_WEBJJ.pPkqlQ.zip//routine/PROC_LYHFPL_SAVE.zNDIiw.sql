create procedure          proc_lyhfpl_save(
      lvsid        varchar2,
      lvuserid     varchar2,
      lvusername   varchar2,
      lvdefen      varchar2,
      lvsadvice    varchar2,
      lvipaddr     varchar2,


) is
lvsid varchar2(16);
begin
  select tc_webjj.fun_get16code(tc_webjj.seq_portal_lyhfpl_pid.nextval) into lvpid from dual;
  insert into tc_webjj.t_portal_mailbox(
     pid,
     sid,
     userid,
     username,
     defen,
     sadvice,
     ipaddr,
     crtdate,
     dbbj
  )values(
     lvpid,
     lvsid,
     lvuserid,
     lvusername,
     lvdefen,
     lvsadvice,
     lvipaddr,
     sysdate,
     '0'
  );
  commit;
end proc_lyhfpl_save;

/

