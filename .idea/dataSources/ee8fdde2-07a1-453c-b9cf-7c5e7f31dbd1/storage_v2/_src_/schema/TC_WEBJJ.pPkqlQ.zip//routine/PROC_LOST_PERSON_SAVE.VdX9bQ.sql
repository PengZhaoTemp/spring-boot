create procedure          proc_lost_person_save(
      lvslostpic      varchar2,
      lvslostname    varchar2,
      lvslostsex       varchar2,
      lvdlostdob      varchar2,
      lvnlostheight    varchar2,
      lvdlostdate     varchar2,
      lvslostplace       varchar2,
      lvslosttype      varchar2,
      lvswheretogo      varchar2,
      lvscluemoney    varchar2,
      lvshomemoney     varchar2,

      lvslostpass       varchar2,
      lvslostproperty      varchar2,
      lvstouchname    varchar2,
      lvsrelation     varchar2,
      lvstouchaddr       varchar2,
      lvstouchtel      varchar2,
      lvstouchmail      varchar2,
      lvstouchqq    varchar2,
      lvsisopentel     varchar2,
      lvsremark    varchar2,
      lvsuserid     varchar2
) is
lvsid varchar2(16);
begin
  select tc_webjj.fun_get16code(tc_webjj.seq_lost_person_sid.nextval) into lvsid from dual;
  insert into tc_webjj.t_lost_person(
     sid ,--     业务编号
    slostpic   ,--   走失人员照片链接
    slostname  ,--   走失姓名
    slostsex   ,--   性别1-男，2-女
    dlostdob  ,--   出生日期
    nlostheight  ,--   身高
    dlostdate  ,--   走失日期
    slostplace   ,--   走失地点
    slosttype  ,--   走失类型
    swheretogo   ,--   可能去哪
    scluemoney   ,--   提供线索酬金
    shomemoney   ,--   护送回家酬金
    slostpass  ,--  走失经过
    slostproperty  ,--  走失特征
    stouchname  ,--   联系人姓名
    srelation  ,--   与走失人员关系
    stouchaddr   ,--   联系人地址
    stouchtel  ,--   联系电话
    stouchmail   ,--   联系人邮箱
    stouchqq   ,--  联系人qq
    sisopentel   ,--   是否公开联系电话0-不公开，1-公开
    sremark，  --   备注
    suserid,--申报人编号
    dbbj,
    dputtime,
    sisgetback
  )values(
    lvsid ,--     业务编号
    lvslostpic   ,--   走失人员照片链接
    lvslostname  ,--   走失姓名
    lvslostsex   ,--   性别1-男，2-女
    to_date(lvdlostdob,'yyyy-MM-dd  HH24:mi:SS')  ,--   出生日期
    lvnlostheight  ,--   身高
    to_date(lvdlostdate,'yyyy-MM-dd  HH24:mi:SS')  ,--   走失日期
    lvslostplace   ,--   走失地点
    lvslosttype  ,--   走失类型
    lvswheretogo   ,--   可能去哪
    lvscluemoney   ,--   提供线索酬金
    lvshomemoney   ,--   护送回家酬金
    lvslostpass  ,--  走失经过
    lvslostproperty  ,--  走失特征
    lvstouchname  ,--   联系人姓名
    lvsrelation  ,--   与走失人员关系
    lvstouchaddr   ,--   联系人地址
   lvstouchtel  ,--   联系电话
    lvstouchmail   ,--   联系人邮箱
    lvstouchqq   ,--  联系人qq
    lvsisopentel   ,--   是否公开联系电话0-不公开，1-公开
    lvsremark，  --   备注
    lvsuserid,--申报人编号
    '0',
    sysdate,
    '0'
  );
  commit;
end proc_lost_person_save;

/

