create procedure proc_commoner_save(
          lvpersonid in out     varchar2,
          lvpid            varchar2,
          lvname            varchar2,
          lvspwd            varchar2,
          lvshome_phone     varchar2,
          lvnickname        varchar2,
          lvsuser_kind      varchar2,
          lvopenid          varchar2,
          lv_procmode       varchar2
       ) is
begin
     --用户注册
  if 'PMINSERT'=lv_procmode then
   select tc_webjj.fun_get16code(tc_webjj.seq_t_commoner_personid.nextval) into lvpersonid from dual;
     insert into tc_webjj.t_commoner
       (slogin_id,
        name,
        spwd,
        shome_phone,
        nickname,
        personid,
        sstate,
        suser_kind,
        openid,
        CSOURCE,
        pid,
        dbbj)
     values
       (
       tc_webjj.fun_encrypkey(lvpid),
        lvname,
        lvspwd,
        lvshome_phone,
        lvnickname,
        lvpersonid,
        '5',
        lvsuser_kind,
        lvopenid,
        '1',
        tc_webjj.fun_encrypkey(lvpid),
        '0');
  end if;
  --实名认证
  if 'PMSMRZ'=lv_procmode then
     update
      tc_webjj.t_commoner
      set pid=tc_webjj.fun_encrypkey(lvpid),
          name=lvname,CSOURCE='1',
          dbbj='0',sstate='0',smrz='',szc_ss=''
     where personid=lvpersonid;
  end if;
   --安康用户注册
  if 'PMAKINSERT'=lv_procmode then
   select tc_webjj.fun_get16code(tc_webjj.seq_t_commoner_personid.nextval) into lvpersonid from dual;
     insert into tc_webjj.t_commoner
       (slogin_id,
        name,
        spwd,
        shome_phone,
        nickname,
        personid,
        sstate,
        suser_kind,
        openid,
        CSOURCE,
        pid,
        dbbj)
     values
       (
       tc_webjj.fun_encrypkey(lvpid),
        lvname,
        lvspwd,
        lvshome_phone,
        lvnickname,
        lvpersonid,
        '5',
        lvsuser_kind,
        lvopenid,
        '8',
        tc_webjj.fun_encrypkey(lvpid),
        '0');
  end if;
  --安康实名认证
  if 'PMAKSMRZ'=lv_procmode then
     update
      tc_webjj.t_commoner
      set pid=tc_webjj.fun_encrypkey(lvpid),
          name=lvname,CSOURCE='8',
          dbbj='0',sstate='0',smrz='',szc_ss=''
     where personid=lvpersonid;
  end if;
  COMMIT;
end;
/

