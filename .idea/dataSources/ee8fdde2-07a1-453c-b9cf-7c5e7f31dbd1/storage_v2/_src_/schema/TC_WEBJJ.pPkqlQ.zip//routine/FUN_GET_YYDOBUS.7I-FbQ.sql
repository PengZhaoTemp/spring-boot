create function          fun_get_yydobus(
       lv_date varchar2,
       lv_dte  varchar2,
       lv_sunit varchar2,
       lv_personid varchar2
) return  number is
  lvres number ;
  lv_cnt         number;
  lv_sum         number;
  lv_user        number;
begin
  begin
  
    select count(*) into lv_cnt
      from tc_webjj.t_dobus
     where dbookingdate = to_date(lv_date, 'yyyy-mm-dd')
       and sbotime = lv_dte
       and sdounitno = lv_sunit;
       
     select to_number(b.sbooknum) into lv_sum
    from tc_webjj.t_orgbook_config  a,
         tc_webjj.t_booktime_config b,
         tc_webjj.t_fd_date         c
   where a.sorgid = lv_sunit
     and a.sbookid = b.sbookid
     and c.fd_date =to_date(lv_date,'yyyy-mm-dd')  
      and c.stype = '1'
      and b.zxbz='0' and sbooktime=lv_dte;
      
       select count(*) into lv_user
        from tc_webjj.t_dobus
       where dbookingdate = to_date(lv_date, 'yyyy-mm-dd')
         and sbotime = lv_dte
         and sdounitno = lv_sunit and SUSERNO=lv_personid;
     if lv_user>0 then
        lvres:=0;
      else
         lvres := lv_sum-lv_cnt;
     end if;
         
    
   exception when others then
        lvres:=0;     
   end;
  return lvres;
end;
/

