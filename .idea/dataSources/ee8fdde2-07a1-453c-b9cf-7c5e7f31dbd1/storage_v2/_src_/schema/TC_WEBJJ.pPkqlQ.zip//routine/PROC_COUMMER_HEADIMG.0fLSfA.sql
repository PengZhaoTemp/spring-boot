create procedure          PROC_COUMMER_HEADIMG(
lvpid VARCHAR2,---------密码重置问题,加密的方式修改密码
head_img VARCHAR2-----------------头像地址

)
 as
begin
  update  tc_webjj.T_COMMONER set  CPHOTO =head_img  where PID =lvpid ;
  commit;

end PROC_COUMMER_HEADIMG;

/

