create procedure          proc_hd_consult(lv_SCONSULT_ID    in out varchar2,
                                                     lv_SNAME          varchar2,
                                                     lv_SGENDER        varchar2,
                                                     lv_SAGE           varchar2,
                                                     lv_SEMAIL         varchar2,
                                                     lv_STEL           varchar2,
                                                     lv_SSUBJECT       varchar2,
                                                     lv_SDETAIL        varchar2,
                                                     lv_SOPEN          varchar2,
                                                     lv_SPASS          varchar2,
                                                     lv_SDEAL_UNITCODE varchar2,
                                                     lv_SDEAL_UNITNAME varchar2,
                                                     lv_ProcMode      varchar2,
                                                     lv_msg_return     in out varchar2) as

begin
  if lv_ProcMode = 'PMINSERT' then
    select tc_webjj.fun_get_hdbh('BIS') into lv_SCONSULT_ID from dual; --业务咨询编号
    insert into tc_webjj.t_hd_consult
      (SCONSULT_ID,
       SNAME,
       SGENDER,
       SAGE,
       SEMAIL,
       STEL,
       SSUBJECT,
       SDETAIL,
       SOPEN,
       SPASS)
    values
      (lv_SCONSULT_ID,
       lv_SNAME,
       lv_SGENDER,
       lv_SAGE,
       lv_SEMAIL,
       lv_STEL,
       lv_SSUBJECT,
       lv_SDETAIL,
       lv_SOPEN,
       lv_SPASS);
    lv_msg_return := '返回的业务编号：' || lv_SCONSULT_ID ||
                     '，请保留该业务编号，可通过该编号获取官方回复！';
  end if;
  commit;
end proc_hd_consult;

/

