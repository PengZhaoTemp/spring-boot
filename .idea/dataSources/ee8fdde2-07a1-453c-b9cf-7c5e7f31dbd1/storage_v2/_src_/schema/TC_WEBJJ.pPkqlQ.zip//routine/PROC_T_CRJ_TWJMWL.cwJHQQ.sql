create PROCEDURE          PROC_t_crj_twjmwl   /*T_CRJ_TWJMWL*/
(
 lvsdono IN OUT VARCHAR2,  --业务编号
 lvsname VARCHAR2,  --姓　　名
 lvssex VARCHAR2,  --性　　别
 lvsbri DATE,  --出生日期
 lvsyj VARCHAR2,  --原　　籍
 lvshyzk VARCHAR2,  --婚姻状况
 lvscsd VARCHAR2,  --出  生 地
 lvssfzhm VARCHAR2,  --身份证号码
 lvszh VARCHAR2,  --住　　址
 lvszy VARCHAR2,  --职　　业
 lvsfwcs VARCHAR2,  --服务处所
 lvszw VARCHAR2,  --职　　务
 lvsbcrjka VARCHAR2,  --口　　岸
 lvsbcrjsj DATE,  --时　　间
 lvsrjcyzj VARCHAR2,  --入境持用证件：1，台湾居民往来大陆通行证 2，中华人民共和国旅行证
 lvsrjcyzj_hm VARCHAR2,  --入境持用证件号码
 lvsrjcyzj_yxqz DATE,  --入境持用证件有效期至
 lvsrjcyqz VARCHAR2,  --入境持用签注：1,一次入境签注 2，来往大陆签注 3，居民签注
 lvsrjcyqz_hm VARCHAR2,  --入境持用签注号码
 lvsrjcyqz_yxqz DATE,  --入境持用签注有效期至
 lvsrjcyqz_yxcs VARCHAR2,  --入境持用签注有效次数
 lvssqlb VARCHAR2,  --申请类别：1，台湾居民来往大陆通行证 2，来往大陆签注 3，居留签注
 lvssltwjmwldltxz VARCHAR2,  --申领台湾居民往来大陆通行证：1，首次申领 2，补、焕发 3，口岸入境
 lvslwdlqz_sqly VARCHAR2,  --居留签注申请事由：1,投资 2，就业 3，就留 4，就学（大学以上） 5，就学（专科以下）6，寄养儿童 7，其他
 lvslwdlqz_sqyxq VARCHAR2,  --居留签注申请有效期：1，一年，2，两年 3，三年 5，五年
 lvsydllxfs_zz VARCHAR2,  --与大陆联系方式：住址
 lvsydllxfs_lxdh VARCHAR2,  --与大陆联系方式：电话
 lvsydllxfs_gzdw VARCHAR2,  --与大陆联系方式：工作单位
 lvsydllxfs_zw VARCHAR2,  --与大陆联系方式：职务
 lvsdlzyqs_cw1 VARCHAR2,  --大陆主要亲属称谓1
 lvsdlzyqs_xm1 VARCHAR2,  --大陆主要亲属姓名1
 lvsdlzyqs_nl1 VARCHAR2,  --大陆主要亲属年龄1
 lvsdlzyqs_zz1 VARCHAR2,  --大陆主要亲属住址1
 lvsdlzyqs_cw2 VARCHAR2,  --大陆主要亲属称谓2
 lvsdlzyqs_xm2 VARCHAR2,  --大陆主要亲属姓名2
 lvsdlzyqs_nl2 VARCHAR2,  --大陆主要亲属年龄2
 lvsdlzyqs_zz2 VARCHAR2,  --大陆主要亲属住址2
 lvsdlzyqs_cw3 VARCHAR2,  --大陆主要亲属称谓3
 lvsdlzyqs_xm3 VARCHAR2,  --大陆主要亲属姓名3
 lvsdlzyqs_nl3 VARCHAR2,  --大陆主要亲属年龄3
 lvsdlzyqs_zz3 VARCHAR2,  --大陆主要亲属住址3
 lvslwdlqz_cssq VARCHAR2,  --来往大陆签注次数申请：1，一次 2，多次
 lvslwdlqz_yxqsq VARCHAR2,  --来往大陆签注有效期申请：1，三个月 2，一年
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
   INSERT into tc_webjj.t_crj_twjmwl
    (
      sdono,   --业务编号
      sname,   --姓　　名
      ssex,   --性　　别
      sbri,   --出生日期
      syj,   --原　　籍
      shyzk,   --婚姻状况
      scsd,   --出  生 地
      ssfzhm,   --身份证号码
      szh,   --住　　址
      szy,   --职　　业
      sfwcs,   --服务处所
      szw,   --职　　务
      sbcrjka,   --口　　岸
      sbcrjsj,   --时　　间
      srjcyzj,   --入境持用证件：1，台湾居民往来大陆通行证 2，中华人民共和国旅行证
      srjcyzj_hm,   --入境持用证件号码
      srjcyzj_yxqz,   --入境持用证件有效期至
      srjcyqz,   --入境持用签注：1,一次入境签注 2，来往大陆签注 3，居民签注
      srjcyqz_hm,   --入境持用签注号码
      srjcyqz_yxqz,   --入境持用签注有效期至
      srjcyqz_yxcs,   --入境持用签注有效次数
      ssqlb,   --申请类别：1，台湾居民来往大陆通行证 2，来往大陆签注 3，居留签注
      ssltwjmwldltxz,   --申领台湾居民往来大陆通行证：1，首次申领 2，补、焕发 3，口岸入境
      slwdlqz_sqly,   --居留签注申请事由：1,投资 2，就业 3，就留 4，就学（大学以上） 5，就学（专科以下）6，寄养儿童 7，其他
      slwdlqz_sqyxq,   --居留签注申请有效期：1，一年，2，两年 3，三年 5，五年
      sydllxfs_zz,   --与大陆联系方式：住址
      sydllxfs_lxdh,   --与大陆联系方式：电话
      sydllxfs_gzdw,   --与大陆联系方式：工作单位
      sydllxfs_zw,   --与大陆联系方式：职务
      sdlzyqs_cw1,   --大陆主要亲属称谓1
      sdlzyqs_xm1,   --大陆主要亲属姓名1
      sdlzyqs_nl1,   --大陆主要亲属年龄1
      sdlzyqs_zz1,   --大陆主要亲属住址1
      sdlzyqs_cw2,   --大陆主要亲属称谓2
      sdlzyqs_xm2,   --大陆主要亲属姓名2
      sdlzyqs_nl2,   --大陆主要亲属年龄2
      sdlzyqs_zz2,   --大陆主要亲属住址2
      sdlzyqs_cw3,   --大陆主要亲属称谓3
      sdlzyqs_xm3,   --大陆主要亲属姓名3
      sdlzyqs_nl3,   --大陆主要亲属年龄3
      sdlzyqs_zz3,   --大陆主要亲属住址3
      slwdlqz_cssq,   --来往大陆签注次数申请：1，一次 2，多次
      slwdlqz_yxqsq    --来往大陆签注有效期申请：1，三个月 2，一年
    )values(
      lvsdono,   --业务编号
      lvsname,   --姓　　名
      lvssex,   --性　　别
      lvsbri,   --出生日期
      lvsyj,   --原　　籍
      lvshyzk,   --婚姻状况
      lvscsd,   --出  生 地
      lvssfzhm,   --身份证号码
      lvszh,   --住　　址
      lvszy,   --职　　业
      lvsfwcs,   --服务处所
      lvszw,   --职　　务
      lvsbcrjka,   --口　　岸
      lvsbcrjsj,   --时　　间
      lvsrjcyzj,   --入境持用证件：1，台湾居民往来大陆通行证 2，中华人民共和国旅行证
      lvsrjcyzj_hm,   --入境持用证件号码
      lvsrjcyzj_yxqz,   --入境持用证件有效期至
      lvsrjcyqz,   --入境持用签注：1,一次入境签注 2，来往大陆签注 3，居民签注
      lvsrjcyqz_hm,   --入境持用签注号码
      lvsrjcyqz_yxqz,   --入境持用签注有效期至
      lvsrjcyqz_yxcs,   --入境持用签注有效次数
      lvssqlb,   --申请类别：1，台湾居民来往大陆通行证 2，来往大陆签注 3，居留签注
      lvssltwjmwldltxz,   --申领台湾居民往来大陆通行证：1，首次申领 2，补、焕发 3，口岸入境
      lvslwdlqz_sqly,   --居留签注申请事由：1,投资 2，就业 3，就留 4，就学（大学以上） 5，就学（专科以下）6，寄养儿童 7，其他
      lvslwdlqz_sqyxq,   --居留签注申请有效期：1，一年，2，两年 3，三年 5，五年
      lvsydllxfs_zz,   --与大陆联系方式：住址
      lvsydllxfs_lxdh,   --与大陆联系方式：电话
      lvsydllxfs_gzdw,   --与大陆联系方式：工作单位
      lvsydllxfs_zw,   --与大陆联系方式：职务
      lvsdlzyqs_cw1,   --大陆主要亲属称谓1
      lvsdlzyqs_xm1,   --大陆主要亲属姓名1
      lvsdlzyqs_nl1,   --大陆主要亲属年龄1
      lvsdlzyqs_zz1,   --大陆主要亲属住址1
      lvsdlzyqs_cw2,   --大陆主要亲属称谓2
      lvsdlzyqs_xm2,   --大陆主要亲属姓名2
      lvsdlzyqs_nl2,   --大陆主要亲属年龄2
      lvsdlzyqs_zz2,   --大陆主要亲属住址2
      lvsdlzyqs_cw3,   --大陆主要亲属称谓3
      lvsdlzyqs_xm3,   --大陆主要亲属姓名3
      lvsdlzyqs_nl3,   --大陆主要亲属年龄3
      lvsdlzyqs_zz3,   --大陆主要亲属住址3
      lvslwdlqz_cssq,   --来往大陆签注次数申请：1，一次 2，多次
      lvslwdlqz_yxqsq    --来往大陆签注有效期申请：1，三个月 2，一年
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_crj_twjmwl
    Set
      sdono=lvsdono,   --业务编号
      sname=lvsname,   --姓　　名
      ssex=lvssex,   --性　　别
      sbri=lvsbri,   --出生日期
      syj=lvsyj,   --原　　籍
      shyzk=lvshyzk,   --婚姻状况
      scsd=lvscsd,   --出  生 地
      ssfzhm=lvssfzhm,   --身份证号码
      szh=lvszh,   --住　　址
      szy=lvszy,   --职　　业
      sfwcs=lvsfwcs,   --服务处所
      szw=lvszw,   --职　　务
      sbcrjka=lvsbcrjka,   --口　　岸
      sbcrjsj=lvsbcrjsj,   --时　　间
      srjcyzj=lvsrjcyzj,   --入境持用证件：1，台湾居民往来大陆通行证 2，中华人民共和国旅行证
      srjcyzj_hm=lvsrjcyzj_hm,   --入境持用证件号码
      srjcyzj_yxqz=lvsrjcyzj_yxqz,   --入境持用证件有效期至
      srjcyqz=lvsrjcyqz,   --入境持用签注：1,一次入境签注 2，来往大陆签注 3，居民签注
      srjcyqz_hm=lvsrjcyqz_hm,   --入境持用签注号码
      srjcyqz_yxqz=lvsrjcyqz_yxqz,   --入境持用签注有效期至
      srjcyqz_yxcs=lvsrjcyqz_yxcs,   --入境持用签注有效次数
      ssqlb=lvssqlb,   --申请类别：1，台湾居民来往大陆通行证 2，来往大陆签注 3，居留签注
      ssltwjmwldltxz=lvssltwjmwldltxz,   --申领台湾居民往来大陆通行证：1，首次申领 2，补、焕发 3，口岸入境
      slwdlqz_sqly=lvslwdlqz_sqly,   --居留签注申请事由：1,投资 2，就业 3，就留 4，就学（大学以上） 5，就学（专科以下）6，寄养儿童 7，其他
      slwdlqz_sqyxq=lvslwdlqz_sqyxq,   --居留签注申请有效期：1，一年，2，两年 3，三年 5，五年
      sydllxfs_zz=lvsydllxfs_zz,   --与大陆联系方式：住址
      sydllxfs_lxdh=lvsydllxfs_lxdh,   --与大陆联系方式：电话
      sydllxfs_gzdw=lvsydllxfs_gzdw,   --与大陆联系方式：工作单位
      sydllxfs_zw=lvsydllxfs_zw,   --与大陆联系方式：职务
      sdlzyqs_cw1=lvsdlzyqs_cw1,   --大陆主要亲属称谓1
      sdlzyqs_xm1=lvsdlzyqs_xm1,   --大陆主要亲属姓名1
      sdlzyqs_nl1=lvsdlzyqs_nl1,   --大陆主要亲属年龄1
      sdlzyqs_zz1=lvsdlzyqs_zz1,   --大陆主要亲属住址1
      sdlzyqs_cw2=lvsdlzyqs_cw2,   --大陆主要亲属称谓2
      sdlzyqs_xm2=lvsdlzyqs_xm2,   --大陆主要亲属姓名2
      sdlzyqs_nl2=lvsdlzyqs_nl2,   --大陆主要亲属年龄2
      sdlzyqs_zz2=lvsdlzyqs_zz2,   --大陆主要亲属住址2
      sdlzyqs_cw3=lvsdlzyqs_cw3,   --大陆主要亲属称谓3
      sdlzyqs_xm3=lvsdlzyqs_xm3,   --大陆主要亲属姓名3
      sdlzyqs_nl3=lvsdlzyqs_nl3,   --大陆主要亲属年龄3
      sdlzyqs_zz3=lvsdlzyqs_zz3,   --大陆主要亲属住址3
      slwdlqz_cssq=lvslwdlqz_cssq,   --来往大陆签注次数申请：1，一次 2，多次
      slwdlqz_yxqsq=lvslwdlqz_yxqsq    --来往大陆签注有效期申请：1，三个月 2，一年
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_crj_twjmwl
    Set
      sdono=lvsdono,   --业务编号
      sname=lvsname,   --姓　　名
      ssex=lvssex,   --性　　别
      sbri=lvsbri,   --出生日期
      syj=lvsyj,   --原　　籍
      shyzk=lvshyzk,   --婚姻状况
      scsd=lvscsd,   --出  生 地
      ssfzhm=lvssfzhm,   --身份证号码
      szh=lvszh,   --住　　址
      szy=lvszy,   --职　　业
      sfwcs=lvsfwcs,   --服务处所
      szw=lvszw,   --职　　务
      sbcrjka=lvsbcrjka,   --口　　岸
      sbcrjsj=lvsbcrjsj,   --时　　间
      srjcyzj=lvsrjcyzj,   --入境持用证件：1，台湾居民往来大陆通行证 2，中华人民共和国旅行证
      srjcyzj_hm=lvsrjcyzj_hm,   --入境持用证件号码
      srjcyzj_yxqz=lvsrjcyzj_yxqz,   --入境持用证件有效期至
      srjcyqz=lvsrjcyqz,   --入境持用签注：1,一次入境签注 2，来往大陆签注 3，居民签注
      srjcyqz_hm=lvsrjcyqz_hm,   --入境持用签注号码
      srjcyqz_yxqz=lvsrjcyqz_yxqz,   --入境持用签注有效期至
      srjcyqz_yxcs=lvsrjcyqz_yxcs,   --入境持用签注有效次数
      ssqlb=lvssqlb,   --申请类别：1，台湾居民来往大陆通行证 2，来往大陆签注 3，居留签注
      ssltwjmwldltxz=lvssltwjmwldltxz,   --申领台湾居民往来大陆通行证：1，首次申领 2，补、焕发 3，口岸入境
      slwdlqz_sqly=lvslwdlqz_sqly,   --居留签注申请事由：1,投资 2，就业 3，就留 4，就学（大学以上） 5，就学（专科以下）6，寄养儿童 7，其他
      slwdlqz_sqyxq=lvslwdlqz_sqyxq,   --居留签注申请有效期：1，一年，2，两年 3，三年 5，五年
      sydllxfs_zz=lvsydllxfs_zz,   --与大陆联系方式：住址
      sydllxfs_lxdh=lvsydllxfs_lxdh,   --与大陆联系方式：电话
      sydllxfs_gzdw=lvsydllxfs_gzdw,   --与大陆联系方式：工作单位
      sydllxfs_zw=lvsydllxfs_zw,   --与大陆联系方式：职务
      sdlzyqs_cw1=lvsdlzyqs_cw1,   --大陆主要亲属称谓1
      sdlzyqs_xm1=lvsdlzyqs_xm1,   --大陆主要亲属姓名1
      sdlzyqs_nl1=lvsdlzyqs_nl1,   --大陆主要亲属年龄1
      sdlzyqs_zz1=lvsdlzyqs_zz1,   --大陆主要亲属住址1
      sdlzyqs_cw2=lvsdlzyqs_cw2,   --大陆主要亲属称谓2
      sdlzyqs_xm2=lvsdlzyqs_xm2,   --大陆主要亲属姓名2
      sdlzyqs_nl2=lvsdlzyqs_nl2,   --大陆主要亲属年龄2
      sdlzyqs_zz2=lvsdlzyqs_zz2,   --大陆主要亲属住址2
      sdlzyqs_cw3=lvsdlzyqs_cw3,   --大陆主要亲属称谓3
      sdlzyqs_xm3=lvsdlzyqs_xm3,   --大陆主要亲属姓名3
      sdlzyqs_nl3=lvsdlzyqs_nl3,   --大陆主要亲属年龄3
      sdlzyqs_zz3=lvsdlzyqs_zz3,   --大陆主要亲属住址3
      slwdlqz_cssq=lvslwdlqz_cssq,   --来往大陆签注次数申请：1，一次 2，多次
      slwdlqz_yxqsq=lvslwdlqz_yxqsq    --来往大陆签注有效期申请：1，三个月 2，一年
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_crj_twjmwl
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

