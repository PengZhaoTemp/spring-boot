create PROCEDURE          PROC_t_cgs_jszdhbg   /*T_CGS_JSZDHBG*/
(
 lvsdono IN OUT VARCHAR2,  --办理编号
 lvsdabh VARCHAR2,  --档案编号
 lvsname VARCHAR2,  --姓　　名
 lvssex VARCHAR2,  --性　　别
 lvspid VARCHAR2,  --身份证号码
 lvsaddress VARCHAR2,  --身份证地址
 lvstel VARCHAR2,  -- 联系电话
 lvszjcx VARCHAR2,  --准驾车型
 lvsnew_tel VARCHAR2,  --变更后的电话
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS

BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/



   INSERT into tc_webjj.t_cgs_jszdhbg
    (
      sdono,   --办理编号
      sdabh,   --档案编号
      sname,   --姓　　名
      ssex,   --性　　别
      spid,   --身份证号码
      saddress,   --身份证地址
      stel,   -- 联系电话
      szjcx,   --准驾车型
      snew_tel    --变更后的电话
    )values(
      lvsdono,   --办理编号
      lvsdabh,   --档案编号
      lvsname,   --姓　　名
      lvssex,   --性　　别
      lvspid,   --身份证号码
      lvsaddress,   --身份证地址
      lvstel,   -- 联系电话
      lvszjcx,   --准驾车型

      lvsnew_tel    --变更后的电话


    );
   -- 返回值

END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_cgs_jszdhbg
    Set
      sdono=lvsdono,   --办理编号
      sdabh=lvsdabh,   --档案编号
      sname=lvsname,   --姓　　名
      ssex=lvssex,   --性　　别
      spid=lvspid,   --身份证号码
      saddress=lvsaddress,   --身份证地址
      stel=lvstel,   -- 联系电话
      szjcx=lvszjcx,   --准驾车型
      snew_tel=lvsnew_tel    --变更后的电话
    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_cgs_jszdhbg
    Set
      sdono=lvsdono,   --办理编号
      sdabh=lvsdabh,   --档案编号
      sname=lvsname,   --姓　　名
      ssex=lvssex,   --性　　别
      spid=lvspid,   --身份证号码
      saddress=lvsaddress,   --身份证地址
      stel=lvstel,   -- 联系电话
      szjcx=lvszjcx,   --准驾车型
      snew_tel=lvsnew_tel    --变更后的电话
    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_cgs_jszdhbg
    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

