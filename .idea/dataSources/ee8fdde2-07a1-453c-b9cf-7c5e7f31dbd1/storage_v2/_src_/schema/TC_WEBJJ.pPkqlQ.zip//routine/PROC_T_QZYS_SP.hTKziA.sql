create PROCEDURE          PROC_t_qzys_sp   /*T_QZYS_SP*/
(
 lvsdono IN OUT VARCHAR2,  --业务编号
 lvsunit_name VARCHAR2,  --单位名称
 lvsunit_addr VARCHAR2,  --地　　址
 lvsfzr VARCHAR2,  --负  责 人
 lvstel VARCHAR2,  --联系电话
 lvsjbr_name VARCHAR2,  --经办人姓名
 lvsjbr_phone VARCHAR2,  --经办人电话
 lvsjbr_pid VARCHAR2,  --经办人身份证号
 lvsqz_type VARCHAR2,  --枪支品种
 lvsqz_sl VARCHAR2,  --枪支数量
 lvsqyd_tjd VARCHAR2,  --起运地及途经地
 lvsywd VARCHAR2,  --运  往 地
 lvyy_fzr VARCHAR2,  --押运负责人
 lvzz_yyy VARCHAR2,  --专职押运员
 lvysfs_aqcs VARCHAR2,  --运输方式及安全措施
 lvunit_yj VARCHAR2,  --单位意见
 lvyj_time DATE,  --意见时间
 lvga_zbr_yj VARCHAR2,  --公安主办人意见
 lvga_zbr_yj_time DATE,  --公安主办人意见时间
 lvga_spr_yj VARCHAR2,  --公安审批人意见
 lvga_spr_yj_time DATE,  --公安审批人意见时间
 lvbz VARCHAR2,  --备　　注
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS

BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/



   INSERT into tc_webjj.t_qzys_sp
    (
      sdono,   --业务编号
      sunit_name,   --单位名称
      sunit_addr,   --地　　址
      sfzr,   --负  责 人
      stel,   --联系电话
      sjbr_name,   --经办人姓名
      sjbr_phone,   --经办人电话
      sjbr_pid,   --经办人身份证号
      sqz_type,   --枪支品种
      sqz_sl,   --枪支数量
      sqyd_tjd,   --起运地及途经地
      sywd,   --运  往 地
      yy_fzr,   --押运负责人
      zz_yyy,   --专职押运员
      ysfs_aqcs,   --运输方式及安全措施
      unit_yj,   --单位意见
      yj_time,   --意见时间
      ga_zbr_yj,   --公安主办人意见
      ga_zbr_yj_time,   --公安主办人意见时间
      ga_spr_yj,   --公安审批人意见
      ga_spr_yj_time,   --公安审批人意见时间
      bz    --备　　注
    )values(
      lvsdono,   --业务编号
      lvsunit_name,   --单位名称
      lvsunit_addr,   --地　　址
      lvsfzr,   --负  责 人
      lvstel,   --联系电话
      lvsjbr_name,   --经办人姓名
      lvsjbr_phone,   --经办人电话
      lvsjbr_pid,   --经办人身份证号
      lvsqz_type,   --枪支品种
      lvsqz_sl,   --枪支数量
      lvsqyd_tjd,   --起运地及途经地
      lvsywd,   --运  往 地
      lvyy_fzr,   --押运负责人
      lvzz_yyy,   --专职押运员
      lvysfs_aqcs,   --运输方式及安全措施
      lvunit_yj,   --单位意见
      lvyj_time,   --意见时间
      lvga_zbr_yj,   --公安主办人意见
      lvga_zbr_yj_time,   --公安主办人意见时间
      lvga_spr_yj,   --公安审批人意见
      lvga_spr_yj_time,   --公安审批人意见时间

      lvbz    --备　　注


    );
   -- 返回值

END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_qzys_sp
    Set
      sdono=lvsdono,   --业务编号
      sunit_name=lvsunit_name,   --单位名称
      sunit_addr=lvsunit_addr,   --地　　址
      sfzr=lvsfzr,   --负  责 人
      stel=lvstel,   --联系电话
      sjbr_name=lvsjbr_name,   --经办人姓名
      sjbr_phone=lvsjbr_phone,   --经办人电话
      sjbr_pid=lvsjbr_pid,   --经办人身份证号
      sqz_type=lvsqz_type,   --枪支品种
      sqz_sl=lvsqz_sl,   --枪支数量
      sqyd_tjd=lvsqyd_tjd,   --起运地及途经地
      sywd=lvsywd,   --运  往 地
      yy_fzr=lvyy_fzr,   --押运负责人
      zz_yyy=lvzz_yyy,   --专职押运员
      ysfs_aqcs=lvysfs_aqcs,   --运输方式及安全措施
      unit_yj=lvunit_yj,   --单位意见
      yj_time=lvyj_time,   --意见时间
      ga_zbr_yj=lvga_zbr_yj,   --公安主办人意见
      ga_zbr_yj_time=lvga_zbr_yj_time,   --公安主办人意见时间
      ga_spr_yj=lvga_spr_yj,   --公安审批人意见
      ga_spr_yj_time=lvga_spr_yj_time,   --公安审批人意见时间
      bz=lvbz    --备　　注
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_qzys_sp
    Set
      sdono=lvsdono,   --业务编号
      sunit_name=lvsunit_name,   --单位名称
      sunit_addr=lvsunit_addr,   --地　　址
      sfzr=lvsfzr,   --负  责 人
      stel=lvstel,   --联系电话
      sjbr_name=lvsjbr_name,   --经办人姓名
      sjbr_phone=lvsjbr_phone,   --经办人电话
      sjbr_pid=lvsjbr_pid,   --经办人身份证号
      sqz_type=lvsqz_type,   --枪支品种
      sqz_sl=lvsqz_sl,   --枪支数量
      sqyd_tjd=lvsqyd_tjd,   --起运地及途经地
      sywd=lvsywd,   --运  往 地
      yy_fzr=lvyy_fzr,   --押运负责人
      zz_yyy=lvzz_yyy,   --专职押运员
      ysfs_aqcs=lvysfs_aqcs,   --运输方式及安全措施
      unit_yj=lvunit_yj,   --单位意见
      yj_time=lvyj_time,   --意见时间
      ga_zbr_yj=lvga_zbr_yj,   --公安主办人意见
      ga_zbr_yj_time=lvga_zbr_yj_time,   --公安主办人意见时间
      ga_spr_yj=lvga_spr_yj,   --公安审批人意见
      ga_spr_yj_time=lvga_spr_yj_time,   --公安审批人意见时间
      bz=lvbz    --备　　注
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_qzys_sp
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

