create PROCEDURE          PROC_t_crj_yscg   /*T_CRJ_YSCG*/
(
 lvsdono IN OUT VARCHAR2,  --业务编号
 lvssfzhm VARCHAR2,  --身份证号码
 lvsxing VARCHAR2,  --姓
 lvsming VARCHAR2,  --名
 lvspyxing VARCHAR2,  --拼  音 姓
 lvspyming VARCHAR2,  --拼  音 名
 lvsmz VARCHAR2,  --民　　族
 lvdcsrq DATE,  --出生日期
 lvscsd VARCHAR2,  --出  生 地
 lvshyzk VARCHAR2,  --婚姻状况
 lvszzmm VARCHAR2,  --政治面貌
 lvswhcd VARCHAR2,  --文化程度
 lvslxdh VARCHAR2,  --联系电话
 lvshkszd VARCHAR2,  --户口所在地
 lvssspcs VARCHAR2,  --所属派出所
 lvsjtxzz VARCHAR2,  --家庭现住址
 lvsyzbm VARCHAR2,  --邮政编码
 lvsbrsf VARCHAR2,  --本人身份：1，国家工作人员 2，国有大中型企业中层以上管理人员 3，金融、保险系统人员 4、国有控股、参股企业中的国有股权代表 5、军人 6、其他人员
 lvsfwcs VARCHAR2,  --服务处所
 lvszwzc VARCHAR2,  --职务职称
 lvsfwcsdz VARCHAR2,  --服务处所地址
 lvsfwcs_lxdh VARCHAR2,  --服务处所地址联系电话
 lvsqwgj VARCHAR2,  --前往国家
 lvssdjcyccg VARCHAR2,  --属第几次因私出国
 lvscgsy VARCHAR2,  --出国事由：1，定居 2，探亲 3，商务 4，劳务 5，留学 6，旅游 7，其他
 lvszjsllb VARCHAR2,  --申请证件种类类别：1，普通护照首次申领 2，普通护照补发 3，普通护照换发 4，普通护照失效重新申领 5，普通护照变更加注
 lvspthzbgjzlb VARCHAR2,  --普通护照变更加注类别
 lvspthzbgjznr VARCHAR2,  --普通护照变更加注内容
 lvspthzhfbfyy VARCHAR2,  --普通护照换发、补发原因
 lvyhzhm VARCHAR2,  --原护照号码
 lvsqfd VARCHAR2,  --签  发 地
 lvsyxqz DATE,  --有效期至
 lvscw1 VARCHAR2,  --称  谓 1
 lvsname1 VARCHAR2,  --姓  名 1
 lvscsrq1 DATE,  --出生日期1
 lvsgzdw1 VARCHAR2,  --工作单位1
 lvsjtzd1 VARCHAR2,  --家庭住址1
 lvscw2 VARCHAR2,  --称  谓 2
 lvsname2 VARCHAR2,  --姓  名 2
 lvscsrq2 DATE,  --出生日期2
 lvsgzdw2 VARCHAR2,  --工作单位2
 lvsjtzd2 VARCHAR2,  --家庭住址2
 lvscw3 VARCHAR2,  --称  谓 3
 lvsname3 VARCHAR2,  --姓  名 3
 lvscsrq3 DATE,  --出生日期3
 lvsgzdw3 VARCHAR2,  --工作单位3
 lvsjtzd3 VARCHAR2,  --家庭住址3
 lvscw4 VARCHAR2,  --称  谓 4
 lvsname4 VARCHAR2,  --姓  名 4
 lvscsrq4 DATE,  --出生日期4
 lvsgzdw4 VARCHAR2,  --工作单位4
 lvsjtzd4 VARCHAR2,  --家庭住址4
 lvscw5 VARCHAR2,  --称  谓 5
 lvsname5 VARCHAR2,  --姓  名 5
 lvscsrt5 DATE,  --出生日期5
 lvsgzdw5 VARCHAR2,  --工作单位5
 lvsjtzd5 VARCHAR2,  --家庭住址5
 lvsbrjl VARCHAR2,  --本人简历
 lvsqzfs VARCHAR2,  --取证方式：1，邮政速递 2，到公安机关领取
 lvsyzdz_yzbm VARCHAR2,  --邮政地址及邮政编码
 lvssjmname VARCHAR2,  --收件人姓名
 lvssjrlxdh VARCHAR2,  --收件人联系电话
 lvssex VARCHAR2,--性别
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
   INSERT into tc_webjj.t_crj_yscg
    (
      sdono,   --业务编号
      ssfzhm,   --身份证号码
      sxing,   --姓
      sming,   --名
      spyxing,   --拼  音 姓
      spyming,   --拼  音 名
      smz,   --民　　族
      dcsrq,   --出生日期
      scsd,   --出  生 地
      shyzk,   --婚姻状况
      szzmm,   --政治面貌
      swhcd,   --文化程度
      slxdh,   --联系电话
      shkszd,   --户口所在地
      ssspcs,   --所属派出所
      sjtxzz,   --家庭现住址
      syzbm,   --邮政编码
      sbrsf,   --本人身份：1，国家工作人员 2，国有大中型企业中层以上管理人员 3，金融、保险系统人员 4、国有控股、参股企业中的国有股权代表 5、军人 6、其他人员
      sfwcs,   --服务处所
      szwzc,   --职务职称
      sfwcsdz,   --服务处所地址
      sfwcs_lxdh,   --服务处所地址联系电话
      sqwgj,   --前往国家
      ssdjcyccg,   --属第几次因私出国
      scgsy,   --出国事由：1，定居 2，探亲 3，商务 4，劳务 5，留学 6，旅游 7，其他
      szjsllb,   --申请证件种类类别：1，普通护照首次申领 2，普通护照补发 3，普通护照换发 4，普通护照失效重新申领 5，普通护照变更加注
      spthzbgjzlb,   --普通护照变更加注类别
      spthzbgjznr,   --普通护照变更加注内容
      spthzhfbfyy,   --普通护照换发、补发原因
      yhzhm,   --原护照号码
      sqfd,   --签  发 地
      syxqz,   --有效期至
      scw1,   --称  谓 1
      sname1,   --姓  名 1
      scsrq1,   --出生日期1
      sgzdw1,   --工作单位1
      sjtzd1,   --家庭住址1
      scw2,   --称  谓 2
      sname2,   --姓  名 2
      scsrq2,   --出生日期2
      sgzdw2,   --工作单位2
      sjtzd2,   --家庭住址2
      scw3,   --称  谓 3
      sname3,   --姓  名 3
      scsrq3,   --出生日期3
      sgzdw3,   --工作单位3
      sjtzd3,   --家庭住址3
      scw4,   --称  谓 4
      sname4,   --姓  名 4
      scsrq4,   --出生日期4
      sgzdw4,   --工作单位4
      sjtzd4,   --家庭住址4
      scw5,   --称  谓 5
      sname5,   --姓  名 5
      scsrt5,   --出生日期5
      sgzdw5,   --工作单位5
      sjtzd5,   --家庭住址5
      sbrjl,   --本人简历
      sqzfs,   --取证方式：1，邮政速递 2，到公安机关领取
      syzdz_yzbm,   --邮政地址及邮政编码
      ssjmname,   --收件人姓名
      ssjrlxdh,    --收件人联系电话
      ssex  --性别
    )values(
      lvsdono,   --业务编号
      lvssfzhm,   --身份证号码
      lvsxing,   --姓
      lvsming,   --名
      lvspyxing,   --拼  音 姓
      lvspyming,   --拼  音 名
      lvsmz,   --民　　族
      lvdcsrq,   --出生日期
      lvscsd,   --出  生 地
      lvshyzk,   --婚姻状况
      lvszzmm,   --政治面貌
      lvswhcd,   --文化程度
      lvslxdh,   --联系电话
      lvshkszd,   --户口所在地
      lvssspcs,   --所属派出所
      lvsjtxzz,   --家庭现住址
      lvsyzbm,   --邮政编码
      lvsbrsf,   --本人身份：1，国家工作人员 2，国有大中型企业中层以上管理人员 3，金融、保险系统人员 4、国有控股、参股企业中的国有股权代表 5、军人 6、其他人员
      lvsfwcs,   --服务处所
      lvszwzc,   --职务职称
      lvsfwcsdz,   --服务处所地址
      lvsfwcs_lxdh,   --服务处所地址联系电话
      lvsqwgj,   --前往国家
      lvssdjcyccg,   --属第几次因私出国
      lvscgsy,   --出国事由：1，定居 2，探亲 3，商务 4，劳务 5，留学 6，旅游 7，其他
      lvszjsllb,   --申请证件种类类别：1，普通护照首次申领 2，普通护照补发 3，普通护照换发 4，普通护照失效重新申领 5，普通护照变更加注
      lvspthzbgjzlb,   --普通护照变更加注类别
      lvspthzbgjznr,   --普通护照变更加注内容
      lvspthzhfbfyy,   --普通护照换发、补发原因
      lvyhzhm,   --原护照号码
      lvsqfd,   --签  发 地
      lvsyxqz,   --有效期至
      lvscw1,   --称  谓 1
      lvsname1,   --姓  名 1
      lvscsrq1,   --出生日期1
      lvsgzdw1,   --工作单位1
      lvsjtzd1,   --家庭住址1
      lvscw2,   --称  谓 2
      lvsname2,   --姓  名 2
      lvscsrq2,   --出生日期2
      lvsgzdw2,   --工作单位2
      lvsjtzd2,   --家庭住址2
      lvscw3,   --称  谓 3
      lvsname3,   --姓  名 3
      lvscsrq3,   --出生日期3
      lvsgzdw3,   --工作单位3
      lvsjtzd3,   --家庭住址3
      lvscw4,   --称  谓 4
      lvsname4,   --姓  名 4
      lvscsrq4,   --出生日期4
      lvsgzdw4,   --工作单位4
      lvsjtzd4,   --家庭住址4
      lvscw5,   --称  谓 5
      lvsname5,   --姓  名 5
      lvscsrt5,   --出生日期5
      lvsgzdw5,   --工作单位5
      lvsjtzd5,   --家庭住址5
      lvsbrjl,   --本人简历
      lvsqzfs,   --取证方式：1，邮政速递 2，到公安机关领取
      lvsyzdz_yzbm,   --邮政地址及邮政编码
      lvssjmname,   --收件人姓名
      lvssjrlxdh ,   --收件人联系电话
      lvssex --性别
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_crj_yscg
    Set
      sdono=lvsdono,   --业务编号
      ssfzhm=lvssfzhm,   --身份证号码
      sxing=lvsxing,   --姓
      sming=lvsming,   --名
      spyxing=lvspyxing,   --拼  音 姓
      spyming=lvspyming,   --拼  音 名
      smz=lvsmz,   --民　　族
      dcsrq=lvdcsrq,   --出生日期
      scsd=lvscsd,   --出  生 地
      shyzk=lvshyzk,   --婚姻状况
      szzmm=lvszzmm,   --政治面貌
      swhcd=lvswhcd,   --文化程度
      slxdh=lvslxdh,   --联系电话
      shkszd=lvshkszd,   --户口所在地
      ssspcs=lvssspcs,   --所属派出所
      sjtxzz=lvsjtxzz,   --家庭现住址
      syzbm=lvsyzbm,   --邮政编码
      sbrsf=lvsbrsf,   --本人身份：1，国家工作人员 2，国有大中型企业中层以上管理人员 3，金融、保险系统人员 4、国有控股、参股企业中的国有股权代表 5、军人 6、其他人员
      sfwcs=lvsfwcs,   --服务处所
      szwzc=lvszwzc,   --职务职称
      sfwcsdz=lvsfwcsdz,   --服务处所地址
      sfwcs_lxdh=lvsfwcs_lxdh,   --服务处所地址联系电话
      sqwgj=lvsqwgj,   --前往国家
      ssdjcyccg=lvssdjcyccg,   --属第几次因私出国
      scgsy=lvscgsy,   --出国事由：1，定居 2，探亲 3，商务 4，劳务 5，留学 6，旅游 7，其他
      szjsllb=lvszjsllb,   --申请证件种类类别：1，普通护照首次申领 2，普通护照补发 3，普通护照换发 4，普通护照失效重新申领 5，普通护照变更加注
      spthzbgjzlb=lvspthzbgjzlb,   --普通护照变更加注类别
      spthzbgjznr=lvspthzbgjznr,   --普通护照变更加注内容
      spthzhfbfyy=lvspthzhfbfyy,   --普通护照换发、补发原因
      yhzhm=lvyhzhm,   --原护照号码
      sqfd=lvsqfd,   --签  发 地
      syxqz=lvsyxqz,   --有效期至
      scw1=lvscw1,   --称  谓 1
      sname1=lvsname1,   --姓  名 1
      scsrq1=lvscsrq1,   --出生日期1
      sgzdw1=lvsgzdw1,   --工作单位1
      sjtzd1=lvsjtzd1,   --家庭住址1
      scw2=lvscw2,   --称  谓 2
      sname2=lvsname2,   --姓  名 2
      scsrq2=lvscsrq2,   --出生日期2
      sgzdw2=lvsgzdw2,   --工作单位2
      sjtzd2=lvsjtzd2,   --家庭住址2
      scw3=lvscw3,   --称  谓 3
      sname3=lvsname3,   --姓  名 3
      scsrq3=lvscsrq3,   --出生日期3
      sgzdw3=lvsgzdw3,   --工作单位3
      sjtzd3=lvsjtzd3,   --家庭住址3
      scw4=lvscw4,   --称  谓 4
      sname4=lvsname4,   --姓  名 4
      scsrq4=lvscsrq4,   --出生日期4
      sgzdw4=lvsgzdw4,   --工作单位4
      sjtzd4=lvsjtzd4,   --家庭住址4
      scw5=lvscw5,   --称  谓 5
      sname5=lvsname5,   --姓  名 5
      scsrt5=lvscsrt5,   --出生日期5
      sgzdw5=lvsgzdw5,   --工作单位5
      sjtzd5=lvsjtzd5,   --家庭住址5
      sbrjl=lvsbrjl,   --本人简历
      sqzfs=lvsqzfs,   --取证方式：1，邮政速递 2，到公安机关领取
      syzdz_yzbm=lvsyzdz_yzbm,   --邮政地址及邮政编码
      ssjmname=lvssjmname,   --收件人姓名
      ssjrlxdh=lvssjrlxdh,   --收件人联系电话
      ssex=lvssex --性别
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_crj_yscg
    Set
      sdono=lvsdono,   --业务编号
      ssfzhm=lvssfzhm,   --身份证号码
      sxing=lvsxing,   --姓
      sming=lvsming,   --名
      spyxing=lvspyxing,   --拼  音 姓
      spyming=lvspyming,   --拼  音 名
      smz=lvsmz,   --民　　族
      dcsrq=lvdcsrq,   --出生日期
      scsd=lvscsd,   --出  生 地
      shyzk=lvshyzk,   --婚姻状况
      szzmm=lvszzmm,   --政治面貌
      swhcd=lvswhcd,   --文化程度
      slxdh=lvslxdh,   --联系电话
      shkszd=lvshkszd,   --户口所在地
      ssspcs=lvssspcs,   --所属派出所
      sjtxzz=lvsjtxzz,   --家庭现住址
      syzbm=lvsyzbm,   --邮政编码
      sbrsf=lvsbrsf,   --本人身份：1，国家工作人员 2，国有大中型企业中层以上管理人员 3，金融、保险系统人员 4、国有控股、参股企业中的国有股权代表 5、军人 6、其他人员
      sfwcs=lvsfwcs,   --服务处所
      szwzc=lvszwzc,   --职务职称
      sfwcsdz=lvsfwcsdz,   --服务处所地址
      sfwcs_lxdh=lvsfwcs_lxdh,   --服务处所地址联系电话
      sqwgj=lvsqwgj,   --前往国家
      ssdjcyccg=lvssdjcyccg,   --属第几次因私出国
      scgsy=lvscgsy,   --出国事由：1，定居 2，探亲 3，商务 4，劳务 5，留学 6，旅游 7，其他
      szjsllb=lvszjsllb,   --申请证件种类类别：1，普通护照首次申领 2，普通护照补发 3，普通护照换发 4，普通护照失效重新申领 5，普通护照变更加注
      spthzbgjzlb=lvspthzbgjzlb,   --普通护照变更加注类别
      spthzbgjznr=lvspthzbgjznr,   --普通护照变更加注内容
      spthzhfbfyy=lvspthzhfbfyy,   --普通护照换发、补发原因
      yhzhm=lvyhzhm,   --原护照号码
      sqfd=lvsqfd,   --签  发 地
      syxqz=lvsyxqz,   --有效期至
      scw1=lvscw1,   --称  谓 1
      sname1=lvsname1,   --姓  名 1
      scsrq1=lvscsrq1,   --出生日期1
      sgzdw1=lvsgzdw1,   --工作单位1
      sjtzd1=lvsjtzd1,   --家庭住址1
      scw2=lvscw2,   --称  谓 2
      sname2=lvsname2,   --姓  名 2
      scsrq2=lvscsrq2,   --出生日期2
      sgzdw2=lvsgzdw2,   --工作单位2
      sjtzd2=lvsjtzd2,   --家庭住址2
      scw3=lvscw3,   --称  谓 3
      sname3=lvsname3,   --姓  名 3
      scsrq3=lvscsrq3,   --出生日期3
      sgzdw3=lvsgzdw3,   --工作单位3
      sjtzd3=lvsjtzd3,   --家庭住址3
      scw4=lvscw4,   --称  谓 4
      sname4=lvsname4,   --姓  名 4
      scsrq4=lvscsrq4,   --出生日期4
      sgzdw4=lvsgzdw4,   --工作单位4
      sjtzd4=lvsjtzd4,   --家庭住址4
      scw5=lvscw5,   --称  谓 5
      sname5=lvsname5,   --姓  名 5
      scsrt5=lvscsrt5,   --出生日期5
      sgzdw5=lvsgzdw5,   --工作单位5
      sjtzd5=lvsjtzd5,   --家庭住址5
      sbrjl=lvsbrjl,   --本人简历
      sqzfs=lvsqzfs,   --取证方式：1，邮政速递 2，到公安机关领取
      syzdz_yzbm=lvsyzdz_yzbm,   --邮政地址及邮政编码
      ssjmname=lvssjmname,   --收件人姓名
      ssjrlxdh=lvssjrlxdh ,   --收件人联系电话
      ssex=lvssex --性别
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_crj_yscg
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

