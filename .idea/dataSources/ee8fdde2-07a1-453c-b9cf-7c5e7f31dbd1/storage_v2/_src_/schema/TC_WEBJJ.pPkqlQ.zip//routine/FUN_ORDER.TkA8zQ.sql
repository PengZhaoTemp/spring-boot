create function          fun_order(lv_sbusno varchar2,
                                     lv_name   varchar2,
                                     lv_pid    varchar2) return varchar2 is
  lv_return     varchar2(80);
  lv_order_date date;
  --lv_sysdate    date;
  lv_count      number;
begin
  /*sss*/
  lv_return :='22';
  if lv_sbusno = '066' then
    select count(*)
      into lv_count
      from tc_webjj.t_cgs_jdcjyyy yy, tc_webjj.t_dobus bus
     where yy.sdono = bus.sdono
       and dyy_time > sysdate
       and bus.state in ('24', '42')
       and yy.scar_name = lv_name
       and yy.scar_pid = lv_pid;
    if lv_count > 0 then
      select max(dyy_time)
        into lv_order_date
        from tc_webjj.t_cgs_jdcjyyy
       where scar_name = lv_name
         and scar_pid = lv_pid;
      if lv_order_date > sysdate then
        return '22'; /*不可以预约*/
      else
        return '11'; /*可以预约*/
      end if;
    else
      return '11'; /*可以预约*/
    end if;
  end if;

  return(lv_return);
end fun_order;

/

