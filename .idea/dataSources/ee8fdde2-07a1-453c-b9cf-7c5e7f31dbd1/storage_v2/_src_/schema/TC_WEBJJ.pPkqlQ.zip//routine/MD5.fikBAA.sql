create function MD5(pass in varchar2) return varchar2 is
  retval varchar2(32);
begin
  retval := utl_raw.cast_to_raw(dbms_obfuscation_toolkit.MD5(input_string => pass));
  return retval;
end;
/

