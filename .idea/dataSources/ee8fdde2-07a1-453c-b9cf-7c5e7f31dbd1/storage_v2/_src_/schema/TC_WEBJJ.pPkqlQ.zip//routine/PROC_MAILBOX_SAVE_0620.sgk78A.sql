create procedure proc_mailbox_save_0620(
      lvsid         in out      varchar2,
      lvsregion_name      varchar2, --区县名称
      lvsregion_id        varchar2, --区县id
      lvstype       varchar2,       --咨询类型
      lvstitle      varchar2,       --咨询标题
      lvscontent    varchar2,       --咨询类型
      lvsuserid     varchar2,       --登记人id
      lvsname       varchar2,       --登记人名称
      lvsphone      varchar2,       --登记人联系方式
      lvsphoneaddr  varchar2,       --
      lvsemail      varchar2,       --
      lvsaddress    varchar2,       --
      lvsmailip     varchar2,       --登记人IP
      lvsgzdw       varchar2,       --
      lvsispublic    varchar2,      --是否公开
      lvjc_type   varchar2,         --提交类型
      lvqx_code varchar2,           --区县编码code
      lvqx_name varchar2,           --区县地址
      lvaddress_xxdz varchar2,      --详细地址字段维护
      lvsheng_name varchar2,        --省居住地名
      lvshi_name varchar2,          --市居住地名
      lv_qx_name varchar2           --区县居住地名
) is
  lvid varchar2(16);
begin
         if  lvsid='' or lvsid is null then
             --select tc_webjj.fun_get16code(tc_webjj.seq_portal_mailbox_sid.nextval) into lvsid from dual;
            SELECT LPAD(tc_webjj.seq_portal_mailbox_sid.nextval,10,'0') into lvsid from dual;
            --lvsid:=lvid;
         end if;

  insert into tc_webjj.t_portal_mailbox(
     sid,
     sregion_name,
     sregion_id,
     stype,
     stitle,
     scontent,
     dcreatedate,
     suserid,
     sispublic,
     sname,
     sphone,
     sphoneaddr,
     semail,
     saddress,
     smailip,
     dmaildeadline,
     sisdone,
     sgzdw,
     ssource,
     jc_type,
     xg_stype,
     qx_code,
     qx_name,
     address_xxdz,
     REMARK1,
     REMARK2,
     REMARK3
  )values(
     lvsid,
     lvsregion_name,
     lvsregion_id,
     lvstype,
     lvstitle,
     lvscontent,
     sysdate,
     lvsuserid,
     lvsispublic,
     lvsname,
     lvsphone,
     lvsphoneaddr,
     lvsemail,
     lvsaddress,
     lvsmailip,
     sysdate+10,
     '0',
     lvsgzdw,
     '1',
     lvjc_type,
     lvstype,
     lvqx_code,
     lvqx_name,
     lvaddress_xxdz,
     lvsheng_name,
     lvshi_name,
     lv_qx_name
  );
  commit;
end proc_mailbox_save_0620;
/

