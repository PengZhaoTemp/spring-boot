create function          fun_dono return varchar2 is
  lvsdono varchar2(500);
begin
   Select TC_WEBJJ.SEQ_T_DOBUS_SDONO.Nextval
      into lvsdono
      From dual; /*????????????*/
     IF length(lvsdono)<2 then
      lvsdono:='411000'||'1'||'2'||'0000000'||lvsdono;
      elsIF length(lvsdono)<3 then
      lvsdono:='411000'||'1'||'2'||'000000'||lvsdono;
      elsIF length(lvsdono)<4 then
      lvsdono:='411000'||'1'||'2'||'00000'||lvsdono;
      elsIF length(lvsdono)<5 then
      lvsdono:='411000'||'1'||'2'||'0000'||lvsdono;
      elsIF length(lvsdono)<6 then
      lvsdono:='411000'||'1'||'2'||'000'||lvsdono;
      elsIF length(lvsdono)<7 then
      lvsdono:='411000'||'1'||'2'||'00'||lvsdono;
      elsIF length(lvsdono)<8 then
      lvsdono:='411000'||'1'||'2'||'0'||lvsdono;
     end if;
  return(lvsdono);
end fun_dono;

/

