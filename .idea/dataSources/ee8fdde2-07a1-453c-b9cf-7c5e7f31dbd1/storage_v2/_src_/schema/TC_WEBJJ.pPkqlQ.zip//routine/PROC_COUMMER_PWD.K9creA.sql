create procedure          PROC_COUMMER_PWD(
pid VARCHAR2,---------密码重置问题
phone VARCHAR2,---------电话
pwd  VARCHAR2-------密码

)
 as
begin
  update  tc_webjj.T_COMMONER set  SPWD =pwd  where PID =pid and SHOME_PHONE=phone;
  commit;
end PROC_COUMMER_PWD;

/

