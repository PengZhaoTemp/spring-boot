create procedure proc_webindex_hitcount  --用户访问

(
--参数
  lvsremark VARCHAR2,
  lvip varchar2,
  lvym varchar2
)

as
lvcnt number;
lvcnt1 number;
lv_cnt number;
begin
   SELECT TRUNC(DBMS_RANDOM.VALUE(500,  999)) into lv_cnt FROM dual;
   
   select count(*) into lvcnt1 from tc_webjj.T_WEBINDEX_COUNT_INFO where  login_date> trunc(sysdate);
   
  if lvcnt1=0 then--当天第一个登陆
     update tc_webjj.t_webindex_hitcount set ntoday_hitcount= 1,nall_hitcount= nall_hitcount+1;
  end if;
  --判断是否同天同sessionid
  select count(*) into lvcnt from tc_webjj.T_WEBINDEX_COUNT_INFO where session_id=lvsremark and login_date> trunc(sysdate);

  --修改访问统计表
  if lvcnt =0 then
     update tc_webjj.t_webindex_hitcount set ntoday_hitcount= ntoday_hitcount+1,nall_hitcount= nall_hitcount+1;
     --update tc_webjj.t_webindex_hitcount set ntoday_hitcount= ntoday_hitcount+lv_cnt,nall_hitcount= nall_hitcount+lv_cnt;
     commit;
  end if;
  --插入详细表
       insert into T_WEBINDEX_COUNT_INFO(
              nid, ip ,login_date, area ,ym,session_id
       )values(
              tc_webjj.SEQ_WEBINDEX_COUNT_INFO.nextval,lvip,sysdate,'',lvym,lvsremark
       );


end;

/

