create PROCEDURE          PROC_t_cgs_txdzbg   /*T_CGS_TXDZBG*/
(
 lvsdono IN OUT VARCHAR2,  --办理编号
 lvscarid VARCHAR2,  --车牌号码
 lvscar_type VARCHAR2,  --车辆类型
 lvsloginid VARCHAR2,  --登记证书编号
 lvscar_sbid VARCHAR2,  --车辆识别代号/车架号
 lvscar_fdjid VARCHAR2,  --发动机号
 lvscar_name VARCHAR2,  -- 机动车所有人
 lvscar_pid VARCHAR2,  --身份证明号/代码
 lvstel VARCHAR2,  --联系电话
 lvsaddress VARCHAR2,  --原通信地址
 lvsnewadr VARCHAR2,  --新通信地址
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS

BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/



   INSERT into tc_webjj.t_cgs_txdzbg
    (
      sdono,   --办理编号
      scarid,   --车牌号码
      scar_type,   --车辆类型
      sloginid,   --登记证书编号
      scar_sbid,   --车辆识别代号/车架号
      scar_fdjid,   --发动机号
      scar_name,   -- 机动车所有人
      scar_pid,   --身份证明号/代码
      stel,   --联系电话
      saddress,   --原通信地址
      snewadr    --新通信地址
    )values(
      lvsdono,   --办理编号
      lvscarid,   --车牌号码
      lvscar_type,   --车辆类型
      lvsloginid,   --登记证书编号
      lvscar_sbid,   --车辆识别代号/车架号
      lvscar_fdjid,   --发动机号
      lvscar_name,   -- 机动车所有人
      lvscar_pid,   --身份证明号/代码
      lvstel,   --联系电话
      lvsaddress,   --原通信地址

      lvsnewadr    --新通信地址


    );
   -- 返回值

END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_cgs_txdzbg
    Set
      sdono=lvsdono,   --办理编号
      scarid=lvscarid,   --车牌号码
      scar_type=lvscar_type,   --车辆类型
      sloginid=lvsloginid,   --登记证书编号
      scar_sbid=lvscar_sbid,   --车辆识别代号/车架号
      scar_fdjid=lvscar_fdjid,   --发动机号
      scar_name=lvscar_name,   -- 机动车所有人
      scar_pid=lvscar_pid,   --身份证明号/代码
      stel=lvstel,   --联系电话
      saddress=lvsaddress,   --原通信地址
      snewadr=lvsnewadr    --新通信地址
    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_cgs_txdzbg
    Set
      sdono=lvsdono,   --办理编号
      scarid=lvscarid,   --车牌号码
      scar_type=lvscar_type,   --车辆类型
      sloginid=lvsloginid,   --登记证书编号
      scar_sbid=lvscar_sbid,   --车辆识别代号/车架号
      scar_fdjid=lvscar_fdjid,   --发动机号
      scar_name=lvscar_name,   -- 机动车所有人
      scar_pid=lvscar_pid,   --身份证明号/代码
      stel=lvstel,   --联系电话
      saddress=lvsaddress,   --原通信地址
      snewadr=lvsnewadr    --新通信地址
    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_cgs_txdzbg
    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

