create view V_NEWS as
  select a."NNO",a."NCOLNO",a."STITLE",a."SPICPATH",a."SPICPATH2",a."SCONTENT",a."SPUBMAN",a."NUSERNO",a."SPUBTIME",a."NLOOKCOUNT",a."SFOCUS",b.sysno,b.scolname,b.scoltype,b.spic,b.norder from  t_news a ,t_column b
   where a.ncolno=b.nno
/

