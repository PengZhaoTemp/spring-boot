create procedure          PROC_t_crj_wszzsq_SDONO
(
     lvoldsdono VARCHAR2,  --办理编号
     lvReturn in out varchar2 --新办理编号
)
as
  cursor c is
     select * from tc_webjj.t_crj_wszzsq
     where 1=1
     and sdono=lvoldsdono;   --公民身份号码
  r c%rowtype;

BEGIN
   select TC_WEBJJ.fun_get16code(TC_WEBJJ.SEQ_T_DOBUS_SDONO.Nextval)  into  lvReturn from dual  where 1=1;
   for r in c loop
   INSERT into tc_webjj.t_crj_wszzsq
    (
      sdono,   --办理编号
      sname,   --姓　　名
      spid,   --身  份 证
      stel,   --联系电话
      sadress,   --通信地址
      ssq_type,   --申请类别
      s_qs,   --是否签收  0未签收 1已签收
      s_qs_date,   --签收时间
      sjj_adr,   --寄件地址
      ssj_adr,    --收件地址
      s_txz       --往来港澳台通行证号
    )values(
      lvReturn,   --办理编号
      r.sname,   --姓　　名
      r.spid,   --身  份 证
      r.stel,   --联系电话
      r.sadress,   --通信地址
      r.ssq_type,   --申请类别
      '0',   --是否签收  0未签收 1已签收
      r.s_qs_date,   --签收时间
      r.sjj_adr,   --寄件地址
      r.ssj_adr,    --收件地址
      r.s_txz
    );
    commit;
    end loop;
END;

/

