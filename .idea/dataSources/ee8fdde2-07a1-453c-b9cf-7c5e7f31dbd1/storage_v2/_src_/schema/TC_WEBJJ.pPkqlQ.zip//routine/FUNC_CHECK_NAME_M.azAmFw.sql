create function          func_check_name_m
(
 lv_name        varchar2
)
return varchar2
as
  lvCzrkXm   varchar2(100);
  lvCzrkCwms varchar2(100);
  tmpHz      varchar2(100);
  bm_gb13000 varchar2(8);
  lv_bm      varchar2(8);
  err        varchar2(45);
begin
  lvCzrkXm   := lv_name;
  err        := '';
  lvCzrkCwms := '';
  if lv_name is null then
     return ('');
  end if;
  for i in 0 .. length(lvCzrkXm) - 1 loop
    tmpHz      := substr(lvCzrkXm, i + 1, 1);
    begin
      bm_gb13000 := UTL_RAW.CAST_TO_RAW(convert(tmpHz,'AL16UTF16','UTF8'));
    exception
      when others then
        return  tmpHz;
    end;
    if bm_gb13000<>'00B7' then
      begin
        select bm into lv_bm from tc_webjj.T_TYGFHZB  where bm=bm_gb13000 and zxbz='0' and rownum<2;
      exception
        when no_data_found then
          err:=err||','||tmpHz;
      end;
    end if;
  end loop;
  return(substr(err,2,45));
end;

/

