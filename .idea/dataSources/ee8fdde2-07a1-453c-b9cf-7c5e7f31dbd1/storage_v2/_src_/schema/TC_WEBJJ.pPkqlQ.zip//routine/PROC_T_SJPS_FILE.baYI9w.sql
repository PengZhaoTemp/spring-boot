create PROCEDURE          PROC_t_sjps_file   /*t_getpid*/
(
 lvsdono IN OUT VARCHAR2,  --办理编号
 lvfilename VARCHAR2,  --文件图片名
 lvfiletype VARCHAR2,  --文件类型
 lvfilesize VARCHAR2,  --文件大小
 --lvupfiledate Date,--文件上传时间
 lv_ProcMode  Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
 lvnid varchar(16);
BEGIN

  --begin TRAN
IF lv_ProcMode='PMINSERT' THEN    /*登记*/
  Select TC_WEBJJ.fun_get16code(TC_WEBJJ.seq_sjps_file_nid.nextval) into lvnid from dual;
   INSERT into tc_webjj.t_sjps_file
   (
       nid,
       sdono,   --办理编号
      filename,
      filetype,
     filesize,
     upfiledate
    )values(
     lvnid,
      lvsdono,   --办理编号
     lvfilename||'.jsp',
     lvfiletype,
     lvfilesize,
     sysdate
    );
   -- 返回值
END IF;

 Commit;
END; /*存储过程结束*/

