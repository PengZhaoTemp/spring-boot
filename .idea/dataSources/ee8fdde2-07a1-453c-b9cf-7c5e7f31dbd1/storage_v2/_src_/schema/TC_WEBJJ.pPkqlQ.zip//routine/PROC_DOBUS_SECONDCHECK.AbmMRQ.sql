create procedure          proc_dobus_secondcheck

/

