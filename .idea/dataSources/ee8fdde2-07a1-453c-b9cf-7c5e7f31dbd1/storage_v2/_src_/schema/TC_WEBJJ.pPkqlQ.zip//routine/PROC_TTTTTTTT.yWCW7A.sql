create procedure proc_tttttttt is
  cursor aa is
    select *
      from tc_webjj.t_portal_mailbox b
     where b.remark1 is null
       and b.sid not in ('0000007859', '0000007876', '0000007888',
            '0000007949', '0000008316', '0000008607','0000000284');
  lv_user tc_webjj.t_commoner%rowtype;
  lv_pid  varchar(18);
  lv_city varchar(300);
  lv_cs   varchar(300);
  lv_qx   varchar2(300);
begin

  for a in aa loop
    select *
      into lv_user
      from tc_webjj.t_commoner
     where personid = a.suserid
       and rownum < 2 and pid is not null and personid not in ('6101002000007580','6101002000007861','6101002000008161','6101002000009854','6101002000013070','6101002000019066');
  
    select tc_webjj.fun_uncrypkey(lv_user.pid) into lv_pid from dual;
  
    select name
      into lv_city
      from tc_jcyw.t_region_all
     where region_id = substr(lv_pid, 0, 2) || '0000'
       and rownum < 2;
  
    select replace(name,
                   (select name
                      from tc_jcyw.t_region_all
                     where region_id = substr(lv_pid, 0, 2) || '0000'),
                   '')
      into lv_cs
      from tc_jcyw.t_region_all
     where region_id = substr(lv_pid, 0, 4) || '00'
       and rownum < 2;
    lv_cs := replace(lv_cs, '地区', '市');
  
    select replace(name,
                   (select name
                      from tc_jcyw.t_region_all
                     where region_id = substr(lv_pid, 0, 2) || '0000'),
                   '')
      into lv_qx
      from tc_jcyw.t_region_all
     where region_id = substr(lv_pid, 0, 6)
       and rownum < 2;
       
    update tc_webjj.t_portal_mailbox
       set remark1 = lv_city, remark2 = lv_cs, remark3 = lv_qx 
     where sid = a.sid;
  
    commit;
  
  end loop;

end;
/

