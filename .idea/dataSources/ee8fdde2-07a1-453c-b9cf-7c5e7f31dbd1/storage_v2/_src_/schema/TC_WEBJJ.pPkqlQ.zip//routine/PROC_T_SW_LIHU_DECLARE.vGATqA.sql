create PROCEDURE          PROC_t_sw_lihu_declare   /*t_sw_LIHU_DECLARE*/
(
 lvsdono IN OUT VARCHAR2,  --业务编号
 lvmaster_relation VARCHAR2,  --与户主关系
 lvapp_type VARCHAR2,  --申请类别
 lvapp_why_apply VARCHAR2,  --申报理由
 lvpid VARCHAR2,  --公民身份证
 lvname VARCHAR2,  --姓　　名
 lvchange_reason VARCHAR2,  --变动原因
 lvremovecity VARCHAR2,  --所属省市
 lvremoveaddr VARCHAR2,  --详　　址
 lvapp_name VARCHAR2,  --申请人姓名
 lvapp_pid VARCHAR2,  --申请人身份证
 lvapplyno VARCHAR2,  --派综申请编号
 lvsypcs VARCHAR2,  --原户口所在派出所
 lvhkzxfs VARCHAR2,  --户口注销方式
 lvwtr_name VARCHAR2,  --投靠人姓名
 lvwtr_pid VARCHAR2,  --投靠人身份证
 lvwtr_relation VARCHAR2,  --与落户人关系
 lvwtr_phone VARCHAR2,  --投靠人联系方式
 lvhaozuo VARCHAR2,  --门  牌 号
 lvseat VARCHAR2,  --楼　　座
 lvroom VARCHAR2,  --室
 lvsxzjd_name VARCHAR2,  --乡镇街道
 lvquxcun_name VARCHAR2,  --居(村)委
 lvteamid VARCHAR2,  --组
 lvbuilding_name VARCHAR2,  --小区（楼房）
 lvhu_kind_name VARCHAR2,  --户别：集体户 家庭户
 lvsseat VARCHAR2,  --楼座单位
 lvsroom VARCHAR2,  --室  单 位
 lvaddr varchar2,--立户地址
 lvqu varchar2,--立户区县
 lvtoponym varchar2,--立户所在地
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
   INSERT into tc_webjj.t_sw_lihu_declare
    (
      sdono,   --业务编号
      master_relation,   --与户主关系
      app_type,   --申请类别
      app_why_apply,   --申报理由
      pid,   --公民身份证
      name,   --姓　　名
      change_reason,   --变动原因
      removecity,   --所属省市
      removeaddr,   --详　　址
      app_name,   --申请人姓名
      app_pid,   --申请人身份证
      applyno,   --派综申请编号
      sypcs,   --原户口所在派出所
      hkzxfs,   --户口注销方式
      wtr_name,   --投靠人姓名
      wtr_pid,   --投靠人身份证
      wtr_relation,   --与落户人关系
      wtr_phone,   --投靠人联系方式
      haozuo,   --门  牌 号
      seat,   --楼　　座
      room,   --室
      sxzjd_name,   --乡镇街道
      quxcun_name,   --居(村)委
      teamid,   --组
      building_name,   --小区（楼房）
      hu_kind_name,   --户别：集体户 家庭户
      sseat,   --楼座单位
      sroom,    --室  单 位
      addr,
      qu,
      toponym
    )values(
      lvsdono,   --业务编号
      lvmaster_relation,   --与户主关系
      lvapp_type,   --申请类别
      lvapp_why_apply,   --申报理由
      lvpid,   --公民身份证
      lvname,   --姓　　名
      lvchange_reason,   --变动原因
      lvremovecity,   --所属省市
      lvremoveaddr,   --详　　址
      lvapp_name,   --申请人姓名
      lvapp_pid,   --申请人身份证
      lvapplyno,   --派综申请编号
      lvsypcs,   --原户口所在派出所
      lvhkzxfs,   --户口注销方式
      lvwtr_name,   --投靠人姓名
      lvwtr_pid,   --投靠人身份证
      lvwtr_relation,   --与落户人关系
      lvwtr_phone,   --投靠人联系方式
      lvhaozuo,   --门  牌 号
      lvseat,   --楼　　座
      lvroom,   --室
      lvsxzjd_name,   --乡镇街道
      lvquxcun_name,   --居(村)委
      lvteamid,   --组
      lvbuilding_name,   --小区（楼房）
      lvhu_kind_name,   --户别：集体户 家庭户
      lvsseat,   --楼座单位
      lvsroom,    --室  单 位
      lvaddr,
      lvqu,
      lvtoponym
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_sw_lihu_declare
    Set
      sdono=lvsdono,   --业务编号
      master_relation=lvmaster_relation,   --与户主关系
      app_type=lvapp_type,   --申请类别
      app_why_apply=lvapp_why_apply,   --申报理由
      pid=lvpid,   --公民身份证
      name=lvname,   --姓　　名
      change_reason=lvchange_reason,   --变动原因
      removecity=lvremovecity,   --所属省市
      removeaddr=lvremoveaddr,   --详　　址
      app_name=lvapp_name,   --申请人姓名
      app_pid=lvapp_pid,   --申请人身份证
      applyno=lvapplyno,   --派综申请编号
      sypcs=lvsypcs,   --原户口所在派出所
      hkzxfs=lvhkzxfs,   --户口注销方式
      wtr_name=lvwtr_name,   --投靠人姓名
      wtr_pid=lvwtr_pid,   --投靠人身份证
      wtr_relation=lvwtr_relation,   --与落户人关系
      wtr_phone=lvwtr_phone,   --投靠人联系方式
      haozuo=lvhaozuo,   --门  牌 号
      seat=lvseat,   --楼　　座
      room=lvroom,   --室
      sxzjd_name=lvsxzjd_name,   --乡镇街道
      quxcun_name=lvquxcun_name,   --居(村)委
      teamid=lvteamid,   --组
      building_name=lvbuilding_name,   --小区（楼房）
      hu_kind_name=lvhu_kind_name,   --户别：集体户 家庭户
      sseat=lvsseat,   --楼座单位
      sroom=lvsroom,    --室  单 位
      addr=lvaddr,
      qu=lvqu,
      toponym=lvtoponym
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_sw_lihu_declare
    Set
      sdono=lvsdono,   --业务编号
      master_relation=lvmaster_relation,   --与户主关系
      app_type=lvapp_type,   --申请类别
      app_why_apply=lvapp_why_apply,   --申报理由
      pid=lvpid,   --公民身份证
      name=lvname,   --姓　　名
      change_reason=lvchange_reason,   --变动原因
      removecity=lvremovecity,   --所属省市
      removeaddr=lvremoveaddr,   --详　　址
      app_name=lvapp_name,   --申请人姓名
      app_pid=lvapp_pid,   --申请人身份证
      applyno=lvapplyno,   --派综申请编号
      sypcs=lvsypcs,   --原户口所在派出所
      hkzxfs=lvhkzxfs,   --户口注销方式
      wtr_name=lvwtr_name,   --投靠人姓名
      wtr_pid=lvwtr_pid,   --投靠人身份证
      wtr_relation=lvwtr_relation,   --与落户人关系
      wtr_phone=lvwtr_phone,   --投靠人联系方式
      haozuo=lvhaozuo,   --门  牌 号
      seat=lvseat,   --楼　　座
      room=lvroom,   --室
      sxzjd_name=lvsxzjd_name,   --乡镇街道
      quxcun_name=lvquxcun_name,   --居(村)委
      teamid=lvteamid,   --组
      building_name=lvbuilding_name,   --小区（楼房）
      hu_kind_name=lvhu_kind_name,   --户别：集体户 家庭户
      sseat=lvsseat,   --楼座单位
      sroom=lvsroom,    --室  单 位
      addr=lvaddr,
      qu=lvqu,
      toponym=lvtoponym
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_sw_lihu_declare
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

