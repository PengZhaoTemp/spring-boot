create procedure          Proc_t_getpid_SDONO
(
     lvoldsdono VARCHAR2,  --办理编号
     lvReturn in out varchar2 --新办理编号
)
as
  cursor c is
     select * from tc_webjj.t_getpid
     where 1=1
     and sdono=lvoldsdono ;  --办理编号
      r c%rowtype;

BEGIN
   select TC_WEBJJ.fun_get16code(TC_WEBJJ.SEQ_T_DOBUS_SDONO.Nextval)  into  lvReturn from dual  where 1=1;
   for r in c loop
   INSERT into tc_webjj.t_getpid(
      sdono,   --办理编号
      hu_master_name,   --户主姓名
      hu_master_pid,   --户主身份证
      master_relation,   --与户主的关系
      applied_reason,   --申领原因
      name,   --姓　　名
      pid,   --公民身份证号码
      gender,   --性　　别
      nation,   --民　　族
      dob,   --出生日期
      addr_region_id,   --省  市 县
      address,   --住　　址
      photoid,   --照片图片号
      photourl,  --照片保存路径
      applied_name,   --领证人姓名
      applied_pid,   --领证人身份证号
      issued_unti,   --签发机关
      issued_untino,   --签发机关编号
      send_date,   --签发日期
      stop_date,   --截止日期
      case_kind,   --制证类型
      get_type,   --领证方式
      stel,   --联系电话
      smemo    --备　　注
    )values(
      lvReturn,   --办理编号
      r.hu_master_name,   --户主姓名
      r.hu_master_pid,   --户主身份证
      r.master_relation,   --与户主的关系
      r.applied_reason,   --申领原因
      r.name,   --姓　　名
      r.pid,   --公民身份证号码
      r.gender,   --性　　别
      r.nation,   --民　　族
      r.dob,   --出生日期
      r.addr_region_id,   --省  市 县
      r.address,   --住　　址
      r.photoid,   --照片图片号
      r.photourl,
      r.applied_name,   --领证人姓名
      r.applied_pid,   --领证人身份证号
      r.issued_unti,   --签发机关
      r.issued_untino,   --签发机关编号
      r.send_date,   --签发日期
      r.stop_date,   --截止日期
      r.case_kind,   --制证类型
      r.get_type,   --领证方式
      r.stel,   --联系电话
      r.smemo    --备　　注
    );
    commit;
    end loop;
END;

/

