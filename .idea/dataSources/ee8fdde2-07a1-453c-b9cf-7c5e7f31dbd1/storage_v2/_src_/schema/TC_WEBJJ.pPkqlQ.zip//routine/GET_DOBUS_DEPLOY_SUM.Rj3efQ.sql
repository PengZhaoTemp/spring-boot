create function get_dobus_deploy_sum return varchar2 is
  lvResult varchar2(10);
begin
  select sum(case count(*)
               when 2 then
                1
               else
                1
             end) + 9
    into lvResult
    from tc_webjj.t_bus_deploy
   where sstatus = '开通'
   group by sbusname;
  return lvResult;
end;
/

