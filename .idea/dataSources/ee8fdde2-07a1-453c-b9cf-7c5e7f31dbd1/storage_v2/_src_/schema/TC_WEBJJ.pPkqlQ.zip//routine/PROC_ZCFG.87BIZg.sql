create PROCEDURE          proc_zcfg
(
 lvtid IN  VARCHAR2,
 lvtitle VARCHAR2,
 lvcontent clob,
 lvusername varchar2,
 lvuserno varchar2,
 lvstype varchar2,
lvprocmode varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS

BEGIN
  --begin TRAN
IF lvprocmode='tj' THEN    /*登记*/

 select   tc_webjj.zcfg_tid.nextval into lvtid from dual ;

   INSERT into tc_webjj.t_zcfg_tzgg
    (
      tid,
      title,
      content,
      fbdate,
      usernmae,
      userno,
      stype,
      state
    )values(
      lvtid,
      lvtitle,
      lvcontent,
      sysdate,
      lvusername,
      lvuserno,
      lvstype,
      '0'
    );

END IF;
IF lvprocmode='bj'  THEN  /*更新*/
   UPDATE tc_webjj.t_zcfg_tzgg
    Set
      tid=lvtid,
      title=lvtitle,
      content=lvcontent,
      username=lvusername,
      userno=lvuserno
    Where 1=1
    and tid=lvtid
    ;
END IF;
IF lvprocmode='zx'  THEN  /*注销*/
   UPDATE tc_webjj.t_zcfg_tzgg
    Set
      state='0'
    Where 1=1
    and tid=lvtid   --编　　号
    ;
END IF;
IF lvprocmode='kt' THEN
    UPDATE tc_webjj.t_zcfg_tzgg
    Set
    state='1'
    Where 1=1
    and tid=lvtid   --编　　号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

