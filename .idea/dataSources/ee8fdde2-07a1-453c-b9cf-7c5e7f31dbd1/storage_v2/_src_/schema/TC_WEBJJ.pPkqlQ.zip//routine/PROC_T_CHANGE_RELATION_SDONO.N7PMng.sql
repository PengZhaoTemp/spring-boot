create procedure          PROC_t_change_relation_SDONO
(
     lvoldsdono VARCHAR2,  --办理编号
     lvReturn in out varchar2 --新办理编号
)
as
  cursor c is
     select * from tc_webjj.t_change_relation
     where 1=1
     and sdono=lvoldsdono ;  --办理编号
      r c%rowtype;

BEGIN
   select TC_WEBJJ.fun_get16code(TC_WEBJJ.SEQ_T_DOBUS_SDONO.Nextval)  into  lvReturn from dual  where 1=1;
   for r in c loop
   INSERT into tc_webjj.t_change_relation
    (
      sdono,   --办理编号
      pid,   --身份证号码(申报人)
      name,   --姓名(申报人)
      pid_1,   --对象身份证1
      name_1,   --对象姓名1
      pid_2,   --对象身份证2
      name_2,   --对象姓名2
      pid_3,   --对象身份证3
      name_3,   --对象姓名3
      relation_1,   --调整后关系1
      relation_2,   --调整后关系2
      relation_3,    --调整后关系3
      old_relation --原来与户主关系
    )values(
     lvReturn,   --业务编号
      r.pid,   --身份证号码(申报人)
      r.name,   --姓名(申报人)
      r.pid_1,   --对象身份证1
      r.name_1,   --对象姓名1
      r.pid_2,   --对象身份证2
      r.name_2,   --对象姓名2
      r.pid_3,   --对象身份证3
      r.name_3,   --对象姓名3
      r.relation_1,   --调整后关系1
      r.relation_2,   --调整后关系2
      r.relation_3,    --调整后关系3
      r.old_relation
    );
   -- 返回值

    commit;
    end loop;
END;

/

