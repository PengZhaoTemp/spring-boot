create procedure proc_dobus_nextflow(
       lvsdono varchar2
) is
lvdobus tc_webjj.v_dobus%rowtype;
lvbusflow tc_webjj.t_busflow_deploy%rowtype;
lvsplanno varchar2(16);
begin
   select  * into lvdobus from tc_webjj.v_dobus where sdono = lvsdono;
   if lvdobus.splanno is null then  --流程接入
      select * into lvbusflow from tc_webjj.t_busflow_deploy a where sbusno=lvdobus.sbusno and a.sflowtaxis=2 and a.sflowstatus='1';--直接提交 从第二步开始
      select tc_webjj.fun_get16code(tc_webjj.seq_busflow_splanno.nextval) into lvsplanno from dual;
      insert into tc_webjj.t_busflow_plan(
             splanno,sflowno,sdono,nstepnum
      )values(
             lvsplanno,
             lvbusflow.sflowno,
             lvsdono,
             1
      );
      update tc_webjj.t_dobus b set b.state=lvbusflow.sbusstatuscode,b.splanno=lvsplanno,b.soperationsno=lvbusflow.soperationno where sdono=lvsdono;
   else
      select * into lvbusflow from tc_webjj.t_busflow_deploy a where sbusno=lvdobus.sbusno and a.sflowtaxis=lvdobus.snexttaxis and a.sflowstatus='1';

      while lvbusflow.sflowtype = '2' loop
         proc_dobus_selectnextflow(lvbusflow,lvdobus); --如果当前流程未选择流程时，对选择值进行判断
      end loop;

      select tc_webjj.fun_get16code(tc_webjj.seq_busflow_splanno.nextval) into lvsplanno from dual;
      insert into tc_webjj.t_busflow_plan(
             splanno,sflowno,sdono,nstepnum
      )values(
             lvsplanno,
             lvbusflow.sflowno,
             lvsdono,
             lvdobus.nstepnum+1
      );
      update tc_webjj.t_busflow_plan a set a.scomplete='1',a.dendtime=sysdate,dbbj='0' where splanno = lvdobus.splanno;
      update tc_webjj.t_dobus b set b.state=lvbusflow.sbusstatuscode,b.splanno=lvsplanno,b.soperationsno=lvbusflow.soperationno,dbbj='0' where sdono=lvsdono;

   end if;
   if lvbusflow.sflowno is not null then
      proc_dobus_sendmsg(
         lvbusflow.sbusno,
         lvbusflow.sflowno,
         lvdobus.sdounitno
      );
   end if;
   commit;
end proc_dobus_nextflow;

/

