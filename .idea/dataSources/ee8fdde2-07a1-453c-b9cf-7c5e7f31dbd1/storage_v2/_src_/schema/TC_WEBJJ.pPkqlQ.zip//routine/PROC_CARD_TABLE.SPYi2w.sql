create PROCEDURE          proc_card_table   /*proc_card_table*/
(
    lvnid   IN OUT  VARCHAR2,  --id
    lvpid    VARCHAR2,  --身份证号
    lvname  VARCHAR2, --姓名
    lvzj_type  VARCHAR2, --证件类型
    lvqf_date date, --签发日期
    lvqf_address  VARCHAR2, --签发地址
    lvqf_yxqx  date, --签发期限
    lvzjhm  VARCHAR2, --证件号码
    lvzz_address VARCHAR2, --住址
    lvcar_type VARCHAR2, --车型
    lvdabh  VARCHAR2, --档案编号
    lvcar_no VARCHAR2, --车牌号
    lvcar_dh VARCHAR2, --车辆代号
    lvcar_fdjh VARCHAR2,--发动机号
    lvsuserno VARCHAR2, --登记人编码
    lvfs_flag  VARCHAR2 ,--是否已提醒
    lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS

BEGIN
  --begin TRAN

IF lv_procMode='PMINSERT' THEN    /*登记*/



   INSERT into tc_webjj.t_card_table
    (
      nid      ,  --id
      pid      ,  --身份证号
      name     , --姓名
      zj_type  , --证件类型
      qf_date  , --签发日期
      qf_address  , --签发地址
      qf_yxqx  , --签发期限
      zjhm     ,   --证件号码
      zz_address , --住址
      car_type , --车型
      dabh     , --档案编号
      car_no   , --车牌号
      car_dh   , --车辆代号
      car_fdjh ,--发动机号
      suserno  , --登记人编码
      dj_date  ,--登记时期
      fs_flag   --是否已提醒
    )values(
      tc_webjj.seq_card_table.nextval,  --id
      lvpid    ,  --身份证号
      lvname , --姓名
      lvzj_type  , --证件类型
      lvqf_date , --签发日期
      lvqf_address  , --签发地址
      lvqf_yxqx  , --签发期限
      lvzjhm  , --证件号码
      lvzz_address , --住址
      lvcar_type , --车型
      lvdabh  , --档案编号
      lvcar_no , --车牌号
      lvcar_dh , --车辆代号
      lvcar_fdjh ,--发动机号
      lvsuserno , --登记人编码
      SYSDATE ,--登记时期
      lvfs_flag   --是否已提醒

    );
   -- 返回值

END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_card_table
    Set
      nid    =lvnid  ,  --id
      pid    = lvpid ,  --身份证号
      name   = lvname , --姓名
      zj_type = lvzj_type , --证件类型
      qf_date = lvqf_date , --签发日期
      qf_address=lvqf_address  , --签发地址
      qf_yxqx = lvqf_yxqx , --签发期限
      zjhm    =lvzjhm ,   --证件号码
      zz_address = lvzz_address, --住址
      car_type = lvcar_type, --车型
      dabh    = lvdabh , --档案编号
      car_no  = lvcar_no , --车牌号
      car_dh  = lvcar_dh , --车辆代号
      car_fdjh = lvcar_fdjh,--发动机号
      suserno = lvsuserno , --登记人编码
      dj_date = SYSDATE ,--登记时期
      fs_flag = lvfs_flag  --是否已提醒
      WHERE 1=1 AND nid=lvnid;

END IF;

IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_card_table
    Where 1=1
    and nid=lvnid;

END IF;
 Commit;
END; /*存储过程结束*/

