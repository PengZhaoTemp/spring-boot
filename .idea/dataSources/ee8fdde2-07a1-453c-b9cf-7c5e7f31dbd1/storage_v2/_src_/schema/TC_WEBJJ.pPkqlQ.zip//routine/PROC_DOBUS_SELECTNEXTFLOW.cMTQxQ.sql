create procedure proc_dobus_selectnextflow(
       lvbusflow in out tc_webjj.t_busflow_deploy%rowtype,
       lvdobus tc_webjj.v_dobus%rowtype
) is
cursor aa(lvsflowno varchar2) is select * from tc_webjj.t_judge_deploy where sflowno=lvsflowno and sjudgestatus='1';
lvcheckvalue varchar2(200);
lvsql_stm varchar2(2000);
lvnextstep number;
begin
    if lvbusflow.sjudgetable = '业务事务表' then
       lvsql_stm := 'select '||lvbusflow.sjudgefield||' from tc_webjj.t_dobus where sdono='''||lvdobus.sdono||'''';
    elsif lvbusflow.sjudgetable = '业务配置表' then
       lvsql_stm := 'select '||lvbusflow.sjudgefield||' from tc_webjj.t_bus_deploy where sdono='''||lvdobus.sbusno||'''';
    elsif lvbusflow.sjudgetable = '业务数据表' then
       lvsql_stm := 'select '||lvbusflow.sjudgefield||' from '||lvdobus.stablename||' where sdono='''||lvdobus.sdono||'''';
    elsif lvbusflow.sjudgetable = '业务操作表' then
       lvsql_stm := 'select '||lvbusflow.sjudgefield||' from (select * from tc_webjj.v_dobus_log where sdono='''||lvdobus.sdono||''' order by nstepnum desc) where rownum<2';
       --lvsql_stm := 'select '||lvbusflow.sjudgefield||' from  tc_webjj.t_dobus_log  where sdono='''||lvdobus.sbusno||'''';
    end if;
    if lvsql_stm is not null then
       --insert into tc_webjj.t_test values(lvsql_stm);
       begin
       execute immediate lvsql_stm into lvcheckvalue;
       exception
       when others then
           RAISE_APPLICATION_ERROR(-20998,'cnot found data!sql:'||lvsql_stm);
       end;
       for a in aa(lvbusflow.sflowno) loop
           if a.sroperator = '等于' then
              if a.sjudgevalue = lvcheckvalue then
                 lvnextstep := a.snexttaxis;
                 exit;
              end if;
           elsif a.sroperator = '大于' then
              if lvcheckvalue > a.sjudgevalue  then
                 lvnextstep := a.snexttaxis;
                 exit;
              end if;
           elsif a.sroperator = '小于' then
              if lvcheckvalue < a.sjudgevalue  then
                 lvnextstep := a.snexttaxis;
                 exit;
              end if;
           elsif a.sroperator = '大于等于' then
              if lvcheckvalue >= a.sjudgevalue  then
                 lvnextstep := a.snexttaxis;
                 exit;
              end if;
           elsif a.sroperator = '小于等于' then
              if lvcheckvalue <= a.sjudgevalue  then
                 lvnextstep := a.snexttaxis;
                 exit;
              end if;
           elsif a.sroperator = '不等于' then
              if lvcheckvalue <> a.sjudgevalue  then
                 lvnextstep := a.snexttaxis;
                 exit;
              end if;
           else
              RAISE_APPLICATION_ERROR(-20998,'cnot compare data!sql:'||a.sjudgevalue||'::'||lvcheckvalue);
           end if;
       end loop;
       if lvnextstep is not null then
          select * into lvbusflow from tc_webjj.t_busflow_deploy a where sbusno=lvdobus.sbusno and a.sflowtaxis=lvnextstep and a.sflowstatus='1';
       else
          RAISE_APPLICATION_ERROR(-20998,'cnot found next flow!sql:'||lvsql_stm);
       end if;
    else
       RAISE_APPLICATION_ERROR(-20998,'cnot create lvsql_stm!');
    end if;
end proc_dobus_selectnextflow;

/

