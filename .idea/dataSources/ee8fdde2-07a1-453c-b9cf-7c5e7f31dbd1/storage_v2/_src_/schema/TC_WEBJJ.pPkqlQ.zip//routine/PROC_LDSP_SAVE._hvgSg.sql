create procedure proc_ldsp_save(
          lv_sid             varchar2,  
          lv_sleaderreport   varchar2,  --批示内容
          lv_ispublic        varchar2,  --是否公开
          lv_ishot           varchar2,  --是否热点
          lv_sreply          varchar2,  --回复内容
          lv_stype           varchar2,  --操作类型
          lv_flag            varchar2,  --审批是否修改回复内容
          lv_zchfnr          varchar2,  --留存原因
          lv_dxtz            varchar2   --是否短信通知
       )
        is
        lv_dcreatedate       varchar(50);
        lv_sorgname          varchar(50);
        lv_photo             varchar(50);
        lv_nid               varchar(16);
        lv_sno               number;
begin
  if lv_stype='1' then
      update tc_webjj.t_portal_mailbox 
        set dbbj='0',sstate='4',
        spdate=sysdate,
        sleaderreport=lv_sleaderreport,
        ishot=lv_ishot,
        sisdone='1',ispublic=lv_ispublic,
        sreply=lv_sreply
      where sid=lv_sid;
       if '1'=lv_dxtz then
         select a.sphone,to_char(dcreatedate,'yyyy')||'年'||to_char(dcreatedate,'mm')||'月'||to_char(dcreatedate,'dd')||'日',a.sregion_name into lv_photo,lv_dcreatedate,lv_sorgname from tc_webjj.t_portal_mailbox a where a.sid=lv_sid;
          if  lv_photo is not null then
            tc_webjj.PROC_t_notetask(
               lv_nid,
               '您好，您于'||lv_dcreatedate||'的留言'||lv_sorgname||'已答复，请登陆陕西“互联网＋公安政务服务”平台或陕西公安微信公众号查看。',
               lv_photo,
               '1',
               'PMINSERT'
            ); 
           end if;
        end if; 
  elsif lv_stype='2' then
        update tc_webjj.t_portal_mailbox 
        set dbbj='0',sstate='3',
        spdate=sysdate,
        sleaderreport=lv_sleaderreport 
        where sid=lv_sid;
  elsif lv_stype='3' then
       update tc_webjj.t_portal_mailbox
        set issave='1',sisdone='1',
        zchfnr=lv_zchfnr,
        REMARK8=sysdate,dbbj='0'
         where sid=lv_sid;
  end if;
  if lv_flag='1' then
     select tc_webjj.seq_portal_mailbox_reply_sno.nextval into lv_sno  from dual;
     if mod(lv_sno,2)=0 then
        lv_sno:=lv_sno-1;
     end if;
     insert into tc_webjj.t_portal_mailbox_reply(
            sno,
            sid,
            username,
            replydate,
            replymsg,
            zxbz,
            dbbj
     )values(
            lv_sno,
            lv_sid,
            'admin',
            sysdate,
            lv_sreply,
            '0',
            '0'
     );
  end if;
  commit;
end;
/

