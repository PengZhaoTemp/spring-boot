create Procedure proc_del_childrentable
(
     lvsdono varchar2
)
as
  deleted       varchar2(1):= 1;
  childrentable varchar2(50);
begin
  if lvsdono is not null then
     --find children table name 
     select stablename into childrentable from tc_webjj.t_dobus a, tc_webjj.t_bus_deploy b 
     where a.sbusno = b.sbusno and a.sdono :=lvsdono;
     --delete children table data by sdono
     --delete from childrentable where sdono :=lvsdono;
     
     return(deleted);
  end if;
end;
/

