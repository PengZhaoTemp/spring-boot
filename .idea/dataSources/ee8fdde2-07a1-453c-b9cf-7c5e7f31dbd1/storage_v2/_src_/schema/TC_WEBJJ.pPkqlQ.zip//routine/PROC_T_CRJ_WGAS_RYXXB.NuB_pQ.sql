create PROCEDURE          PROC_t_crj_wgas_ryxxb   /*T_CRJ_WGAS_RYXXB*/
(
 lvsdono  VARCHAR2,  --业务编号
 lvsryxxb_seqno IN OUT VARCHAR2,  --序  列 号
 lvsname VARCHAR2,  --姓　　名
 lvssex VARCHAR2,  --性　　别
 lvsfzhm VARCHAR2,  --身份证号码
 lvszw VARCHAR2,  --职　　务
 lvsrzsj DATE,  --任职时间
 lvshkszd VARCHAR2,  --户口所在地
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
   INSERT into tc_webjj.t_crj_wgas_ryxxb
    (
      sdono,   --业务编号
      sryxxb_seqno,   --序  列 号
      sname,   --姓　　名
      ssex,   --性　　别
      sfzhm,   --身份证号码
      szw,   --职　　务
      srzsj,   --任职时间
      shkszd    --户口所在地
    )values(
      lvsdono,   --业务编号
      lvsryxxb_seqno,   --序  列 号
      lvsname,   --姓　　名
      lvssex,   --性　　别
      lvsfzhm,   --身份证号码
      lvszw,   --职　　务
      lvsrzsj,   --任职时间
      lvshkszd    --户口所在地
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_crj_wgas_ryxxb
    Set
      sdono=lvsdono,   --业务编号
      sryxxb_seqno=lvsryxxb_seqno,   --序  列 号
      sname=lvsname,   --姓　　名
      ssex=lvssex,   --性　　别
      sfzhm=lvsfzhm,   --身份证号码
      szw=lvszw,   --职　　务
      srzsj=lvsrzsj,   --任职时间
      shkszd=lvshkszd    --户口所在地
    Where 1=1
    and sryxxb_seqno=lvsryxxb_seqno   --序  列 号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_crj_wgas_ryxxb
    Set
      sdono=lvsdono,   --业务编号
      sryxxb_seqno=lvsryxxb_seqno,   --序  列 号
      sname=lvsname,   --姓　　名
      ssex=lvssex,   --性　　别
      sfzhm=lvsfzhm,   --身份证号码
      szw=lvszw,   --职　　务
      srzsj=lvsrzsj,   --任职时间
      shkszd=lvshkszd    --户口所在地
    Where 1=1
    and sryxxb_seqno=lvsryxxb_seqno   --序  列 号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_crj_wgas_ryxxb
    Where 1=1
    and sryxxb_seqno=lvsryxxb_seqno   --序  列 号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

