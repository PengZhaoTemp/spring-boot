create PROCEDURE          PROC_t_gwcq_sp   /*T_GWCQ_SP*/
(
 lvsdono IN OUT VARCHAR2,  --业务编号
 lvname VARCHAR2,  --姓　　名
 lvsex VARCHAR2,  --性　　别
 lvbirth DATE,  --出生日期
 lvxzqh VARCHAR2,  --所在单位行政区划
 lvssxt VARCHAR2,  --所在单位所属系统
 lvunit_name VARCHAR2,  --所在单位
 lvunit_bm VARCHAR2,  --部　　门
 lvunit_zw VARCHAR2,  --职　　务
 lvpid VARCHAR2,  --身份证号
 lvnation VARCHAR2,  --民　　族
 lvzzmm VARCHAR2,  --政治面貌
 lvwhcd VARCHAR2,  --文化程度
 lvaddr VARCHAR2,  --住　　址
 lvhk_addr VARCHAR2,  --户口所在地
 lvqz_intr VARCHAR2,  --使用枪支情况
 lvpq_unit_bmyj VARCHAR2,  --配枪单位政治（人事）部门审查意见
 lvpq_unit_fzryj VARCHAR2,  --配枪单位负责人意见
 lvscore_lilun VARCHAR2,  --理论考核
 lvscore_sdsj VARCHAR2,  --实弹射击
 lvscore_qlcz VARCHAR2,  --勤劳操作
 lvscore_date DATE,  --考核时间
 lvxj_sc_unit VARCHAR2,  --县级审查单位
 lvxj_sc_person VARCHAR2,  --县级审查人
 lvsj_sc_unit VARCHAR2,  --市级审查单位
 lvsj_sc_person VARCHAR2,  --市级审查人
 lvcqz_id VARCHAR2,  --持枪证号
 lvfz_time DATE,  --发证时间
 lvyxqx VARCHAR2,  --有效期限
 lvtb_unit VARCHAR2,  --填表单位
 lvtb_person VARCHAR2,  --填  表 人
 lvtb_date DATE,  --填表时间
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
   INSERT into tc_webjj.t_gwcq_sp
    (
      sdono,   --业务编号
      name,   --姓　　名
      sex,   --性　　别
      birth,   --出生日期
      xzqh,   --所在单位行政区划
      ssxt,   --所在单位所属系统
      unit_name,   --所在单位
      unit_bm,   --部　　门
      unit_zw,   --职　　务
      pid,   --身份证号
      nation,   --民　　族
      zzmm,   --政治面貌
      whcd,   --文化程度
      addr,   --住　　址
      hk_addr,   --户口所在地
      qz_intr,   --使用枪支情况
      pq_unit_bmyj,   --配枪单位政治（人事）部门审查意见
      pq_unit_fzryj,   --配枪单位负责人意见
      score_lilun,   --理论考核
      score_sdsj,   --实弹射击
      score_qlcz,   --勤劳操作
      score_date,   --考核时间
      xj_sc_unit,   --县级审查单位
      xj_sc_person,   --县级审查人
      sj_sc_unit,   --市级审查单位
      sj_sc_person,   --市级审查人
      cqz_id,   --持枪证号
      fz_time,   --发证时间
      yxqx,   --有效期限
      tb_unit,   --填表单位
      tb_person,   --填  表 人
      tb_date    --填表时间
    )values(
      lvsdono,   --业务编号
      lvname,   --姓　　名
      lvsex,   --性　　别
      lvbirth,   --出生日期
      lvxzqh,   --所在单位行政区划
      lvssxt,   --所在单位所属系统
      lvunit_name,   --所在单位
      lvunit_bm,   --部　　门
      lvunit_zw,   --职　　务
      lvpid,   --身份证号
      lvnation,   --民　　族
      lvzzmm,   --政治面貌
      lvwhcd,   --文化程度
      lvaddr,   --住　　址
      lvhk_addr,   --户口所在地
      lvqz_intr,   --使用枪支情况
      lvpq_unit_bmyj,   --配枪单位政治（人事）部门审查意见
      lvpq_unit_fzryj,   --配枪单位负责人意见
      lvscore_lilun,   --理论考核
      lvscore_sdsj,   --实弹射击
      lvscore_qlcz,   --勤劳操作
      lvscore_date,   --考核时间
      lvxj_sc_unit,   --县级审查单位
      lvxj_sc_person,   --县级审查人
      lvsj_sc_unit,   --市级审查单位
      lvsj_sc_person,   --市级审查人
      lvcqz_id,   --持枪证号
      lvfz_time,   --发证时间
      lvyxqx,   --有效期限
      lvtb_unit,   --填表单位
      lvtb_person,   --填  表 人
      lvtb_date    --填表时间
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_gwcq_sp
    Set
      sdono=lvsdono,   --业务编号
      name=lvname,   --姓　　名
      sex=lvsex,   --性　　别
      birth=lvbirth,   --出生日期
      xzqh=lvxzqh,   --所在单位行政区划
      ssxt=lvssxt,   --所在单位所属系统
      unit_name=lvunit_name,   --所在单位
      unit_bm=lvunit_bm,   --部　　门
      unit_zw=lvunit_zw,   --职　　务
      pid=lvpid,   --身份证号
      nation=lvnation,   --民　　族
      zzmm=lvzzmm,   --政治面貌
      whcd=lvwhcd,   --文化程度
      addr=lvaddr,   --住　　址
      hk_addr=lvhk_addr,   --户口所在地
      qz_intr=lvqz_intr,   --使用枪支情况
      pq_unit_bmyj=lvpq_unit_bmyj,   --配枪单位政治（人事）部门审查意见
      pq_unit_fzryj=lvpq_unit_fzryj,   --配枪单位负责人意见
      score_lilun=lvscore_lilun,   --理论考核
      score_sdsj=lvscore_sdsj,   --实弹射击
      score_qlcz=lvscore_qlcz,   --勤劳操作
      score_date=lvscore_date,   --考核时间
      xj_sc_unit=lvxj_sc_unit,   --县级审查单位
      xj_sc_person=lvxj_sc_person,   --县级审查人
      sj_sc_unit=lvsj_sc_unit,   --市级审查单位
      sj_sc_person=lvsj_sc_person,   --市级审查人
      cqz_id=lvcqz_id,   --持枪证号
      fz_time=lvfz_time,   --发证时间
      yxqx=lvyxqx,   --有效期限
      tb_unit=lvtb_unit,   --填表单位
      tb_person=lvtb_person,   --填  表 人
      tb_date=lvtb_date    --填表时间
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_gwcq_sp
    Set
      sdono=lvsdono,   --业务编号
      name=lvname,   --姓　　名
      sex=lvsex,   --性　　别
      birth=lvbirth,   --出生日期
      xzqh=lvxzqh,   --所在单位行政区划
      ssxt=lvssxt,   --所在单位所属系统
      unit_name=lvunit_name,   --所在单位
      unit_bm=lvunit_bm,   --部　　门
      unit_zw=lvunit_zw,   --职　　务
      pid=lvpid,   --身份证号
      nation=lvnation,   --民　　族
      zzmm=lvzzmm,   --政治面貌
      whcd=lvwhcd,   --文化程度
      addr=lvaddr,   --住　　址
      hk_addr=lvhk_addr,   --户口所在地
      qz_intr=lvqz_intr,   --使用枪支情况
      pq_unit_bmyj=lvpq_unit_bmyj,   --配枪单位政治（人事）部门审查意见
      pq_unit_fzryj=lvpq_unit_fzryj,   --配枪单位负责人意见
      score_lilun=lvscore_lilun,   --理论考核
      score_sdsj=lvscore_sdsj,   --实弹射击
      score_qlcz=lvscore_qlcz,   --勤劳操作
      score_date=lvscore_date,   --考核时间
      xj_sc_unit=lvxj_sc_unit,   --县级审查单位
      xj_sc_person=lvxj_sc_person,   --县级审查人
      sj_sc_unit=lvsj_sc_unit,   --市级审查单位
      sj_sc_person=lvsj_sc_person,   --市级审查人
      cqz_id=lvcqz_id,   --持枪证号
      fz_time=lvfz_time,   --发证时间
      yxqx=lvyxqx,   --有效期限
      tb_unit=lvtb_unit,   --填表单位
      tb_person=lvtb_person,   --填  表 人
      tb_date=lvtb_date    --填表时间
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_gwcq_sp
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

