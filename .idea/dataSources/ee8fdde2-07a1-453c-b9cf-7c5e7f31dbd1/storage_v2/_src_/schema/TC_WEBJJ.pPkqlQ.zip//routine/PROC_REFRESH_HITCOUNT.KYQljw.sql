create procedure          proc_refresh_hitcount
 is
begin
  update tc_webjj.t_webindex_hitcount set ntoday_hitcount = 0;
  commit;
end proc_refresh_hitcount;

/

