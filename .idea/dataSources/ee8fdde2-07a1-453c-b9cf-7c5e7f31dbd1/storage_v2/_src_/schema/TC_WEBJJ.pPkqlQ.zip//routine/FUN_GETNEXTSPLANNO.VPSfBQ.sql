create function          fun_getNextSplanno(
       lvsplanno varchar2
) return varchar2 is
lvnextsplanno varchar2(16);
begin
  select tc_webjj.fun_get16code(tc_webjj.seq_busflow_splanno.nextval) into lvnextsplanno from dual;
  if lvsplanno is null then


  else
     null;
  end if;

  return(lvnextsplanno);
end fun_getNextSplanno;

/

