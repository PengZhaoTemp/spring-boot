create view V_HD_WJ_QUESTION as
  select a."OID",
       a."CONTENT",
       a."QTYPE",
       a."SEQ",
       a."REMARK",
       a."DBBJ",
       a."DBSJ",
       a."QUESTIONID"
  from TC_WEBJJ.T_HD_WJ_QUESTION a, TC_WEBJJ.t_Hd_Wj_Object b
 where a.oid = b.oid
   and b.state > 0
/

