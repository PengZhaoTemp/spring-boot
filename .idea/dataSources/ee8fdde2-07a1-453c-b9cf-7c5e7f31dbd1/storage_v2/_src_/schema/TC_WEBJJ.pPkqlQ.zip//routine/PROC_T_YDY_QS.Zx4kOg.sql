create PROCEDURE          PROC_T_YDY_QS   /*T_CRJ_WSZZSQ*/
(
 lvsdono IN OUT VARCHAR2,  --办理编号
 lvs_qs varchar2,
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS

BEGIN
  --begin TRAN

IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_crj_wszzsq
    Set
      s_qs='1',
      s_qs_date=sysdate
    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
    UPDATE tc_webjj.t_dobus
    Set
      state='43'
    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
END IF;

 Commit;
END; /*存储过程结束*/

