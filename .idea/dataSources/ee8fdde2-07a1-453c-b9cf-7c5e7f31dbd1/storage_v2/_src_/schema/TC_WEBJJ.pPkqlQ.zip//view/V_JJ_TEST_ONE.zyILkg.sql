create view V_JJ_TEST_ONE as
  select a.SDONO,
       SNAME,
       SPID,
       sTYPE,
       SKEY,
       SRESULT,
       b.sbusno,
       b.sdodata,
       b.state,
       b.soperationsno,
       b.splanno,
       b.ssecondcheck,
       a.jhid
  from tc_webjj.T_JJ_TEST_ONE a,
  tc_webjj.t_dobus b
  where a.sdono = b.sdono
/

