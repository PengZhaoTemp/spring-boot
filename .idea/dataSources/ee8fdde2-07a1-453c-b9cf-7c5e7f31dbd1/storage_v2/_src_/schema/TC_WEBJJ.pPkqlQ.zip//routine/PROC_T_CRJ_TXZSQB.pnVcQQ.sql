create PROCEDURE          PROC_t_crj_txzsqb   /*T_CRJ_TXZSQB*/
(
 lvsdono IN OUT VARCHAR2,  --业务编号
 lvsxing VARCHAR2,  --姓
 lvsming VARCHAR2,  --名
 lvssex VARCHAR2,  --性　　别
 lvscsrq DATE,  --出生日期
 lvspyxing VARCHAR2,  --拼  音 姓
 lvspym VARCHAR2,  --拼  音 名
 lvsmz VARCHAR2,  --民　　族
 lvscsd VARCHAR2,  --出  生 地
 lvszzd VARCHAR2,  --暂  住 地
 lvslxdh VARCHAR2,  --联系电话
 lvssfzhm VARCHAR2,  --身份证号码
 lvsrjdd VARCHAR2,  --入境地点
 lvsrjsj DATE,  --入境时间
 lvsrjhmdd VARCHAR2,  --入境后目的地
 lvsscyzzmc VARCHAR2,  --所持原证照名称
 lvsscyzzhm VARCHAR2,  --所持原证照号码
 lvsqfjg VARCHAR2,  --签发机关
 lvsyxqz DATE,  --有效期至
 lvsname1 VARCHAR2,  --姓  名 1
 lvssex1 VARCHAR2,  --性  别 1
 lvsnl1 VARCHAR2,  --年  龄 1
 lvsybrgx1 VARCHAR2,  --与本人关系1
 lvszy1 VARCHAR2,  --职  业 1
 lvsjtzz1 VARCHAR2,  --现住住址1
 lvsname2 VARCHAR2,  --姓  名 2
 lvssex2 VARCHAR2,  --性  别 2
 lvsnl2 VARCHAR2,  --年  龄 2
 lvsybrgx2 VARCHAR2,  --与本人关系2
 lvszy2 VARCHAR2,  --职  业 2
 lvsjtzz2 VARCHAR2,  --现住住址2
 lvsname3 VARCHAR2,  --姓  名 3
 lvssex3 VARCHAR2,  --性  别 3
 lvsnl3 VARCHAR2,  --年  龄 3
 lvsybrgx3 VARCHAR2,  --与本人关系3
 lvszy3 VARCHAR2,  --职  业 3
 lvsjtzz3 VARCHAR2,  --现住住址3
 lvsname4 VARCHAR2,  --姓  名 4
 lvssex4 VARCHAR2,  --性  别 4
 lvsnl4 VARCHAR2,  --年  龄 4
 lvsybrgx4 VARCHAR2,  --与本人关系4
 lvszy4 VARCHAR2,  --职  业 4
 lvsjtzz4 VARCHAR2,  --现住住址4
 lvssqlx VARCHAR2,  --ssqlx
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
   INSERT into tc_webjj.t_crj_txzsqb
    (
      sdono,   --业务编号
      sxing,   --姓
      sming,   --名
      ssex,   --性　　别
      scsrq,   --出生日期
      spyxing,   --拼  音 姓
      spym,   --拼  音 名
      smz,   --民　　族
      scsd,   --出  生 地
      szzd,   --暂  住 地
      slxdh,   --联系电话
      ssfzhm,   --身份证号码
      srjdd,   --入境地点
      srjsj,   --入境时间
      srjhmdd,   --入境后目的地
      sscyzzmc,   --所持原证照名称
      sscyzzhm,   --所持原证照号码
      sqfjg,   --签发机关
      syxqz,   --有效期至
      sname1,   --姓  名 1
      ssex1,   --性  别 1
      snl1,   --年  龄 1
      sybrgx1,   --与本人关系1
      szy1,   --职  业 1
      sjtzz1,   --现住住址1
      sname2,   --姓  名 2
      ssex2,   --性  别 2
      snl2,   --年  龄 2
      sybrgx2,   --与本人关系2
      szy2,   --职  业 2
      sjtzz2,   --现住住址2
      sname3,   --姓  名 3
      ssex3,   --性  别 3
      snl3,   --年  龄 3
      sybrgx3,   --与本人关系3
      szy3,   --职  业 3
      sjtzz3,   --现住住址3
      sname4,   --姓  名 4
      ssex4,   --性  别 4
      snl4,   --年  龄 4
      sybrgx4,   --与本人关系4
      szy4,   --职  业 4
      sjtzz4,   --现住住址4
      ssqlx    --ssqlx
    )values(
      lvsdono,   --业务编号
      lvsxing,   --姓
      lvsming,   --名
      lvssex,   --性　　别
      lvscsrq,   --出生日期
      lvspyxing,   --拼  音 姓
      lvspym,   --拼  音 名
      lvsmz,   --民　　族
      lvscsd,   --出  生 地
      lvszzd,   --暂  住 地
      lvslxdh,   --联系电话
      lvssfzhm,   --身份证号码
      lvsrjdd,   --入境地点
      lvsrjsj,   --入境时间
      lvsrjhmdd,   --入境后目的地
      lvsscyzzmc,   --所持原证照名称
      lvsscyzzhm,   --所持原证照号码
      lvsqfjg,   --签发机关
      lvsyxqz,   --有效期至
      lvsname1,   --姓  名 1
      lvssex1,   --性  别 1
      lvsnl1,   --年  龄 1
      lvsybrgx1,   --与本人关系1
      lvszy1,   --职  业 1
      lvsjtzz1,   --现住住址1
      lvsname2,   --姓  名 2
      lvssex2,   --性  别 2
      lvsnl2,   --年  龄 2
      lvsybrgx2,   --与本人关系2
      lvszy2,   --职  业 2
      lvsjtzz2,   --现住住址2
      lvsname3,   --姓  名 3
      lvssex3,   --性  别 3
      lvsnl3,   --年  龄 3
      lvsybrgx3,   --与本人关系3
      lvszy3,   --职  业 3
      lvsjtzz3,   --现住住址3
      lvsname4,   --姓  名 4
      lvssex4,   --性  别 4
      lvsnl4,   --年  龄 4
      lvsybrgx4,   --与本人关系4
      lvszy4,   --职  业 4
      lvsjtzz4,   --现住住址4
      lvssqlx    --ssqlx
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_crj_txzsqb
    Set
      sdono=lvsdono,   --业务编号
      sxing=lvsxing,   --姓
      sming=lvsming,   --名
      ssex=lvssex,   --性　　别
      scsrq=lvscsrq,   --出生日期
      spyxing=lvspyxing,   --拼  音 姓
      spym=lvspym,   --拼  音 名
      smz=lvsmz,   --民　　族
      scsd=lvscsd,   --出  生 地
      szzd=lvszzd,   --暂  住 地
      slxdh=lvslxdh,   --联系电话
      ssfzhm=lvssfzhm,   --身份证号码
      srjdd=lvsrjdd,   --入境地点
      srjsj=lvsrjsj,   --入境时间
      srjhmdd=lvsrjhmdd,   --入境后目的地
      sscyzzmc=lvsscyzzmc,   --所持原证照名称
      sscyzzhm=lvsscyzzhm,   --所持原证照号码
      sqfjg=lvsqfjg,   --签发机关
      syxqz=lvsyxqz,   --有效期至
      sname1=lvsname1,   --姓  名 1
      ssex1=lvssex1,   --性  别 1
      snl1=lvsnl1,   --年  龄 1
      sybrgx1=lvsybrgx1,   --与本人关系1
      szy1=lvszy1,   --职  业 1
      sjtzz1=lvsjtzz1,   --现住住址1
      sname2=lvsname2,   --姓  名 2
      ssex2=lvssex2,   --性  别 2
      snl2=lvsnl2,   --年  龄 2
      sybrgx2=lvsybrgx2,   --与本人关系2
      szy2=lvszy2,   --职  业 2
      sjtzz2=lvsjtzz2,   --现住住址2
      sname3=lvsname3,   --姓  名 3
      ssex3=lvssex3,   --性  别 3
      snl3=lvsnl3,   --年  龄 3
      sybrgx3=lvsybrgx3,   --与本人关系3
      szy3=lvszy3,   --职  业 3
      sjtzz3=lvsjtzz3,   --现住住址3
      sname4=lvsname4,   --姓  名 4
      ssex4=lvssex4,   --性  别 4
      snl4=lvsnl4,   --年  龄 4
      sybrgx4=lvsybrgx4,   --与本人关系4
      szy4=lvszy4,   --职  业 4
      sjtzz4=lvsjtzz4,   --现住住址4
      ssqlx=lvssqlx    --ssqlx
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_crj_txzsqb
    Set
      sdono=lvsdono,   --业务编号
      sxing=lvsxing,   --姓
      sming=lvsming,   --名
      ssex=lvssex,   --性　　别
      scsrq=lvscsrq,   --出生日期
      spyxing=lvspyxing,   --拼  音 姓
      spym=lvspym,   --拼  音 名
      smz=lvsmz,   --民　　族
      scsd=lvscsd,   --出  生 地
      szzd=lvszzd,   --暂  住 地
      slxdh=lvslxdh,   --联系电话
      ssfzhm=lvssfzhm,   --身份证号码
      srjdd=lvsrjdd,   --入境地点
      srjsj=lvsrjsj,   --入境时间
      srjhmdd=lvsrjhmdd,   --入境后目的地
      sscyzzmc=lvsscyzzmc,   --所持原证照名称
      sscyzzhm=lvsscyzzhm,   --所持原证照号码
      sqfjg=lvsqfjg,   --签发机关
      syxqz=lvsyxqz,   --有效期至
      sname1=lvsname1,   --姓  名 1
      ssex1=lvssex1,   --性  别 1
      snl1=lvsnl1,   --年  龄 1
      sybrgx1=lvsybrgx1,   --与本人关系1
      szy1=lvszy1,   --职  业 1
      sjtzz1=lvsjtzz1,   --现住住址1
      sname2=lvsname2,   --姓  名 2
      ssex2=lvssex2,   --性  别 2
      snl2=lvsnl2,   --年  龄 2
      sybrgx2=lvsybrgx2,   --与本人关系2
      szy2=lvszy2,   --职  业 2
      sjtzz2=lvsjtzz2,   --现住住址2
      sname3=lvsname3,   --姓  名 3
      ssex3=lvssex3,   --性  别 3
      snl3=lvsnl3,   --年  龄 3
      sybrgx3=lvsybrgx3,   --与本人关系3
      szy3=lvszy3,   --职  业 3
      sjtzz3=lvsjtzz3,   --现住住址3
      sname4=lvsname4,   --姓  名 4
      ssex4=lvssex4,   --性  别 4
      snl4=lvsnl4,   --年  龄 4
      sybrgx4=lvsybrgx4,   --与本人关系4
      szy4=lvszy4,   --职  业 4
      sjtzz4=lvsjtzz4,   --现住住址4
      ssqlx=lvssqlx    --ssqlx
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_crj_txzsqb
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

