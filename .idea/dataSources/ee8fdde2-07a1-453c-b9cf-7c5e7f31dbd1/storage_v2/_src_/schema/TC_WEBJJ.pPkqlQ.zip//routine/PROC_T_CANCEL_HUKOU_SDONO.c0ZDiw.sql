create procedure          Proc_t_cancel_hukou_SDONO
(
     lvoldsdono VARCHAR2,  --办理编号
     lvReturn in out varchar2 --新办理编号
)
as
  cursor c is
     select * from tc_webjj.t_cancel_hukou
     where 1=1
     and sdono=lvoldsdono;   --公民身份号码
  r c%rowtype;

BEGIN
   select TC_WEBJJ.fun_get16code(TC_WEBJJ.SEQ_T_DOBUS_SDONO.Nextval)  into  lvReturn from dual  where 1=1;
   for r in c loop
   INSERT into tc_webjj.t_cancel_hukou
    (
     sdono,   --办理编号
      master_relation,   --与户主关系
      name,   --姓　　名
      pid,   --公民身份号码
      gender,   --性　　别
      nation,   --民　　族
      native_country,   --籍贯（国家地区）
      native_place,   --籍贯（省市县区）
      dob,   --出生日期
      master_name,   --户主姓名
      master_pid,   --户主身份证号
      app_pid,   --申请人公民身份号码
      app_name,   --申请人姓名
      cancel_reason,   --注销原因
      memo,   --备　　注
      goto_address_decode,   --前往地区编码(参军省市县,前往国家)
      goto_address,   --前往地区(参军省市县,前往国家)
      can_address,    --前往地详址
      new_master_pid
    )values(
      lvReturn,   --办理编号
      r.master_relation,   --与户主关系
      r.name,   --姓　　名
      r.pid,   --公民身份号码
      r.gender,   --性　　别
      r.nation,   --民　　族
      r.native_country,   --籍贯（国家地区）
      r.native_place,   --籍贯（省市县区）
      r.dob,   --出生日期
      r.master_name,   --户主姓名
      r.master_pid,   --户主身份证号
      r.app_pid,   --申请人公民身份号码
      r.app_name,   --申请人姓名
      r.cancel_reason,   --注销原因
      r.memo,   --备　　注
      r.goto_address_decode,   --前往地区编码(参军省市县,前往国家)
      r.goto_address,   --前往地区(参军省市县,前往国家)
      r.can_address,    --前往地详址
      r.new_master_pid
    );
    commit;
    end loop;
END;

/

