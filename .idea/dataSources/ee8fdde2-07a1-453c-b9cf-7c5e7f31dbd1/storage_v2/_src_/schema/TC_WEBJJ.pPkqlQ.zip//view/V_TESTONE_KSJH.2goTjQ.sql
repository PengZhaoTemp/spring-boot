create view V_TESTONE_KSJH as
  select sdono,
       jhid,
       decode(kskm,1,'科目一',2,'科目二',3,'科目三',4,'科目四','') kskm,
       kscx,
       kcdd,
       to_char(ksrq,'yyyy-mm-dd') ksrq,
       '第'||kscc||'场' kscc,
       jhrs,
       yyrs,
       decode(jhlx,'ggjh','公共计划','jxjh','驾校计划') jhlx,
       decode(jhlx,'ggjh','<font color=red>注：公共计划有名额限制，即使计划人数大于已约人数。</font>','') msg
  from t_testone_ksjh t
  order by ksrq
/

