create PROCEDURE          PROC_t_bus_cancel   /*t_chaRGECENTER*/
(

 lvsdono IN OUT VARCHAR2  --办理编号
)
AS

BEGIN
  --begin TRAN
  update tc_webjj.t_dobus d set d.state='35',d.flownote='',d.dbbj='0' where sdono=lvsdono;
 Commit;
END; /*存储过程结束*/

