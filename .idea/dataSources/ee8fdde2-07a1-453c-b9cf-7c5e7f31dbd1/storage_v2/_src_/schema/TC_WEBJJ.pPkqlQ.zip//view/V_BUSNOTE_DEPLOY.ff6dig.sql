create view V_BUSNOTE_DEPLOY as
  select SBUSNOTENO,
       a.SBUSNO,
       SFLOWNO,
       SDOBUSORGID,
       SDOBUSUSERID,
       b.sother_info,
       b.name,
       c.sbusname
  from tc_webjj.t_busnote_deploy a,tc_jcyw.t_user b,tc_webjj.t_bus_deploy c
  where a.sdobususerid = to_char(b.npolice_id)
  and a.sbusno = c.sbusno
/

