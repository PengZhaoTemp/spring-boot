create Procedure          proc_applymasterdata_info
(
     lvsdono VARCHAR2,  --旧办理编号
     lvcailiao VARCHAR2,
     lv_ProcFlag VARCHAR2
)
as
   lvSMASTERIALSNO varchar2(50);
   lvSMASTERIALSNAME varchar2(500);
   lv_cailiao varchar2(500);
   lvsno varchar2(16);
   lvdbbj varchar2(1);
   inddh number;
begin
   delete from tc_webjj.t_applymasterdata where sdono = lvsdono;
   if lv_ProcFlag = 'PMSUBMIT' then
     lvdbbj := '0';
    else
       lvdbbj := '1';
    end if;
   lv_cailiao := lvcailiao;
   while length(lv_cailiao)>0 loop
      select instr(lv_cailiao,',',1,1) into inddh from dual;
      if inddh = 0 then
         lvSMASTERIALSNO := lv_cailiao;
         lv_cailiao := '';
      else
         lvSMASTERIALSNO := substr(lv_cailiao,1,inddh-1);
         lv_cailiao := substr(lv_cailiao,inddh+1,length(lv_cailiao));
      end if;
      select sitem into lvSMASTERIALSNAME from tc_webjj.t_applymasterials where sno = lvSMASTERIALSNO;

      insert into tc_webjj.t_applymasterdata(
           sno,
           sdono,
           smasterialsno,
           smasterialsname,
           dbbj
      )values(
           fun_get16code_pz(tc_webjj.seq_applymasterdata_nid.nextval),
           lvsdono,
           lvSMASTERIALSNO,
           lvSMASTERIALSNAME,
           lvdbbj

      );
   end loop;
end;

/

