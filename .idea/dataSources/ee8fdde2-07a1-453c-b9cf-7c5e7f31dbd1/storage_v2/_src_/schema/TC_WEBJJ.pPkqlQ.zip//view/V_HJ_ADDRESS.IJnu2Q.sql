create view V_HJ_ADDRESS as
  select ad_sheng,ad_shi,ad_quxian,ad_qxmc||address_mc as address,tj_date
    from  tc_webjj.t_hj_address order by tj_date desc
/

