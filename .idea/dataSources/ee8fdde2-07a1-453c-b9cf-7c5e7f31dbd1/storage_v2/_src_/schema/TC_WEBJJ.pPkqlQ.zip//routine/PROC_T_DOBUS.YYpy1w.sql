create PROCEDURE          PROC_t_dobus   /*T_DOBUS*/
(
 lvsdono IN OUT VARCHAR2,  --办理编号
 lvsbusno VARCHAR2,  --业务编码
 lvsdounit VARCHAR2,  --办理单位
 lvsdounitno VARCHAR2,  --办理单位编码
 lvsuserno VARCHAR2,  --用户编码
 lvstate IN OUT VARCHAR2,  --状　　态
 lvsbooking VARCHAR2,  --是否预约
 lvdbookingdate DATE,  --预约时间
 lvsnotealert VARCHAR2,  --是否短信提醒
 lvncharge NUMBER,  --支付金额
 lvnsercharge NUMBER,  --服务资费
 lvnexpcharge NUMBER,  --快递资费
 lvnrecharge NUMBER,  --回寄资费
 lvsexpno VARCHAR2,  --快递单号
 lvsexpaddress VARCHAR2,  --快递地址
 lvsexppostcode VARCHAR2,  --快递地址邮政编码
 lvsconsignee VARCHAR2,  --收  件 人
 lvscontel VARCHAR2,  --收件人联系电话
 lvsnetbus VARCHAR2,  --是否网上下单
 lvsreno VARCHAR2,  --回寄快递单号
 lvsreaddress IN OUT VARCHAR2,  --回寄地址
 lvsrepostcode VARCHAR2,  --回寄地址邮政编码
 lvsrecon VARCHAR2,  --回寄收件人
 lvsrecontel VARCHAR2,  --回寄收件人联系电话
 lvddecdate DATE,  --申报时间
 lvschecker VARCHAR2,  --审  核 人
 lvdcheckdate DATE,  --审核时间
 lvsacceptman VARCHAR2,  --受  理 人
 lvsacceptdate DATE,  --受理时间
 lvsunreason VARCHAR2,  --退回原因
 lvsopinion VARCHAR2,  --评价内容
 lvsserattitude VARCHAR2,  --服务态度得分
 lvsefficiency VARCHAR2,  --办事效率得分
 lvssatisfaction VARCHAR2,  --满  意 度
 lvsopdate DATE,  --评价时间
 lvsdodata VARCHAR2,  --业务数据概要
 lvsprocity VARCHAR2,  --回寄省市
 lvaddress VARCHAR2,  --回寄详细地址
 lvsreems VARCHAR2,  --是否需回寄材料
 lvsemssend varchar2,--是否寄送原件
 lvsbotime varchar2,--预约时间段
 lvsprint_hkb varchar2,
lv_ProcMode Varchar2,    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
lv_ProcFlag varchar2 --区别是保存还是提交
)
AS
    lvdbbj varchar2(1);
    lvdbsj date;
BEGIN
  --begin TRAN
  lvsreaddress:=lvsprocity||lvaddress;
   IF lv_ProcFlag='PMSAVE' THEN
      lvstate:='10';
   ELSIF lv_ProcFlag='PMSUBMIT'  THEN
      lvdbbj:='0';
      lvdbsj:=sysdate;
      lvstate:='20';
         IF lvsemssend='1' THEN
           lvstate:='12';
         ELSIF  lvsemssend='0' THEN
           lvstate:='20';
         ELSIF lvsbusno='035' THEN
           lvstate:='43';
         END IF;
       IF lvsbooking='1' THEN
           lvstate:='24';
         END IF;
       IF lvsbusno='032' THEN
           lvstate:='11';
       END IF;
     END IF;



IF lv_procMode='PMINSERT' THEN    /*登记*/
   INSERT into tc_webjj.t_dobus
    (
      sdono,   --办理编号
      sbusno,   --业务编码
      sdounit,   --办理单位
      sdounitno,   --办理单位编码
      suserno,   --用户编码
      state,   --状　　态
      sbooking,   --是否预约
      dbookingdate,   --预约时间
      snotealert,   --是否短信提醒
      ncharge,   --支付金额
      nsercharge,   --服务资费
      nexpcharge,   --快递资费
      nrecharge,   --回寄资费
      sexpno,   --快递单号
      sexpaddress,   --快递地址
      sexppostcode,   --快递地址邮政编码
      sconsignee,   --收  件 人
      scontel,   --收件人联系电话
      snetbus,   --是否网上下单
      sreno,   --回寄快递单号
      sreaddress,   --回寄地址
      srepostcode,   --回寄地址邮政编码
      srecon,   --回寄收件人
      srecontel,   --回寄收件人联系电话
      ddecdate,   --申报时间
      schecker,   --审  核 人
      dcheckdate,   --审核时间
      sacceptman,   --受  理 人
      sacceptdate,   --受理时间
      sunreason,   --退回原因
      sopinion,   --评价内容
      sserattitude,   --服务态度得分
      sefficiency,   --办事效率得分
      ssatisfaction,   --满  意 度
      sopdate,   --评价时间
      sdodata,   --业务数据概要
      sprocity,   --回寄省市
      address,   --回寄详细地址
      sreems,   --是否需回寄材料
      semssend, --是否寄送原件
      sbotime,--预约时间段
      sprint_hkb,
      dbbj,
      dbsj
    )values(
      lvsdono,   --办理编号
      lvsbusno,   --业务编码
      lvsdounit,   --办理单位
      lvsdounitno,   --办理单位编码
      lvsuserno,   --用户编码
      lvstate,   --状　　态
      lvsbooking,   --是否预约
      lvdbookingdate,   --预约时间
      lvsnotealert,   --是否短信提醒
      lvncharge,   --支付金额
      lvnsercharge,   --服务资费
      lvnexpcharge,   --快递资费
      lvnrecharge,   --回寄资费
      lvsexpno,   --快递单号
      lvsexpaddress,   --快递地址
      lvsexppostcode,   --快递地址邮政编码
      lvsconsignee,   --收  件 人
      lvscontel,   --收件人联系电话
      lvsnetbus,   --是否网上下单
      lvsreno,   --回寄快递单号
      lvsreaddress,   --回寄地址
      lvsrepostcode,   --回寄地址邮政编码
      lvsrecon,   --回寄收件人
      lvsrecontel,   --回寄收件人联系电话
      sysdate,   --申报时间
      lvschecker,   --审  核 人
      lvdcheckdate,   --审核时间
      lvsacceptman,   --受  理 人
      lvsacceptdate,   --受理时间
      lvsunreason,   --退回原因
      lvsopinion,   --评价内容
      lvsserattitude,   --服务态度得分
      lvsefficiency,   --办事效率得分
      lvssatisfaction,   --满  意 度
      lvsopdate,   --评价时间
      lvsdodata,   --业务数据概要
      lvsprocity,   --回寄省市
      lvaddress,   --回寄详细地址
      lvsreems,    --是否需回寄材料
      lvsemssend,
      lvsbotime,
      lvsprint_hkb,
      lvdbbj,
      lvdbsj
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_dobus
    Set
      sdono=lvsdono,   --办理编号
      sbusno=lvsbusno,   --业务编码
      sdounit=lvsdounit,   --办理单位
      sdounitno=lvsdounitno,   --办理单位编码
      suserno=lvsuserno,   --用户编码
      state=lvstate,   --状　　态
      sbooking=lvsbooking,   --是否预约
      dbookingdate=lvdbookingdate,   --预约时间
      snotealert=lvsnotealert,   --是否短信提醒
      ncharge=lvncharge,   --支付金额
      nsercharge=lvnsercharge,   --服务资费
      nexpcharge=lvnexpcharge,   --快递资费
      nrecharge=lvnrecharge,   --回寄资费
      sexpno=lvsexpno,   --快递单号
      sexpaddress=lvsexpaddress,   --快递地址
      sexppostcode=lvsexppostcode,   --快递地址邮政编码
      sconsignee=lvsconsignee,   --收  件 人
      scontel=lvscontel,   --收件人联系电话
      snetbus=lvsnetbus,   --是否网上下单
      sreno=lvsreno,   --回寄快递单号
      sreaddress=lvsreaddress,   --回寄地址
      srepostcode=lvsrepostcode,   --回寄地址邮政编码
      srecon=lvsrecon,   --回寄收件人
      srecontel=lvsrecontel,   --回寄收件人联系电话
      ddecdate=sysdate,   --申报时间
      schecker=lvschecker,   --审  核 人
      dcheckdate=lvdcheckdate,   --审核时间
      sacceptman=lvsacceptman,   --受  理 人
      sacceptdate=lvsacceptdate,   --受理时间
      sunreason=lvsunreason,   --退回原因
      sopinion=lvsopinion,   --评价内容
      sserattitude=lvsserattitude,   --服务态度得分
      sefficiency=lvsefficiency,   --办事效率得分
      ssatisfaction=lvssatisfaction,   --满  意 度
      sopdate=lvsopdate,   --评价时间
      sdodata=lvsdodata,   --业务数据概要
      sprocity=lvsprocity,   --回寄省市
      address=lvaddress,   --回寄详细地址
      sreems=lvsreems,    --是否需回寄材料
      semssend=lvsemssend,
      sbotime=lvsbotime,
      sprint_hkb=lvsprint_hkb,
      dbbj=lvdbbj,
      dbsj=lvdbsj
    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_dobus
    Set
      sdono=lvsdono,   --办理编号
      sbusno=lvsbusno,   --业务编码
      sdounit=lvsdounit,   --办理单位
      sdounitno=lvsdounitno,   --办理单位编码
      suserno=lvsuserno,   --用户编码
      state=lvstate,   --状　　态
      sbooking=lvsbooking,   --是否预约
      dbookingdate=lvdbookingdate,   --预约时间
      snotealert=lvsnotealert,   --是否短信提醒
      ncharge=lvncharge,   --支付金额
      nsercharge=lvnsercharge,   --服务资费
      nexpcharge=lvnexpcharge,   --快递资费
      nrecharge=lvnrecharge,   --回寄资费
      sexpno=lvsexpno,   --快递单号
      sexpaddress=lvsexpaddress,   --快递地址
      sexppostcode=lvsexppostcode,   --快递地址邮政编码
      sconsignee=lvsconsignee,   --收  件 人
      scontel=lvscontel,   --收件人联系电话
      snetbus=lvsnetbus,   --是否网上下单
      sreno=lvsreno,   --回寄快递单号
      sreaddress=lvsreaddress,   --回寄地址
      srepostcode=lvsrepostcode,   --回寄地址邮政编码
      srecon=lvsrecon,   --回寄收件人
      srecontel=lvsrecontel,   --回寄收件人联系电话
      ddecdate=sysdate,   --申报时间
      schecker=lvschecker,   --审  核 人
      dcheckdate=lvdcheckdate,   --审核时间
      sacceptman=lvsacceptman,   --受  理 人
      sacceptdate=lvsacceptdate,   --受理时间
      sunreason=lvsunreason,   --退回原因
      sopinion=lvsopinion,   --评价内容
      sserattitude=lvsserattitude,   --服务态度得分
      sefficiency=lvsefficiency,   --办事效率得分
      ssatisfaction=lvssatisfaction,   --满  意 度
      sopdate=lvsopdate,   --评价时间
      sdodata=lvsdodata,   --业务数据概要
      sprocity=lvsprocity,   --回寄省市
      address=lvaddress,   --回寄详细地址
      sreems=lvsreems,    --是否需回寄材料
       semssend=lvsemssend,
       sbotime=lvsbotime,
       sprint_hkb=lvsprint_hkb,
       dbbj=lvdbbj,
      dbsj=lvdbsj
    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_dobus
    Where 1=1
    and sdono=lvsdono   --办理编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

