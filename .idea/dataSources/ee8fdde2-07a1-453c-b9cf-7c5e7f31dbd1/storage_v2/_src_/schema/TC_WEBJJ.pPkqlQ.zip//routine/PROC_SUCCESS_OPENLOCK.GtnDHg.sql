create procedure          proc_success_openlock
(

   proc_sname varchar2,
   proc_saddress VARCHAR2,
   proc_nLongitude number,
   proc_nLatitude number,
   proc_slinkman varchar2,
   proc_stel VARCHAR2,
    proc_sno varchar2
) is
begin
   UPDATE tc_webjj.T_OPEN_LOCK
   Set
      SNAME = proc_sname,
      SADDRESS = proc_saddress,
      nLongitude=proc_nLongitude,
      nLatitude=proc_nLatitude,
      SLINKMAN=proc_slinkman,
      STEL=proc_stel,
    Where SNO = proc_sno;
    Commit;
end proc_success_openlock;

/

