create procedure          proc_weixin_commoner_locking(
        lv_personid in out varchar2,
        lv_pid            varchar2,
        lv_name            varchar2,
        lv_shome_phone     varchar2,
        lv_csource         varchar2,
				lv_sstate          varchar2 
       ) as
begin
  select tc_webjj.fun_get16code(tc_webjj.seq_t_commoner_personid.nextval) into lv_personid from dual;
  insert into tc_webjj.t_commoner
    (personid, pid, name, shome_phone, csource, sstate, dbbj)
  values
    (lv_personid,
     tc_webjj.fun_encrypkey(lv_pid),
     lv_name,
     lv_shome_phone,
     lv_csource,
     '1',
     '0');
     commit;
end;
/

