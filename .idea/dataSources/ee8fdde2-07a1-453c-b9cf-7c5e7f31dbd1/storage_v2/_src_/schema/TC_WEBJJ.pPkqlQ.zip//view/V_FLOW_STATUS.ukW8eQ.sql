create view V_FLOW_STATUS as
  select
a.FLOWSTATUSNO,
a.BUSFLOWNO,
a.BUSSTATUSNO,
b.busstatusname,
b.busstatuscode,
b.busstatusflag
from tc_webjj.t_flow_status a,tc_webjj.t_busStatus_deploy b
where a.busstatusno=b.busstatusno
/

