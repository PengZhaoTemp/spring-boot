create procedure          proc_lost_item_save(
      lvsitemsname      varchar2,
      lvsbigtype    varchar2,
      lvssmalltype       varchar2,
      lvscolor      varchar2,
      lvsidcode    varchar2,
      lvsnumormuch     varchar2,
      lvdlostdate       varchar2,
      lvsproperty      varchar2,
      lvswordorg      varchar2,
      lvslostpass    varchar2,
      lvslostplace     varchar2,

      lvsplacedemo       varchar2,
      lvsthankstype      varchar2,
      lvslostname    varchar2,
      lvslosttel     varchar2,
      lvslostpid       varchar2,
      lvsuserid      varchar2,
      lvslostpic      varchar2,
      lvstouchname    varchar2,
      lvstouchtel     varchar2
) is
lvsid varchar2(16);
begin
  select tc_webjj.fun_get16code(tc_webjj.seq_lost_item_sid.nextval) into lvsid from dual;
  insert into tc_webjj.t_lost_items(
     sid,
     sitemsname,
     sbigtype,
     ssmalltype,
     scolor,
     sidcode,
     snumormuch,
     dlostdate,
     sproperty,
     swordorg,
     slostpass,
     slostplace,
     splacedemo,
     sthankstype,
     slostname,
     slosttel,
     slostpid,
     suserid,
     slostpic,
     stouchname,
     stouchtel,
     scheckresult,
     dputtime,
     sisgetback,
     dregtime,
     dbbj,
     zxbz
  )values(
    lvsid,
     lvsitemsname,
     lvsbigtype,
     lvssmalltype,
     lvscolor,
     lvsidcode,
     lvsnumormuch,
     to_date(lvdlostdate,'yyyy-MM-dd  HH24:mi:SS'),
     lvsproperty,
     lvswordorg,
     lvslostpass,
     lvslostplace,
     lvsplacedemo,
     lvsthankstype,
     lvslostname,
     lvslosttel,
     lvslostpid,
     lvsuserid,
     lvslostpic,
     lvstouchname,
     lvstouchtel,
     '0',
     sysdate,
     '0',
     sysdate,
     '0',
     '0'
  );
  commit;
end proc_lost_item_save;

/

