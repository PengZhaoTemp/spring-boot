create view V_LDRK_TMP as
  select a.pid,  xzbm
  from tc_webjj.t_ldrk_info_bz a
 where 1=1
   and pid is not null
   and xzbm is not null
/

