create PROCEDURE          PROC_t_gmwp   /*T_GMWP*/
(
 lvsdono IN OUT VARCHAR2,  --业务编号
 lvsgm_ckbh VARCHAR2,  --仓库编号
 lvsgm_hd_ccl VARCHAR2,  --核定储存量
 lvsgm_xy_ccl VARCHAR2,  --现有储存量
 lvsgmh_pz VARCHAR2,  --购买后品种
 lvsgmh_sl VARCHAR2,  --购买后数量
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS

BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/



   INSERT into tc_webjj.t_gmwp
    (
      sdono,   --业务编号
      sgm_ckbh,   --仓库编号
      sgm_hd_ccl,   --核定储存量
      sgm_xy_ccl,   --现有储存量
      sgmh_pz,   --购买后品种
      sgmh_sl  ,  --购买后数量
      dbbj,
      dbsj
    )values(
      lvsdono,   --业务编号
      lvsgm_ckbh,   --仓库编号
      lvsgm_hd_ccl,   --核定储存量
      lvsgm_xy_ccl,   --现有储存量
      lvsgmh_pz,   --购买后品种

      lvsgmh_sl  ,  --购买后数量
      '0',
      sysdate

    );
   -- 返回值

END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_gmwp
    Set
      sdono=lvsdono,   --业务编号
      sgm_ckbh=lvsgm_ckbh,   --仓库编号
      sgm_hd_ccl=lvsgm_hd_ccl,   --核定储存量
      sgm_xy_ccl=lvsgm_xy_ccl,   --现有储存量
      sgmh_pz=lvsgmh_pz,   --购买后品种
      sgmh_sl=lvsgmh_sl ,   --购买后数量
      dbbj='0',
      dbsj=sysdate
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_gmwp
    Set
      sdono=lvsdono,   --业务编号
      sgm_ckbh=lvsgm_ckbh,   --仓库编号
      sgm_hd_ccl=lvsgm_hd_ccl,   --核定储存量
      sgm_xy_ccl=lvsgm_xy_ccl,   --现有储存量
      sgmh_pz=lvsgmh_pz,   --购买后品种
      sgmh_sl=lvsgmh_sl  ,  --购买后数量
      dbbj='0',
      dbsj=sysdate
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_gmwp
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

