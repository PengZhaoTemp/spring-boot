create procedure          proc_dobus_sendmsg(
       lvsbusno varchar2,
       lvsflowno varchar2,
       lvsdobusorgid  varchar2
) is
lvbusnote tc_webjj.v_busnote_deploy%rowtype;
begin
   --insert into t_test values(lvsbusno||'..'||lvsflowno||'..'||lvsdobusorgid);
   begin
     select * into lvbusnote from tc_webjj.v_busnote_deploy where sbusno = lvsbusno and sdobusorgid=lvsdobusorgid;
     if instr(lvbusnote.SFLOWNO,lvsflowno)>0 then
        if lvbusnote.sother_info is not null then
           insert into tc_webjj.t_notetask(
               sno,snote,stel,ssendflag,stype,dbbj
           )values(
               'W'||tc_webjj.seq_t_notetask_nno.nextval,
               '您有一笔《'||lvbusnote.sbusname ||'》等待处理。',
               lvbusnote.sother_info,
               '0',
               '1',
               '0'
           );
        end if;
     end if;
   exception
   when others then
     null;
   end;
end proc_dobus_sendmsg;

/

