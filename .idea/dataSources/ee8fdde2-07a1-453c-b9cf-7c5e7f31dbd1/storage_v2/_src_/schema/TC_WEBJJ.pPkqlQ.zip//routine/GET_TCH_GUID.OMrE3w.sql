create function          get_tch_guid return varchar2 is
 lvret varchar2(36);
begin
  select sys_guid() into lvret from dual;
  return lvret;
end;
/

