create PROCEDURE          PROC_t_crj_dljmwltw   /*T_CRJ_DLJMWLTW*/
(
 lvsdono IN OUT VARCHAR2,  --业务编号
 lvsfzjmc VARCHAR2,  --身份证件名称
 lvszjhm VARCHAR2,  --证件号码
 lvsxing VARCHAR2,  --姓
 lvsming VARCHAR2,  --名
 lvszym VARCHAR2,  --曾  用 名
 lvspyzym VARCHAR2,  --拼音曾用名
 lvspyx VARCHAR2,  --拼  音 姓
 lvspym VARCHAR2,  --拼  音 名
 lvssex VARCHAR2,  --性　　别
 lvscsrq DATE,  --出生日期
 lvscsd VARCHAR2,  --出  生 地
 lvsmz VARCHAR2,  --民　　族
 lvswhcd VARCHAR2,  --文化程度
 lvshyzk VARCHAR2,  --婚姻状况 1,已婚  2,未婚  3,离异  4,丧偶
 lvshkszd VARCHAR2,  --户口所在地
 lvshkszdpcs VARCHAR2,  --户口所在地派出所
 lvsxzdz VARCHAR2,  --现住地址
 lvslldh VARCHAR2,  --联络电话
 lvsyzbm VARCHAR2,  --邮政编码
 lvsgzdw VARCHAR2,  --工作单位
 lvsxrzw VARCHAR2,  --现任职务
 lvssqzj VARCHAR2,  --申请证件   1,首次  2,证件期满  3,内页用完  4,证件遗失  5,证件损毁 6,其他
 lvssqly VARCHAR2,  --申请理由   1,应邀  2 非公职应邀  3,定居 4,探亲 5,居留 6,旅游  7,乘务 8,其他
 lvscw1 VARCHAR2,  --称  谓 1
 lvsname1 VARCHAR2,  --姓  名 1
 lvssex1 VARCHAR2,  --性  别 1
 lvsaddr1 VARCHAR2,  --住  址 1
 lvslldh1 VARCHAR2,  --联络电话1
 lvscw2 VARCHAR2,  --称  谓 2
 lvsname2 VARCHAR2,  --姓  名 2
 lvssex2 VARCHAR2,  --性  别 2
 lvsaddr2 VARCHAR2,  --住  址 2
 lvslldh2 VARCHAR2,  --联络电话2
 lvscw3 VARCHAR2,  --称  谓 3
 lvsname3 VARCHAR2,  --姓  名 3
 lvssex3 VARCHAR2,  --性  别 3
 lvsaddr3 VARCHAR2,  --住  址 3
 lvslldh3 VARCHAR2,  --联络电话3
 lvscw4 VARCHAR2,  --称  谓 4
 lvsname4 VARCHAR2,  --姓  名 4
 lvssex4 VARCHAR2,  --性  别 4
 lvsaddr4 VARCHAR2,  --住  址 4
 lvslldh4 VARCHAR2,  --联络电话4
 lvscw5 VARCHAR2,  --称  谓 5
 lvsname5 VARCHAR2,  --姓  名 5
 lvssex5 VARCHAR2,  --性  别 5
 lvsaddr5 VARCHAR2,  --住  址 5
 lvslldh5 VARCHAR2,  --联络电话5
 lvsysqrgx VARCHAR2,  --与申请人关系 0,父亲 1,母亲 3,其他监护人
 lvsjhssfzjhm VARCHAR2,  --监护人身份证件号码
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
   INSERT into tc_webjj.t_crj_dljmwltw
    (
      sdono,   --业务编号
      sfzjmc,   --身份证件名称
      szjhm,   --证件号码
      sxing,   --姓
      sming,   --名
      szym,   --曾  用 名
      spyzym,   --拼音曾用名
      spyx,   --拼  音 姓
      spym,   --拼  音 名
      ssex,   --性　　别
      scsrq,   --出生日期
      scsd,   --出  生 地
      smz,   --民　　族
      swhcd,   --文化程度
      shyzk,   --婚姻状况 1,已婚  2,未婚  3,离异  4,丧偶
      shkszd,   --户口所在地
      shkszdpcs,   --户口所在地派出所
      sxzdz,   --现住地址
      slldh,   --联络电话
      syzbm,   --邮政编码
      sgzdw,   --工作单位
      sxrzw,   --现任职务
      ssqzj,   --申请证件   1,首次  2,证件期满  3,内页用完  4,证件遗失  5,证件损毁 6,其他
      ssqly,   --申请理由   1,应邀  2 非公职应邀  3,定居 4,探亲 5,居留 6,旅游  7,乘务 8,其他
      scw1,   --称  谓 1
      sname1,   --姓  名 1
      ssex1,   --性  别 1
      saddr1,   --住  址 1
      slldh1,   --联络电话1
      scw2,   --称  谓 2
      sname2,   --姓  名 2
      ssex2,   --性  别 2
      saddr2,   --住  址 2
      slldh2,   --联络电话2
      scw3,   --称  谓 3
      sname3,   --姓  名 3
      ssex3,   --性  别 3
      saddr3,   --住  址 3
      slldh3,   --联络电话3
      scw4,   --称  谓 4
      sname4,   --姓  名 4
      ssex4,   --性  别 4
      saddr4,   --住  址 4
      slldh4,   --联络电话4
      scw5,   --称  谓 5
      sname5,   --姓  名 5
      ssex5,   --性  别 5
      saddr5,   --住  址 5
      slldh5,   --联络电话5
      sysqrgx,   --与申请人关系 0,父亲 1,母亲 3,其他监护人
      sjhssfzjhm    --监护人身份证件号码
    )values(
      lvsdono,   --业务编号
      lvsfzjmc,   --身份证件名称
      lvszjhm,   --证件号码
      lvsxing,   --姓
      lvsming,   --名
      lvszym,   --曾  用 名
      lvspyzym,   --拼音曾用名
      lvspyx,   --拼  音 姓
      lvspym,   --拼  音 名
      lvssex,   --性　　别
      lvscsrq,   --出生日期
      lvscsd,   --出  生 地
      lvsmz,   --民　　族
      lvswhcd,   --文化程度
      lvshyzk,   --婚姻状况 1,已婚  2,未婚  3,离异  4,丧偶
      lvshkszd,   --户口所在地
      lvshkszdpcs,   --户口所在地派出所
      lvsxzdz,   --现住地址
      lvslldh,   --联络电话
      lvsyzbm,   --邮政编码
      lvsgzdw,   --工作单位
      lvsxrzw,   --现任职务
      lvssqzj,   --申请证件   1,首次  2,证件期满  3,内页用完  4,证件遗失  5,证件损毁 6,其他
      lvssqly,   --申请理由   1,应邀  2 非公职应邀  3,定居 4,探亲 5,居留 6,旅游  7,乘务 8,其他
      lvscw1,   --称  谓 1
      lvsname1,   --姓  名 1
      lvssex1,   --性  别 1
      lvsaddr1,   --住  址 1
      lvslldh1,   --联络电话1
      lvscw2,   --称  谓 2
      lvsname2,   --姓  名 2
      lvssex2,   --性  别 2
      lvsaddr2,   --住  址 2
      lvslldh2,   --联络电话2
      lvscw3,   --称  谓 3
      lvsname3,   --姓  名 3
      lvssex3,   --性  别 3
      lvsaddr3,   --住  址 3
      lvslldh3,   --联络电话3
      lvscw4,   --称  谓 4
      lvsname4,   --姓  名 4
      lvssex4,   --性  别 4
      lvsaddr4,   --住  址 4
      lvslldh4,   --联络电话4
      lvscw5,   --称  谓 5
      lvsname5,   --姓  名 5
      lvssex5,   --性  别 5
      lvsaddr5,   --住  址 5
      lvslldh5,   --联络电话5
      lvsysqrgx,   --与申请人关系 0,父亲 1,母亲 3,其他监护人
      lvsjhssfzjhm    --监护人身份证件号码
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_crj_dljmwltw
    Set
      sdono=lvsdono,   --业务编号
      sfzjmc=lvsfzjmc,   --身份证件名称
      szjhm=lvszjhm,   --证件号码
      sxing=lvsxing,   --姓
      sming=lvsming,   --名
      szym=lvszym,   --曾  用 名
      spyzym=lvspyzym,   --拼音曾用名
      spyx=lvspyx,   --拼  音 姓
      spym=lvspym,   --拼  音 名
      ssex=lvssex,   --性　　别
      scsrq=lvscsrq,   --出生日期
      scsd=lvscsd,   --出  生 地
      smz=lvsmz,   --民　　族
      swhcd=lvswhcd,   --文化程度
      shyzk=lvshyzk,   --婚姻状况 1,已婚  2,未婚  3,离异  4,丧偶
      shkszd=lvshkszd,   --户口所在地
      shkszdpcs=lvshkszdpcs,   --户口所在地派出所
      sxzdz=lvsxzdz,   --现住地址
      slldh=lvslldh,   --联络电话
      syzbm=lvsyzbm,   --邮政编码
      sgzdw=lvsgzdw,   --工作单位
      sxrzw=lvsxrzw,   --现任职务
      ssqzj=lvssqzj,   --申请证件   1,首次  2,证件期满  3,内页用完  4,证件遗失  5,证件损毁 6,其他
      ssqly=lvssqly,   --申请理由   1,应邀  2 非公职应邀  3,定居 4,探亲 5,居留 6,旅游  7,乘务 8,其他
      scw1=lvscw1,   --称  谓 1
      sname1=lvsname1,   --姓  名 1
      ssex1=lvssex1,   --性  别 1
      saddr1=lvsaddr1,   --住  址 1
      slldh1=lvslldh1,   --联络电话1
      scw2=lvscw2,   --称  谓 2
      sname2=lvsname2,   --姓  名 2
      ssex2=lvssex2,   --性  别 2
      saddr2=lvsaddr2,   --住  址 2
      slldh2=lvslldh2,   --联络电话2
      scw3=lvscw3,   --称  谓 3
      sname3=lvsname3,   --姓  名 3
      ssex3=lvssex3,   --性  别 3
      saddr3=lvsaddr3,   --住  址 3
      slldh3=lvslldh3,   --联络电话3
      scw4=lvscw4,   --称  谓 4
      sname4=lvsname4,   --姓  名 4
      ssex4=lvssex4,   --性  别 4
      saddr4=lvsaddr4,   --住  址 4
      slldh4=lvslldh4,   --联络电话4
      scw5=lvscw5,   --称  谓 5
      sname5=lvsname5,   --姓  名 5
      ssex5=lvssex5,   --性  别 5
      saddr5=lvsaddr5,   --住  址 5
      slldh5=lvslldh5,   --联络电话5
      sysqrgx=lvsysqrgx,   --与申请人关系 0,父亲 1,母亲 3,其他监护人
      sjhssfzjhm=lvsjhssfzjhm    --监护人身份证件号码
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_crj_dljmwltw
    Set
      sdono=lvsdono,   --业务编号
      sfzjmc=lvsfzjmc,   --身份证件名称
      szjhm=lvszjhm,   --证件号码
      sxing=lvsxing,   --姓
      sming=lvsming,   --名
      szym=lvszym,   --曾  用 名
      spyzym=lvspyzym,   --拼音曾用名
      spyx=lvspyx,   --拼  音 姓
      spym=lvspym,   --拼  音 名
      ssex=lvssex,   --性　　别
      scsrq=lvscsrq,   --出生日期
      scsd=lvscsd,   --出  生 地
      smz=lvsmz,   --民　　族
      swhcd=lvswhcd,   --文化程度
      shyzk=lvshyzk,   --婚姻状况 1,已婚  2,未婚  3,离异  4,丧偶
      shkszd=lvshkszd,   --户口所在地
      shkszdpcs=lvshkszdpcs,   --户口所在地派出所
      sxzdz=lvsxzdz,   --现住地址
      slldh=lvslldh,   --联络电话
      syzbm=lvsyzbm,   --邮政编码
      sgzdw=lvsgzdw,   --工作单位
      sxrzw=lvsxrzw,   --现任职务
      ssqzj=lvssqzj,   --申请证件   1,首次  2,证件期满  3,内页用完  4,证件遗失  5,证件损毁 6,其他
      ssqly=lvssqly,   --申请理由   1,应邀  2 非公职应邀  3,定居 4,探亲 5,居留 6,旅游  7,乘务 8,其他
      scw1=lvscw1,   --称  谓 1
      sname1=lvsname1,   --姓  名 1
      ssex1=lvssex1,   --性  别 1
      saddr1=lvsaddr1,   --住  址 1
      slldh1=lvslldh1,   --联络电话1
      scw2=lvscw2,   --称  谓 2
      sname2=lvsname2,   --姓  名 2
      ssex2=lvssex2,   --性  别 2
      saddr2=lvsaddr2,   --住  址 2
      slldh2=lvslldh2,   --联络电话2
      scw3=lvscw3,   --称  谓 3
      sname3=lvsname3,   --姓  名 3
      ssex3=lvssex3,   --性  别 3
      saddr3=lvsaddr3,   --住  址 3
      slldh3=lvslldh3,   --联络电话3
      scw4=lvscw4,   --称  谓 4
      sname4=lvsname4,   --姓  名 4
      ssex4=lvssex4,   --性  别 4
      saddr4=lvsaddr4,   --住  址 4
      slldh4=lvslldh4,   --联络电话4
      scw5=lvscw5,   --称  谓 5
      sname5=lvsname5,   --姓  名 5
      ssex5=lvssex5,   --性  别 5
      saddr5=lvsaddr5,   --住  址 5
      slldh5=lvslldh5,   --联络电话5
      sysqrgx=lvsysqrgx,   --与申请人关系 0,父亲 1,母亲 3,其他监护人
      sjhssfzjhm=lvsjhssfzjhm    --监护人身份证件号码
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_crj_dljmwltw
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

