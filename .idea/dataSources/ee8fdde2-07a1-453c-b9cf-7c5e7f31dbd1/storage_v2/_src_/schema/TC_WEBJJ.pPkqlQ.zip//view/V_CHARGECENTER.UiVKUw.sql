create view V_CHARGECENTER as
  select a.SCHARGENO,
       a.SDONO,
       a.SUSERNO,
       a.SACCOUNTS,
       a.SDEALACC,
       a.MERABBR,
       a.MERABBRNO,
       a.NMONEY,
       a.SMEMO,
       to_char(a.DDEALDATE,'yyyy-mm-dd hh24:mi:ss') ddealdate,
       a.NSERCHARGE,
       a.NEXPCHARGE,
       a.NRECHARGE,
       b.sdodata
  from tc_webjj.t_chargecenter a,tc_webjj.t_dobus b
  where a.sdono = b.sdono
/

