create function          fun_xzfy_tb(lv_sdono varchar2) return varchar2 is
  lv_return  varchar2(80);
begin
  /*文件类型（
  行政复议终止决定书13/
  补正行政复议申请通知书11/
  行政复议申请受理通知书10/
  行政复议告知书12）*/
  lv_return:='num';
  for r in (select stype_code
              from tc_webjj.t_xzfy_table
             where sdono = lv_sdono) loop
   if r.stype_code ='10' then
     lv_return := lv_return ||',10';
   end if;
   if r.stype_code ='11' then
     lv_return := lv_return ||',11';
   end if;
   if r.stype_code ='12' then
     lv_return := lv_return ||',12';
   end if;
   if r.stype_code ='13' then
     lv_return := lv_return ||',13';
   end if;
  end loop;

  return(lv_return);
end fun_xzfy_tb;

/

