create procedure          proc_dobus_selecttestplan(
       lvsdono varchar2,
       lvsoperationno varchar2,
       lvjhid         varchar2,
       lvsuserno           varchar2,--用户编号
       lvsusername         varchar2,--用户姓名
       lvsorgid            varchar2,--操作单位代码（群众的时候不需要操作单位）
       lvsorgname          varchar2,--操作单位名称（群众的时候不需要操作单位）
       lvsplanno           varchar2
) is
lvslogno varchar2(16);
lvsoperationname varchar2(16);
lvsusertype varchar2(1);
lvsresult varchar2(500);
lvksjh tc_webjj.v_testone_ksjh%rowtype;
begin
    select * into lvksjh from tc_webjj.v_testone_ksjh where jhid=to_number(lvjhid) and sdono=lvsdono;
    lvsresult := '您已经提交预约场次申请。'||lvksjh.ksrq||' '||lvksjh.kskm||' '||lvksjh.kscc;
    update tc_webjj.t_dobus a set a.scontext=lvsresult where sdono = lvsdono;
    update tc_webjj.t_jj_test_one b set b.jhid=lvjhid,b.dbbj='0' where sdono = lvsdono;
    --日志

    select a.sname,a.stype into lvsoperationname,lvsusertype from tc_webjj.t_operation_deploy a where a.sno=lvsoperationno;
    proc_dobus_log_info(
      lvslogno,
      lvsplanno,
      lvsoperationno,
      lvsoperationname,
      lvsdono,
      lvsusertype,
      lvsuserno,
      lvsusername,
      lvsorgid,
      lvsorgname,
      lvsresult
    );
    proc_dobus_nextflow(lvsdono);
    commit;
end proc_dobus_selecttestplan;

/

