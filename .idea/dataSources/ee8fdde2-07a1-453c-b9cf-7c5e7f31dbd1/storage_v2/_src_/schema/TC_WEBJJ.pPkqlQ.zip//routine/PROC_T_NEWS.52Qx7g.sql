create PROCEDURE          PROC_t_news   /*新闻内容*/
(
 lvnno IN OUT NUMBER,  --新闻编号
 lvncolno NUMBER,  --所属栏目编号
 lvstitle VARCHAR2,  --新闻标题
 lvspicpath VARCHAR2,  --引导图片
 lvspicpath2 VARCHAR2,  --引导缩图片
 lvscontent VARCHAR2,  --新闻内容
 lvspubman VARCHAR2,  --发  布 人
 lvnuserno NUMBER,  --发布会员编号
 lvspubtime DATE,  --发布时间
 lvnlookcount NUMBER,  --访问次数
 lvsfocus VARCHAR2,  --是否热点
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
    Select tc_webjj.SEQ_T_NEWS_NNO.Nextval  into lvnno From dual;    /*新闻编号序列*/
   INSERT into tc_webjj.t_news
    (
      nno,   --新闻编号
      ncolno,   --所属栏目编号
      stitle,   --新闻标题
      spicpath,   --引导图片
      spicpath2,   --引导缩图片
      scontent,   --新闻内容
      spubman,   --发  布 人
      nuserno,   --发布会员编号
      spubtime,   --发布时间
      nlookcount,   --访问次数
      sfocus    --是否热点
    )values(
      lvnno,   --新闻编号
      lvncolno,   --所属栏目编号
      lvstitle,   --新闻标题
      lvspicpath,   --引导图片
      lvspicpath2,   --引导缩图片
      lvscontent,   --新闻内容
      lvspubman,   --发  布 人
      lvnuserno,   --发布会员编号
      lvspubtime,   --发布时间
      lvnlookcount,   --访问次数
      lvsfocus    --是否热点
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_news
    Set
      nno=lvnno,   --新闻编号
      ncolno=lvncolno,   --所属栏目编号
      stitle=lvstitle,   --新闻标题
      spicpath=lvspicpath,   --引导图片
      spicpath2=lvspicpath2,   --引导缩图片
      scontent=lvscontent,   --新闻内容
      spubman=lvspubman,   --发  布 人
      nuserno=lvnuserno,   --发布会员编号
      spubtime=lvspubtime,   --发布时间
      nlookcount=lvnlookcount,   --访问次数
      sfocus=lvsfocus    --是否热点
    Where 1=1
    and nno=lvnno   --新闻编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_news
    Set
      nno=lvnno,   --新闻编号
      ncolno=lvncolno,   --所属栏目编号
      stitle=lvstitle,   --新闻标题
      spicpath=lvspicpath,   --引导图片
      spicpath2=lvspicpath2,   --引导缩图片
      scontent=lvscontent,   --新闻内容
      spubman=lvspubman,   --发  布 人
      nuserno=lvnuserno,   --发布会员编号
      spubtime=lvspubtime,   --发布时间
      nlookcount=lvnlookcount,   --访问次数
      sfocus=lvsfocus    --是否热点
    Where 1=1
    and nno=lvnno   --新闻编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_news
    Where 1=1
    and nno=lvnno   --新闻编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

