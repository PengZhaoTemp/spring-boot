create PROCEDURE          PROC_dobus_info_update   /*T_DOBUS*/
(
  lvsdono          varchar2,--办理编号
  lvsbusno         varchar2,--业务编号
  lvsdodata        varchar2,--业务数据概要
  lvsdounit        varchar2,--办理单位名称
  lvsdounitno      varchar2,--办理单位代码
  lvsuserno        varchar2,--申请人编码
  lvsapppid        varchar2,--申请人公民身份号码
  lvsappname       varchar2,--申请人姓名
  lvsapptel        varchar2,--申请人联系电话
  lvsbusdotype     varchar2,--1-办理 2-预约 3-查询 4-下载
  lvncharge        number,--支付金额
  lvnsercharge     number,--服务资费
  lvnexpcharge     number,--快递资费
  lvnrecharge      number,--回寄资费
  lvsemssend       varchar2,--0-不需要 1-需要
  lvssendtype      varchar2,--1-快递 2-亲自送
  lvsexpaddress    varchar2,--寄送快递地址
  lvsexppostcode   varchar2,--寄送邮政编码
  lvsconsignee     varchar2,--寄送收件人
  lvscontel        varchar2,--寄送联系电话
  lvsreems         varchar2,--0-不需要 1-需要
  lvssbacktype     varchar2,--1-邮政速递 2-邮货到付 3-亲自取
  lvsreno          varchar2,--回寄快递单号
  lvsprocity       varchar2,--回寄省市区县
  lvsreaddress     varchar2,--回寄地址
  lvsrepostcode    varchar2,--回寄邮政编码
  lvsrecon         varchar2,--回寄收件人
  lvsrecontel      varchar2,--回寄联系电话
  lvmastertypesno  varchar2,--材料类编号
  lvsitem_sno      varchar2,--材料配置编号
  lvsitem_files    varchar2,--上传材料路径
  lvexectype       varchar2,--材料寄送方式
  lvcsource        varchar2, --0-网站 1-微信 2-手机
  lvdbookingdate   varchar2,
  lvsbotime        varchar2,
  lvswtrpid        varchar2,
  lvswtrname       varchar2,
  lvswtrtel        varchar2
)
AS
BEGIN
 --更新数据数据
 update tc_webjj.t_dobus set
 sbusno=lvsbusno,
 sdodata=lvsdodata,--业务数据概要
 sdounitno=lvsdounitno,--办理单位代码
 sdounit=lvsdounit,--办理单位
 sapppid=lvsapppid,---申请人公民身份号码
 sappname=lvsappname,--申请人姓名
 suserno=lvsuserno,--申请人编码
 sapptel=lvsapptel,--申请人联系电话
 sbusdotype=lvsbusdotype,--1-办理 2-预约 3-查询 4-下载
 ncharge=lvncharge, --支付金额
 nsercharge=lvnsercharge, --服务资费
 nexpcharge=lvnexpcharge,--快递资费
 nrecharge=lvnrecharge,--回寄资费
 semssend=lvsemssend,--0-不需要 1-需要
 ssendtype=lvssendtype,--1-快递 2-亲自送
 sexpaddress=lvsexpaddress,--寄送快递地址
 sexppostcode=lvsexppostcode,--寄送邮政编码
 sconsignee=lvsconsignee,--寄送收件人
 scontel=lvscontel,--寄送联系电话
 sreems=lvsreems,--0-不需要 1-需要
 ssbacktype=lvssbacktype,--1-邮政速递 2-邮货到付 3-亲自取
 sreno=lvsreno,--回寄快递单号
 sprocity=lvsprocity,--回寄省市区县
 sreaddress=lvsreaddress,--回寄地址
 srepostcode=lvsrepostcode,--回寄邮政编码
 srecon=lvsrecon,--回寄收件人
 srecontel=lvsrecontel,--回寄联系电话
 mastertypesno=lvmastertypesno,--材料类编号
 csource=lvcsource,
 ddecdate=sysdate,
 exectype=lvexectype,
 dbookingdate=to_date(lvdbookingdate,'yyyy-mm-dd'),
 sbotime=lvsbotime,
 dbbj='0',
 swtrpid=lvswtrpid,
 swtrname=lvswtrname,
 swtrtel=lvswtrtel
 where 1=1 and sdono=lvsdono;
 Commit;
 delete from tc_webjj.t_applymasterdata where sdono = lvsdono;
 Commit;
  if lvsbusdotype = '1' or lvsbusdotype = '2' then
  --写入材料信息
  if lvexectype = '1' or lvexectype = '3' then  --办理或预约类业务
      proc_publicsave_master(lvsdono,lvsitem_sno,lvsitem_files,'PMSAVE');
             --lvsitem_sno 材料编号 4110001000001405,4110001000001406,4110001000001407
             --lvsitem_files具体文件 材料路径集合      11.jpg,12.jpg;21.jpg;31.jpg,32.jpg
    elsif lvexectype = '2' then
       proc_applymasterdata_info(lvsdono,lvsitem_sno,'PMSAVE');
    end if;


  end if;
 Commit;
END; /*存储过程结束*/

