create view V_DOBUS_LOG as
  select
       b.splanno,
       a.slogno,
       a.soperationno,
       a.soperationname,
       b.sdono,
       a.susertype,
       a.suserno,
       a.susername,
       a.sorgid,
       a.sorgname,
       a.sdotime,
       a.sresult,
       b.scomplete,
       b.nstepnum,
       c.sflowtaxis,
       c.sflowname,
--     decode(a.susertype,'0',a.susername||'于'||to_char(a.sdotime,'yyyy-mm-dd hh24:mi:ss')||a.soperationname,'1',a.sorgname||' '||a.susername||'于'||to_char(a.sdotime,'yyyy-mm-dd hh24:mi:ss')||a.soperationname,'等待处理') domsg,
--      decode(a.susertype,'0',a.susername||'于'||to_char(a.sdotime,'yyyy-mm-dd hh24:mi:ss')||a.soperationname,'1',a.sorgname||' '||'于'||to_char(a.sdotime,'yyyy-mm-dd hh24:mi:ss')||a.soperationname,'等待处理') domsg,
        decode(a.susertype,'0',a.susername||a.soperationname,'1',a.sorgname||' '||a.soperationname,'等待处理') domsg,
       c.sbusstatuscode,
       c.sshowtype
  from tc_webjj.t_busflow_plan   b,
       tc_webjj.t_dobus_log      a,
       tc_webjj.t_busflow_deploy c
 where b.splanno = a.splanno(+)
   and b.sflowno = c.sflowno
/

