create procedure          proc_dobus_submit(
       lvsdono varchar2,
       lvsoperationno varchar2,
       lvsuserno      varchar2,
       lvsusername    varchar2,
       lvsorgid       varchar2,
       lvsorgname     varchar2,
       lvsplanno      varchar2
) is
lvslogno varchar2(16);
lvsoperationname varchar2(16);
lvsusertype varchar2(1);
lvsresult varchar2(500);
lvsbusno varchar(4);
begin
  select sbusno into lvsbusno from tc_webjj.t_dobus where sdono=lvsdono;
  if lvsbusno = '0701' then
     update tc_webjj.t_petition_letter b set b.pdate=sysdate where sdono=lvsdono;
  end if;
  lvsresult := '申请信息已经提交';
  update tc_webjj.t_dobus a set a.scontext=lvsresult where sdono=lvsdono;
  select a.sname,a.stype into lvsoperationname,lvsusertype from tc_webjj.t_operation_deploy a where a.sno=lvsoperationno;
  --写入操作日志
  proc_dobus_log_info(
      lvslogno,
      lvsplanno,
      lvsoperationno,
      lvsoperationname,
      lvsdono,
      lvsusertype,
      lvsuserno,
      lvsusername,
      lvsorgid,
      lvsorgname,
      lvsresult
  );
  proc_dobus_nextflow(lvsdono);
  update tc_webjj.t_applymasterdata set dbbj = '0' where sdono=lvsdono;
  commit;
end;

/

