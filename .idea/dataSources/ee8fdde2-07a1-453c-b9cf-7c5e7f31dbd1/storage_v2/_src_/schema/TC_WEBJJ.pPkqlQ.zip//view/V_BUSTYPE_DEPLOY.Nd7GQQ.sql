create view V_BUSTYPE_DEPLOY as
  select SBUSTYPENO,
       SBUSTYPENAME,
       SBUSTYPELOGO,
       SBUSTYPESTATE,
       decode(SBUSTYPESTATE,'1','有效','0','注销') SBUSTYPESTATE_cn,
       SBUSTYPEINTRO,
       PY_CODE,
       WB_CODE,
       dbbj,
       DBSJ,
       norder,
       norder_busind
  from t_bustype_deploy t
  order by SBUSTYPENO
/

