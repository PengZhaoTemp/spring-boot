create PROCEDURE          PROC_t_mb_yssq   /*T_MB_YSSQ*/
(
 lvsdono IN OUT VARCHAR2,  --业务编号
 lvssh_name VARCHAR2,  --收货单位名称
 lvssh_dz VARCHAR2,  --收货地址
 lvssh_xkz VARCHAR2,  --收货许可证编号
 lvssh_fzr VARCHAR2,  --收货负责人
 lvssh_lxfs VARCHAR2,  --收货负责人联系方式
 lvssh_jbr VARCHAR2,  --收货经办人
 lvssh_jbr_pid VARCHAR2,  --收货经办人姓名
 lvssh_jbr_lxfs VARCHAR2,  --收货经办人联系方式
 lvsgh_name VARCHAR2,  --供货单位名称
 lvsgh_dz VARCHAR2,  --供货地址
 lvsgh_xkz VARCHAR2,  --供货许可证编号
 lvsgh_fzr VARCHAR2,  --供货负责人
 lvsgh_lxfs VARCHAR2,  --供货负责人联系方式
 lvsys_name VARCHAR2,  --承运单位名称
 lvsys_dz VARCHAR2,  --承运地址
 lvsys_zzzm VARCHAR2,  --承运资质证明编号
 lvsys_fzr VARCHAR2,  --承运负责人
 lvsys_lxfs VARCHAR2,  --承运负责人联系方式
 lvsys_jsy VARCHAR2,  --驾  驶 员
 lvsys_jsy_zzzm VARCHAR2,  --驾驶员资质证明
 lvsys_jsy_lxfs VARCHAR2,  --驾驶员联系方式
 lvsys_yy VARCHAR2,  --押  运 员
 lvsys_yy_zzzm VARCHAR2,  --押运员资质证明
 lvsys_yy_lxfs VARCHAR2,  --押运员联系方式
 lvsys_car_zmbh VARCHAR2,  --道路运输证明编号
 lvsys_car VARCHAR2,  --运输车牌号
 lvsys_time_start DATE,  --运输开始时间
 lvsys_time_end DATE,  --运输结束时间
 lvsys_addr_start VARCHAR2,  --运输起始地点
 lvsys_addr_middle VARCHAR2,  --经停地点
 lvsys_addr_end VARCHAR2,  --运输结束地点
 lvsys_bz VARCHAR2,  --备　　注
 lvsys_shr VARCHAR2,  --审  核 人
 lvsys_shsj DATE,  --审核时间
 lvsys_qfr VARCHAR2,  --签  发 人
 lvsys_qfsj DATE,  --签发时间
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS

BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/



   INSERT into tc_webjj.t_mb_yssq
    (
      sdono,   --业务编号
      ssh_name,   --收货单位名称
      ssh_dz,   --收货地址
      ssh_xkz,   --收货许可证编号
      ssh_fzr,   --收货负责人
      ssh_lxfs,   --收货负责人联系方式
      ssh_jbr,   --收货经办人
      ssh_jbr_pid,   --收货经办人姓名
      ssh_jbr_lxfs,   --收货经办人联系方式
      sgh_name,   --供货单位名称
      sgh_dz,   --供货地址
      sgh_xkz,   --供货许可证编号
      sgh_fzr,   --供货负责人
      sgh_lxfs,   --供货负责人联系方式
      sys_name,   --承运单位名称
      sys_dz,   --承运地址
      sys_zzzm,   --承运资质证明编号
      sys_fzr,   --承运负责人
      sys_lxfs,   --承运负责人联系方式
      sys_jsy,   --驾  驶 员
      sys_jsy_zzzm,   --驾驶员资质证明
      sys_jsy_lxfs,   --驾驶员联系方式
      sys_yy,   --押  运 员
      sys_yy_zzzm,   --押运员资质证明
      sys_yy_lxfs,   --押运员联系方式
      sys_car_zmbh,   --道路运输证明编号
      sys_car,   --运输车牌号
      sys_time_start,   --运输开始时间
      sys_time_end,   --运输结束时间
      sys_addr_start,   --运输起始地点
      sys_addr_middle,   --经停地点
      sys_addr_end,   --运输结束地点
      sys_bz,   --备　　注
      sys_shr,   --审  核 人
      sys_shsj,   --审核时间
      sys_qfr,   --签  发 人
      sys_qfsj,    --签发时间
      dbbj,
      dbsj
    )values(
      lvsdono,   --业务编号
      lvssh_name,   --收货单位名称
      lvssh_dz,   --收货地址
      lvssh_xkz,   --收货许可证编号
      lvssh_fzr,   --收货负责人
      lvssh_lxfs,   --收货负责人联系方式
      lvssh_jbr,   --收货经办人
      lvssh_jbr_pid,   --收货经办人姓名
      lvssh_jbr_lxfs,   --收货经办人联系方式
      lvsgh_name,   --供货单位名称
      lvsgh_dz,   --供货地址
      lvsgh_xkz,   --供货许可证编号
      lvsgh_fzr,   --供货负责人
      lvsgh_lxfs,   --供货负责人联系方式
      lvsys_name,   --承运单位名称
      lvsys_dz,   --承运地址
      lvsys_zzzm,   --承运资质证明编号
      lvsys_fzr,   --承运负责人
      lvsys_lxfs,   --承运负责人联系方式
      lvsys_jsy,   --驾  驶 员
      lvsys_jsy_zzzm,   --驾驶员资质证明
      lvsys_jsy_lxfs,   --驾驶员联系方式
      lvsys_yy,   --押  运 员
      lvsys_yy_zzzm,   --押运员资质证明
      lvsys_yy_lxfs,   --押运员联系方式
      lvsys_car_zmbh,   --道路运输证明编号
      lvsys_car,   --运输车牌号
      lvsys_time_start,   --运输开始时间
      lvsys_time_end,   --运输结束时间
      lvsys_addr_start,   --运输起始地点
      lvsys_addr_middle,   --经停地点
      lvsys_addr_end,   --运输结束地点
      lvsys_bz,   --备　　注
      lvsys_shr,   --审  核 人
      lvsys_shsj,   --审核时间
      lvsys_qfr,   --签  发 人

      lvsys_qfsj  ,  --签发时间
      '0',
      sysdate
    );
   -- 返回值

END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_mb_yssq
    Set
      sdono=lvsdono,   --业务编号
      ssh_name=lvssh_name,   --收货单位名称
      ssh_dz=lvssh_dz,   --收货地址
      ssh_xkz=lvssh_xkz,   --收货许可证编号
      ssh_fzr=lvssh_fzr,   --收货负责人
      ssh_lxfs=lvssh_lxfs,   --收货负责人联系方式
      ssh_jbr=lvssh_jbr,   --收货经办人
      ssh_jbr_pid=lvssh_jbr_pid,   --收货经办人姓名
      ssh_jbr_lxfs=lvssh_jbr_lxfs,   --收货经办人联系方式
      sgh_name=lvsgh_name,   --供货单位名称
      sgh_dz=lvsgh_dz,   --供货地址
      sgh_xkz=lvsgh_xkz,   --供货许可证编号
      sgh_fzr=lvsgh_fzr,   --供货负责人
      sgh_lxfs=lvsgh_lxfs,   --供货负责人联系方式
      sys_name=lvsys_name,   --承运单位名称
      sys_dz=lvsys_dz,   --承运地址
      sys_zzzm=lvsys_zzzm,   --承运资质证明编号
      sys_fzr=lvsys_fzr,   --承运负责人
      sys_lxfs=lvsys_lxfs,   --承运负责人联系方式
      sys_jsy=lvsys_jsy,   --驾  驶 员
      sys_jsy_zzzm=lvsys_jsy_zzzm,   --驾驶员资质证明
      sys_jsy_lxfs=lvsys_jsy_lxfs,   --驾驶员联系方式
      sys_yy=lvsys_yy,   --押  运 员
      sys_yy_zzzm=lvsys_yy_zzzm,   --押运员资质证明
      sys_yy_lxfs=lvsys_yy_lxfs,   --押运员联系方式
      sys_car_zmbh=lvsys_car_zmbh,   --道路运输证明编号
      sys_car=lvsys_car,   --运输车牌号
      sys_time_start=lvsys_time_start,   --运输开始时间
      sys_time_end=lvsys_time_end,   --运输结束时间
      sys_addr_start=lvsys_addr_start,   --运输起始地点
      sys_addr_middle=lvsys_addr_middle,   --经停地点
      sys_addr_end=lvsys_addr_end,   --运输结束地点
      sys_bz=lvsys_bz,   --备　　注
      sys_shr=lvsys_shr,   --审  核 人
      sys_shsj=lvsys_shsj,   --审核时间
      sys_qfr=lvsys_qfr,   --签  发 人
      sys_qfsj=lvsys_qfsj ,   --签发时间
      dbbj='0',
      dbsj=sysdate
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_mb_yssq
    Set
      sdono=lvsdono,   --业务编号
      ssh_name=lvssh_name,   --收货单位名称
      ssh_dz=lvssh_dz,   --收货地址
      ssh_xkz=lvssh_xkz,   --收货许可证编号
      ssh_fzr=lvssh_fzr,   --收货负责人
      ssh_lxfs=lvssh_lxfs,   --收货负责人联系方式
      ssh_jbr=lvssh_jbr,   --收货经办人
      ssh_jbr_pid=lvssh_jbr_pid,   --收货经办人姓名
      ssh_jbr_lxfs=lvssh_jbr_lxfs,   --收货经办人联系方式
      sgh_name=lvsgh_name,   --供货单位名称
      sgh_dz=lvsgh_dz,   --供货地址
      sgh_xkz=lvsgh_xkz,   --供货许可证编号
      sgh_fzr=lvsgh_fzr,   --供货负责人
      sgh_lxfs=lvsgh_lxfs,   --供货负责人联系方式
      sys_name=lvsys_name,   --承运单位名称
      sys_dz=lvsys_dz,   --承运地址
      sys_zzzm=lvsys_zzzm,   --承运资质证明编号
      sys_fzr=lvsys_fzr,   --承运负责人
      sys_lxfs=lvsys_lxfs,   --承运负责人联系方式
      sys_jsy=lvsys_jsy,   --驾  驶 员
      sys_jsy_zzzm=lvsys_jsy_zzzm,   --驾驶员资质证明
      sys_jsy_lxfs=lvsys_jsy_lxfs,   --驾驶员联系方式
      sys_yy=lvsys_yy,   --押  运 员
      sys_yy_zzzm=lvsys_yy_zzzm,   --押运员资质证明
      sys_yy_lxfs=lvsys_yy_lxfs,   --押运员联系方式
      sys_car_zmbh=lvsys_car_zmbh,   --道路运输证明编号
      sys_car=lvsys_car,   --运输车牌号
      sys_time_start=lvsys_time_start,   --运输开始时间
      sys_time_end=lvsys_time_end,   --运输结束时间
      sys_addr_start=lvsys_addr_start,   --运输起始地点
      sys_addr_middle=lvsys_addr_middle,   --经停地点
      sys_addr_end=lvsys_addr_end,   --运输结束地点
      sys_bz=lvsys_bz,   --备　　注
      sys_shr=lvsys_shr,   --审  核 人
      sys_shsj=lvsys_shsj,   --审核时间
      sys_qfr=lvsys_qfr,   --签  发 人
      sys_qfsj=lvsys_qfsj ,   --签发时间
      dbbj='0',
      dbsj=sysdate
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_mb_yssq
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

