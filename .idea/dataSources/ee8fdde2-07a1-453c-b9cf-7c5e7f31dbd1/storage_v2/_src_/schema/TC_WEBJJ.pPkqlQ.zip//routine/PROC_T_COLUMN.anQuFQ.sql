create PROCEDURE          PROC_t_column   /*栏目*/
(
 lvnno IN OUT NUMBER,  --栏目编号
 lvnparentno NUMBER,  --父栏目编号
 lvscolname VARCHAR2,  --栏目名称
 lvscoltype VARCHAR2,  --栏目类型
 lvspic VARCHAR2,  --引导图片
 lvnorder NUMBER,  --排　　序
 lvspri VARCHAR2,  --权限设置
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
    Select tc_webjj.SEQ_T_COLUMN_NNO.Nextval  into lvnno From dual;    /*栏目编号序列*/
   INSERT into tc_webjj.t_column
    (
      nno,   --栏目编号
      nparentno,   --父栏目编号
      scolname,   --栏目名称
      scoltype,   --栏目类型
      spic,   --引导图片
      norder,   --排　　序
      spri    --权限设置
    )values(
      lvnno,   --栏目编号
      lvnparentno,   --父栏目编号
      lvscolname,   --栏目名称
      lvscoltype,   --栏目类型
      lvspic,   --引导图片
      lvnorder,   --排　　序
      lvspri    --权限设置
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_column
    Set
      nno=lvnno,   --栏目编号
      nparentno=lvnparentno,   --父栏目编号
      scolname=lvscolname,   --栏目名称
      scoltype=lvscoltype,   --栏目类型
      spic=lvspic,   --引导图片
      norder=lvnorder,   --排　　序
      spri=lvspri    --权限设置
    Where 1=1
    and nno=lvnno   --栏目编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_column
    Set
      nno=lvnno,   --栏目编号
      nparentno=lvnparentno,   --父栏目编号
      scolname=lvscolname,   --栏目名称
      scoltype=lvscoltype,   --栏目类型
      spic=lvspic,   --引导图片
      norder=lvnorder,   --排　　序
      spri=lvspri    --权限设置
    Where 1=1
    and nno=lvnno   --栏目编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_column
    Where 1=1
    and nno=lvnno   --栏目编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

