create view V_DOBUS2011 as
  select A.SDODATA,A."SDONO",A."SBUSNO",A."SDOUNIT",A."SDOUNITNO",A."SUSERNO",A."STATE",A."SBOOKING",A."DBOOKINGDATE",A."SNOTEALERT",A."NCHARGE",A."NSERCHARGE",A."NEXPCHARGE",A."NRECHARGE",A."SEXPNO",A."SEXPADDRESS",A."SEXPPOSTCODE",A."SCONSIGNEE",A."SCONTEL",A."SNETBUS",A."SRENO",A."SREADDRESS",A."SREPOSTCODE",A."SRECON",A."SRECONTEL",A."DDECDATE",A."SCHECKER",A."DCHECKDATE",A."SACCEPTMAN",A."SACCEPTDATE",A."SUNREASON",A."SOPINION",A."SSERATTITUDE",A."SEFFICIENCY",A."SSATISFACTION",A."SOPDATE" ,B.Sbsort,B.Sssort,B.SDOBUS,B.SDOBOOKING,B.SSTATUS,B.Dokdate, C."SLOGIN_ID",C."SPWD",C."PERSONID",C."NAME",C."PID",C."DOB",C."GENDER",C."NATION",C."MARRIAGE",C."NATIVE_PLACE",C."NATAL",C."SNOW_FULL_ADDR",C."SSWITCH_VISAGE",C."EDU_DEGREE",C."SOTHER_INFO",C."SHUJI_REGION",C."SHUJI_FULL_ADDR",C."SSPECIALITY",C."STASTE",C."SUSER_KIND",C."SLOGIN_TYPE",C."WHO_LOGGED",C."WHO_UNIT",C."WHEN_LOGGED",C."SSTATE",C."SWORK_STORY",C."SHOME_PHONE",C."SINTERNET_MAIL",C."NAREAID",C."SUNITCODE",C."DBBJ",C."DBSJ",C."QUESTION",C."ANSWER",C."QQ" ,

decode(a.state,'10','<img src=''/webjjcss/waitsubmit.gif'' />待提交',
'11','<img src=''/webjjcss/money.gif'' />待支付',
'12','<img src=''/webjjcss/ems.gif'' />待寄送原件',
'25','<img src=''/webjjcss/emsback.gif'' />原件已寄出',
'20','<img src=''/webjjcss/doing.gif'' />办理中',
'21','<img src=''/webjjcss/doing.gif'' />已审核',
'22','<img src=''/webjjcss/doing.gif'' />受理中',

'25','<img src=''/webjjcss/doing.gif'' />已上报省厅制证',
'26','<img src=''/webjjcss/doing.gif'' />省厅制证下发中',

'23','<img src=''/webjjcss/ems.gif'' />需回寄资料',
'24','<img src=''/webjjcss/tel.gif'' />预约中',

'50','<img src=''/webjjcss/doing.gif'' />审批中',
'51','<img src=''/webjjcss/doing.gif'' />已审批',
'52','<img src=''/webjjcss/emsback.gif'' />资料回寄中',

'610','已受理签发机关未审核->22',
'611','签发机关已审核未签发->22',
'620','已签发未质检->22',
'621','已质检等待上传省厅->22',
'630','已上传省厅未反馈->25',
'640','制证信息已反馈未分所-26',
'641','已分所未下发->26',
'650','已下发派出所未接收-26',
'651','派出所已接收未发证->23',
'690','被错办撤消 ->31',
'691','未上传省厅且存在质量反馈->22',
'692','存在省厅质量反馈->22',
'693','已发证 ->41',

'31','<img src=''/webjjcss/error.gif'' />退回<BR>('||SUNREASON||')',
'32','<img src=''/webjjcss/error.gif'' />已退款<BR>('||SUNREASON||')',
'33','<img src=''/webjjcss/error.gif'' />预约失败<BR>('||SUNREASON||')',
'34','申请退款中',
'35','<img src=''/webjjcss/error.gif'' />关闭<BR>('||SUNREASON||')',
'36','<img src=''/webjjcss/error.gif'' />关闭(已退款)<BR>('||SUNREASON||')',

'41','<img src=''/webjjcss/ok.gif'' />办理成功',
'42','<img src=''/webjjcss/ok.gif'' />预约成功',
'43','<img src=''/webjjcss/ok.gif'' />完成') as stateCn ,


B.Sssort||decode(B.SDOBUS,null,'','.'||B.SDOBUS)||decode(sbooking,'1','(预约)','') as sbusname  ,

decode(state,'10','<a href='''||b.surl||'step=3=PMSUBMIT=PMUPDATE='||b.sbusno||'='||sdono||'='||sbooking||'''><img src=''/webjjcss/submit.gif'' /><font color=blue>提 交</font></a><br><a href='''||b.surl||'=2=PMSAVE=PMUPDATE='||b.sbusno||'='||sdono||'='||sbooking||'''><img src=''/webjjcss/edit.gif'' /><font color=blue>编 辑</font></a>' ,
 '12','<a href=''/webjjnet/t_ems_send.jsp?step=5=PMUPDATE='||b.sbusno||'='||sdono||'='||sbooking||'''><img src=''/webjjcss/ems.gif'' /><font color=blue>寄送原件</font></a>',
 '25','<img src=''/webjjcss/wait.gif'' />等待...<br><a target=''_ems'' href=''/webjjnet/t_expressinterface_edit.jsp?step=2=PMDETAIL='||b.sbusno||'='||sdono||'='||sexpno||'''><font color=blue>寄送物流状态</font></a>',
 '11','<a href=''/webjjnet/t_charge_edit.jsp?step=4=PMUPDATE='||sdono||'='||sbooking||'''><img src=''/webjjcss/money.gif'' /><font color=blue>支付</font></a>',
 '41','<a href=''/webjjnet/t_opinion_edit.jsp?step=8=PMUPDATE='||sdono||'='||sbooking||'''><img src=''/webjjcss/pj.gif'' /><font color=blue>评价</font></a>',
 '42','<a href=''/webjjnet/t_opinion_edit.jsp?step=8=PMUPDATE='||sdono||'='||sbooking||'''><img src=''/webjjcss/pj.gif'' /><font color=blue>评价</font></a>',
 '31',decode(ncharge,0,'<a href='''||b.surl||'step=2=PMREDO='||b.sbusno||'='||sdono||'='||sbooking||'''><img src=''/webjjcss/reedit.gif'' /><font color=blue>重新编辑</font></a>','<br><a href=''/webjjnet/t_charge_back.jsp?step=2=PMUPDATE='||sdono||'''><img src=''/webjjcss/remoney.gif'' /><font color=blue>申请退款</font></a>'),
 '33',decode(ncharge,0,'<a href='''||b.surl||'step=2=PMREDO='||b.sbusno||'='||sdono||'='||sbooking||'''><img src=''/webjjcss/reedit.gif'' /><font color=blue>重新预约</font></a>','<br><a href=''/webjjnet/t_charge_back.jsp?step=2=PMUPDATE='||sdono||'''><img src=''/webjjcss/remoney.gif'' /><font color=blue>申请退款</font></a>'),
 '32',decode(sbooking,'1','<a href='''||b.surl||'step=2=PMREDO='||b.sbusno||'='||sdono||'='||sbooking||'''><img src=''/webjjcss/reedit.gif'' /><font color=blue>重新预约</font></a>','<a href='''||b.surl||'step=2=PMREDO='||b.sbusno||'='||sdono||'='||sbooking||'''><img src=''/webjjcss/reedit.gif'' /><font color=blue>重新编辑</font></a>'),
 '52','<a href=''/webjjnet/t_check_ems.jsp?step=7procmode=PMUPDATE='||sdono||'='||sbooking||'''><img src=''/webjjcss/getems.gif'' /><font color=blue>确认收件</font></a><br><a target=''_ems'' href=''/webjjnet/t_expressinterface_edit.jsp?step=2=PMDETAIL='||sdono||'='||SRENO||'''><font color=blue>回寄物流状态</font></a>',
   '32','',
   '35','',
   '36','',
   '43','',
   '<img src=''/webjjcss/wait.gif'' />等待...'
 )  as stateop ,



 decode(state,'10','<a href='''||b.surl||'=3=PMDETAIL=PMDETAIL='||sdono||'='||sbooking||'''>',
 '11','<a href='''||b.surl||'=4=PMDETAIL=PMDETAIL='||sdono||'='||sbooking||'''>',
 '41','<a href='''||b.surl||'=8=PMDETAIL=PMDETAIL='||sdono||'='||sbooking||'''>',
  '42','<a href='''||b.surl||'=8=PMDETAIL=PMDETAIL='||sdono||'='||sbooking||'''>',
    '43','<a href='''||b.surl||'=9=PMDETAIL=PMDETAIL='||sdono||'='||sbooking||'''>',
  '31','<a href='''||b.surl||'=0=PMDETAIL=PMDETAIL='||sdono||'='||sbooking||'''>',
   '33','<a href='''||b.surl||'=0=PMDETAIL=PMDETAIL='||sdono||'='||sbooking||'''>',
   '25','<a href='''||b.surl||'=6=PMDETAIL=PMDETAIL='||sdono||'='||sbooking||'''>',
   '32','<a href='''||b.surl||'=5=PMDETAIL=PMDETAIL='||sdono||'='||sbooking||'''>',
    '<a href='''||b.surl||'=5=PMDETAIL=PMDETAIL='||sdono||'='||sbooking||'''>'
 )||'<font color=blue>' ||SDODATA||'</font></a>'  as slinkdetail ,

   '￥'||decode(round(a.NCHARGE),0,'0')||decode(NCHARGe,0,'',NCHARGe)||'元'||decode(a.NRECHARGE,0,'',null,'','<br>(含快递'||a.NRECHARGE||'元)') as  sCHARGE ,

  decode(a.NRECHARGE,0,'',null,'','需回寄') as  need_back,
   decode(a.sbooking,0,'否',null,'否','是') as booking_need,

   decode(SSATISFACTION,'1','<img src=''/webjjcss/pj1.gif'' />非常满意',
   '2','<img src=''/webjjcss/pj2.gif'' />很满意',
   '3','<img src=''/webjjcss/pj3.gif'' />一般',
   '4','<img src=''/webjjcss/pj4.gif'' />不满意',
   '' )  as SSATISFACTIONIMg

from    tc_webjj.t_dobus A  , tc_webjj.t_bus_deploy  B   , tc_webjj.t_commoner C    Where A.sbusno=B.sbusno and  A.suserNo=C.personid
/

