create PROCEDURE          PROC_t_gasw_xxhc   /*T_GASW_XXHC*/
(
 lvsdono IN OUT VARCHAR2,  --业务编号
 lvsname VARCHAR2,  --单位名称
 lvszcbh VARCHAR2,  --工商注册号
 lvsdz VARCHAR2,  --单位地址
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
   INSERT into tc_webjj.t_gasw_xxhc
    (
      sdono,   --业务编号
      sname,   --单位名称
      szcbh,   --工商注册号
      sdz ,   --单位地址
      dbbj,
      dbsj
    )values(
      lvsdono,   --业务编号
      lvsname,   --单位名称
      lvszcbh,   --工商注册号
      lvsdz ,   --单位地址
      '0',
      sysdate
    );
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_gasw_xxhc
    Set
      sdono=lvsdono,   --业务编号
      sname=lvsname,   --单位名称
      szcbh=lvszcbh,   --工商注册号
      sdz=lvsdz,    --单位地址
      dbbj='0',
      dbsj=sysdate
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_gasw_xxhc
    Set
      sdono=lvsdono,   --业务编号
      sname=lvsname,   --单位名称
      szcbh=lvszcbh,   --工商注册号
      sdz=lvsdz ,   --单位地址
        dbbj='0',
      dbsj=sysdate
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_gasw_xxhc
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

