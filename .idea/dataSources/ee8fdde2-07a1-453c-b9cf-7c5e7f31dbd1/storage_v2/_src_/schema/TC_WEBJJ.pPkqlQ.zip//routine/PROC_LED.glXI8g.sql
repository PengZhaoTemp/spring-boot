create procedure          proc_led authid current_user
(vsql  varchar2,vsql1 varchar2,num number)
 is
   vsql varchar2(2000);
begin
  if num>0   then
     execute  immediate  vsql;
  end if;
     execute  immediate  vsql1;

end;
/

