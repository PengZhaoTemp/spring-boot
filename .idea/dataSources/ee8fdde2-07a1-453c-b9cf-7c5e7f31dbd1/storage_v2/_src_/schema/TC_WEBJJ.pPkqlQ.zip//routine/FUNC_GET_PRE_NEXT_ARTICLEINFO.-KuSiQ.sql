create FUNCTION          FUNC_GET_PRE_NEXT_ARTICLEINFO(lv_ARTICLE_SID varchar2,
                                                         lv_GROUP_SID   varchar2,
                                                         lv_GENERA_SID  varchar2,
                                                         lv_SPLIT_TAG   varchar2,
                                                         lv_TYPE        varchar2)

 Return VarChar2 is
  lv_ARTICLE_INFO VarChar2(600);

Begin
  lv_ARTICLE_INFO := '';
  if lv_TYPE = 'PRE' then
    for r in (select ARTICLE_TITLE,
                     ARTICLE_SID,
                     genera_sid,
                     group_sid,
                     BOOKINUSERNAME,
                     PUTOUTTIME,
                     BOOKINORGNAME,
                     to_char(PUTOUTTIME, 'YYYY-MM-DD') as putoutdate
                from (select *
                        from TC_WEBJJ.T_ARTICLE_INFO
                       where orglevel = 2
                         and group_sid = lv_GROUP_SID
                         and genera_sid = lv_GENERA_SID
                      and checkstate = '2'
                      )
               where ARTICLE_SID =
                     (select c.p
                        from (select ARTICLE_SID,
                                     lag(ARTICLE_SID, 1, 0) over(order by ARTICLE_SID) as p
                                from (select *
                                        from TC_WEBJJ.T_ARTICLE_INFO
                                       where orglevel = 2
                                         and group_sid = lv_GROUP_SID
                                         and genera_sid = lv_GENERA_SID
                                      and checkstate = '2'
                                      )) c
                       where c.ARTICLE_SID = lv_ARTICLE_SID)) loop
      lv_ARTICLE_INFO := r.putoutdate || lv_SPLIT_TAG || r.ARTICLE_TITLE ||
                         lv_SPLIT_TAG || r.ARTICLE_SID;
    end loop;
  elsif lv_TYPE = 'NEXT' then
    for r in (select ARTICLE_TITLE,
                     ARTICLE_SID,
                     genera_sid,
                     group_sid,
                     BOOKINUSERNAME,
                     PUTOUTTIME,
                     BOOKINORGNAME,
                     to_char(PUTOUTTIME, 'YYYY-MM-DD') as putoutdate
                from (select *
                        from TC_WEBJJ.T_ARTICLE_INFO
                       where orglevel = 2
                         and group_sid = lv_GROUP_SID
                         and genera_sid = lv_GENERA_SID
                         and checkstate = '2')
               where ARTICLE_SID =
                     (select c.p
                        from (select ARTICLE_SID,
                                     lead(ARTICLE_SID, 1, 0) over(order by ARTICLE_SID) as p
                                from (select *
                                        from TC_WEBJJ.T_ARTICLE_INFO
                                       where orglevel = 2
                                         and group_sid = lv_GROUP_SID
                                         and genera_sid = lv_GENERA_SID
                                         and checkstate = '2')) c
                       where c.ARTICLE_SID = lv_ARTICLE_SID)) loop
      lv_ARTICLE_INFO := r.putoutdate || lv_SPLIT_TAG || r.ARTICLE_TITLE ||
                         lv_SPLIT_TAG || r.ARTICLE_SID;
    end loop;
  end if;
  Return(lv_ARTICLE_INFO);
End FUNC_GET_PRE_NEXT_ARTICLEINFO;

/

