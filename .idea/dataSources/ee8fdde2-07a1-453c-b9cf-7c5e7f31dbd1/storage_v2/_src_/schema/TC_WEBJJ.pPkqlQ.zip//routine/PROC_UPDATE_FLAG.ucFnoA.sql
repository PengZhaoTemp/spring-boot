create procedure proc_update_flag as
begin
  update tc_webjj.UPDATE_FLAG set state='1', flag='Y',up_date=sysdate where state='0' and flag='N';
  commit;
end;
/

