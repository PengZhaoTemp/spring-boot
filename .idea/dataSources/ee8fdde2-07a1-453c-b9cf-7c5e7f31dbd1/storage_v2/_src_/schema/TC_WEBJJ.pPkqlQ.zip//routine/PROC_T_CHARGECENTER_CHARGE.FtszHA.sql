create PROCEDURE          PROC_t_chargecenter_charge(
 lvschargeno IN OUT VARCHAR2,  --支付编号
 lvsdono VARCHAR2,  --办理编号
 lvsuserno VARCHAR2,  --用户编码
 lvsaccounts VARCHAR2,  --账　　号
 lvsdealacc VARCHAR2,  --交易账号
 lvnmoney NUMBER,  --金　　额
 lvsmemo VARCHAR2,  --备　　注
 lvddealdate DATE,  --交易时间
 lvnsercharge NUMBER,  --服务资费
 lvnexpcharge NUMBER,  --快递资费
 lvnrecharge NUMBER,  --回寄资费
 lvsemssend varchar2,--是否寄送
 lvsbooking varchar2,--是否预约
 lvmerabbr  varchar2,--商户名称
 lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS
lvflowstep number;
lvsbusno varchar2(5);
lvflownote number;
lvcnt  number;
lvcnt1  number;
BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/
    Select tc_webjj.fun_get16code(tc_WEBJJ.SEQ_T_CHARGECENTER_SCHARGENO.Nextval)  into lvschargeno From dual;    /*支付编号序列*/
    select flowstep+1,sbusno into lvflowstep,lvsbusno from tc_webjj.v_dobus where sdono=lvsdono;
    select busflowno into lvflownote from tc_webjj.t_bus_flow where sbusno = lvsbusno and flowstep=lvflowstep;
    select count(*) cn into lvcnt1 from tc_webjj.t_chargecenter where sdono = lvsdono;
    delete from tc_webjj.t_chargecenter where sdono = lvsdono and merabbr = lvmerabbr;
    if lvnsercharge = '0' or lvnrecharge = '0' then
         delete from tc_webjj.t_chargecenter where sdono=lvsdono ;
         UPDATE tc_webjj.t_dobus
         set
           state='21',
           dbbj='0',
           dbsj=sysdate,
           flownote = lvflownote
         where sdono=lvsdono;
    end if;
    -- delete from tc_webjj.t_chargecenter where sdono=lvsdono ;
   if lvcnt1 < 2 then
   INSERT into tc_webjj.t_chargecenter
    (
      schargeno,   --支付编号
      sdono,   --办理编号
      suserno,   --用户编码
      saccounts,   --账　　号
      sdealacc,   --交易账号
      nmoney,   --金　　额
      smemo,   --备　　注
      ddealdate,   --交易时间
      nsercharge,   --服务资费
      nexpcharge,   --快递资费
      nrecharge,    --回寄资费
      merabbr,
      dbbj,
      dbsj
    )values(
      lvschargeno,   --支付编号
      lvsdono,   --办理编号
      lvsuserno,   --用户编码
      lvsaccounts,   --账　　号
      lvsdealacc,   --交易账号
      lvnmoney,   --金　　额
      lvsmemo,   --备　　注
      sysdate,   --交易时间
      lvnsercharge,   --服务资费
      lvnexpcharge,   --快递资费
      lvnrecharge,    --回寄资费
      lvmerabbr,
      '0',
      sysdate
    );
   end if;
    select count(*) cn into lvcnt from tc_webjj.t_chargecenter where sdono = lvsdono;
    if lvnsercharge <> '0' or lvnrecharge <> '0' then
       if lvcnt = 2 then
         UPDATE tc_webjj.t_dobus
         set
           state='21',
           dbbj='0',
           dbsj=sysdate,
           flownote = lvflownote
         where sdono=lvsdono;
       end if;
    end if;
   -- 返回值
END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_chargecenter
    Set
      schargeno=lvschargeno,   --支付编号
      sdono=lvsdono,   --办理编号
      suserno=lvsuserno,   --用户编码
      saccounts=lvsaccounts,   --账　　号
      sdealacc=lvsdealacc,   --交易账号
      nmoney=lvnmoney,   --金　　额
      smemo=lvsmemo,   --备　　注
      ddealdate=lvddealdate,   --交易时间
      nsercharge=lvnsercharge,   --服务资费
      nexpcharge=lvnexpcharge,   --快递资费
      nrecharge=lvnrecharge,    --回寄资费
      merabbr=lvmerabbr,
      dbbj='0',
      dbsj=sysdate
    Where 1=1
    and schargeno=lvschargeno   --支付编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_chargecenter
    Set
      schargeno=lvschargeno,   --支付编号
      sdono=lvsdono,   --办理编号
      suserno=lvsuserno,   --用户编码
      saccounts=lvsaccounts,   --账　　号
      sdealacc=lvsdealacc,   --交易账号
      nmoney=lvnmoney,   --金　　额
      smemo=lvsmemo,   --备　　注
      ddealdate=lvddealdate,   --交易时间
      nsercharge=lvnsercharge,   --服务资费
      nexpcharge=lvnexpcharge,   --快递资费
      nrecharge=lvnrecharge,   --回寄资费
      dbbj='0',
      dbsj=sysdate
    Where 1=1
    and schargeno=lvschargeno   --支付编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_chargecenter
    Where 1=1
    and schargeno=lvschargeno   --支付编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

