create FUNCTION          TO_HEX( P_DEC IN NUMBER ) RETURN VARCHAR2
is
begin
  return to_base( p_dec, 16 );
end to_hex;

/

