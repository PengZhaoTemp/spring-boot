create PROCEDURE          PROC_t_mbwp_sq   /*T_MBWP_SQ*/
(
 lvsdono IN OUT VARCHAR2,  --业务编号
 lvsq_unit VARCHAR2,  --申请单位名称
 lvstel VARCHAR2,  --联系号码
 lvsddtj_ms VARCHAR2,  --储存地点、安全条件描述
 lvsyt_ms VARCHAR2,  --用途说明0生产1销售2使用
 lvsyhzh VARCHAR2,  --银行账户
 lvswpmc_zy1 VARCHAR2,  --物品名称
 lvskrl_zy1 VARCHAR2,  --库  容 量
 lvsxycl_zy1 VARCHAR2,  --现有储量
 lvssqsl_zy1 VARCHAR2,  --申请数量
 lvsbzcl_zy1 VARCHAR2,  --包装材料及方式
 lvsol1 VARCHAR2,  --备  注 1
 lvswpmc_zy2 VARCHAR2,  --物品名称
 lvskrl_zy2 VARCHAR2,  --库  容 量
 lvsxycl_zy2 VARCHAR2,  --现有储量
 lvssqsl_zy2 VARCHAR2,  --申请数量
 lvsbzcl_zy2 VARCHAR2,  --包装材料及方式
 lvswpmc_zy3 VARCHAR2,  --物品名称
 lvskrl_zy3 VARCHAR2,  --库  容 量
 lvsxycl_zy3 VARCHAR2,  --现有储量
 lvssqsl_zy3 VARCHAR2,  --申请数量
 lvsbzcl_zy3 VARCHAR2,  --包装材料及方式
 lvswpmc_lg1 VARCHAR2,  --物品名称
 lvskrl_lg1 VARCHAR2,  --库  容 量
 lvsxycl_lg1 VARCHAR2,  --现有储量
 lvssqsl_lg1 VARCHAR2,  --申请数量
 lvsbzcl_lg1 VARCHAR2,  --包装材料及方式
 lvswpmc_lg2 VARCHAR2,  --物品名称
 lvskrl_lg2 VARCHAR2,  --库  容 量
 lvsxycl_lg2 VARCHAR2,  --现有储量
 lvssqsl_lg2 VARCHAR2,  --申请数量
 lvsbzcl_lg2 VARCHAR2,  --包装材料及方式
 lvswpmc_lg3 VARCHAR2,  --物品名称
 lvskrl_lg3 VARCHAR2,  --库  容 量
 lvsxycl_lg3 VARCHAR2,  --现有储量
 lvssqsl_lg3 VARCHAR2,  --申请数量
 lvsbzcl_lg3 VARCHAR2,  --包装材料及方式
 lvswpmc_sl1 VARCHAR2,  --物品名称
 lvskrl_sl1 VARCHAR2,  --库  容 量
 lvsxycl_sl1 VARCHAR2,  --现有储量
 lvssqsl_sl1 VARCHAR2,  --申请数量
 lvsbzcl_sl1 VARCHAR2,  --包装材料及方式
 lvswpmc_sl2 VARCHAR2,  --物品名称
 lvskrl_sl2 VARCHAR2,  --库  容 量
 lvsxycl_sl2 VARCHAR2,  --现有储量
 lvssqsl_sl2 VARCHAR2,  --申请数量
 lvsbzcl_sl2 VARCHAR2,  --包装材料及方式
 lvswpmc_sl3 VARCHAR2,  --物品名称
 lvskrl_sl3 VARCHAR2,  --库  容 量
 lvsxycl_sl3 VARCHAR2,  --现有储量
 lvssqsl_sl3 VARCHAR2,  --申请数量
 lvsbzcl_sl3 VARCHAR2,  --包装材料及方式
 lvswpmc_qt1 VARCHAR2,  --物品名称
 lvskrl_qt1 VARCHAR2,  --库  容 量
 lvsxycl_qt1 VARCHAR2,  --现有储量
 lvssqsl_qt1 VARCHAR2,  --申请数量
 lvsbzcl_qt1 VARCHAR2,  --包装材料及方式
 lvsgh_unit VARCHAR2,  --供货单位名称
 lvsgh_address VARCHAR2,  --地　　址
 lvsgh_xkz VARCHAR2,  --许可证号
 lvsgh_yhzh VARCHAR2,  --银行账户
 lvsgh_lxr VARCHAR2,  --联  系 人
 lvsgh_tel VARCHAR2,  --联系号码
 lvscy_unit VARCHAR2,  --承运单位名称
 lvscy_zzzh VARCHAR2,  --资质证号
 lvscy_start_time VARCHAR2,  --运输开始时间
 lvscy_end_time VARCHAR2,  --运输结束时间
 lvscy_tel VARCHAR2,  --联系号码
 lvscy_lx1 VARCHAR2,  --运输路线 1
 lvscy_lx2 VARCHAR2,  --运输路线 2
 lvscy_lx3 VARCHAR2,  --运输路线 3
 lvscy_lx4 VARCHAR2,  --运输路线 4
 lvscy_lx5 VARCHAR2,  --运输路线 5
 lvscy_lx6 VARCHAR2,  --运输路线 6
 lvscy_lx7 VARCHAR2,  --运输路线 7
 lvscy_lx8 VARCHAR2,  --运输路线 8
 lvscy_lx9 VARCHAR2,  --运输路线 9
 lvscy_lx10 VARCHAR2,  --运输路线 10
 lvscy_lx11 VARCHAR2,  --运输路线 11
 lvscy_lx12 VARCHAR2,  --运输路线 12
 lvssub_time DATE,  --提交时间
 lvssh_time DATE,  --审核通过时间
 lvssh_person VARCHAR2,  --审  核 人
 lvssh_unit VARCHAR2,  --审核人单位
 lvsol2 varchar2,--备注2
lv_ProcMode Varchar2    /* 存储模式 PMINSERT,PMUPDATE,PMCANCEL,PMDELETE*/
)
AS

BEGIN
  --begin TRAN
IF lv_procMode='PMINSERT' THEN    /*登记*/



   INSERT into tc_webjj.t_mbwp_sq
    (
      sdono,   --业务编号
      sq_unit,   --申请单位名称
      stel,   --联系号码
      sddtj_ms,   --储存地点、安全条件描述
      syt_ms,   --用途说明0生产1销售2使用
      syhzh,   --银行账户
      swpmc_zy1,   --物品名称
      skrl_zy1,   --库  容 量
      sxycl_zy1,   --现有储量
      ssqsl_zy1,   --申请数量
      sbzcl_zy1,   --包装材料及方式
      sol1,   --备  注 1
      swpmc_zy2,   --物品名称
      skrl_zy2,   --库  容 量
      sxycl_zy2,   --现有储量
      ssqsl_zy2,   --申请数量
      sbzcl_zy2,   --包装材料及方式
      swpmc_zy3,   --物品名称
      skrl_zy3,   --库  容 量
      sxycl_zy3,   --现有储量
      ssqsl_zy3,   --申请数量
      sbzcl_zy3,   --包装材料及方式
      swpmc_lg1,   --物品名称
      skrl_lg1,   --库  容 量
      sxycl_lg1,   --现有储量
      ssqsl_lg1,   --申请数量
      sbzcl_lg1,   --包装材料及方式
      swpmc_lg2,   --物品名称
      skrl_lg2,   --库  容 量
      sxycl_lg2,   --现有储量
      ssqsl_lg2,   --申请数量
      sbzcl_lg2,   --包装材料及方式
      swpmc_lg3,   --物品名称
      skrl_lg3,   --库  容 量
      sxycl_lg3,   --现有储量
      ssqsl_lg3,   --申请数量
      sbzcl_lg3,   --包装材料及方式
      swpmc_sl1,   --物品名称
      skrl_sl1,   --库  容 量
      sxycl_sl1,   --现有储量
      ssqsl_sl1,   --申请数量
      sbzcl_sl1,   --包装材料及方式
      swpmc_sl2,   --物品名称
      skrl_sl2,   --库  容 量
      sxycl_sl2,   --现有储量
      ssqsl_sl2,   --申请数量
      sbzcl_sl2,   --包装材料及方式
      swpmc_sl3,   --物品名称
      skrl_sl3,   --库  容 量
      sxycl_sl3,   --现有储量
      ssqsl_sl3,   --申请数量
      sbzcl_sl3,   --包装材料及方式
      swpmc_qt1,   --物品名称
      skrl_qt1,   --库  容 量
      sxycl_qt1,   --现有储量
      ssqsl_qt1,   --申请数量
      sbzcl_qt1,   --包装材料及方式
      sgh_unit,   --供货单位名称
      sgh_address,   --地　　址
      sgh_xkz,   --许可证号
      sgh_yhzh,   --银行账户
      sgh_lxr,   --联  系 人
      sgh_tel,   --联系号码
      scy_unit,   --承运单位名称
      scy_zzzh,   --资质证号
      scy_start_time,   --运输开始时间
      scy_end_time,   --运输结束时间
      scy_tel,   --联系号码
      scy_lx1,   --运输路线1
      scy_lx2,   --运输路线2
      scy_lx3,   --运输路线3
      scy_lx4,   --运输路线4
      scy_lx5,   --运输路线5
      scy_lx6,   --运输路线6
      scy_lx7,   --运输路线7
      scy_lx8,   --运输路线8
      scy_lx9,   --运输路线9
      scy_lx10,   --运输路线10
      scy_lx11,   --运输路线11
      scy_lx12,   --运输路线12
      ssub_time,   --提交时间
      ssh_time,   --审核通过时间
      ssh_person,   --审  核 人
      ssh_unit,    --审核人单位
      sol2
    )values(
      lvsdono,   --业务编号
      lvsq_unit,   --申请单位名称
      lvstel,   --联系号码
      lvsddtj_ms,   --储存地点、安全条件描述
      lvsyt_ms,   --用途说明0生产1销售2使用
      lvsyhzh,   --银行账户
      lvswpmc_zy1,   --物品名称
      lvskrl_zy1,   --库  容 量
      lvsxycl_zy1,   --现有储量
      lvssqsl_zy1,   --申请数量
      lvsbzcl_zy1,   --包装材料及方式
      lvsol1,   --备  注 1
      lvswpmc_zy2,   --物品名称
      lvskrl_zy2,   --库  容 量
      lvsxycl_zy2,   --现有储量
      lvssqsl_zy2,   --申请数量
      lvsbzcl_zy2,   --包装材料及方式
      lvswpmc_zy3,   --物品名称
      lvskrl_zy3,   --库  容 量
      lvsxycl_zy3,   --现有储量
      lvssqsl_zy3,   --申请数量
      lvsbzcl_zy3,   --包装材料及方式
      lvswpmc_lg1,   --物品名称
      lvskrl_lg1,   --库  容 量
      lvsxycl_lg1,   --现有储量
      lvssqsl_lg1,   --申请数量
      lvsbzcl_lg1,   --包装材料及方式
      lvswpmc_lg2,   --物品名称
      lvskrl_lg2,   --库  容 量
      lvsxycl_lg2,   --现有储量
      lvssqsl_lg2,   --申请数量
      lvsbzcl_lg2,   --包装材料及方式
      lvswpmc_lg3,   --物品名称
      lvskrl_lg3,   --库  容 量
      lvsxycl_lg3,   --现有储量
      lvssqsl_lg3,   --申请数量
      lvsbzcl_lg3,   --包装材料及方式
      lvswpmc_sl1,   --物品名称
      lvskrl_sl1,   --库  容 量
      lvsxycl_sl1,   --现有储量
      lvssqsl_sl1,   --申请数量
      lvsbzcl_sl1,   --包装材料及方式
      lvswpmc_sl2,   --物品名称
      lvskrl_sl2,   --库  容 量
      lvsxycl_sl2,   --现有储量
      lvssqsl_sl2,   --申请数量
      lvsbzcl_sl2,   --包装材料及方式
      lvswpmc_sl3,   --物品名称
      lvskrl_sl3,   --库  容 量
      lvsxycl_sl3,   --现有储量
      lvssqsl_sl3,   --申请数量
      lvsbzcl_sl3,   --包装材料及方式
      lvswpmc_qt1,   --物品名称
      lvskrl_qt1,   --库  容 量
      lvsxycl_qt1,   --现有储量
      lvssqsl_qt1,   --申请数量
      lvsbzcl_qt1,   --包装材料及方式
      lvsgh_unit,   --供货单位名称
      lvsgh_address,   --地　　址
      lvsgh_xkz,   --许可证号
      lvsgh_yhzh,   --银行账户
      lvsgh_lxr,   --联  系 人
      lvsgh_tel,   --联系号码
      lvscy_unit,   --承运单位名称
      lvscy_zzzh,   --资质证号
      lvscy_start_time,   --运输开始时间
      lvscy_end_time,   --运输结束时间
      lvscy_tel,   --联系号码
      lvscy_lx1 ,  --运输路线 1
       lvscy_lx2,  --运输路线 2
       lvscy_lx3,  --运输路线 3
       lvscy_lx4,  --运输路线 4
       lvscy_lx5,  --运输路线 5
       lvscy_lx6,  --运输路线 6
       lvscy_lx7,  --运输路线 7
       lvscy_lx8,  --运输路线 8
       lvscy_lx9,  --运输路线 9
       lvscy_lx10,  --运输路线 10
       lvscy_lx11,  --运输路线 11
       lvscy_lx12,  --运输路线 12
      sysdate,   --提交时间
      lvssh_time,   --审核通过时间
      lvssh_person,   --审  核 人

      lvssh_unit,    --审核人单位

      lvsol2
    );
   -- 返回值

END IF;
IF lv_procMode='PMUPDATE'  THEN  /*更新*/
   UPDATE tc_webjj.t_mbwp_sq
    Set
      sdono=lvsdono,   --业务编号
      sq_unit=lvsq_unit,   --申请单位名称
      stel=lvstel,   --联系号码
      sddtj_ms=lvsddtj_ms,   --储存地点、安全条件描述
      syt_ms=lvsyt_ms,   --用途说明0生产1销售2使用
      syhzh=lvsyhzh,   --银行账户
      swpmc_zy1=lvswpmc_zy1,   --物品名称
      skrl_zy1=lvskrl_zy1,   --库  容 量
      sxycl_zy1=lvsxycl_zy1,   --现有储量
      ssqsl_zy1=lvssqsl_zy1,   --申请数量
      sbzcl_zy1=lvsbzcl_zy1,   --包装材料及方式
      sol1=lvsol1,   --备  注 1
      swpmc_zy2=lvswpmc_zy2,   --物品名称
      skrl_zy2=lvskrl_zy2,   --库  容 量
      sxycl_zy2=lvsxycl_zy2,   --现有储量
      ssqsl_zy2=lvssqsl_zy2,   --申请数量
      sbzcl_zy2=lvsbzcl_zy2,   --包装材料及方式
      swpmc_zy3=lvswpmc_zy3,   --物品名称
      skrl_zy3=lvskrl_zy3,   --库  容 量
      sxycl_zy3=lvsxycl_zy3,   --现有储量
      ssqsl_zy3=lvssqsl_zy3,   --申请数量
      sbzcl_zy3=lvsbzcl_zy3,   --包装材料及方式
      swpmc_lg1=lvswpmc_lg1,   --物品名称
      skrl_lg1=lvskrl_lg1,   --库  容 量
      sxycl_lg1=lvsxycl_lg1,   --现有储量
      ssqsl_lg1=lvssqsl_lg1,   --申请数量
      sbzcl_lg1=lvsbzcl_lg1,   --包装材料及方式
      swpmc_lg2=lvswpmc_lg2,   --物品名称
      skrl_lg2=lvskrl_lg2,   --库  容 量
      sxycl_lg2=lvsxycl_lg2,   --现有储量
      ssqsl_lg2=lvssqsl_lg2,   --申请数量
      sbzcl_lg2=lvsbzcl_lg2,   --包装材料及方式
      swpmc_lg3=lvswpmc_lg3,   --物品名称
      skrl_lg3=lvskrl_lg3,   --库  容 量
      sxycl_lg3=lvsxycl_lg3,   --现有储量
      ssqsl_lg3=lvssqsl_lg3,   --申请数量
      sbzcl_lg3=lvsbzcl_lg3,   --包装材料及方式
      swpmc_sl1=lvswpmc_sl1,   --物品名称
      skrl_sl1=lvskrl_sl1,   --库  容 量
      sxycl_sl1=lvsxycl_sl1,   --现有储量
      ssqsl_sl1=lvssqsl_sl1,   --申请数量
      sbzcl_sl1=lvsbzcl_sl1,   --包装材料及方式
      swpmc_sl2=lvswpmc_sl2,   --物品名称
      skrl_sl2=lvskrl_sl2,   --库  容 量
      sxycl_sl2=lvsxycl_sl2,   --现有储量
      ssqsl_sl2=lvssqsl_sl2,   --申请数量
      sbzcl_sl2=lvsbzcl_sl2,   --包装材料及方式
      swpmc_sl3=lvswpmc_sl3,   --物品名称
      skrl_sl3=lvskrl_sl3,   --库  容 量
      sxycl_sl3=lvsxycl_sl3,   --现有储量
      ssqsl_sl3=lvssqsl_sl3,   --申请数量
      sbzcl_sl3=lvsbzcl_sl3,   --包装材料及方式
      swpmc_qt1=lvswpmc_qt1,   --物品名称
      skrl_qt1=lvskrl_qt1,   --库  容 量
      sxycl_qt1=lvsxycl_qt1,   --现有储量
      ssqsl_qt1=lvssqsl_qt1,   --申请数量
      sbzcl_qt1=lvsbzcl_qt1,   --包装材料及方式
      sgh_unit=lvsgh_unit,   --供货单位名称
      sgh_address=lvsgh_address,   --地　　址
      sgh_xkz=lvsgh_xkz,   --许可证号
      sgh_yhzh=lvsgh_yhzh,   --银行账户
      sgh_lxr=lvsgh_lxr,   --联  系 人
      sgh_tel=lvsgh_tel,   --联系号码
      scy_unit=lvscy_unit,   --承运单位名称
      scy_zzzh=lvscy_zzzh,   --资质证号
      scy_start_time=lvscy_start_time,   --运输开始时间
      scy_end_time=lvscy_end_time,   --运输结束时间
      scy_tel=lvscy_tel,   --联系号码
      scy_lx1=lvscy_lx1,   --运输路线 1
      scy_lx2=lvscy_lx2,   --运输路线 2
      scy_lx3=lvscy_lx3,   --运输路线 3
      scy_lx4=lvscy_lx4,   --运输路线 4
      scy_lx5=lvscy_lx5,   --运输路线 5
      scy_lx6=lvscy_lx6,   --运输路线 6
      scy_lx7=lvscy_lx7,   --运输路线 7
      scy_lx8=lvscy_lx8,   --运输路线 8
      scy_lx9=lvscy_lx9,   --运输路线 9
      scy_lx10=lvscy_lx10,   --运输路线 10
      scy_lx11=lvscy_lx11,   --运输路线 11
      scy_lx12=lvscy_lx12,   --运输路线 12
      ssub_time=sysdate,   --提交时间
      ssh_time=lvssh_time,   --审核通过时间
      ssh_person=lvssh_person,   --审  核 人
      ssh_unit=lvssh_unit,    --审核人单位
      sol2=lvsol2
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMCANCEL'  THEN  /*注销*/
   UPDATE tc_webjj.t_mbwp_sq
    Set
      sdono=lvsdono,   --业务编号
      sq_unit=lvsq_unit,   --申请单位名称
      stel=lvstel,   --联系号码
      sddtj_ms=lvsddtj_ms,   --储存地点、安全条件描述
      syt_ms=lvsyt_ms,   --用途说明0生产1销售2使用
      syhzh=lvsyhzh,   --银行账户
      swpmc_zy1=lvswpmc_zy1,   --物品名称
      skrl_zy1=lvskrl_zy1,   --库  容 量
      sxycl_zy1=lvsxycl_zy1,   --现有储量
      ssqsl_zy1=lvssqsl_zy1,   --申请数量
      sbzcl_zy1=lvsbzcl_zy1,   --包装材料及方式
      sol1=lvsol1,   --备  注 1
      swpmc_zy2=lvswpmc_zy2,   --物品名称
      skrl_zy2=lvskrl_zy2,   --库  容 量
      sxycl_zy2=lvsxycl_zy2,   --现有储量
      ssqsl_zy2=lvssqsl_zy2,   --申请数量
      sbzcl_zy2=lvsbzcl_zy2,   --包装材料及方式
      swpmc_zy3=lvswpmc_zy3,   --物品名称
      skrl_zy3=lvskrl_zy3,   --库  容 量
      sxycl_zy3=lvsxycl_zy3,   --现有储量
      ssqsl_zy3=lvssqsl_zy3,   --申请数量
      sbzcl_zy3=lvsbzcl_zy3,   --包装材料及方式
      swpmc_lg1=lvswpmc_lg1,   --物品名称
      skrl_lg1=lvskrl_lg1,   --库  容 量
      sxycl_lg1=lvsxycl_lg1,   --现有储量
      ssqsl_lg1=lvssqsl_lg1,   --申请数量
      sbzcl_lg1=lvsbzcl_lg1,   --包装材料及方式
      swpmc_lg2=lvswpmc_lg2,   --物品名称
      skrl_lg2=lvskrl_lg2,   --库  容 量
      sxycl_lg2=lvsxycl_lg2,   --现有储量
      ssqsl_lg2=lvssqsl_lg2,   --申请数量
      sbzcl_lg2=lvsbzcl_lg2,   --包装材料及方式
      swpmc_lg3=lvswpmc_lg3,   --物品名称
      skrl_lg3=lvskrl_lg3,   --库  容 量
      sxycl_lg3=lvsxycl_lg3,   --现有储量
      ssqsl_lg3=lvssqsl_lg3,   --申请数量
      sbzcl_lg3=lvsbzcl_lg3,   --包装材料及方式
      swpmc_sl1=lvswpmc_sl1,   --物品名称
      skrl_sl1=lvskrl_sl1,   --库  容 量
      sxycl_sl1=lvsxycl_sl1,   --现有储量
      ssqsl_sl1=lvssqsl_sl1,   --申请数量
      sbzcl_sl1=lvsbzcl_sl1,   --包装材料及方式
      swpmc_sl2=lvswpmc_sl2,   --物品名称
      skrl_sl2=lvskrl_sl2,   --库  容 量
      sxycl_sl2=lvsxycl_sl2,   --现有储量
      ssqsl_sl2=lvssqsl_sl2,   --申请数量
      sbzcl_sl2=lvsbzcl_sl2,   --包装材料及方式
      swpmc_sl3=lvswpmc_sl3,   --物品名称
      skrl_sl3=lvskrl_sl3,   --库  容 量
      sxycl_sl3=lvsxycl_sl3,   --现有储量
      ssqsl_sl3=lvssqsl_sl3,   --申请数量
      sbzcl_sl3=lvsbzcl_sl3,   --包装材料及方式
      swpmc_qt1=lvswpmc_qt1,   --物品名称
      skrl_qt1=lvskrl_qt1,   --库  容 量
      sxycl_qt1=lvsxycl_qt1,   --现有储量
      ssqsl_qt1=lvssqsl_qt1,   --申请数量
      sbzcl_qt1=lvsbzcl_qt1,   --包装材料及方式
      sgh_unit=lvsgh_unit,   --供货单位名称
      sgh_address=lvsgh_address,   --地　　址
      sgh_xkz=lvsgh_xkz,   --许可证号
      sgh_yhzh=lvsgh_yhzh,   --银行账户
      sgh_lxr=lvsgh_lxr,   --联  系 人
      sgh_tel=lvsgh_tel,   --联系号码
      scy_unit=lvscy_unit,   --承运单位名称
      scy_zzzh=lvscy_zzzh,   --资质证号
      scy_start_time=lvscy_start_time,   --运输开始时间
      scy_end_time=lvscy_end_time,   --运输结束时间
      scy_tel=lvscy_tel,   --联系号码
      scy_lx1=lvscy_lx1,   --运输路线 1
      scy_lx2=lvscy_lx2,   --运输路线 2
      scy_lx3=lvscy_lx3,   --运输路线 3
      scy_lx4=lvscy_lx4,   --运输路线 4
      scy_lx5=lvscy_lx5,   --运输路线 5
      scy_lx6=lvscy_lx6,   --运输路线 6
      scy_lx7=lvscy_lx7,   --运输路线 7
      scy_lx8=lvscy_lx8,   --运输路线 8
      scy_lx9=lvscy_lx9,   --运输路线 9
      scy_lx10=lvscy_lx10,   --运输路线 10
      scy_lx11=lvscy_lx11,   --运输路线 11
      scy_lx12=lvscy_lx12,   --运输路线 12
      ssub_time=sysdate,   --提交时间
      ssh_time=lvssh_time,   --审核通过时间
      ssh_person=lvssh_person,   --审  核 人
      ssh_unit=lvssh_unit,    --审核人单位
      sol2=lvsol2
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
IF lv_procMode='PMDELETE' THEN    /*删除*/
    DElETE FROM tc_webjj.t_mbwp_sq
    Where 1=1
    and sdono=lvsdono   --业务编号
    ;
END IF;
 Commit;
END; /*存储过程结束*/

