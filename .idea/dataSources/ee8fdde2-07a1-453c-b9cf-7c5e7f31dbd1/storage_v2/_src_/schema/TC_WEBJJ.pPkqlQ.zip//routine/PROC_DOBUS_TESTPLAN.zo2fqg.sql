create procedure          proc_dobus_testplan(
       lvsdono varchar2,
       lvsoperationno varchar2,
       lvstype varchar2,
       lvsplanno   varchar2
) is
lvslogno varchar2(16);
lvsoperationname varchar2(30);
lvsusertype varchar2(1);
lvsresult varchar2(500);
lvnotesno varchar2(16);
lvnotemsg varchar2(2000);
lvsapptel varchar2(20);
lvsappname varchar2(20);
lvsorgid varchar2(12);
lvsorgname varchar2(200);
begin
    select sapptel,sappname,sdounit,sdounitno into lvsapptel,lvsappname,lvsorgname,lvsorgid from tc_webjj.t_dobus where sdono=lvsdono;
    if lvstype = '0' then
       lvsresult := '考试计划获取失败，考试预约被退回，请稍后再申请。';
       lvnotemsg := '您的驾驶证考试预约，考试计划获取失败，考试预约被退回。详情请登录长沙市网上公安局查看。';
    elsif lvstype = '1' then
       lvsresult := '成功获取考试计划，请选择你要预约的场次。';
       lvnotemsg := '您的驾驶证考试预约，学员信息核查成功，正在为您获取预约场次。详情请登录长沙市网上公安局查看。';
    elsif lvstype = '-1' then
       lvsresult := '考试计划获取异常，考试预约被退回,请稍后再申请。';
       lvnotemsg := '您的驾驶证考试预约，考试计划获取异常，预约被退回。详情请登录长沙市网上公安局查看。';
    end if;
    update tc_webjj.t_dobus a set a.scontext=lvsresult where sdono = lvsdono;
    update tc_webjj.t_jj_test_one b set b.stype = lvstype,b.dbbj='0' where sdono = lvsdono;
    --日志
    select a.sname,a.stype into lvsoperationname,lvsusertype from tc_webjj.t_operation_deploy a where a.sno=lvsoperationno;
    proc_dobus_log_info(
      lvslogno,
      lvsplanno,
      lvsoperationno,
      lvsoperationname,
      lvsdono,
      lvsusertype,
      '',
      '自主预约',
      lvsorgid,
      lvsorgname,
      lvsresult
    );
    proc_dobus_nextflow(lvsdono);
    --发送短信
    PROC_t_notetask(
      lvnotesno,
      lvnotemsg,
      sysdate,
      lvsapptel,
      '0',
      '1',
      '0',
      null,
      'PMINSERT'
    );
    commit;
end proc_dobus_testplan;

/

